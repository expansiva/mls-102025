/// <mls shortName="collabMessagesFilter" project="102025" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, classMap } from 'lit';
import { customElement, state, property } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { collab_magnifying_glass } from '/_102025_/l2/collabMessagesIcons.js';
let CollabMessagesFilter = class CollabMessagesFilter extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-filter-102025 .container{display:flex;align-items:center;background:var(--bg-secondary-color-lighter);border-radius:2rem;padding:.25rem .5rem;box-shadow:0 1px 3px rgba(0,0,0,0.08);transition:all var(--transition-normal) ease;width:2.5rem;overflow:hidden;cursor:pointer}collab-messages-filter-102025 .container.expanded{width:100%;cursor:text;background:var(--bg-primary-color)}collab-messages-filter-102025 .icon{border:none;background:transparent;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:var(--font-size-16);color:var(--text-primary-color-lighter);transition:color var(--transition-normal) ease}collab-messages-filter-102025 .icon>span{margin:0;display:flex}collab-messages-filter-102025 .icon:hover{color:var(--text-primary-color)}collab-messages-filter-102025 .icon:focus{outline:none;color:var(--text-primary-color-focus)}collab-messages-filter-102025 .container.expanded input{opacity:1}collab-messages-filter-102025 input{flex:1;border:none;outline:none;font-family:var(--font-family-primary);font-size:var(--font-size-16);background:transparent;color:var(--text-primary-color);margin-left:var(--space-8);width:100%;opacity:0;transition:opacity var(--transition-normal) ease}collab-messages-filter-102025 input::placeholder{color:var(--text-primary-color-lighter)}`);
        this.expanded = false;
        this.query = '';
        this.placeholder = '';
    }
    toggleExpand(e) {
        if (e.target.closest('input'))
            return;
        if (this.expanded) {
            this.expanded = false;
            this.query = '';
        }
        else {
            this.expanded = true;
            setTimeout(() => {
                const input = this.querySelector('input');
                input?.focus();
            }, 100);
        }
    }
    handleKey(e) {
        if (e.key === 'Escape') {
            this.expanded = false;
            this.query = '';
        }
    }
    handleInput(e) {
        const target = e.target;
        this.query = target.value;
        this.dispatchEvent(new CustomEvent('search-change', {
            detail: this.query,
            bubbles: true,
            composed: true
        }));
    }
    render() {
        return html `
			<div @click=${this.toggleExpand} class=${classMap({ container: true, expanded: this.expanded })}>
				<button
					class="icon"
					
					title=${this.expanded ? 'Fechar pesquisa' : 'Buscar'}
				>
					<span>${collab_magnifying_glass}</span>
				</button>

				<input
					type="text"
					placeholder=${this.placeholder}
					.value=${this.query}
					@input=${this.handleInput}
	                @keydown=${this.handleKey}
				/>
			</div>
		`;
    }
};
__decorate([
    state()
], CollabMessagesFilter.prototype, "expanded", void 0);
__decorate([
    state()
], CollabMessagesFilter.prototype, "query", void 0);
__decorate([
    property()
], CollabMessagesFilter.prototype, "placeholder", void 0);
CollabMessagesFilter = __decorate([
    customElement('collab-messages-filter-102025')
], CollabMessagesFilter);
export { CollabMessagesFilter };
