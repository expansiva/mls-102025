/// <mls shortName="collabMessagesTaskLogPreview" project="102025" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/stateLitElement.js';
import { getRootAgent } from '/_100554_/aiAgentHelper.js';
import { loadAgent } from '/_100554_/aiAgentOrchestration.js';
let CollabMessagesTaskLogPreview = class CollabMessagesTaskLogPreview extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-task-log-preview-102025{display:block}`);
        this.task = undefined;
        this.onTaskChange = async (e) => {
            if (!this.task)
                return;
            const customEvent = e;
            const context = customEvent.detail.context;
            const message = context.message;
            const _task = context.task;
            if (this.task.PK !== _task.PK)
                return;
            this.task = _task;
            this.createFeedBack();
        };
    }
    async firstUpdated(changedProperties) {
        window.addEventListener('task-change', this.onTaskChange);
        //this.task = await getTask('20250917143000.1001');
        this.createFeedBack();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        window.removeEventListener('task-change', this.onTaskChange);
    }
    render() {
        return html `
    <div>${this.template}</div>`;
    }
    async createFeedBack() {
        if (!this.task)
            return;
        const firstAgent = getRootAgent(this.task);
        if (!firstAgent)
            return;
        const agentName = firstAgent.agentName;
        const info = mls.l2.getPath(`_${mls.actualProject}_${agentName} `);
        const agent = await loadAgent(info.shortName, info.folder);
        if (!agent || !agent.getFeedBack)
            return;
        const html = await agent.getFeedBack(this.task);
        this.template = html;
    }
};
__decorate([
    property()
], CollabMessagesTaskLogPreview.prototype, "task", void 0);
__decorate([
    state()
], CollabMessagesTaskLogPreview.prototype, "template", void 0);
CollabMessagesTaskLogPreview = __decorate([
    customElement('collab-messages-task-log-preview-102025')
], CollabMessagesTaskLogPreview);
export { CollabMessagesTaskLogPreview };
