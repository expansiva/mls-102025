/// <mls shortName="collabMessagesHelper" project="102025" enhancement="_blank" />
import { getTemporaryContext, notifyMessageSendChange, notifyThreadChange, notifyThreadCreate, getAgentInstanceByName } from '/_100554_/l2/aiAgentHelper.js';
import { addThread, listThreads, updateThread } from '/_102025_/l2/collabMessagesIndexedDB.js';
const LS_KEY_OLD = 'collabChatPreferences';
const LOCAL_STORAGE_KEY = 'serviceCollabMessages';
export const AGENTDEFAULT = 'agentPlanner1';
export const defaultThreadImage = "https://images.unsplash.com/photo-1577563908411-5077b6dc7624?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D";
export async function registerToken() {
    const token = await mls.events.getFCMTokenForBackend();
    if (token === null) {
        saveNotificationPreferences('denied');
        return token;
    }
    const lastToken = loadNotificationToken();
    if (lastToken === token)
        return token;
    saveNotificationToken(token);
    try {
        const deviceId = crypto.randomUUID();
        saveNotificationDeviceId(deviceId);
        const userResponse = await mls.api.msgGetUserUpdate({ userId: "" });
        await mls.api.msgUpdateUserDetails({
            userId: userResponse.user.userId,
            avatar_url: userResponse.user.avatar_url,
            name: userResponse.user.name,
            status: userResponse.user.status,
            deviceId,
            notificationToken: token
        });
        saveNotificationPreferences('granted');
        return token;
    }
    catch (err) {
        throw new Error('Error on register token' + err.message);
    }
}
export async function addMessage(threadId, messageContent, contextToBot) {
    const userId = getUserId() || '';
    if (!userId)
        throw new Error('Invalid user id');
    const context = getTemporaryContext(threadId, userId, messageContent);
    if (!messageContent.startsWith('@@')) {
        const params = {
            action: 'addMessage',
            content: messageContent,
            threadId: threadId,
            userId: userId,
            contextToBot: contextToBot
        };
        const res = await mls.api.msgAddMessage(params);
        notifyMessageSendChange({ message: res.message, task: undefined });
        return;
    }
    const agentName = extractAgentName(messageContent) || AGENTDEFAULT;
    const moduleAgent = await getAgentInstanceByName(agentName);
    if (!moduleAgent)
        throw new Error('Invalid Agent');
    await moduleAgent.beforePrompt(context);
    return context;
}
export async function getArgsToBots() {
    const data = {
        project: mls.actualProject
    };
    return data;
}
export async function getBotsContext(thread, prompt, context) {
    const argsToBot = await getArgsToBots();
    const botsVarsBefore = mls.bots.getBotContextVarsBeforeMessageSend(thread, prompt);
    const botsVarsBefore2 = mls.bots.getBotContextVarsBeforeMessageSend2(botsVarsBefore, argsToBot);
    const auxContextToBot = [];
    for await (let bot of botsVarsBefore2) {
        try {
            const moduleBot = await getAgentInstanceByName(bot.toolName);
            if (moduleBot && moduleBot.beforeBot && typeof moduleBot.beforeBot === 'function') {
                const argsBot = await moduleBot.beforeBot(context, prompt, botsVarsBefore2);
                auxContextToBot.push(argsBot);
            }
        }
        catch (err) {
            console.error(err.message);
            continue;
        }
    }
    const merged = auxContextToBot.reduce((acc, curr) => {
        return { ...acc, ...curr };
    }, {});
    return merged;
}
export function saveNotificationDeviceId(deviceId) {
    let dataLocal = loadLocalStorage();
    if (!dataLocal)
        dataLocal = { deviceId };
    else
        dataLocal.deviceId = deviceId;
    saveLocalStorage(dataLocal);
}
export function loadNotificationDeviceId() {
    const lsData = loadLocalStorage();
    if (lsData && lsData.deviceId)
        return lsData.deviceId;
    return null;
}
export function saveNotificationToken(tokenFCM) {
    let dataLocal = loadLocalStorage();
    if (!dataLocal)
        dataLocal = { tokenFCM };
    else
        dataLocal.tokenFCM = tokenFCM;
    saveLocalStorage(dataLocal);
}
export function loadNotificationToken() {
    const lsData = loadLocalStorage();
    if (lsData && lsData.tokenFCM)
        return lsData.tokenFCM;
    return null;
}
export function saveNotificationPreferences(notificationPreference) {
    let dataLocal = loadLocalStorage();
    if (!dataLocal)
        dataLocal = { notificationPreference };
    else
        dataLocal.notificationPreference = notificationPreference;
    saveLocalStorage(dataLocal);
}
export function loadNotificationPreferences() {
    const lsData = loadLocalStorage();
    if (lsData && lsData.notificationPreference)
        return lsData.notificationPreference;
    return null;
}
export function saveNotificationPreferencesAudio(enable) {
    let dataLocal = loadLocalStorage();
    if (!dataLocal)
        dataLocal = { notificationAudio: enable };
    else
        dataLocal.notificationAudio = enable;
    saveLocalStorage(dataLocal);
}
export function loadNotificationPreferencesAudio() {
    const lsData = loadLocalStorage();
    if (lsData && lsData.notificationAudio)
        return lsData.notificationAudio;
    return true;
}
export function saveLastAlertTime(time) {
    let dataLocal = loadLocalStorage();
    if (!dataLocal)
        dataLocal = { lastNotificationAlertTime: time };
    else
        dataLocal.lastNotificationAlertTime = time;
    saveLocalStorage(dataLocal);
}
export function loadLastAlertTime() {
    const lsData = loadLocalStorage();
    if (lsData && lsData.lastNotificationAlertTime)
        return lsData.lastNotificationAlertTime;
    return undefined;
}
export function saveLastTab(lastTab) {
    let dataLocal = loadLocalStorage();
    if (!dataLocal)
        dataLocal = { lastTab };
    else
        dataLocal.lastTab = lastTab;
    saveLocalStorage(dataLocal);
}
export function loadLastTab() {
    const lsData = loadLocalStorage();
    if (lsData && lsData.lastTab)
        return lsData.lastTab;
    return 'CRM';
}
export function saveUserId(userId) {
    let dataLocal = loadLocalStorage();
    if (!dataLocal)
        dataLocal = { userId };
    else
        dataLocal.userId = userId;
    saveLocalStorage(dataLocal);
}
export function getUserId() {
    const savedOld = localStorage.getItem('collabMessages_userId');
    if (savedOld) {
        saveUserId(savedOld);
        localStorage.removeItem('collabMessages_userId');
    }
    const lsData = loadLocalStorage();
    if (lsData && lsData.userId)
        return lsData.userId;
    return null;
}
export function loadChatPreferences() {
    const savedOld = localStorage.getItem(LS_KEY_OLD);
    if (savedOld) {
        try {
            const data = JSON.parse(savedOld);
            saveChatPreferences(data);
            localStorage.removeItem(LS_KEY_OLD);
        }
        catch (e) {
            localStorage.removeItem(LS_KEY_OLD);
            console.warn('Invalid preferences in localStorage');
        }
    }
    const lsData = loadLocalStorage();
    if (lsData && lsData.chatPreferences)
        return lsData.chatPreferences;
    return loadDefaultPreferences();
}
export function saveChatPreferences(chatPreferences) {
    let dataLocal = loadLocalStorage();
    if (!dataLocal) {
        dataLocal = { chatPreferences };
    }
    else {
        dataLocal.chatPreferences = chatPreferences;
    }
    saveLocalStorage(dataLocal);
}
function saveLocalStorage(data) {
    try {
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(data));
    }
    catch (e) {
        console.error('Erro ao salvar no localStorage:', e);
    }
}
function loadLocalStorage() {
    let dataLocal;
    try {
        const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
        if (stored)
            dataLocal = JSON.parse(stored);
        return dataLocal;
    }
    catch (e) {
        console.error('Erro ao carregar do localStorage:', e);
    }
}
function loadDefaultPreferences() {
    return {
        language: document.documentElement?.lang?.split('-')?.shift() || 'en',
        translationMode: 'icon',
        threadMaintenance: ''
    };
}
function extractAgentName(str) {
    const match = str.match(/^@@([a-zA-Z]+)/);
    if (!match)
        return undefined;
    const name = match[1];
    if (name.toLowerCase().startsWith('agent')) {
        return name;
    }
    return 'agent' + name[0].toUpperCase() + name.slice(1);
}
export async function checkThreadAlreadyExist(threadName) {
    const userId = getUserId();
    if (!userId)
        throw new Error('No find user id');
}
export async function getDmThreadByUsers(userId1, userId2) {
    const allThreads = await listThreads();
    return allThreads.find(thread => {
        if (!thread.name.startsWith('@'))
            return false;
        if (thread.users.length !== 2)
            return false;
        const userIds = thread.users.map(u => u.userId);
        return userIds.includes(userId1) && userIds.includes(userId2);
    });
}
export async function createThread(threadName, languages, visibility, avatar_url = '') {
    const userId = getUserId();
    if (!userId)
        throw new Error('No find user id');
    const params = {
        action: 'addThread',
        name: threadName,
        group: 'CONNECT',
        languages,
        userId,
        visibility,
        status: 'active',
        avatar_url
    };
    try {
        const response = await mls.api.msgAddThread(params);
        if (response.thread) {
            const thr = await addThread(response.thread);
            notifyThreadCreate(thr);
            return response.thread;
        }
    }
    catch (err) {
        console.error(err);
        throw new Error(err.message);
    }
}
export async function createThreadDM(threadName, dmUser, group) {
    const userId = getUserId();
    if (!userId)
        throw new Error('No find user id');
    const alreadyExistThread = await getDmThreadByUsers(userId, dmUser);
    if (alreadyExistThread)
        throw new Error('A direct message thread with this user already exists.');
    const params = {
        action: 'addThread',
        name: threadName,
        group,
        languages: [],
        userId,
        visibility: 'private',
        status: 'active',
        avatar_url: ''
    };
    try {
        const response = await mls.api.msgAddThread(params);
        if (response.thread) {
            const thr = await addThread(response.thread);
            notifyThreadCreate(thr);
            const responseAddUsuer = await mls.api.msgAddUserInThread({
                auth: 'admin',
                userIdOrName: dmUser,
                threadId: thr.threadId,
                userId: userId,
            });
            if (responseAddUsuer.thread) {
                await updateThread(response.thread.threadId, response.thread);
                notifyThreadChange(responseAddUsuer.thread);
                return responseAddUsuer.thread;
            }
            return response.thread;
        }
    }
    catch (err) {
        console.error(err);
        throw new Error(err.message);
    }
}
