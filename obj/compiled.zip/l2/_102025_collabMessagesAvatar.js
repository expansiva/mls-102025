/// <mls shortName="collabMessagesAvatar" project="102025" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/stateLitElement.js';
import { collab_user } from '/_102025_/collabMessagesIcons.js';
let CollabMessagesAvatar = class CollabMessagesAvatar extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-avatar-102025{display:block;position:relative}collab-messages-avatar-102025 .avatar{position:absolute;display:flex;flex-direction:column;gap:.4rem;align-items:center}collab-messages-avatar-102025 .avatar img{width:var(--avatar-width, 30px);height:var(--avatar-height, 30px);border-radius:50%;object-fit:cover}collab-messages-avatar-102025 .avatar svg{width:var(--avatar-width, 30px);height:var(--avatar-height, 30px);border-radius:50%}collab-messages-avatar-102025 .avatar .avatar-placeholder{width:var(--avatar-width, 30px);height:var(--avatar-height, 30px);border-radius:50%;background-color:#ccc;display:flex;align-items:center;justify-content:center;font-size:40px;color:white;cursor:pointer}collab-messages-avatar-102025 .avatar .avatar-placeholder svg{width:12px;height:12px}`);
        this.avatar = '';
        this.width = '30px';
        this.height = '30px';
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('width') || changedProperties.has('height')) {
            this.style.setProperty('--avatar-width', this.width);
            this.style.setProperty('--avatar-height', this.height);
        }
    }
    render() {
        const isSvg = this.avatar.trim().startsWith('<svg');
        return html `
        <div class="avatar">
            ${this.avatar
            ? isSvg ? html `${unsafeHTML(this.avatar)}` : html `<img src="${this.avatar}" alt="Avatar" />`
            : html `<div class="avatar-placeholder">${collab_user}</div>`}
        </div>`;
    }
};
__decorate([
    property()
], CollabMessagesAvatar.prototype, "avatar", void 0);
__decorate([
    property({ type: String })
], CollabMessagesAvatar.prototype, "width", void 0);
__decorate([
    property({ type: String })
], CollabMessagesAvatar.prototype, "height", void 0);
CollabMessagesAvatar = __decorate([
    customElement('collab-messages-avatar-102025')
], CollabMessagesAvatar);
export { CollabMessagesAvatar };
