/// <mls fileReference="_102025_/l2/collabMessagesTaskInfo.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102027_/l2/stateLitElement.js';
import { getClarificationElement, continuePoolingTask } from '/_102027_/l2/aiAgentOrchestration.js';
import { getNextPendentStep, getNextClarificationStep, getInteractionStepId, getStepById } from '/_102027_/l2/aiAgentHelper.js';
import '/_102025_/l2/collabMessagesTaskDetails.js';
import '/_102025_/l2/collabMessagesTaskPreview.js';
import '/_102025_/l2/collabMessagesTaskLogPreview.js';
import '/_102025_/l2/collabMessagesTaskRoom.js';
let CollabMessagesTaskInfo = class CollabMessagesTaskInfo extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-task-info-102025 {
  display: flex;
  flex-direction: column;
  overflow: auto;
  font-family: var(--font-family-primary);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-primary-color);
  background-color: var(--bg-primary-color);
  height: 100%;
  min-height: 0;
  box-sizing: border-box;
  padding: 0 0.5rem;
  position: relative;
}
collab-messages-task-info-102025 .viewraw {
  border: none;
  margin-top: 2px;
  background: var(--bg-primary-color);
  color: var(--text-primary-color);
  cursor: pointer;
  position: absolute;
  right: 5px;
  top: 5px;
}
collab-messages-task-info-102025 .direct-clarification {
  height: 100%;
}
collab-messages-task-info-102025 .tabs {
  display: flex;
  border-bottom: 1px solid var(--grey-color);
  margin-bottom: 0;
  flex-shrink: 0;
}
collab-messages-task-info-102025 .tab {
  padding: 0.5rem 1rem;
  cursor: pointer;
  border-bottom: 2px solid transparent;
  transition: border-color 0.3s, color 0.3s;
  font-size: 0.9rem;
  color: var(--text-primary-color-disabled);
}
collab-messages-task-info-102025 .tab:hover {
  color: var(--text-primary-color-darker);
}
collab-messages-task-info-102025 .tab.active {
  border-bottom: 2px solid var(--link-color);
  font-weight: 600;
  color: var(--text-primary-color-lighter-focus);
}
collab-messages-task-info-102025 .tab-shell {
  display: flex;
  flex-direction: column;
  flex: 1;
  height: 100%;
  min-height: 0;
}
collab-messages-task-info-102025 .content {
  flex: 1;
  min-height: 0;
  padding: 0.5rem 0;
  overflow: auto;
}
collab-messages-task-info-102025 .content.chat,
collab-messages-task-info-102025 .content.step {
  display: flex;
  flex-direction: column;
  padding: 0;
  overflow: hidden;
}
`);
        this.forceViewRaw = false;
        this.hasTodo = true;
        this.currentStepId = 0;
        this.task = undefined;
        this.message = undefined;
        this.restartPooling = false;
        this.isTest = false;
        this.stepid = '';
        this.seen = new Set();
        this.activeTab = 'todo';
        this.isClarificationPending = false;
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        if (this.elParent)
            this.elParent.style.width = '';
        this.restoreServiceDetailContainer();
        window.removeEventListener('task-change', this.onTaskChange.bind(this));
    }
    async updated(changedProperties) {
        if ((changedProperties.has('task') || changedProperties.has('message')) && this.hasPendingClarification() && !this.forceViewRaw) {
            this.setClarification();
        }
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        this.normalizeServiceDetailContainer();
        window.addEventListener('task-change', this.onTaskChange.bind(this));
        if (this.interactionClarification) {
            this.setClarification();
        }
        if (this.restartPooling && this.message && this.task) {
            const context = {
                task: this.task,
                message: this.message,
                isTest: this.isTest || false
            };
            continuePoolingTask(context);
        }
    }
    render() {
        if (!this.task)
            return html `No task.`;
        const isClarificationPending = this.hasPendingClarification();
        if (isClarificationPending && !this.forceViewRaw)
            return this.renderDirectClarification();
        return this.renderTab(isClarificationPending);
    }
    renderTab(isClarificationPending = this.hasPendingClarification()) {
        let aux = '';
        const hasTaskRoom = this.canUseTaskRoom();
        const activeTab = hasTaskRoom || this.activeTab !== 'chat' ? this.activeTab : 'todo';
        if (this.hasTodo) {
            aux = html `
            <div class="tab ${activeTab === 'todo' ? 'active' : ''}" @click=${() => this.setTab('todo')} >Todo</div>`;
        }
        return html `
            ${isClarificationPending ? html `<button class="viewraw" @click=${() => this.clickForceViewRaw(false)}>Clarification</button>` : ''}
            <div class="tab-shell">
                <div class="tabs">
                    ${aux}
                    <div
                        class="tab ${activeTab === 'step' ? 'active' : ''}"
                        @click=${() => this.setTab('step')}
                    >Steps</div>
                    ${hasTaskRoom ? html `
                        <div
                            class="tab ${activeTab === 'chat' ? 'active' : ''}"
                            @click=${() => this.setTab('chat')}
                        >Chat</div>
                    ` : ''}
                    <div
                        style="display:none"
                        class="tab ${activeTab === 'raw' ? 'active' : ''}"
                        @click=${() => this.setTab('raw')}
                    >Raw</div>
                    <div
                        style="display:none"
                        class="tab ${activeTab === 'workflow' ? 'active' : ''}"
                        @click=${() => this.setTab('workflow')}
                    >Workflow</div>

                </div>
                <div class="content ${activeTab}">
                    ${this.renderTabContent(activeTab)}
                </div>
            </div>
        `;
    }
    renderTabContent(activeTab) {
        switch (activeTab) {
            case 'workflow': return html `workflow`;
            case 'step': return this.renderStep();
            case 'chat': return this.renderChat();
            case 'raw': return this.renderRaw();
            case 'todo': return this.renderTodo();
            default: return html `workflow`;
        }
    }
    renderRaw() {
        return html `<collab-messages-task-details-102025 .task=${this.task} .message=${this.message} taskId=${this.task?.PK}></collab-messages-task-details-102025>`;
    }
    renderStep() {
        return html `<collab-messages-task-preview-102025 .message=${this.message} .task=${this.task} .father="${this}" .currentStepId=${this.currentStepId}></collab-messages-task-preview-102025>`;
    }
    renderTodo() {
        return html `<collab-messages-task-log-preview-102025 .message=${this.message} .task=${this.task} .father="${this}"></collab-messages-task-log-preview-102025>`;
    }
    renderChat() {
        return html `<collab-messages-task-room-102025 .message=${this.message} .task=${this.task}></collab-messages-task-room-102025>`;
    }
    renderDirectClarification() {
        if (!this.task)
            throw new Error('Invalid task');
        const payload = getNextClarificationStep(this.task);
        if (!payload)
            return html ``;
        return html `
        <button class="viewraw" @click=${() => this.clickForceViewRaw(true)}>View raw</button>
        <div class="direct-clarification">${this.renderClarification(payload)}
        </div>`;
    }
    hasPendingClarification() {
        if (!this.task)
            return false;
        const nextStepPending = getNextPendentStep(this.task);
        if (nextStepPending?.type === 'clarification')
            return true;
        return !!getNextClarificationStep(this.task);
    }
    renderClarification(payload) {
        if (!this.task)
            return html `Invalid task`;
        const parentInteraction = getInteractionStepId(this.task, payload.stepId);
        if (!parentInteraction)
            return html `No found parentInteraction ${payload.stepId} on task: ${this.task.PK} `;
        const interaction = getStepById(this.task, parentInteraction);
        this.interactionClarification = interaction;
        if (!interaction)
            return html `Invalid interaction id:${parentInteraction} on task: ${this.task.PK} `;
        if (!interaction.agentName)
            return html `Invalid agent name for step id:${interaction.stepId} on task: ${this.task.PK} `;
        return html `<div class="content"> Processing...</div>`;
    }
    //---------IMPLEMENTATION -----------
    clickForceViewRaw(force) {
        this.forceViewRaw = force;
        this.requestUpdate();
        if (!force)
            setTimeout(() => this.setClarification(), 300);
    }
    async setClarification() {
        if (!this.directClarificationContent || !this.task || !this.message)
            return;
        let clarification = null;
        try {
            clarification = await getClarificationElement({ message: this.message, task: this.task, isTest: false });
        }
        catch (error) {
            if (mls.isTraceAgent)
                console.error('[collabMessagesTaskInfo](setClarification)', error);
            return;
        }
        if (!clarification)
            return;
        this.directClarificationContent.innerHTML = '';
        this.directClarificationContent.appendChild(clarification);
        this.executeHTMLClarificationScript();
    }
    executeHTMLClarificationScript() {
        this.directClarification?.querySelectorAll('script').forEach(oldScript => {
            const newScript = document.createElement('script');
            newScript.type = oldScript.type || 'text/javascript';
            if (!newScript.type) {
                newScript.type = 'text/javascript';
            }
            if (oldScript.hasAttribute('type') && oldScript.getAttribute('type') === 'module') {
                newScript.type = 'module';
            }
            if (oldScript.src) {
                newScript.src = oldScript.src;
            }
            else {
                newScript.textContent = oldScript.textContent;
            }
            oldScript.replaceWith(newScript);
        });
    }
    setTab(tab) {
        if (tab === 'chat' && !this.canUseTaskRoom())
            return;
        this.activeTab = tab;
    }
    canUseTaskRoom() {
        if (!this.task)
            return false;
        if (this.task.taskRoom?.threadId || this.task.taskRoom?.workflowType)
            return true;
        const firstStep = this.task.iaCompressed?.nextSteps?.[0];
        return firstStep?.type === 'staticWorkflow' || firstStep?.type === 'dynamicWorkflow';
    }
    onTaskChange(e) {
        if (!this.task)
            return;
        const customEvent = e;
        const task = customEvent.detail.context.task;
        if (task.PK !== this.task.PK)
            return;
        this.task = task;
    }
    normalizeServiceDetailContainer() {
        const serviceDetail = this.closest('service-detail-100554');
        const contentPlugin = this.closest('#contentPlugin');
        if (!serviceDetail || !contentPlugin || this.contentPluginStyle)
            return;
        this.contentPluginStyle = {
            element: contentPlugin,
            overflow: contentPlugin.style.overflow,
            height: contentPlugin.style.height,
            padding: contentPlugin.style.padding,
        };
        contentPlugin.style.overflow = 'hidden';
        contentPlugin.style.height = '100%';
        contentPlugin.style.padding = '0';
        const wrapper = this.parentElement;
        if (wrapper) {
            wrapper.style.height = '100%';
            wrapper.style.minHeight = '0';
            wrapper.style.display = 'flex';
            wrapper.style.flexDirection = 'column';
        }
    }
    restoreServiceDetailContainer() {
        if (!this.contentPluginStyle)
            return;
        const { element, overflow, height, padding } = this.contentPluginStyle;
        element.style.overflow = overflow;
        element.style.height = height;
        element.style.padding = padding;
        this.contentPluginStyle = undefined;
    }
};
__decorate([
    property()
], CollabMessagesTaskInfo.prototype, "task", void 0);
__decorate([
    property()
], CollabMessagesTaskInfo.prototype, "message", void 0);
__decorate([
    property()
], CollabMessagesTaskInfo.prototype, "restartPooling", void 0);
__decorate([
    property()
], CollabMessagesTaskInfo.prototype, "isTest", void 0);
__decorate([
    property()
], CollabMessagesTaskInfo.prototype, "stepid", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesTaskInfo.prototype, "seen", void 0);
__decorate([
    property()
], CollabMessagesTaskInfo.prototype, "interactionClarification", void 0);
__decorate([
    query('.direct-clarification')
], CollabMessagesTaskInfo.prototype, "directClarification", void 0);
__decorate([
    query('.direct-clarification .content')
], CollabMessagesTaskInfo.prototype, "directClarificationContent", void 0);
__decorate([
    state()
], CollabMessagesTaskInfo.prototype, "activeTab", void 0);
__decorate([
    state()
], CollabMessagesTaskInfo.prototype, "isClarificationPending", void 0);
CollabMessagesTaskInfo = __decorate([
    customElement('collab-messages-task-info-102025')
], CollabMessagesTaskInfo);
export { CollabMessagesTaskInfo };
