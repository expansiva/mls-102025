function childrenOf(step) {
    return [...(step.nextSteps || []), ...(step.interaction?.payload || [])];
}
export function isTransparentCompletedStep(step) {
    return step.status === 'completed'
        && (step.type === 'flexible' || step.type === 'result' || step.type === 'clarification');
}
/** True only when a visible branch and every descendant have completed. */
export function isBranchCompleted(step) {
    return step.status === 'completed'
        && countCollapsedRows(step) > 0
        && childrenOf(step).every(child => child.status === 'completed' && descendantsCompleted(child));
}
/** Counts visible descendant rows, traversing completed transparent nodes. */
export function countCollapsedRows(step) {
    return childrenOf(step).reduce((total, child) => total + visibleRows(child), 0);
}
function descendantsCompleted(step) {
    return childrenOf(step).every(child => child.status === 'completed' && descendantsCompleted(child));
}
function visibleRows(step) {
    const descendants = countCollapsedRows(step);
    return isTransparentCompletedStep(step) ? descendants : 1 + descendants;
}
