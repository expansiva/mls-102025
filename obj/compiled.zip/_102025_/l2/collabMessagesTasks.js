/// <mls fileReference="_102025_/l2/collabMessagesTasks.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    tasks: 'Tasks',
    board: 'Board',
    myTasks: 'Minhas tasks',
    workflows: 'Workflows',
    simulator: 'Simulador',
    approvals: 'Aprovações',
    analytics: 'Analytics',
    settings: 'Configurações',
    reload: 'Recarregar',
};
const message_en = {
    tasks: 'Tasks',
    board: 'Board',
    myTasks: 'My tasks',
    workflows: 'Workflows',
    simulator: 'Simulator',
    approvals: 'Approvals',
    analytics: 'Analytics',
    settings: 'Settings',
    reload: 'Reload',
};
/// **collab_i18n_end**
import { html, css, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { getUserId } from '/_102025_/l2/collabMessagesHelper.js';
import '/_102025_/l2/collabTasksSidebar.js';
import '/_102025_/l2/collabTasksTopbar.js';
import '/_102025_/l2/collabTasksBoard.js';
import '/_102025_/l2/collabTasksMyTasks.js';
import '/_102025_/l2/collabTasksEmptyState.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
let CollabMessagesTasks = class CollabMessagesTasks extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-tasks-102025 .task-details {
  padding: 1rem;
  display: flex;
  flex-direction: column;
  gap: 1rem;
}
collab-messages-tasks-102025 .back-btn {
  background: none;
  border: none;
  color: var(--grey-color-darker);
  cursor: pointer;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 0.25rem;
}
collab-messages-tasks-102025 .back-btn:hover {
  text-decoration: underline;
}
collab-messages-tasks-102025 .task-list-container {
  display: flex;
  flex-direction: column;
  gap: 2rem;
  padding: 1rem;
}
collab-messages-tasks-102025 .task-stage {
  display: flex;
  flex-direction: column;
}
collab-messages-tasks-102025 .task-stage-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  font-size: var(--font-size-12);
  font-weight: bold;
  padding: 0.5rem 0;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
}
collab-messages-tasks-102025 .stage-name {
  text-transform: uppercase;
}
collab-messages-tasks-102025 .stage-count {
  color: var(--grey-color-darker);
}
collab-messages-tasks-102025 .stage-add {
  margin-left: auto;
  font-weight: normal;
  color: var(--grey-color-darker);
  cursor: pointer;
}
collab-messages-tasks-102025 .stage-add:hover {
  text-decoration: underline;
}
collab-messages-tasks-102025 .task-items {
  list-style: none;
  margin: 0;
  padding: 0.25rem 0;
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}
collab-messages-tasks-102025 .task-row {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: var(--font-size-12);
  padding: 0.5rem 0.25rem;
  border-radius: 4px;
  cursor: pointer;
}
collab-messages-tasks-102025 .task-row:hover {
  background: rgba(255, 255, 255, 0.05);
}
collab-messages-tasks-102025 .task-title {
  flex: 1;
}
collab-messages-tasks-102025 .task-check {
  font-size: 12px;
  opacity: 0.7;
}
collab-messages-tasks-102025 .task-meta {
  font-size: 11px;
  opacity: 0.6;
}
collab-messages-tasks-102025 .task-tag {
  font-size: 10px;
  padding: 0.1rem 0.4rem;
  border-radius: 4px;
  text-transform: uppercase;
}
collab-messages-tasks-102025 .task-tag.bug {
  background: #d32f2f;
  color: white;
}
`);
        this.screen = 'board';
        this.reloadKey = 0;
    }
    render() {
        const msg = getMsg();
        const userId = getUserId() || '';
        return html `
      <collab-tasks-sidebar-102025
        .activeScreen=${this.screen}
        @screen-change=${(e) => { this.screen = e.detail; }}
      ></collab-tasks-sidebar-102025>
      <div class="dashboard-main">
        <collab-tasks-topbar-102025
          .title=${this._screenLabel(this.screen, msg)}
          @dashboard-reload=${() => { this.reloadKey++; }}
        ></collab-tasks-topbar-102025>
        <div class="dashboard-content">
          ${this._renderScreen(userId, msg)}
        </div>
      </div>
    `;
    }
    _renderScreen(userId, msg) {
        const key = this.reloadKey;
        switch (this.screen) {
            case 'board':
                return html `<collab-tasks-board-102025 .userId=${userId} .reloadKey=${key}></collab-tasks-board-102025>`;
            case 'mytasks':
                return html `<collab-tasks-my-tasks-102025 .userId=${userId} .reloadKey=${key}></collab-tasks-my-tasks-102025>`;
            case 'workflows':
                return html `<collab-tasks-empty-state-102025
          title=${msg.workflows}
          subtitle="In development — depends on Workflow definitions"
        ></collab-tasks-empty-state-102025>`;
            case 'simulator':
                return html `<collab-tasks-empty-state-102025
          title=${msg.simulator}
          subtitle="In development — depends on Workflow simulator"
        ></collab-tasks-empty-state-102025>`;
            case 'approvals':
                return html `<collab-tasks-empty-state-102025
          title=${msg.approvals}
          subtitle="In development — depends on Guardrails (Stage 5)"
        ></collab-tasks-empty-state-102025>`;
            case 'analytics':
                return html `<collab-tasks-empty-state-102025
          title=${msg.analytics}
          subtitle="In development — depends on Evaluation (Stage 6)"
        ></collab-tasks-empty-state-102025>`;
            case 'settings':
                return html `<collab-tasks-empty-state-102025
          title=${msg.settings}
          subtitle="In development"
        ></collab-tasks-empty-state-102025>`;
            default:
                return nothing;
        }
    }
    _screenLabel(screen, msg) {
        const map = {
            board: msg.board,
            mytasks: msg.myTasks,
            workflows: msg.workflows,
            simulator: msg.simulator,
            approvals: msg.approvals,
            analytics: msg.analytics,
            settings: msg.settings,
        };
        return map[screen] || screen;
    }
};
CollabMessagesTasks.styles = css `
    :host {
      display: flex;
      height: 100%;
      overflow: hidden;
      font-family: var(--font-sans, sans-serif);
      background: var(--color-background-primary, #fff);
      color: var(--color-text-primary, #111);
    }
    .dashboard-main {
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden;
      min-width: 0;
    }
    .dashboard-content {
      flex: 1;
      overflow: auto;
      padding: 0;
    }
  `;
__decorate([
    state()
], CollabMessagesTasks.prototype, "screen", void 0);
__decorate([
    state()
], CollabMessagesTasks.prototype, "reloadKey", void 0);
CollabMessagesTasks = __decorate([
    customElement('collab-messages-tasks-102025')
], CollabMessagesTasks);
export { CollabMessagesTasks };
