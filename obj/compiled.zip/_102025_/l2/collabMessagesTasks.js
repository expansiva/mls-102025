/// <mls fileReference="_102025_/l2/collabMessagesTasks.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    myTasks: 'Minhas tasks',
    workflows: 'Workflows',
    simulator: 'Simulador',
    approvals: 'Aprovações',
    analytics: 'Analytics',
    settings: 'Configurações',
    board: 'Board',
    comingSoon: 'Em desenvolvimento',
};
const message_en = {
    myTasks: 'My tasks',
    workflows: 'Workflows',
    simulator: 'Simulator',
    approvals: 'Approvals',
    analytics: 'Analytics',
    settings: 'Settings',
    board: 'Board',
    comingSoon: 'In development',
};
/// **collab_i18n_end**
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { getUserId } from '/_102025_/l2/collabMessagesHelper.js';
import { openElementInServiceDetails } from '/_102027_/l2/libCommom.js';
import '/_102025_/l2/collabTasksSidebar.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
let CollabMessagesTasks = class CollabMessagesTasks extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-tasks-102025 {
  display: flex;
  height: 100%;
  overflow: hidden;
}
collab-messages-tasks-102025 collab-tasks-sidebar-102025 {
  flex: 1;
}
`);
        this.screen = 'board';
    }
    connectedCallback() {
        super.connectedCallback();
        this._openScreen('board');
    }
    render() {
        return html `
      <collab-tasks-sidebar-102025
        .activeScreen=${this.screen}
        @screen-change=${(e) => this._onScreenChange(e.detail)}
      ></collab-tasks-sidebar-102025>
    `;
    }
    _onScreenChange(screen) {
        this.screen = screen;
        this._openScreen(screen);
    }
    async _openScreen(screen) {
        const msg = getMsg();
        const userId = getUserId() || '';
        let el;
        if (screen === 'board') {
            await import('/_102025_/l2/collabTasksBoard.js');
            const board = document.createElement('collab-tasks-board-102025');
            board.userId = userId;
            board.organizationId = 'collabcodes';
            board.reloadKey = Date.now();
            el = board;
        }
        else {
            await import('/_102025_/l2/collabTasksEmptyState.js');
            const empty = document.createElement('collab-tasks-empty-state-102025');
            const label = msg[screen] ?? screen;
            empty.setAttribute('title', label);
            empty.setAttribute('subtitle', msg.comingSoon);
            el = empty;
        }
        openElementInServiceDetails(el);
    }
};
__decorate([
    state()
], CollabMessagesTasks.prototype, "screen", void 0);
CollabMessagesTasks = __decorate([
    customElement('collab-messages-tasks-102025')
], CollabMessagesTasks);
export { CollabMessagesTasks };
