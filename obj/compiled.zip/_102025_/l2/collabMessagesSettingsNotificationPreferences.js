/// <mls fileReference="_102025_/l2/collabMessagesSettingsNotificationPreferences.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { saveNotificationPreferencesAudio, loadNotificationPreferencesAudio, loadNotificationPreferences, registerToken, saveNotificationPreferences, } from '/_102025_/l2/collabMessagesHelper.js';
import { collab_bell, } from '/_102025_/l2/collabMessagesIcons.js';
/// **collab_i18n_start**
const message_pt = {
    prefNotification: 'Preferências de notificação',
    infoNotification: 'Avisamos quando houver mudanças e novas mensagens, sem pop-ups, só sincronismo, mais velocidade para você',
    moreNotification: 'Saiba mais',
    notificationStatusEnabled: 'Notificações ativadas',
    notificationStatusFailed: 'Não foi possível ativar as notificações, verificar permissões no browser',
    btnEnableNotifications: 'Ativar notificações',
    soundEnable: 'Ativar som nas notificações',
};
const message_en = {
    prefNotification: 'Notification Preferences',
    infoNotification: 'We\'ll notify you when there are changes and new messages — no pop-ups, just seamless syncing for faster performance.',
    moreNotification: 'Learn more',
    notificationStatusEnabled: 'Notifications enabled',
    notificationStatusFailed: 'Unable to enable notifications, check browser permissions',
    btnEnableNotifications: 'Enable notifications',
    soundEnable: 'Enable sound for notifications',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesSettingsNotificationPreferences = class CollabMessagesSettingsNotificationPreferences extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-settings-notification-preferences-102025 {
  display: block;
}
collab-messages-settings-notification-preferences-102025 .section {
  padding: 1.4rem 0.75rem;
  border-radius: 10px;
  box-shadow: #e7e3e3 0px 1px 4px;
  background-color: var(--bg-primary-color-darker);
  margin-bottom: 1.5rem;
}
collab-messages-settings-notification-preferences-102025 .section h4 {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 0.75rem;
  margin-block-start: 0;
  padding-bottom: 0.4rem;
  border-bottom: 1px solid #d2d2d2;
}
collab-messages-settings-notification-preferences-102025 .section h4 svg {
  fill: currentColor;
  width: 20px;
  height: 20px;
}
collab-messages-settings-notification-preferences-102025 .section .loader {
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid #ccc;
  border-top: 2px solid #333;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
collab-messages-settings-notification-preferences-102025 .section .saving-ok {
  color: var(--success-color);
  font-size: var(--font-size-12);
  display: block;
  margin-top: 0.5rem;
}
collab-messages-settings-notification-preferences-102025 .section .saving-error {
  color: var(--error-color);
  font-size: var(--font-size-12);
  display: block;
  margin-top: 0.5rem;
}
collab-messages-settings-notification-preferences-102025 .section button {
  background-color: var(--info-color);
  box-shadow: 0px 1px 3px 0px var(--grey-color);
  flex-direction: row;
  justify-content: center;
  width: max-content;
  transition: height 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
  color: #ffffff;
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: var(--font-size-12);
  font-weight: var(--font-weight-bold);
  display: flex;
  align-items: center;
  gap: 0.25rem;
  white-space: nowrap;
  flex-shrink: 0;
}
collab-messages-settings-notification-preferences-102025 .section button svg {
  flex-shrink: 0;
  fill: currentColor;
}
collab-messages-settings-notification-preferences-102025 .section button:hover {
  background-color: var(--info-color-hover);
}
collab-messages-settings-notification-preferences-102025 .section button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}
collab-messages-settings-notification-preferences-102025 .notification-preferences .notification-status {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.75rem 1rem;
  border-radius: 6px;
  font-size: var(--font-size-12);
  margin-bottom: 1rem;
}
collab-messages-settings-notification-preferences-102025 .notification-preferences .notification-status.enabled {
  background-color: rgba(82, 196, 26, 0.1);
  color: #3f9714;
  border: 1px solid rgba(82, 196, 26, 0.25);
}
collab-messages-settings-notification-preferences-102025 .notification-preferences .notification-status.enabled .status-icon {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background-color: var(--success-color);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: bold;
}
collab-messages-settings-notification-preferences-102025 .notification-preferences .btn-enable {
  margin-bottom: 0.5rem;
}
collab-messages-settings-notification-preferences-102025 .notification-preferences details {
  margin-top: 1rem;
}
collab-messages-settings-notification-preferences-102025 .notification-preferences details summary {
  cursor: pointer;
  font-size: var(--font-size-12);
  color: var(--active-color);
}
collab-messages-settings-notification-preferences-102025 .notification-preferences details summary:hover {
  text-decoration: underline;
}
collab-messages-settings-notification-preferences-102025 .notification-preferences details .details-content {
  padding: 0.75rem 0 0 1rem;
  font-size: var(--font-size-12);
  color: var(--text-primary-color-lighter);
  line-height: 1.5;
}
collab-messages-settings-notification-preferences-102025 .notification-preferences .notification-audio-config {
  margin-top: 1rem;
  padding-top: 1rem;
  border-top: 1px solid var(--grey-color);
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
collab-messages-settings-notification-preferences-102025 .notification-preferences .notification-audio-config label {
  font-size: var(--font-size-12);
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  color: var(--text-primary-color);
}
collab-messages-settings-notification-preferences-102025 .notification-preferences .notification-audio-config input[type="checkbox"] {
  width: 16px;
  height: 16px;
  cursor: pointer;
  accent-color: var(--info-color);
}
`);
        this.msg = messages['en'];
        this.notificationPreferences = null;
        this.audioEnabled = false;
        this.isSaving = false;
        this.labelOk = '';
        this.labelError = '';
    }
    async firstUpdated() {
        this.notificationPreferences = this.getNotificationStatus();
        this.audioEnabled = loadNotificationPreferencesAudio();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        // Atualiza o status atual
        this.notificationPreferences = this.getNotificationStatus();
        return html `
        <div class="section notification-preferences">
            <h4>${collab_bell} ${this.msg.prefNotification}</h4>

            ${this.notificationPreferences === 'granted'
            ? this.renderEnabled()
            : this.renderDisabled()}

            <div class="notification-audio-config">
                <label>
                    <input 
                        type="checkbox" 
                        .checked=${this.audioEnabled} 
                        @change=${this.handleAudioToggle} 
                    />
                    ${this.msg.soundEnable}
                </label>
            </div>
        </div>
        `;
    }
    renderEnabled() {
        return html `
            <div class="notification-status enabled">
                <span class="status-icon">✓</span>
                <span>${this.msg.notificationStatusEnabled}</span>
            </div>
            ${this.renderReadMore()}
        `;
    }
    renderDisabled() {
        return html `
            <button 
                class="btn-enable" 
                @click=${this.handleEnableNotifications} 
                ?disabled=${this.isSaving}
            >
                ${this.isSaving
            ? html `<span class="loader"></span>`
            : this.msg.btnEnableNotifications}
            </button>
            
            ${this.labelOk ? html `<small class="saving-ok">${this.labelOk}</small>` : ''}
            ${this.labelError ? html `<small class="saving-error">${this.labelError}</small>` : ''}
            
            ${this.renderReadMore()}
        `;
    }
    renderReadMore() {
        return html `
            <details>
                <summary>${this.msg.moreNotification}</summary>
                <div class="details-content">
                    <span>${this.msg.infoNotification}</span>
                </div>   
            </details>
        `;
    }
    // ========== HELPERS ==========
    getNotificationStatus() {
        const notificationPreferences = loadNotificationPreferences();
        if ('Notification' in window) {
            const permission = Notification.permission;
            if (permission === this.notificationPreferences) {
                return notificationPreferences;
            }
            if (permission === 'granted' && notificationPreferences === 'denied') {
                saveNotificationPreferences('default');
                return 'default';
            }
            if (permission === 'denied' && notificationPreferences === 'granted') {
                saveNotificationPreferences('denied');
                return 'default';
            }
        }
        return notificationPreferences;
    }
    // ========== HANDLERS ==========
    handleAudioToggle(e) {
        const target = e.target;
        this.audioEnabled = target.checked;
        saveNotificationPreferencesAudio(this.audioEnabled);
        this.dispatchEvent(new CustomEvent('audio-preference-changed', {
            detail: { audioEnabled: this.audioEnabled },
            bubbles: true,
            composed: true
        }));
    }
    async handleEnableNotifications() {
        this.labelError = '';
        this.labelOk = '';
        this.isSaving = true;
        try {
            saveNotificationPreferences('default');
            const token = await registerToken();
            this.notificationPreferences = loadNotificationPreferences();
            if (token === null) {
                this.labelOk = this.msg.notificationStatusFailed;
            }
            else {
                this.labelOk = this.msg.notificationStatusEnabled;
                this.dispatchEvent(new CustomEvent('notifications-enabled', {
                    detail: { token },
                    bubbles: true,
                    composed: true
                }));
            }
        }
        catch (err) {
            console.error('Error on enable notification:', err.message);
            this.labelError = err.message;
        }
        finally {
            this.isSaving = false;
        }
    }
};
__decorate([
    state()
], CollabMessagesSettingsNotificationPreferences.prototype, "notificationPreferences", void 0);
__decorate([
    state()
], CollabMessagesSettingsNotificationPreferences.prototype, "audioEnabled", void 0);
__decorate([
    state()
], CollabMessagesSettingsNotificationPreferences.prototype, "isSaving", void 0);
__decorate([
    state()
], CollabMessagesSettingsNotificationPreferences.prototype, "labelOk", void 0);
__decorate([
    state()
], CollabMessagesSettingsNotificationPreferences.prototype, "labelError", void 0);
CollabMessagesSettingsNotificationPreferences = __decorate([
    customElement('collab-messages-settings-notification-preferences-102025')
], CollabMessagesSettingsNotificationPreferences);
export { CollabMessagesSettingsNotificationPreferences };
