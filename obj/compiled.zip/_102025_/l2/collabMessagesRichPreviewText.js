/// <mls fileReference="_102025_/l2/collabMessagesRichPreviewText.ts" enhancement="_100554_enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import '/_102025_/l2/collabMessagesTextCode.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    copy: 'Copiar',
    copied: 'Copiado',
};
const message_en = {
    loading: 'Loading...',
    copy: 'Copy',
    copied: 'Copied',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesRichPreviewText102025 = class CollabMessagesRichPreviewText102025 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-rich-preview-text-102025 .collab-md-codeblock-card{margin:1rem .3rem;font-size:var(--font-size-12)}collab-messages-rich-preview-text-102025 .collab-md-codeblock-card pre{white-space:normal}collab-messages-rich-preview-text-102025 .collab-md-codeblock-card pre code{white-space:break-spaces}collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header{display:flex;justify-content:space-between;align-items:center;background:#eaeef2;border-bottom:1px solid #d0d7de;padding:4px 8px;font-size:12px;font-weight:bold;text-transform:uppercase;color:#57606a}collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header .collab-md-inlinecode-lang,collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header .collab-md-codeblock-lang{font-size:11px;background:#d0d7de;border-radius:3px;padding:1px 4px;color:#24292f}collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header .collab-md-inlinecode-copy,collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header .collab-md-codeblock-copy{background:none;border:none;cursor:pointer;font-size:14px;color:#57606a;padding:2px 4px}collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header .collab-md-inlinecode-copy:hover,collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header .collab-md-codeblock-copy:hover{color:#1f2328}collab-messages-rich-preview-text-102025 .command--valid{color:var(--active-color);background:var(--bg-secondary-color-lighter);padding:0 var(--space-8);border-radius:var(--space-8);font-family:monospace}collab-messages-rich-preview-text-102025 .help--valid{color:var(--success-color);background:var(--bg-secondary-color-lighter);padding:0 var(--space-8);border-radius:.2em}collab-messages-rich-preview-text-102025 .channel.channel--valid{color:#1976d2;background:#e3f0fd;padding:0 var(--space-8);border-radius:var(--space-8);cursor:pointer;font-weight:600;transition:background var(--transition-normal),color var(--transition-normal)}collab-messages-rich-preview-text-102025 .channel.channel--valid:hover{background:#bbdefb;color:#0d47a1}collab-messages-rich-preview-text-102025 .mention.mention--valid{color:#1565c0;background:#e3f0fd;padding:0 var(--space-8);border-radius:.3em;cursor:pointer;font-weight:600;transition:background var(--transition-normal),color var(--transition-normal)}collab-messages-rich-preview-text-102025 .mention.mention--valid:hover{background:#bbdefb;color:#0d47a1}collab-messages-rich-preview-text-102025 .mention-agent{color:var(--active-color);background-color:transparent;padding:0 var(--space-8);border-radius:var(--space-8);font-weight:var(--font-weight-bold);cursor:pointer;transition:background var(--transition-normal)}collab-messages-rich-preview-text-102025 .mention-agent:hover{color:var(--active-color-hover)}collab-messages-rich-preview-text-102025 .channel-ref{color:#1976d2;background:#e3f0fd;padding:0 var(--space-8);border-radius:var(--space-8);cursor:pointer;font-weight:600;transition:background var(--transition-normal),color var(--transition-normal)}collab-messages-rich-preview-text-102025 .channel-ref:hover{background:#bbdefb;color:#0d47a1}`);
        this.msg = messages['en'];
        this.allHelpers = ['?help'];
        this.allCommands = ['/command1'];
        this.allThreads = [];
        this.allUsers = [];
        this.text = ``;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const tokens = this.parseSlackMarkdown(this.text);
        return this.renderSlackTokens(tokens);
    }
    renderSlackTokens(tokens) {
        return html `${tokens.map(token => this.renderToken(token))}`;
    }
    renderToken(token) {
        switch (token.type) {
            case 'text': return this.renderText(token);
            case 'bold': return this.renderBold(token);
            case 'italic': return this.renderItalic(token);
            case 'strike': return this.renderStrike(token);
            case 'inline-code': return this.renderInlineCode(token);
            case 'code-block': return this.renderCodeBlock(token);
            case 'mention': return this.renderMention(token);
            case 'agent': return this.renderAgent(token);
            case 'channel': return this.renderChannel(token);
            case 'command': return this.renderCommand(token);
            case 'help': return this.renderHelp(token);
            case 'link': return this.renderLink(token);
            case 'raw-link': return this.renderRawLink(token);
            case 'blockquote': return this.renderBlockquote(token);
            case 'list': return this.renderList(token);
            default: return html ``;
        }
    }
    renderText(token) {
        const parts = token.value.split('\n');
        return html `
            ${parts.map((part, index) => index === 0
            ? html `${part}`
            : html `<br />${part}`)}
        `;
    }
    renderBold(token) {
        return html `<strong>${token.value}</strong>`;
    }
    renderItalic(token) {
        return html `<em>${token.value}</em>`;
    }
    renderStrike(token) {
        return html `<del>${token.value}</del>`;
    }
    renderInlineCode(token) {
        return html `<code class="inline-code">${token.value}</code>`;
    }
    renderCodeBlock(token) {
        return html `
            <div class="collab-md-codeblock-card">
            <div class="collab-md-codeblock-header">
                <span class="collab-md-codeblock-lang">${token.language}</span>
                <button
                class="collab-md-codeblock-copy"
                title="Copiar código"
                @click=${(e) => this.copyToClipboard(e, token.value)}
                >
                ${this.msg.copy}
                </button>
            </div>

            <collab-messages-text-code-102025
                language="${token.language}"
                .text="${token.value}">
            </collab-messages-text-code-102025>
            </div>
        `;
    }
    renderAgent(token) {
        return html `
            <span
            class="mention-agent"
            data-agent="${token.value}"
            >
            @@${token.value}
            </span>
        `;
    }
    renderMention(token) {
        const user = this.allUsers?.find(u => u.name.toLowerCase() === token.value.toLowerCase());
        const isValid = Boolean(user);
        return html `
            <span
            class="mention ${isValid ? 'mention--valid' : 'mention--invalid'}"
            data-user-id="${user?.userId ?? ''}"
            data-username="${token.value}"

            @click=${(e) => {
            if (!isValid)
                return;
            this.dispatchEvent(new CustomEvent('mention-click', {
                detail: { userId: user.userId, element: e.target },
                bubbles: true,
                composed: true,
            }));
        }}

            @mouseenter=${(e) => {
            if (!isValid)
                return;
            this.dispatchEvent(new CustomEvent('mention-hover', {
                detail: { userId: user.userId, element: e.target },
                bubbles: true,
                composed: true,
            }));
        }}

            @mouseleave=${(e) => {
            if (!isValid)
                return;
            this.dispatchEvent(new CustomEvent('mention-leave', {
                detail: { userId: user.userId, element: e.target },
                bubbles: true,
                composed: true,
            }));
        }}
            >
            @${token.value}
            </span>
        `;
    }
    renderChannel(token) {
        const channelName = `#${token.value}`;
        const thread = this.allThreads?.find(t => t.name === channelName);
        const isValid = Boolean(thread);
        return html `
            <span
            class="channel ${isValid ? 'channel--valid' : 'channel--invalid'}"
            data-channel="${token.value}"
            data-thread-id="${thread?.threadId ?? ''}"

            @click=${(ev) => {
            if (!isValid)
                return;
            this.dispatchEvent(new CustomEvent('channel-click', {
                detail: { threadId: thread.threadId, element: ev.target },
                bubbles: true,
                composed: true,
            }));
        }}

            @mouseenter=${(ev) => {
            if (!isValid)
                return;
            this.dispatchEvent(new CustomEvent('channel-hover', {
                detail: { threadId: thread.threadId, element: ev.target },
                bubbles: true,
                composed: true,
            }));
        }}

            @mouseleave=${(ev) => {
            if (!isValid)
                return;
            this.dispatchEvent(new CustomEvent('channel-leave', {
                detail: { threadId: thread.threadId, element: ev.target },
                bubbles: true,
                composed: true,
            }));
        }}
            >
            #${token.value}
            </span>
        `;
    }
    renderCommand(token) {
        const fullCommand = `/${token.value}`;
        const isValid = this.allCommands?.includes(fullCommand);
        return html `
            <span
            class="command ${isValid ? 'command--valid' : 'command--invalid'}"
            data-command="${token.value}"
            @click=${() => {
            if (!isValid)
                return;
            this.dispatchEvent(new CustomEvent('command-click', {
                detail: { command: token.value },
                bubbles: true,
                composed: true,
            }));
        }}
            >
            ${fullCommand}
            </span>
        `;
    }
    renderHelp(token) {
        const full = `?${token.value}`;
        const isValid = this.allHelpers?.includes(full);
        return html `
            <span
            class="help ${isValid ? 'help--valid' : 'help--invalid'}"
            data-help="${token.value}"
            >
            ${full}
            </span>
        `;
    }
    renderLink(token) {
        return html `
            <a href="${token.url}" target="_blank" rel="noopener">
            ${token.text}
            </a>
        `;
    }
    renderRawLink(token) {
        const href = token.url.startsWith('http')
            ? token.url
            : `https://${token.url}`;
        return html `
            <a href="${href}" target="_blank" rel="noopener">
            ${token.url}
            </a>
        `;
    }
    renderBlockquote(token) {
        return html `
            <blockquote>
            ${this.renderSlackTokens(token.children)}
            </blockquote>
        `;
    }
    renderList(token) {
        return token.ordered
            ? html `
                <ol>
                ${token.items.map(item => html `<li>${this.renderSlackTokens(item)}</li>`)}
                </ol>
            `
            : html `
                <ul>
                ${token.items.map(item => html `<li>${this.renderSlackTokens(item)}</li>`)}
                </ul>
            `;
    }
    copyToClipboard(e, code) {
        if (navigator && navigator.clipboard) {
            navigator.clipboard.writeText(code);
        }
        else {
            const t = document.createElement('textarea');
            t.value = code;
            document.body.appendChild(t);
            t.select();
            document.execCommand('copy');
            document.body.removeChild(t);
        }
        if (e.target)
            e.target.innerText = `${this.msg.copied}!`;
        setTimeout(() => { e.target.innerText = `${this.msg.copy}`; }, 1200);
    }
    parseSlackMarkdown(input) {
        const tokens = [];
        const lines = input.split(/\r?\n/);
        let i = 0;
        while (i < lines.length) {
            const line = lines[i];
            /* ───── CODE BLOCK (delegado ao inline parser) ───── */
            if (line.startsWith('```')) {
                // junta tudo até fechar ```
                let block = line + '\n';
                i++;
                while (i < lines.length && !lines[i].startsWith('```')) {
                    block += lines[i] + '\n';
                    i++;
                }
                if (i < lines.length) {
                    block += lines[i];
                    i++;
                }
                tokens.push(...this.parseInlineSlackMarkdown(block));
                continue;
            }
            /* ───── BLOCKQUOTE ───── */
            if (line.startsWith('>')) {
                const quoteLines = [];
                while (i < lines.length && lines[i].startsWith('>')) {
                    quoteLines.push(lines[i].replace(/^>\s?/, ''));
                    i++;
                }
                tokens.push({
                    type: 'blockquote',
                    children: this.parseSlackMarkdown(quoteLines.join('\n')),
                });
                continue;
            }
            /* ───── UNORDERED LIST ───── */
            if (/^- /.test(line)) {
                const items = [];
                while (i < lines.length && /^- /.test(lines[i])) {
                    items.push(this.parseInlineSlackMarkdown(lines[i].replace(/^- /, '')));
                    i++;
                }
                tokens.push({
                    type: 'list',
                    ordered: false,
                    items,
                });
                continue;
            }
            /* ───── ORDERED LIST ───── */
            if (/^\d+\. /.test(line)) {
                const items = [];
                while (i < lines.length && /^\d+\. /.test(lines[i])) {
                    items.push(this.parseInlineSlackMarkdown(lines[i].replace(/^\d+\. /, '')));
                    i++;
                }
                tokens.push({
                    type: 'list',
                    ordered: true,
                    items,
                });
                continue;
            }
            /* ───── NORMAL LINE ───── */
            if (line !== '') {
                tokens.push(...this.parseInlineSlackMarkdown(line));
            }
            tokens.push({ type: 'text', value: '\n' });
            i++;
        }
        return tokens;
    }
    parseInlineSlackMarkdown(input) {
        const tokens = [];
        let state = 'NORMAL';
        let buffer = '';
        let codeLang = '';
        let i = 0;
        const matchRawLink = (s) => s.match(/^(https?:\/\/[^\s]+|www\.[^\s]+)/);
        const flushText = () => {
            if (buffer) {
                tokens.push({ type: 'text', value: buffer });
                buffer = '';
            }
        };
        const isBoundary = (char) => !char || /\s/.test(char);
        while (i < input.length) {
            /* ───────────── CODE BLOCK START ───────────── */
            if (state === 'NORMAL' && input.startsWith('```', i)) {
                flushText();
                i += 3;
                while (i < input.length && input[i] !== '\n') {
                    codeLang += input[i++];
                }
                if (input[i] === '\n')
                    i++;
                state = 'CODE_BLOCK';
                buffer = '';
                continue;
            }
            /* ───────────── CODE BLOCK END ───────────── */
            if (state === 'CODE_BLOCK' && input.startsWith('```', i)) {
                tokens.push({
                    type: 'code-block',
                    language: codeLang.trim() || 'plain',
                    value: buffer,
                });
                buffer = '';
                codeLang = '';
                state = 'NORMAL';
                i += 3;
                continue;
            }
            /* ───────────── INLINE CODE ───────────── */
            if (state === 'NORMAL' && input[i] === '`') {
                flushText();
                state = 'INLINE_CODE';
                buffer = '';
                i++;
                continue;
            }
            if (state === 'INLINE_CODE' && input[i] === '`') {
                tokens.push({ type: 'inline-code', value: buffer });
                buffer = '';
                state = 'NORMAL';
                i++;
                continue;
            }
            /* ───────────── FORMATTING (NORMAL ONLY) ───────────── */
            if (state === 'NORMAL') {
                // bold **
                if (input.startsWith('**', i)) {
                    const end = input.indexOf('**', i + 2);
                    if (end !== -1) {
                        flushText();
                        tokens.push({
                            type: 'bold',
                            value: input.slice(i + 2, end),
                        });
                        i = end + 2;
                        continue;
                    }
                }
                // strike ~~
                if (input.startsWith('~~', i)) {
                    const end = input.indexOf('~~', i + 2);
                    if (end !== -1) {
                        flushText();
                        tokens.push({
                            type: 'strike',
                            value: input.slice(i + 2, end),
                        });
                        i = end + 2;
                        continue;
                    }
                }
                // italic _
                if (input[i] === '_') {
                    const end = input.indexOf('_', i + 1);
                    if (end !== -1) {
                        flushText();
                        tokens.push({
                            type: 'italic',
                            value: input.slice(i + 1, end),
                        });
                        i = end + 1;
                        continue;
                    }
                }
                // agent @@agent
                if (state === 'NORMAL' &&
                    input[i] === '@' &&
                    input[i + 1] === '@' &&
                    isBoundary(input[i - 1])) {
                    const match = input.slice(i + 2).match(/^[a-zA-Z0-9_-]+/);
                    if (match) {
                        flushText();
                        tokens.push({
                            type: 'agent',
                            value: match[0],
                        });
                        i += match[0].length + 2;
                        continue;
                    }
                }
                // mention markdown [@Name](userId)
                if (input[i] === '[' && input[i + 1] === '@') {
                    const closeText = input.indexOf(']', i + 2);
                    const openParen = input[closeText + 1] === '(' ? closeText + 1 : -1;
                    const closeParen = openParen !== -1
                        ? input.indexOf(')', openParen + 1)
                        : -1;
                    if (closeText !== -1 && openParen !== -1 && closeParen !== -1) {
                        flushText();
                        const name = input.slice(i + 2, closeText); // remove [@
                        const userId = input.slice(openParen + 1, closeParen);
                        tokens.push({
                            type: 'mention',
                            value: name,
                            userId,
                        });
                        i = closeParen + 1;
                        continue;
                    }
                }
                // channel #
                if (input[i] === '#' && isBoundary(input[i - 1])) {
                    const match = input.slice(i + 1).match(/^[a-zA-Z0-9_-]+/);
                    if (match) {
                        flushText();
                        tokens.push({
                            type: 'channel',
                            value: match[0],
                        });
                        i += match[0].length + 1;
                        continue;
                    }
                }
                // command /
                if (input[i] === '/' && isBoundary(input[i - 1])) {
                    const match = input.slice(i + 1).match(/^[a-zA-Z0-9_-]+/);
                    if (match) {
                        flushText();
                        tokens.push({
                            type: 'command',
                            value: match[0], // sem a barra
                        });
                        i += match[0].length + 1;
                        continue;
                    }
                }
                // help ?
                if (input[i] === '?' && isBoundary(input[i - 1])) {
                    const match = input.slice(i + 1).match(/^[a-zA-Z0-9_-]+/);
                    if (match) {
                        flushText();
                        tokens.push({ type: 'help', value: match[0] });
                        i += match[0].length + 1;
                        continue;
                    }
                }
                // markdown link [text](url)
                if (state === 'NORMAL' && input[i] === '[') {
                    const closeText = input.indexOf(']', i + 1);
                    const openParen = input[closeText + 1] === '(' ? closeText + 1 : -1;
                    const closeParen = openParen !== -1 ? input.indexOf(')', openParen + 1) : -1;
                    if (closeText !== -1 && openParen !== -1 && closeParen !== -1) {
                        flushText();
                        const text = input.slice(i + 1, closeText);
                        const url = input.slice(openParen + 1, closeParen);
                        tokens.push({ type: 'link', text, url });
                        i = closeParen + 1;
                        continue;
                    }
                }
                // raw link
                if (state === 'NORMAL' && isBoundary(input[i - 1])) {
                    const match = matchRawLink(input.slice(i));
                    if (match) {
                        flushText();
                        const url = match[0];
                        tokens.push({ type: 'raw-link', url });
                        i += url.length;
                        continue;
                    }
                }
            }
            /* ───────────── DEFAULT CHAR ───────────── */
            buffer += input[i];
            i++;
        }
        /* ───────────── FLUSH ───────────── */
        if (buffer) {
            if (state === 'INLINE_CODE') {
                tokens.push({ type: 'text', value: '`' + buffer });
            }
            else if (state === 'CODE_BLOCK') {
                tokens.push({
                    type: 'code-block',
                    language: codeLang.trim() || 'plain',
                    value: buffer,
                });
            }
            else {
                tokens.push({ type: 'text', value: buffer });
            }
        }
        return tokens;
    }
};
__decorate([
    property()
], CollabMessagesRichPreviewText102025.prototype, "allHelpers", void 0);
__decorate([
    property()
], CollabMessagesRichPreviewText102025.prototype, "allCommands", void 0);
__decorate([
    property()
], CollabMessagesRichPreviewText102025.prototype, "allThreads", void 0);
__decorate([
    property()
], CollabMessagesRichPreviewText102025.prototype, "allUsers", void 0);
__decorate([
    property({ type: String })
], CollabMessagesRichPreviewText102025.prototype, "text", void 0);
CollabMessagesRichPreviewText102025 = __decorate([
    customElement('collab-messages-rich-preview-text-102025')
], CollabMessagesRichPreviewText102025);
export { CollabMessagesRichPreviewText102025 };
