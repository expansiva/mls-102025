/// <mls fileReference="_102025_/l2/collabMessagesRichPreviewText.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { parseRichText } from '/_102025_/l2/collabMessagesRichTextParser.js';
import '/_102025_/l2/collabMessagesTextCode.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    copy: 'Copiar',
    copied: 'Copiado',
    showMore: 'ver mais',
    showLess: 'ver menos',
};
const message_en = {
    loading: 'Loading...',
    copy: 'Copy',
    copied: 'Copied',
    showMore: 'show more',
    showLess: 'show less',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesRichPreviewText102025 = class CollabMessagesRichPreviewText102025 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-rich-preview-text-102025 {
  display: block;
  width: 100%;
}
collab-messages-rich-preview-text-102025 a {
  color: var(--link-color);
  text-decoration: underline;
  text-underline-offset: 2px;
}
collab-messages-rich-preview-text-102025 a:hover {
  color: var(--link-color-hover);
}
collab-messages-rich-preview-text-102025 ul,
collab-messages-rich-preview-text-102025 ol {
  margin: 0.25rem 0;
  padding-inline-start: 1.4rem;
  list-style-position: outside;
}
collab-messages-rich-preview-text-102025 ul {
  list-style: disc;
}
collab-messages-rich-preview-text-102025 ol {
  list-style: decimal;
}
collab-messages-rich-preview-text-102025 ul ul {
  list-style: circle;
}
collab-messages-rich-preview-text-102025 ol ol {
  list-style: lower-alpha;
}
collab-messages-rich-preview-text-102025 li {
  display: list-item;
  margin: 0.12rem 0;
  padding-inline-start: 0.1rem;
}
collab-messages-rich-preview-text-102025 h1,
collab-messages-rich-preview-text-102025 h2,
collab-messages-rich-preview-text-102025 h3,
collab-messages-rich-preview-text-102025 h4,
collab-messages-rich-preview-text-102025 h5,
collab-messages-rich-preview-text-102025 h6 {
  margin: 0.35rem 0 0.2rem;
  color: #1f2328;
  line-height: 1.25;
  font-weight: 700;
}
collab-messages-rich-preview-text-102025 h1 {
  font-size: 1.25em;
}
collab-messages-rich-preview-text-102025 h2 {
  font-size: 1.15em;
}
collab-messages-rich-preview-text-102025 h3,
collab-messages-rich-preview-text-102025 h4,
collab-messages-rich-preview-text-102025 h5,
collab-messages-rich-preview-text-102025 h6 {
  font-size: 1.05em;
}
collab-messages-rich-preview-text-102025 hr {
  width: 100%;
  margin: 0.5rem 0;
  border: 0;
  border-top: 1px solid #d0d7de;
}
collab-messages-rich-preview-text-102025 blockquote {
  margin: 0.35rem 0;
  padding-inline-start: 0.75rem;
  border-left: 3px solid #8c959f;
  color: #57606a;
}
collab-messages-rich-preview-text-102025 .collab-md-codeblock-card {
  margin: 1rem 0.3rem;
  font-size: var(--font-size-12);
}
collab-messages-rich-preview-text-102025 .collab-md-codeblock-card pre {
  white-space: normal;
}
collab-messages-rich-preview-text-102025 .collab-md-codeblock-card pre code {
  white-space: break-spaces;
}
collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background: #eaeef2;
  border-bottom: 1px solid #d0d7de;
  padding: 4px 8px;
  font-size: 12px;
  font-weight: bold;
  text-transform: uppercase;
  color: #57606a;
}
collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header .collab-md-inlinecode-lang,
collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header .collab-md-codeblock-lang {
  font-size: 11px;
  background: #d0d7de;
  border-radius: 3px;
  padding: 1px 4px;
  color: #24292f;
}
collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header .collab-md-codeblock-actions {
  display: inline-flex;
  align-items: center;
  gap: 0.35rem;
}
collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header .collab-md-codeblock-toggle {
  background: none;
  border: none;
  cursor: pointer;
  font-size: 12px;
  color: #0969da;
  padding: 2px 4px;
}
collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header .collab-md-codeblock-toggle:hover {
  color: #054da7;
}
collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header .collab-md-inlinecode-copy,
collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header .collab-md-codeblock-copy {
  background: none;
  border: none;
  cursor: pointer;
  font-size: 14px;
  color: #57606a;
  padding: 2px 4px;
}
collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header .collab-md-inlinecode-copy:hover,
collab-messages-rich-preview-text-102025 .collab-md-codeblock-card .collab-md-codeblock-header .collab-md-codeblock-copy:hover {
  color: #1f2328;
}
collab-messages-rich-preview-text-102025 .command--valid {
  color: var(--active-color);
  background: var(--bg-secondary-color-lighter);
  padding: 0 var(--space-8);
  border-radius: var(--space-8);
  font-family: monospace;
}
collab-messages-rich-preview-text-102025 .help--valid {
  color: var(--success-color);
  background: var(--bg-secondary-color-lighter);
  padding: 0 var(--space-8);
  border-radius: 0.2em;
}
collab-messages-rich-preview-text-102025 .inline-code {
  background-color: rgba(29, 28, 29, 0.07);
  color: #c2185b;
  border-radius: 2px;
}
collab-messages-rich-preview-text-102025 .channel.channel--valid {
  color: #1976d2;
  background: #e3f0fd;
  padding: 0 var(--space-8);
  border-radius: var(--space-8);
  cursor: pointer;
  font-weight: 600;
  transition: background var(--transition-normal), color var(--transition-normal);
}
collab-messages-rich-preview-text-102025 .channel.channel--valid:hover {
  background: #bbdefb;
  color: #0d47a1;
}
collab-messages-rich-preview-text-102025 .mention.mention--valid {
  color: #1565c0;
  background: #e3f0fd;
  padding: 0 var(--space-8);
  border-radius: 0.3em;
  cursor: pointer;
  font-weight: 600;
  transition: background var(--transition-normal), color var(--transition-normal);
}
collab-messages-rich-preview-text-102025 .mention.mention--valid:hover {
  background: #bbdefb;
  color: #0d47a1;
}
collab-messages-rich-preview-text-102025 .mention-agent {
  color: var(--active-color);
  background-color: transparent;
  padding: 0 var(--space-8);
  border-radius: var(--space-8);
  font-weight: var(--font-weight-bold);
  cursor: pointer;
  transition: background var(--transition-normal);
}
collab-messages-rich-preview-text-102025 .mention-agent:hover {
  color: var(--active-color-hover);
}
collab-messages-rich-preview-text-102025 .channel-ref {
  color: #1976d2;
  background: #e3f0fd;
  padding: 0 var(--space-8);
  border-radius: var(--space-8);
  cursor: pointer;
  font-weight: 600;
  transition: background var(--transition-normal), color var(--transition-normal);
}
collab-messages-rich-preview-text-102025 .channel-ref:hover {
  background: #bbdefb;
  color: #0d47a1;
}
`);
        this.msg = messages['en'];
        this.allHelpers = ['?help'];
        this.allCommands = ['/command1'];
        this.allThreads = [];
        this.allUsers = [];
        this.text = ``;
        this.showMarkers = false;
        this.expandedCodeBlocks = [];
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const tokens = parseRichText(this.text);
        return this.renderTokens(tokens, 'root');
    }
    renderTokens(tokens, path) {
        return html `${tokens.map((token, index) => this.renderToken(token, `${path}-${index}`))}`;
    }
    renderMarker(marker) {
        if (!this.showMarkers || !marker)
            return html ``;
        return html `<span class="marker">${marker}</span>`;
    }
    renderToken(token, key) {
        switch (token.type) {
            case 'text': return this.renderText(token);
            case 'bold': return this.renderBold(token);
            case 'italic': return this.renderItalic(token);
            case 'strike': return this.renderStrike(token);
            case 'inline-code': return this.renderInlineCode(token);
            case 'code-block': return this.renderCodeBlock(token, key);
            case 'mention': return this.renderMention(token);
            case 'agent': return this.renderAgent(token);
            case 'channel': return this.renderChannel(token);
            case 'command': return this.renderCommand(token);
            case 'help': return this.renderHelp(token);
            case 'link': return this.renderLink(token);
            case 'raw-link': return this.renderRawLink(token);
            case 'heading': return this.renderHeading(token, key);
            case 'horizontal-rule': return html `<hr />`;
            case 'blockquote': return this.renderBlockquote(token, key);
            case 'list': return this.renderList(token, key);
            default:
                console.warn('Token não reconhecido:', token);
                return html ``;
        }
    }
    renderText(token) {
        const parts = token.value.split('\n');
        return html `
            ${parts.map((part, index) => index === 0
            ? html `${part}`
            : html `<br />${part}`)}
        `;
    }
    renderBold(token) {
        return html `${this.renderMarker(token.markerStart)}<strong>${token.value}</strong>${this.renderMarker(token.markerEnd)}`;
    }
    renderItalic(token) {
        return html `${this.renderMarker(token.markerStart)}<em>${token.value}</em>${this.renderMarker(token.markerEnd)}`;
    }
    renderStrike(token) {
        return html `${this.renderMarker(token.markerStart)}<del>${token.value}</del>${this.renderMarker(token.markerEnd)}`;
    }
    renderInlineCode(token) {
        return html `${this.renderMarker(token.markerStart)}<code class="inline-code">${token.value}</code>${this.renderMarker(token.markerEnd)}`;
    }
    renderCodeBlock(token, key) {
        if (this.showMarkers) {
            return html `
                ${this.renderMarker(token.markerStart)}
                <code class="inline-code">${token.value}</code>
                ${this.renderMarker(token.markerEnd)}
            `;
        }
        const lines = token.value.split(/\r?\n/);
        const shouldCollapse = lines.length > 3;
        const expanded = this.expandedCodeBlocks.includes(key);
        const visibleValue = shouldCollapse && !expanded ? lines.slice(0, 3).join('\n') : token.value;
        return html `
            <div class="collab-md-codeblock-card">
            <div class="collab-md-codeblock-header">
                <span class="collab-md-codeblock-lang">${token.language}</span>
                <div class="collab-md-codeblock-actions">
                ${shouldCollapse ? html `
                    <button
                    class="collab-md-codeblock-toggle"
                    @click=${() => this.toggleCodeBlock(key)}
                    >
                    ${expanded ? this.msg.showLess : this.msg.showMore}
                    </button>
                ` : html ``}
                <button
                class="collab-md-codeblock-copy"
                title="Copiar código"
                @click=${(e) => this.copyToClipboard(e, token.value)}
                >
                ${this.msg.copy}
                </button>
                </div>
            </div>

            <collab-messages-text-code-102025
                language="${token.language}"
                .text="${visibleValue}">
            </collab-messages-text-code-102025>
            </div>
        `;
    }
    toggleCodeBlock(key) {
        this.expandedCodeBlocks = this.expandedCodeBlocks.includes(key)
            ? this.expandedCodeBlocks.filter(item => item !== key)
            : [...this.expandedCodeBlocks, key];
    }
    renderAgent(token) {
        return html `
            <span
            class="mention-agent"
            data-agent="${token.value}"
            >
            @@${token.value}
            </span>
        `;
    }
    renderMention(token) {
        const user = this.allUsers?.find(u => u.name.toLowerCase() === token.value.toLowerCase());
        const isValid = Boolean(user);
        return html `
            <span
            class="mention ${isValid ? 'mention--valid' : 'mention--invalid'}"
            data-user-id="${user?.userId ?? ''}"
            data-username="${token.value}"

            @click=${(e) => {
            if (!isValid)
                return;
            e.stopPropagation();
            this.dispatchEvent(new CustomEvent('mention-click', {
                detail: { userId: user.userId, element: e.target },
                bubbles: true,
                composed: true,
            }));
        }}
            >
            @${token.value}
            </span>
        `;
    }
    renderChannel(token) {
        const channelName = `#${token.value}`;
        const thread = this.allThreads?.find(t => t.name === channelName);
        const isValid = Boolean(thread);
        return html `
            <span
            class="channel ${isValid ? 'channel--valid' : 'channel--invalid'}"
            data-channel="${token.value}"
            data-thread-id="${thread?.threadId ?? ''}"

            @click=${(ev) => {
            if (!isValid)
                return;
            this.dispatchEvent(new CustomEvent('channel-click', {
                detail: { threadId: thread.threadId, element: ev.target },
                bubbles: true,
                composed: true,
            }));
        }}

            @mouseenter=${(ev) => {
            if (!isValid)
                return;
            this.dispatchEvent(new CustomEvent('channel-hover', {
                detail: { threadId: thread.threadId, element: ev.target },
                bubbles: true,
                composed: true,
            }));
        }}

            @mouseleave=${(ev) => {
            if (!isValid)
                return;
            this.dispatchEvent(new CustomEvent('channel-leave', {
                detail: { threadId: thread.threadId, element: ev.target },
                bubbles: true,
                composed: true,
            }));
        }}
            >
            #${token.value}
            </span>
        `;
    }
    renderCommand(token) {
        const fullCommand = `/${token.value}`;
        const isValid = this.allCommands?.includes(fullCommand);
        return html `
            <span
            class="command ${isValid ? 'command--valid' : 'command--invalid'}"
            data-command="${token.value}"
            @click=${() => {
            if (!isValid)
                return;
            this.dispatchEvent(new CustomEvent('command-click', {
                detail: { command: token.value },
                bubbles: true,
                composed: true,
            }));
        }}
            >
            ${fullCommand}
            </span>
        `;
    }
    renderHelp(token) {
        const full = `?${token.value}`;
        const isValid = this.allHelpers?.includes(full);
        return html `
            <span
            class="help ${isValid ? 'help--valid' : 'help--invalid'}"
            data-help="${token.value}"
            >
            ${full}
            </span>
        `;
    }
    renderLink(token) {
        const href = this.normalizeLinkHref(token.url);
        if (!href)
            return html `[${token.text}](${token.url})`;
        return html `
            <a href="${href}" target="_blank" rel="noopener noreferrer">
            ${token.text}
            </a>
        `;
    }
    renderRawLink(token) {
        const href = this.normalizeLinkHref(token.url);
        if (!href)
            return html `${token.url}`;
        return html `
            <a href="${href}" target="_blank" rel="noopener noreferrer">
            ${token.url}
            </a>
        `;
    }
    renderHeading(token, key) {
        const content = this.renderTokens(token.children, `${key}-heading`);
        switch (token.level) {
            case 1: return html `<h1>${content}</h1>`;
            case 2: return html `<h2>${content}</h2>`;
            case 3: return html `<h3>${content}</h3>`;
            case 4: return html `<h4>${content}</h4>`;
            case 5: return html `<h5>${content}</h5>`;
            default: return html `<h6>${content}</h6>`;
        }
    }
    renderBlockquote(token, key) {
        return html `
            <blockquote>
            ${this.renderTokens(token.children, `${key}-quote`)}
            </blockquote>
        `;
    }
    renderList(token, key) {
        return token.ordered
            ? html `
                <ol>
                ${token.items.map((item, index) => html `<li>${this.renderTokens(item.children, `${key}-li-${index}`)}</li>`)}
                </ol>
            `
            : html `
                <ul>
                ${token.items.map((item, index) => html `<li>${this.renderTokens(item.children, `${key}-li-${index}`)}</li>`)}
                </ul>
            `;
    }
    normalizeLinkHref(url) {
        const trimmed = url.trim();
        if (!trimmed || /[\s\u0000-\u001F]/.test(trimmed))
            return undefined;
        const href = trimmed.startsWith('www.') ? `https://${trimmed}` : trimmed;
        if (!/^(https?:\/\/|mailto:)/i.test(href))
            return undefined;
        try {
            const parsed = new URL(href);
            return parsed.href;
        }
        catch (_err) {
            return undefined;
        }
    }
    copyToClipboard(e, code) {
        if (navigator && navigator.clipboard) {
            navigator.clipboard.writeText(code);
        }
        else {
            const t = document.createElement('textarea');
            t.value = code;
            document.body.appendChild(t);
            t.select();
            document.execCommand('copy');
            document.body.removeChild(t);
        }
        if (e.target)
            e.target.innerText = `${this.msg.copied}!`;
        setTimeout(() => { e.target.innerText = `${this.msg.copy}`; }, 1200);
    }
};
__decorate([
    property()
], CollabMessagesRichPreviewText102025.prototype, "allHelpers", void 0);
__decorate([
    property()
], CollabMessagesRichPreviewText102025.prototype, "allCommands", void 0);
__decorate([
    property()
], CollabMessagesRichPreviewText102025.prototype, "allThreads", void 0);
__decorate([
    property()
], CollabMessagesRichPreviewText102025.prototype, "allUsers", void 0);
__decorate([
    property({ type: String })
], CollabMessagesRichPreviewText102025.prototype, "text", void 0);
__decorate([
    property({ type: Boolean })
], CollabMessagesRichPreviewText102025.prototype, "showMarkers", void 0);
__decorate([
    state()
], CollabMessagesRichPreviewText102025.prototype, "expandedCodeBlocks", void 0);
CollabMessagesRichPreviewText102025 = __decorate([
    customElement('collab-messages-rich-preview-text-102025')
], CollabMessagesRichPreviewText102025);
export { CollabMessagesRichPreviewText102025 };
