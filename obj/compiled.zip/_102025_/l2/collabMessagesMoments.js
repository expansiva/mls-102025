/// <mls fileReference="_102025_/l2/collabMessagesMoments.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { msgGetMomentsFeed, msgGetMomentsStats, msgMarkMomentSeen, momentsStartIndex, } from '/_102025_/l2/collabMessagesMomentsApi.js';
import { collab_chevron_left, collab_eye, collab_gear, collab_plus, collab_signal } from '/_102025_/l2/collabMessagesIcons.js';
import { REACTION_EMOJIS } from '/_102025_/l2/collabMessagesReactions.js';
import { msgUpdateMessage } from '/_102025_/l2/shared/api.js';
import '/_102025_/l2/collabMessagesRichPreviewText.js';
import '/_102025_/l2/collabMessagesMomentsNew.js';
import '/_102025_/l2/collabMessagesSettingsMoments.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    newMoment: 'Novo moment',
    stats: 'Estatísticas',
    publishers: 'Publicadores',
    caughtUp: 'Você está em dia',
    refresh: 'atualizar',
    newMoments: 'Novos moments',
    retry: 'tentar de novo',
    networkError: 'Não foi possível carregar os moments.',
    back: 'Voltar',
    reach: 'alcance',
    reachOf: 'Alcance: {reach} de {audience}',
    reactions: 'reações',
};
const message_en = {
    loading: 'Loading...',
    newMoment: 'New moment',
    stats: 'Statistics',
    publishers: 'Publishers',
    caughtUp: "You're all caught up",
    refresh: 'refresh',
    newMoments: 'New moments',
    retry: 'try again',
    networkError: 'Could not load moments.',
    back: 'Back',
    reach: 'reach',
    reachOf: 'Reach: {reach} of {audience}',
    reactions: 'reactions',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
const SEEN_FLUSH_MS = 3000;
const SEEN_BATCH = 50;
const SEEN_THRESHOLD = 0.6;
let CollabMessagesMoments102025 = class CollabMessagesMoments102025 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-moments-102025 {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
  box-sizing: border-box;
}
collab-messages-moments-102025 .moments-shell {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
}
collab-messages-moments-102025 .moments-top {
  display: flex;
  gap: 0.5rem;
  align-items: center;
  justify-content: flex-end;
  padding: 0.5rem 0.75rem;
  position: sticky;
  top: 0;
  z-index: 2;
  background: var(--surface-bg);
}
collab-messages-moments-102025 .moments-top .moments-back {
  margin-right: auto;
}
collab-messages-moments-102025 .moments-top button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 36px;
  height: 36px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: inherit;
  cursor: pointer;
}
collab-messages-moments-102025 .moments-top button svg {
  width: 18px;
  height: 18px;
  fill: currentColor;
  stroke: currentColor;
}
collab-messages-moments-102025 .moments-new {
  display: block;
  margin: 0 auto 0.5rem;
  padding: 0.35rem 0.8rem;
  border: 0;
  border-radius: 999px;
  background: var(--surface-alt-bg);
  cursor: pointer;
}
collab-messages-moments-102025 .moments-feed {
  flex: 1;
  min-height: 0;
  height: 100%;
  overflow-y: auto;
  scroll-snap-type: y mandatory;
}
collab-messages-moments-102025 .moment-card,
collab-messages-moments-102025 .moment-end {
  scroll-snap-align: start;
  height: 100%;
  box-sizing: border-box;
}
collab-messages-moments-102025 .moment-card {
  display: flex;
  flex-direction: column;
  padding: 1rem 1.25rem 1.5rem;
}
collab-messages-moments-102025 .moment-head {
  display: flex;
  align-items: center;
  gap: 0.6rem;
}
collab-messages-moments-102025 .moment-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
  background: var(--surface-alt-bg);
  display: inline-block;
}
collab-messages-moments-102025 .moment-name {
  font-weight: 600;
}
collab-messages-moments-102025 .moment-date {
  margin-left: auto;
  opacity: 0.7;
  font-size: 0.85rem;
}
collab-messages-moments-102025 .moment-body {
  flex: 1;
  overflow: auto;
  padding: 1rem 0;
}
collab-messages-moments-102025 .moment-foot {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  align-items: center;
}
collab-messages-moments-102025 .moment-reaction,
collab-messages-moments-102025 .moment-reach {
  display: inline-flex;
  align-items: center;
  gap: 0.25rem;
  padding: 0.2rem 0.55rem;
  border-radius: 999px;
  background: var(--surface-alt-bg);
}
collab-messages-moments-102025 .moment-reaction svg,
collab-messages-moments-102025 .moment-reach svg {
  width: 16px;
  height: 16px;
  fill: currentColor;
}
collab-messages-moments-102025 .moment-end {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
  text-align: center;
}
collab-messages-moments-102025 .moment-end button {
  border: 0;
  border-radius: 8px;
  padding: 0.45rem 0.9rem;
  cursor: pointer;
}
collab-messages-moments-102025 .moments-stats {
  list-style: none;
  margin: 0;
  padding: 0.75rem;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  overflow-y: auto;
}
collab-messages-moments-102025 .moments-stats-card {
  display: flex;
  flex-direction: column;
  gap: 0.45rem;
  padding: 0.85rem 1rem;
  border-radius: 12px;
  background: var(--surface-alt-bg);
}
collab-messages-moments-102025 .moments-stats-card time {
  opacity: 0.7;
  font-size: 0.85rem;
}
collab-messages-moments-102025 .moments-stats-card p,
collab-messages-moments-102025 .moments-stats-card span {
  margin: 0;
}
collab-messages-moments-102025 .moments-status,
collab-messages-moments-102025 .moments-placeholder {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
  padding: 1rem;
}
`);
        this.msg = messages['en'];
        this.userId = '';
        this.view = 'feed';
        this.items = [];
        this.loading = false;
        this.error = '';
        this.hasNewMoments = false;
        this.statsPosts = [];
        this.audience = 0;
        this.statsError = '';
        this.statsLoading = false;
        this.seenQueue = [];
        this.seenKeys = new Set();
        this.flushTimer = 0;
        this.flushing = false;
        this.pendingScroll = false;
        this.startIndex = 0;
        this.loadedFor = '';
        this.onVisibility = () => {
            if (document.visibilityState === 'hidden')
                void this.flushSeen();
        };
        this.onPush = (ev) => {
            const detail = ev.detail;
            const threadId = detail?.threadId;
            if (!threadId)
                return;
            if (this.items.some((item) => item.threadId === threadId))
                this.hasNewMoments = true;
        };
        this.onPublished = () => {
            this.view = 'feed';
            void this.loadFeed();
        };
    }
    connectedCallback() {
        super.connectedCallback();
        window.addEventListener('message-change', this.onPush);
        window.addEventListener('thread-change', this.onPush);
        document.addEventListener('visibilitychange', this.onVisibility);
        this.flushTimer = window.setInterval(() => { void this.flushSeen(); }, SEEN_FLUSH_MS);
    }
    disconnectedCallback() {
        window.removeEventListener('message-change', this.onPush);
        window.removeEventListener('thread-change', this.onPush);
        document.removeEventListener('visibilitychange', this.onVisibility);
        window.clearInterval(this.flushTimer);
        this.observer?.disconnect();
        this.observer = undefined;
        void this.flushSeen();
        super.disconnectedCallback();
    }
    updated(changed) {
        const uid = this.userId || this.userPerfil?.userId || '';
        if (uid && uid !== this.loadedFor && (changed.has('userId') || changed.has('userPerfil') || !this.loadedFor)) {
            void this.loadFeed();
        }
        if (changed.has('view') && this.view === 'stats')
            void this.loadStats();
        if (this.view === 'feed') {
            if (this.pendingScroll)
                this.scrollToStart();
            this.bindObserver();
        }
    }
    currentUserId() {
        return this.userId || this.userPerfil?.userId || '';
    }
    async loadFeed() {
        const userId = this.currentUserId();
        if (!userId)
            return;
        this.loadedFor = userId;
        this.loading = true;
        this.error = '';
        this.hasNewMoments = false;
        try {
            const result = await msgGetMomentsFeed({ userId });
            if (!result.ok) {
                console.error(result.error);
                this.error = result.error || this.msg.networkError;
                this.items = [];
                return;
            }
            this.items = result.response.items ?? [];
            this.startIndex = momentsStartIndex(this.items);
            this.pendingScroll = true;
        }
        catch (err) {
            console.error(err);
            this.error = err instanceof Error ? err.message : this.msg.networkError;
            this.items = [];
        }
        finally {
            this.loading = false;
        }
    }
    scrollToStart() {
        const scroller = this.querySelector('.moments-feed');
        if (!scroller)
            return;
        const cards = scroller.querySelectorAll('.moment-card, .moment-end');
        const target = cards[this.startIndex] ?? cards[cards.length - 1];
        target?.scrollIntoView({ block: 'start' });
        this.pendingScroll = false;
    }
    bindObserver() {
        this.observer?.disconnect();
        const scroller = this.querySelector('.moments-feed');
        if (!scroller)
            return;
        this.observer = new IntersectionObserver((entries) => {
            for (const entry of entries) {
                if (entry.intersectionRatio < SEEN_THRESHOLD)
                    continue;
                const el = entry.target;
                if (el.classList.contains('moment-end')) {
                    void this.flushSeen();
                    continue;
                }
                const index = Number(el.dataset.index);
                const item = this.items[index];
                if (!item || item.seen)
                    continue;
                if (this.isOwn(item))
                    continue;
                this.markLocalSeen(item);
            }
        }, { root: scroller, threshold: SEEN_THRESHOLD });
        scroller.querySelectorAll('.moment-card, .moment-end').forEach((el) => this.observer?.observe(el));
    }
    isOwn(item) {
        const uid = this.currentUserId();
        return !!uid && (item.publisher.userId === uid || item.message.senderId === uid);
    }
    markLocalSeen(item) {
        const messageId = `${item.threadId}/${item.message.orderAt}`;
        const key = `${item.threadId}:${messageId}`;
        item.seen = true;
        if (this.seenKeys.has(key))
            return;
        this.seenKeys.add(key);
        this.seenQueue.push({ threadId: item.threadId, messageId });
    }
    async flushSeen() {
        const userId = this.currentUserId();
        if (this.flushing || !userId || this.seenQueue.length === 0)
            return;
        this.flushing = true;
        const batch = this.seenQueue.splice(0, SEEN_BATCH);
        try {
            const result = await msgMarkMomentSeen({ userId, items: batch });
            if (!result.ok) {
                console.error(result.error);
                this.restoreQueue(batch);
            }
            else {
                for (const item of batch)
                    this.seenKeys.delete(`${item.threadId}:${item.messageId}`);
            }
        }
        catch (err) {
            console.error(err);
            this.restoreQueue(batch);
        }
        finally {
            this.flushing = false;
        }
    }
    restoreQueue(batch) {
        const queued = new Set(this.seenQueue.map((item) => `${item.threadId}:${item.messageId}`));
        const back = batch.filter((item) => !queued.has(`${item.threadId}:${item.messageId}`));
        this.seenQueue = back.concat(this.seenQueue);
    }
    openView(action) {
        this.view = action;
        this.dispatchEvent(new CustomEvent('moments-action', { detail: action, bubbles: true }));
    }
    backToFeed() {
        this.view = 'feed';
        void this.loadFeed();
    }
    formatWhen(value) {
        if (!/^\d{14}/.test(value))
            return value;
        return `${value.slice(6, 8)}/${value.slice(4, 6)}/${value.slice(0, 4)} ${value.slice(8, 10)}:${value.slice(10, 12)}`;
    }
    renderTop() {
        return html `
            <header class="moments-top">
                ${this.view === 'feed' ? nothing : html `
                    <button type="button" class="moments-back" title=${this.msg.back} @click=${() => this.backToFeed()}>${collab_chevron_left}</button>
                `}
                <button type="button" title=${this.msg.newMoment} @click=${() => this.openView('new')}>${collab_plus}</button>
                <button type="button" title=${this.msg.stats} @click=${() => this.openView('stats')}>${collab_signal}</button>
                <button type="button" title=${this.msg.publishers} @click=${() => this.openView('publishers')}>${collab_gear}</button>
            </header>
            ${this.hasNewMoments ? html `
                <button type="button" class="moments-new" @click=${() => { void this.loadFeed(); }}>${this.msg.newMoments}</button>
            ` : nothing}
        `;
    }
    async toggleReaction(item, reaction) {
        const userId = this.currentUserId();
        if (!userId)
            return;
        const previous = item.message.reactions;
        const current = previous ?? {};
        const next = {};
        for (const [name, users] of Object.entries(current)) {
            const filtered = users.filter((id) => id !== userId);
            if (filtered.length)
                next[name] = filtered;
        }
        if (!current[reaction]?.includes(userId)) {
            next[reaction] = [...(next[reaction] ?? []), userId];
        }
        const apply = (reactions) => {
            item.message = { ...item.message, reactions };
            this.items = this.items.map((row) => row === item ? { ...row, message: item.message } : row);
        };
        apply(Object.keys(next).length ? next : undefined);
        try {
            const result = await msgUpdateMessage({
                messageId: item.message.orderAt,
                threadId: item.threadId,
                userId,
                reaction,
            });
            if (!result.success || !result.response?.message) {
                throw new Error(result.error || 'Failed to update message reaction');
            }
        }
        catch (err) {
            console.error(err);
            apply(previous);
        }
    }
    renderCard(item, index) {
        const userId = this.currentUserId();
        const reactions = item.message.reactions ?? {};
        return html `
            <article class="moment-card" data-index=${index}>
                <header class="moment-head">
                    ${item.publisher.avatar_url
            ? html `<img class="moment-avatar" src=${item.publisher.avatar_url} alt="">`
            : html `<span class="moment-avatar"></span>`}
                    <span class="moment-name">${item.publisher.name}</span>
                    <time class="moment-date">${this.formatWhen(item.message.createAt)}</time>
                </header>
                <div class="moment-body">
                    <collab-messages-rich-preview-text-102025 .text=${item.message.content}></collab-messages-rich-preview-text-102025>
                </div>
                <footer class="moment-foot">
                    ${Object.entries(REACTION_EMOJIS).map(([name, emoji]) => html `
                        <button
                            type="button"
                            class="moment-reaction ${reactions[name]?.includes(userId) ? 'is-mine' : ''}"
                            @click=${() => { void this.toggleReaction(item, name); }}
                        >${emoji} ${reactions[name]?.length ?? 0}</button>
                    `)}
                    ${this.isOwn(item) ? html `<span class="moment-reach">${collab_eye} ${item.reach ?? 0}</span>` : nothing}
                </footer>
            </article>
        `;
    }
    renderEnd() {
        return html `
            <section class="moment-end">
                <p>${this.msg.caughtUp}</p>
                <button type="button" @click=${() => { void this.loadFeed(); }}>${this.msg.refresh}</button>
            </section>
        `;
    }
    async loadStats() {
        const userId = this.currentUserId();
        if (!userId)
            return;
        this.statsLoading = true;
        this.statsError = '';
        try {
            const result = await msgGetMomentsStats({ userId });
            if (!result.ok) {
                console.error(result.error);
                this.statsError = result.error || this.msg.networkError;
                this.statsPosts = [];
                return;
            }
            this.audience = result.response.audience ?? 0;
            this.statsPosts = result.response.posts ?? [];
        }
        catch (err) {
            console.error(err);
            this.statsError = err instanceof Error ? err.message : this.msg.networkError;
            this.statsPosts = [];
        }
        finally {
            this.statsLoading = false;
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <div class="moments-shell">
                ${this.renderTop()}
                ${this.renderBody()}
            </div>
        `;
    }
    renderBody() {
        const userId = this.currentUserId();
        if (this.view === 'new') {
            return html `
                <collab-messages-moments-new-102025
                    .userId=${userId}
                    @moments-published=${this.onPublished}
                ></collab-messages-moments-new-102025>
            `;
        }
        if (this.view === 'stats')
            return this.renderStats();
        if (this.view === 'publishers') {
            return html `<collab-messages-settings-moments-102025></collab-messages-settings-moments-102025>`;
        }
        return this.renderFeed();
    }
    renderStats() {
        if (this.statsLoading && this.statsPosts.length === 0 && !this.statsError) {
            return html `<p class="moments-status">${this.msg.loading}</p>`;
        }
        if (this.statsError) {
            return html `
                <div class="moments-status">
                    <p>${this.statsError}</p>
                    <button type="button" @click=${() => { void this.loadStats(); }}>${this.msg.retry}</button>
                </div>
            `;
        }
        return html `
            <ul class="moments-stats">
                ${this.statsPosts.map((post) => html `
                    <li class="moments-stats-card">
                        <time>${this.formatWhen(post.createAt)}</time>
                        <collab-messages-rich-preview-text-102025 .text=${post.preview}></collab-messages-rich-preview-text-102025>
                        <p>${this.msg.reachOf.replace('{reach}', String(post.reach)).replace('{audience}', String(this.audience))}</p>
                        <span>${post.reactions} ${this.msg.reactions}</span>
                    </li>
                `)}
            </ul>
        `;
    }
    renderFeed() {
        if (this.loading && this.items.length === 0 && !this.error) {
            return html `<p class="moments-status">${this.msg.loading}</p>`;
        }
        if (this.error) {
            return html `
                <div class="moments-status">
                    <p>${this.error}</p>
                    <button type="button" @click=${() => { this.loadedFor = ''; void this.loadFeed(); }}>${this.msg.retry}</button>
                </div>
            `;
        }
        return html `
            <div class="moments-feed">
                ${this.items.map((item, index) => this.renderCard(item, index))}
                ${this.renderEnd()}
            </div>
        `;
    }
};
__decorate([
    property({ type: String })
], CollabMessagesMoments102025.prototype, "userId", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesMoments102025.prototype, "userPerfil", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "view", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "items", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "loading", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "error", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "hasNewMoments", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "statsPosts", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "audience", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "statsError", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "statsLoading", void 0);
CollabMessagesMoments102025 = __decorate([
    customElement('collab-messages-moments-102025')
], CollabMessagesMoments102025);
export { CollabMessagesMoments102025 };
