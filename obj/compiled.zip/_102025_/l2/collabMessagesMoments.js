/// <mls fileReference="_102025_/l2/collabMessagesMoments.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { formatMomentDate, mergeMural, msgEnsureMomentsRoom, msgGetMomentsFeed, msgGetMomentsStats, msgMarkMomentSeen, oldestOrderAt, } from '/_102025_/l2/collabMessagesMomentsApi.js';
import { collab_chevron_left, collab_eye, collab_gear, collab_plus, collab_signal } from '/_102025_/l2/collabMessagesIcons.js';
import { REACTION_EMOJIS } from '/_102025_/l2/collabMessagesReactions.js';
import { msgUpdateMessage } from '/_102025_/l2/shared/api.js';
import '/_102025_/l2/collabMessagesRichPreviewText.js';
import '/_102025_/l2/collabMessagesMomentsNew.js';
import '/_102025_/l2/collabMessagesSettingsMoments.js';
function publisherInitials(name) {
    const parts = name.trim().split(/\s+/).filter(Boolean);
    return parts.slice(0, 2).map((part) => part[0]?.toUpperCase() ?? '').join('');
}
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    newMoment: 'Novo moment',
    stats: 'Estatísticas',
    publishers: 'Publicadores',
    newBadge: 'novo',
    loadingMore: 'carregando…',
    allSeen: 'Você viu todos os moments',
    newMoments: 'Novos moments',
    retry: 'tentar de novo',
    networkError: 'Não foi possível carregar os moments.',
    back: 'Voltar',
    reach: 'alcance',
    reachOf: 'Alcance: {reach} de {audience}',
    reactions: 'reações',
    audienceAll: 'Público: todos',
    audienceCount: 'Público: {n} pessoas',
};
const message_en = {
    loading: 'Loading...',
    newMoment: 'New moment',
    stats: 'Statistics',
    publishers: 'Publishers',
    newBadge: 'new',
    loadingMore: 'loading…',
    allSeen: "You've seen all moments",
    newMoments: 'New moments',
    retry: 'try again',
    networkError: 'Could not load moments.',
    back: 'Back',
    reach: 'reach',
    reachOf: 'Reach: {reach} of {audience}',
    reactions: 'reactions',
    audienceAll: 'Audience: everyone',
    audienceCount: 'Audience: {n} people',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
const SEEN_FLUSH_MS = 3000;
const SEEN_BATCH = 50;
const SEEN_THRESHOLD = 0.6;
const FEED_PAGE = 30;
let CollabMessagesMoments102025 = class CollabMessagesMoments102025 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-moments-102025 {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
  box-sizing: border-box;
}
collab-messages-moments-102025 .moments-shell {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
}
collab-messages-moments-102025 .moments-top {
  display: flex;
  gap: 0.5rem;
  align-items: center;
  justify-content: flex-end;
  padding: 0.5rem 0.75rem;
  position: sticky;
  top: 0;
  z-index: 2;
  background: var(--surface-bg);
}
collab-messages-moments-102025 .moments-top .moments-back {
  margin-right: auto;
}
collab-messages-moments-102025 .moments-top button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 36px;
  height: 36px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: inherit;
  cursor: pointer;
}
collab-messages-moments-102025 .moments-top button svg {
  width: 18px;
  height: 18px;
  fill: currentColor;
  stroke: currentColor;
}
collab-messages-moments-102025 .moments-new {
  display: block;
  margin: 0 auto 0.5rem;
  padding: 0.35rem 0.8rem;
  border: 0;
  border-radius: 999px;
  background: var(--surface-alt-bg);
  cursor: pointer;
}
collab-messages-moments-102025 .moments-feed {
  flex: 1;
  min-height: 0;
  height: 100%;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 12px;
  padding: 12px;
  box-sizing: border-box;
}
collab-messages-moments-102025 .moment-card {
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
}
collab-messages-moments-102025 .moments-sentinel {
  height: 1px;
  flex-shrink: 0;
}
collab-messages-moments-102025 .moments-more {
  margin: 0;
  padding: 0.75rem 0 1rem;
  text-align: center;
  color: var(--text-muted);
  font-family: var(--font-family-primary);
  font-size: var(--font-size-12);
}
collab-messages-moments-102025 .moments-more p {
  margin: 0 0 0.5rem;
}
collab-messages-moments-102025 .moments-more button {
  padding: 0.35rem 0.8rem;
  border: 0;
  border-radius: 999px;
  background: var(--surface-alt-bg);
  color: var(--text-default);
  font-family: var(--font-family-primary);
  font-size: var(--font-size-12);
  cursor: pointer;
}
collab-messages-moments-102025 .moment-surface {
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  padding: 20px;
  background: var(--surface-bg);
  border: 1px solid var(--border-subtle);
  border-radius: 16px;
  box-shadow: var(--shadow-small);
  color: var(--text-default);
  font-family: var(--font-family-primary);
}
collab-messages-moments-102025 .moment-head {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  flex-shrink: 0;
}
collab-messages-moments-102025 .moment-avatar {
  width: 40px;
  height: 40px;
  border-radius: 50%;
  object-fit: cover;
  background: var(--surface-alt-bg);
  color: var(--text-default);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  font-size: var(--font-size-12);
  font-weight: var(--font-weight-bold);
}
collab-messages-moments-102025 .moment-who {
  display: flex;
  flex-direction: column;
  min-width: 0;
}
collab-messages-moments-102025 .moment-name {
  font-weight: var(--font-weight-bold);
  color: var(--text-default);
}
collab-messages-moments-102025 .moment-date {
  color: var(--text-muted);
  font-size: var(--font-size-12);
}
collab-messages-moments-102025 .moment-badge {
  margin-left: auto;
  flex-shrink: 0;
  padding: 0.15rem 0.55rem;
  border-radius: 999px;
  background: var(--surface-alt-bg);
  color: var(--text-default);
  font-size: var(--font-size-12);
  font-weight: var(--font-weight-bold);
  font-family: var(--font-family-primary);
}
collab-messages-moments-102025 .moment-body {
  overflow: visible;
  max-width: 65ch;
  margin: 0.75rem 0;
  line-height: 1.6;
  color: var(--text-default);
}
collab-messages-moments-102025 .moment-body h1,
collab-messages-moments-102025 .moment-body h2,
collab-messages-moments-102025 .moment-body h3,
collab-messages-moments-102025 .moment-body h4,
collab-messages-moments-102025 .moment-body p,
collab-messages-moments-102025 .moment-body ul,
collab-messages-moments-102025 .moment-body ol,
collab-messages-moments-102025 .moment-body blockquote {
  margin: 0.6em 0;
}
collab-messages-moments-102025 .moment-body h1 {
  font-size: var(--font-size-24);
}
collab-messages-moments-102025 .moment-body h2 {
  font-size: var(--font-size-20);
}
collab-messages-moments-102025 .moment-body h3,
collab-messages-moments-102025 .moment-body h4 {
  font-size: var(--font-size-16);
}
collab-messages-moments-102025 .moment-body ul,
collab-messages-moments-102025 .moment-body ol {
  padding-left: 1.25rem;
}
collab-messages-moments-102025 .moment-body li + li {
  margin-top: 0.25em;
}
collab-messages-moments-102025 .moment-body blockquote {
  padding-left: 0.75rem;
  border-left: 3px solid var(--border-default);
  color: var(--text-muted);
}
collab-messages-moments-102025 .moment-body a {
  color: var(--button-primary-bg);
}
collab-messages-moments-102025 .moment-body img {
  max-width: 100%;
  border-radius: 8px;
}
collab-messages-moments-102025 .moment-body .inline-code,
collab-messages-moments-102025 .moment-body .collab-md-codeblock-card,
collab-messages-moments-102025 .moment-body pre {
  background: var(--surface-alt-bg);
  border-radius: 8px;
}
collab-messages-moments-102025 .moment-body .collab-md-codeblock-card,
collab-messages-moments-102025 .moment-body pre {
  overflow-x: auto;
}
collab-messages-moments-102025 .moment-body .inline-code {
  padding: 0.1em 0.35em;
}
collab-messages-moments-102025 .moment-foot {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  align-items: center;
  flex-shrink: 0;
}
collab-messages-moments-102025 .moment-reaction,
collab-messages-moments-102025 .moment-reach {
  display: inline-flex;
  align-items: center;
  gap: 0.25rem;
  min-height: 36px;
  padding: 0.2rem 0.75rem;
  border-radius: 999px;
  background: var(--surface-alt-bg);
  color: var(--text-default);
  border: 1px solid transparent;
}
collab-messages-moments-102025 .moment-reaction svg,
collab-messages-moments-102025 .moment-reach svg {
  width: 16px;
  height: 16px;
  fill: currentColor;
}
collab-messages-moments-102025 .moment-reaction {
  cursor: pointer;
  font-family: var(--font-family-primary);
}
collab-messages-moments-102025 .moment-reaction.is-mine {
  border-color: var(--selected-border);
  color: var(--selected-text);
}
collab-messages-moments-102025 .moment-reach {
  margin-left: auto;
}
collab-messages-moments-102025 .moments-stats {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
}
collab-messages-moments-102025 .moments-stats .moments-feed {
  height: auto;
  flex: none;
  overflow: visible;
  list-style: none;
  margin: 0;
}
collab-messages-moments-102025 .moments-stats-summary {
  margin: 0;
  padding: 0.75rem 12px 0;
  color: var(--text-default);
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-bold);
}
collab-messages-moments-102025 .moments-status,
collab-messages-moments-102025 .moments-placeholder {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 0.75rem;
  padding: 1rem;
}
`);
        this.msg = messages['en'];
        this.userId = '';
        this.view = 'feed';
        this.items = [];
        this.loading = false;
        this.loadingOlder = false;
        this.olderFailed = false;
        this.exhausted = false;
        this.error = '';
        this.hasNewMoments = false;
        this.statsPosts = [];
        this.audience = 0;
        this.audienceMode = '';
        this.statsError = '';
        this.statsLoading = false;
        this.seenQueue = [];
        this.seenKeys = new Set();
        this.flushTimer = 0;
        this.flushing = false;
        this.loadedFor = '';
        this.onVisibility = () => {
            if (document.visibilityState === 'hidden')
                void this.flushSeen();
        };
        this.onPush = (ev) => {
            const detail = ev.detail;
            const threadId = detail?.threadId;
            if (!threadId)
                return;
            if (this.items.some((item) => item.threadId === threadId))
                this.hasNewMoments = true;
        };
        this.onPublished = () => {
            this.view = 'feed';
            void this.loadFeed();
        };
    }
    connectedCallback() {
        super.connectedCallback();
        window.addEventListener('message-change', this.onPush);
        window.addEventListener('thread-change', this.onPush);
        document.addEventListener('visibilitychange', this.onVisibility);
        this.flushTimer = window.setInterval(() => { void this.flushSeen(); }, SEEN_FLUSH_MS);
    }
    disconnectedCallback() {
        window.removeEventListener('message-change', this.onPush);
        window.removeEventListener('thread-change', this.onPush);
        document.removeEventListener('visibilitychange', this.onVisibility);
        window.clearInterval(this.flushTimer);
        this.observer?.disconnect();
        this.observer = undefined;
        this.sentinelObserver?.disconnect();
        this.sentinelObserver = undefined;
        void this.flushSeen();
        super.disconnectedCallback();
    }
    updated(changed) {
        const uid = this.userId || this.userPerfil?.userId || '';
        if (uid && uid !== this.loadedFor && (changed.has('userId') || changed.has('userPerfil') || !this.loadedFor)) {
            void this.loadFeed();
        }
        if (changed.has('view') && this.view === 'stats')
            void this.loadStats();
        if (this.keepScrollTop !== undefined) {
            const scroller = this.querySelector('.moments-feed');
            if (scroller)
                scroller.scrollTop = this.keepScrollTop;
            this.keepScrollTop = undefined;
        }
        if (this.view === 'feed')
            this.bindObserver();
    }
    currentUserId() {
        return this.userId || this.userPerfil?.userId || '';
    }
    async loadFeed() {
        const userId = this.currentUserId();
        if (!userId)
            return;
        this.loadedFor = userId;
        this.loading = true;
        this.loadingOlder = false;
        this.olderFailed = false;
        this.exhausted = false;
        this.error = '';
        this.hasNewMoments = false;
        try {
            const result = await msgGetMomentsFeed({ userId });
            if (!result.ok) {
                console.error(result.error);
                this.error = result.error || this.msg.networkError;
                this.items = [];
                return;
            }
            const incoming = result.response.items ?? [];
            this.items = mergeMural([], incoming);
            this.exhausted = incoming.length === 0;
            this.keepScrollTop = 0;
        }
        catch (err) {
            console.error(err);
            this.error = err instanceof Error ? err.message : this.msg.networkError;
            this.items = [];
        }
        finally {
            this.loading = false;
        }
    }
    async loadOlder() {
        const userId = this.currentUserId();
        const before = oldestOrderAt(this.items);
        if (!userId || !before || this.loading || this.loadingOlder || this.exhausted || this.olderFailed)
            return;
        this.loadingOlder = true;
        try {
            const result = await msgGetMomentsFeed({ userId, limit: FEED_PAGE, before });
            if (!result.ok) {
                console.error(result.error);
                this.olderFailed = true;
                return;
            }
            const incoming = result.response.items ?? [];
            if (incoming.length === 0) {
                this.exhausted = true;
                return;
            }
            const scroller = this.querySelector('.moments-feed');
            if (scroller)
                this.keepScrollTop = scroller.scrollTop;
            this.items = mergeMural(this.items, incoming);
        }
        catch (err) {
            console.error(err);
            this.olderFailed = true;
        }
        finally {
            this.loadingOlder = false;
        }
    }
    bindObserver() {
        this.observer?.disconnect();
        this.sentinelObserver?.disconnect();
        const scroller = this.querySelector('.moments-feed');
        if (!scroller)
            return;
        this.observer = new IntersectionObserver((entries) => {
            for (const entry of entries) {
                if (entry.intersectionRatio < SEEN_THRESHOLD)
                    continue;
                const el = entry.target;
                const index = Number(el.dataset.index);
                const item = this.items[index];
                if (!item || item.seen)
                    continue;
                if (this.isOwn(item))
                    continue;
                this.markLocalSeen(item);
            }
        }, { root: scroller, threshold: SEEN_THRESHOLD });
        scroller.querySelectorAll('.moment-card').forEach((el) => this.observer?.observe(el));
        const sentinel = scroller.querySelector('.moments-sentinel');
        if (!sentinel)
            return;
        this.sentinelObserver = new IntersectionObserver((entries) => {
            if (entries.some((entry) => entry.isIntersecting))
                void this.loadOlder();
        }, { root: scroller });
        this.sentinelObserver.observe(sentinel);
    }
    isOwn(item) {
        const uid = this.currentUserId();
        return !!uid && (item.publisher.userId === uid || item.message.senderId === uid);
    }
    markLocalSeen(item) {
        const messageId = `${item.threadId}/${item.message.orderAt}`;
        const key = `${item.threadId}:${messageId}`;
        item.seen = true;
        if (this.seenKeys.has(key))
            return;
        this.seenKeys.add(key);
        this.seenQueue.push({ threadId: item.threadId, messageId });
        this.requestUpdate();
    }
    async flushSeen() {
        const userId = this.currentUserId();
        if (this.flushing || !userId || this.seenQueue.length === 0)
            return;
        this.flushing = true;
        const batch = this.seenQueue.splice(0, SEEN_BATCH);
        try {
            const result = await msgMarkMomentSeen({ userId, items: batch });
            if (!result.ok) {
                console.error(result.error);
                this.restoreQueue(batch);
            }
            else {
                for (const item of batch)
                    this.seenKeys.delete(`${item.threadId}:${item.messageId}`);
            }
        }
        catch (err) {
            console.error(err);
            this.restoreQueue(batch);
        }
        finally {
            this.flushing = false;
        }
    }
    restoreQueue(batch) {
        const queued = new Set(this.seenQueue.map((item) => `${item.threadId}:${item.messageId}`));
        const back = batch.filter((item) => !queued.has(`${item.threadId}:${item.messageId}`));
        this.seenQueue = back.concat(this.seenQueue);
    }
    openView(action) {
        this.view = action;
        this.dispatchEvent(new CustomEvent('moments-action', { detail: action, bubbles: true }));
    }
    backToFeed() {
        this.view = 'feed';
        void this.loadFeed();
    }
    renderTop() {
        return html `
            <header class="moments-top">
                ${this.view === 'feed' ? nothing : html `
                    <button type="button" class="moments-back" title=${this.msg.back} @click=${() => this.backToFeed()}>${collab_chevron_left}</button>
                `}
                <button type="button" title=${this.msg.newMoment} @click=${() => this.openView('new')}>${collab_plus}</button>
                <button type="button" title=${this.msg.stats} @click=${() => this.openView('stats')}>${collab_signal}</button>
                <button type="button" title=${this.msg.publishers} @click=${() => this.openView('publishers')}>${collab_gear}</button>
            </header>
            ${this.hasNewMoments ? html `
                <button type="button" class="moments-new" @click=${() => { void this.loadFeed(); }}>${this.msg.newMoments}</button>
            ` : nothing}
        `;
    }
    async toggleReaction(item, reaction) {
        const userId = this.currentUserId();
        if (!userId)
            return;
        const previous = item.message.reactions;
        const current = previous ?? {};
        const next = {};
        for (const [name, users] of Object.entries(current)) {
            const filtered = users.filter((id) => id !== userId);
            if (filtered.length)
                next[name] = filtered;
        }
        if (!current[reaction]?.includes(userId)) {
            next[reaction] = [...(next[reaction] ?? []), userId];
        }
        const apply = (reactions) => {
            item.message = { ...item.message, reactions };
            this.items = this.items.map((row) => row === item ? { ...row, message: item.message } : row);
        };
        apply(Object.keys(next).length ? next : undefined);
        try {
            const result = await msgUpdateMessage({
                messageId: item.message.orderAt,
                threadId: item.threadId,
                userId,
                reaction,
            });
            if (!result.success || !result.response?.message) {
                throw new Error(result.error || 'Failed to update message reaction');
            }
        }
        catch (err) {
            console.error(err);
            apply(previous);
        }
    }
    renderCard(item, index) {
        const userId = this.currentUserId();
        const reactions = item.message.reactions ?? {};
        return html `
            <article class="moment-card" data-index=${index}>
                <div class="moment-surface">
                    <header class="moment-head">
                        ${item.publisher.avatar_url
            ? html `<img class="moment-avatar" src=${item.publisher.avatar_url} alt="">`
            : html `<span class="moment-avatar" aria-hidden="true">${publisherInitials(item.publisher.name)}</span>`}
                        <div class="moment-who">
                            <span class="moment-name">${item.publisher.name}</span>
                            <time class="moment-date">${formatMomentDate(item.message.createAt, this.getMessageKey(messages))}</time>
                        </div>
                        ${item.seen ? nothing : html `<span class="moment-badge">${this.msg.newBadge}</span>`}
                    </header>
                    <div class="moment-body">
                        <collab-messages-rich-preview-text-102025 .text=${item.message.content}></collab-messages-rich-preview-text-102025>
                    </div>
                    <footer class="moment-foot">
                        ${Object.entries(REACTION_EMOJIS).map(([name, emoji]) => html `
                            <button
                                type="button"
                                class="moment-reaction ${reactions[name]?.includes(userId) ? 'is-mine' : ''}"
                                @click=${() => { void this.toggleReaction(item, name); }}
                            >${emoji} ${reactions[name]?.length ?? 0}</button>
                        `)}
                        ${this.isOwn(item) ? html `<span class="moment-reach">${collab_eye} ${item.reach ?? 0}</span>` : nothing}
                    </footer>
                </div>
            </article>
        `;
    }
    renderFoot() {
        if (this.loadingOlder)
            return html `<p class="moments-more">${this.msg.loadingMore}</p>`;
        if (this.olderFailed) {
            return html `
                <div class="moments-more">
                    <p>${this.msg.networkError}</p>
                    <button type="button" @click=${() => { this.olderFailed = false; void this.loadOlder(); }}>${this.msg.retry}</button>
                </div>
            `;
        }
        if (this.exhausted)
            return html `<p class="moments-more">${this.msg.allSeen}</p>`;
        return html `<div class="moments-sentinel" aria-hidden="true"></div>`;
    }
    async loadStats() {
        const userId = this.currentUserId();
        if (!userId)
            return;
        this.statsLoading = true;
        this.statsError = '';
        this.audienceMode = '';
        try {
            const [result, room] = await Promise.all([
                msgGetMomentsStats({ userId }),
                msgEnsureMomentsRoom({ userId }),
            ]);
            if (room.ok && (room.response.audience === 'all' || room.response.audience === 'selected')) {
                this.audienceMode = room.response.audience;
            }
            else {
                console.error(room.ok ? 'Moments room without audience' : room.error);
            }
            if (!result.ok) {
                console.error(result.error);
                this.statsError = result.error || this.msg.networkError;
                this.statsPosts = [];
                return;
            }
            this.audience = result.response.audience ?? 0;
            this.statsPosts = result.response.posts ?? [];
        }
        catch (err) {
            console.error(err);
            this.statsError = err instanceof Error ? err.message : this.msg.networkError;
            this.statsPosts = [];
        }
        finally {
            this.statsLoading = false;
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <div class="moments-shell">
                ${this.renderTop()}
                ${this.renderBody()}
            </div>
        `;
    }
    renderBody() {
        const userId = this.currentUserId();
        if (this.view === 'new') {
            return html `
                <collab-messages-moments-new-102025
                    .userId=${userId}
                    @moments-published=${this.onPublished}
                    @moments-open-settings=${() => this.openView('publishers')}
                ></collab-messages-moments-new-102025>
            `;
        }
        if (this.view === 'stats')
            return this.renderStats();
        if (this.view === 'publishers') {
            return html `<collab-messages-settings-moments-102025></collab-messages-settings-moments-102025>`;
        }
        return this.renderFeed();
    }
    renderStats() {
        if (this.statsLoading && this.statsPosts.length === 0 && !this.statsError) {
            return html `<p class="moments-status">${this.msg.loading}</p>`;
        }
        if (this.statsError) {
            return html `
                <div class="moments-status">
                    <p>${this.statsError}</p>
                    <button type="button" @click=${() => { void this.loadStats(); }}>${this.msg.retry}</button>
                </div>
            `;
        }
        const audienceLabel = this.audienceMode === 'all'
            ? this.msg.audienceAll
            : this.msg.audienceCount.replace('{n}', String(this.audience));
        const reachLabel = (reach) => this.msg.reachOf
            .replace('{reach}', String(reach))
            .replace('{audience}', String(this.audience));
        return html `
            <div class="moments-stats">
                <p class="moments-stats-summary">${audienceLabel}</p>
                <ul class="moments-feed">
                    ${this.statsPosts.map((post) => html `
                        <li class="moment-card">
                            <div class="moment-surface">
                                <header class="moment-head">
                                    <time class="moment-date">${formatMomentDate(post.createAt, this.getMessageKey(messages))}</time>
                                </header>
                                <div class="moment-body">
                                    <collab-messages-rich-preview-text-102025 .text=${post.preview}></collab-messages-rich-preview-text-102025>
                                </div>
                                <footer class="moment-foot">
                                    <span class="moment-reaction">${post.reactions} ${this.msg.reactions}</span>
                                    <span class="moment-reach">${collab_eye} ${reachLabel(post.reach)}</span>
                                </footer>
                            </div>
                        </li>
                    `)}
                </ul>
            </div>
        `;
    }
    renderFeed() {
        if (this.loading && this.items.length === 0 && !this.error) {
            return html `<p class="moments-status">${this.msg.loading}</p>`;
        }
        if (this.error) {
            return html `
                <div class="moments-status">
                    <p>${this.error}</p>
                    <button type="button" @click=${() => { this.loadedFor = ''; void this.loadFeed(); }}>${this.msg.retry}</button>
                </div>
            `;
        }
        return html `
            <div class="moments-feed">
                ${this.items.map((item, index) => this.renderCard(item, index))}
                ${this.renderFoot()}
            </div>
        `;
    }
};
__decorate([
    property({ type: String })
], CollabMessagesMoments102025.prototype, "userId", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesMoments102025.prototype, "userPerfil", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "view", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "items", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "loading", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "loadingOlder", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "olderFailed", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "exhausted", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "error", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "hasNewMoments", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "statsPosts", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "audience", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "audienceMode", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "statsError", void 0);
__decorate([
    state()
], CollabMessagesMoments102025.prototype, "statsLoading", void 0);
CollabMessagesMoments102025 = __decorate([
    customElement('collab-messages-moments-102025')
], CollabMessagesMoments102025);
export { CollabMessagesMoments102025 };
