/// <mls fileReference="_102025_/l2/collabMessagesMoments.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
let CollabMessagesMoments102025 = class CollabMessagesMoments102025 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.name = 'Somebody';
    }
    render() {
        return html `<p> In develpoment </p>`;
    }
};
__decorate([
    property()
], CollabMessagesMoments102025.prototype, "name", void 0);
CollabMessagesMoments102025 = __decorate([
    customElement('collab-messages-moments-102025')
], CollabMessagesMoments102025);
export { CollabMessagesMoments102025 };
