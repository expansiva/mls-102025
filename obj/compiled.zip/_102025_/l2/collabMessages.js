/// <mls fileReference="_102025_/l2/collabMessages.ts" enhancement="_102027_/l2/enhancementLit" /> 
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, property, state } from 'lit/decorators.js';
import { environment } from '/_102036_/l2/environmentContract.js';
import { listThreads, addThread, listUsers, updateUsers, getThread, cleanupThreads, listPoolings, getTask, getMessage, deletePooling, getAllThreads } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { saveLastTab, loadLastTab, saveUserId, saveLastAlertTime, loadLastAlertTime, changeFavIcon } from "/_102025_/l2/collabMessagesHelper.js";
import { acceptNotificationOffer, checkIfNotificationUnread, dismissNotificationOffer, getNotificationOffer, initNotifications, } from '/_102025_/l2/collabMessagesSyncNotifications.js';
import { msgGetUserUpdate, msgGetThreadUpdates } from '/_102025_/l2/shared/api.js';
import { threadOpenFromHash } from '/_102025_/l2/collabMessagesEvents.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { collab_crm, collab_tasks, collab_connect, collab_moments, collab_apps, collab_gear, collab_bell_slash, collab_xmark } from '/_102025_/l2/collabMessagesIcons.js';
import '/_102025_/l2/collabMessagesAdd.js';
import '/_102025_/l2/collabMessagesChat.js';
import '/_102025_/l2/collabMessagesTasks.js';
import '/_102025_/l2/collabMessagesApps.js';
import '/_102025_/l2/collabMessagesMoments.js';
import '/_102025_/l2/collabMessagesSettingsGeral.js';
import '/_102025_/l2/collabMessagesTabMenu.js';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    crm: 'CRM',
    tasks: 'Tasks',
    docs: 'Docs',
    connect: 'Conectar',
    alertMsgTitle: 'Ative as notificações',
    alertMsgBody: 'Para não perder mensagens importantes, permita notificações no navegador.',
    offerMsgTitle: 'Fique por dentro',
    offerMsgBody: 'Ative as notificações para saber quando chegar uma mensagem nova.',
    offerEnable: 'Ativar',
    moments: 'Moments',
    apps: 'Apps',
    settings: 'Configurações'
};
const message_en = {
    loading: 'Loading...',
    crm: 'CRM',
    tasks: 'Tasks',
    docs: 'Docs',
    connect: 'Connect',
    alertMsgTitle: 'Enable notifications',
    alertMsgBody: 'To avoid missing important messages, allow notifications in your browser.',
    offerMsgTitle: 'Stay up to date',
    offerMsgBody: 'Enable notifications to know when a new message arrives.',
    offerEnable: 'Enable',
    moments: 'Moments',
    apps: 'Apps',
    settings: 'Settings'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessages = class CollabMessages extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-102025 {
  --cm-green: #008f4c;
  --cm-green-dark: #007a3d;
  --cm-green-soft: #aee8c4;
  --cm-green-avatar: #cfe9d8;
  --cm-chat-bg: #eef5f0;
  --cm-chat-pattern: rgba(0, 122, 61, 0.026);
  --cm-panel-bg: #ffffff;
  --cm-panel-muted: #f3f7f4;
  --cm-input-bg: #ffffff;
  --cm-date-bg: rgba(255, 255, 255, 0.9);
  --cm-soft-overlay: rgba(255, 255, 255, 0.74);
  --cm-bubble-in: #ffffff;
  --cm-bubble-out: #aee8c4;
  --cm-text-on-bubble-in: #016835;
  --cm-text-on-bubble-out: #2d8c5d;
  --cm-attachment-bg: rgba(255, 255, 255, 0.78);
  --cm-border: #e2e7e3;
  --cm-border-soft: rgba(0, 0, 0, 0.08);
  --cm-text: #111827;
  --cm-text-muted: #5b635f;
  --cm-text-on-green: #ffffff;
  --cm-danger: #b42318;
  --cm-shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.1);
  --cm-shadow-md: 0 2px 6px rgba(0, 0, 0, 0.12);
  --cm-radius-sm: 8px;
  --cm-radius-md: 12px;
  --cm-radius-pill: 9999px;
  display: block;
  position: relative;
  overflow: hidden !important;
  width: var(--collab-messages-width, 375px);
  max-width: 100%;
  color-scheme: light dark;
  font-family: var(--font-family-primary);
  color: var(--cm-text);
  background: var(--cm-panel-bg);
}
collab-messages-102025 .section-add {
  padding: 1rem;
}
collab-messages-102025 .alert-notification {
  position: relative;
  width: calc(100% - 2rem - 2px);
  z-index: 999999;
  background: var(--cm-soft-overlay, #e8f9e8);
  color: var(--cm-text, #111827);
  border: 1px solid var(--cm-border, #b4e2b4);
  padding: 1rem;
  display: flex;
  align-items: center;
  gap: 2rem;
}
collab-messages-102025 .alert-notification > div {
  font-size: 14px;
  display: flex;
  justify-content: space-between;
  flex-direction: column;
}
collab-messages-102025 .alert-notification > svg {
  width: 50px;
  height: 50px;
  fill: currentColor;
}
collab-messages-102025 .alert-notification button.alert-close {
  position: absolute;
  top: 10px;
  right: 10px;
  background: none;
  border: none;
  font-size: 18px;
  cursor: pointer;
}
collab-messages-102025 .alert-notification button.alert-enable {
  position: static;
  align-self: flex-start;
  margin-top: 0.5rem;
  padding: 0.35rem 0.75rem;
  width: fit-content;
  background: var(--cm-green);
  color: var(--cm-text-on-green);
  border: none;
  border-radius: var(--cm-radius-sm);
  font-size: 13px;
  cursor: pointer;
}
[data-theme="dark"] collab-messages-102025,
collab-messages-102025[data-theme="dark"] {
  --cm-green: #00a884;
  --cm-green-dark: #075e54;
  --cm-green-soft: #005c4b;
  --cm-green-avatar: #173f37;
  --cm-chat-bg: #0b141a;
  --cm-chat-pattern: rgba(255, 255, 255, 0.024);
  --cm-panel-bg: #111b21;
  --cm-panel-muted: #202c33;
  --cm-input-bg: #202c33;
  --cm-date-bg: rgba(32, 44, 51, 0.92);
  --cm-soft-overlay: rgba(32, 44, 51, 0.82);
  --cm-bubble-in: #202c33;
  --cm-bubble-out: #005c4b;
  --cm-text-on-bubble-in: #00cfb7;
  --cm-text-on-bubble-out: #75b4ad;
  --cm-attachment-bg: rgba(17, 27, 33, 0.78);
  --cm-border: rgba(134, 150, 160, 0.18);
  --cm-border-soft: rgba(134, 150, 160, 0.18);
  --cm-text: #e9edef;
  --cm-text-muted: #aebac1;
  --cm-text-on-green: #e9edef;
  --cm-danger: #ff6b6b;
  --cm-shadow-sm: 0 1px 3px rgba(0, 0, 0, 0.28);
  --cm-shadow-md: 0 4px 12px rgba(0, 0, 0, 0.28);
}
`);
        this.msg = messages['en'];
        this.dataLocal = { lastTab: 'CRM' };
        this.activeTab = 'CRM';
        this.activeScenerie = 'tabs';
        this.isLoadingThread = false;
        this.userThreads = {};
        this.showNotificationAlert = false;
        this.notificationAlertKind = 'blocked';
        this.threadToOpen = '';
        this.taskToOpen = '';
        this.lastLevel = -1;
        this.modeMenu = 'default';
        this.e01RootSessionKey = this.newE01RootSessionKey();
        this.groupSelected = 'CRM';
        this.hashOpenConsumed = false;
        this.menuItems = [
            { id: 'CRM', icon: collab_crm, label: this.msg.crm, type: 'tab' },
            { id: 'TASK', icon: collab_tasks, label: this.msg.tasks, type: 'tab' },
            { id: 'CONNECT', icon: collab_connect, label: this.msg.connect, type: 'tab' },
            { id: 'MOMENTS', icon: collab_moments, label: this.msg.moments, type: 'tab', active: true },
            { id: 'APPS', icon: collab_apps, label: this.msg.apps, type: 'tab' },
            { id: 'SETTINGS', icon: collab_gear, label: this.msg.settings, type: 'button' }
        ];
        this.onThreadCreate = async (e) => {
            const customEvent = e;
            const thread = customEvent.detail;
            if (!thread)
                return;
            this.userThreads[thread.threadId] = {
                thread: thread,
                users: []
            };
            this.requestUpdate();
            void this.tryOpenFromHash();
        };
    }
    async connectedCallback() {
        super.connectedCallback();
        this.dataLocal.lastTab = loadLastTab();
        this.setEvents();
    }
    disconnectedCallback() {
        this.removeEvents();
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('userPerfil')) {
            this.e01RootSessionKey = this.newE01RootSessionKey();
        }
        if (changedProperties.has('activeTab') && ['CRM', 'TASK', 'DOCS', 'CONNECT'].includes(this.activeTab)) {
            if (!this.userPerfil) {
                this.userPerfil = await this.getUser();
                saveUserId(this.userPerfil.userId);
                await cleanupThreads(this.userPerfil.threads);
                void initNotifications().then(() => {
                    if (getNotificationOffer() === 'offer') {
                        this.notificationAlertKind = 'offer';
                        this.showNotificationAlert = true;
                        this.requestUpdate();
                    }
                });
            }
            await this.getThreadFromLocalDB();
            this.updateThreads();
            void this.tryOpenFromHash();
        }
        if (changedProperties.has('dataLocal')) {
            if (this.activeTab !== 'Loading')
                this.activeTab = this.dataLocal.lastTab;
        }
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        this.modeMenu = environment.config.getMenuMode();
        if (!this.activeTab)
            this.activeTab = this.dataLocal.lastTab;
        this.checkNotificationPermission();
        this.startPendentsPoolingsIfNeeded();
        this.checkNotificationPending();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${this.renderHeader()}
            ${this.renderTabs()}
        `;
    }
    checkNotificationPermission() {
        if (typeof Notification === "undefined" || Notification.permission !== "denied") {
            return;
        }
        const lastShown = Number(loadLastAlertTime() || 0);
        const now = Date.now();
        const oneWeek = 7 * 24 * 60 * 60 * 1000;
        if (!lastShown || (now - lastShown) > oneWeek) {
            this.showNotificationAlert = true;
            saveLastAlertTime(now);
        }
    }
    async startPendentsPoolingsIfNeeded() {
        const pendingsTasks = await listPoolings();
        if (!pendingsTasks || pendingsTasks.length === 0)
            return;
        for (let taskPending of pendingsTasks) {
            const task = await getTask(taskPending.taskId);
            if (!task || !task.messageid_created)
                continue;
            const message = await getMessage(task.messageid_created);
            if (!message)
                continue;
            try {
                const context = { message, task, isTest: false };
                // await continuePoolingTask(context);
            }
            catch (err) {
                deletePooling(task.PK);
            }
        }
    }
    async onThreadChange(e) {
        const customEvent = e;
        const thread = customEvent.detail;
        if (this.userThreads[thread.threadId]) {
            this.userThreads[thread.threadId].thread = thread;
        }
        else {
            await this.updateUsersThread(thread);
        }
        if (this.groupSelected !== 'CONNECT') {
            this.checkNotificationPending();
        }
        void this.tryOpenFromHash();
    }
    async onThreadOpen(e) {
        const customEvent = e;
        const data = customEvent.detail;
        if (!data.threadId)
            return;
        const thread = await getThread(data.threadId);
        if (!thread)
            return;
        if (data.taskId)
            this.taskToOpen = data.taskId;
        this.threadToOpen = thread.threadId;
        const group = thread.group;
        if (group !== this.activeTab)
            this.activeTab = group;
    }
    setEvents() {
        window.addEventListener('thread-change', this.onThreadChange.bind(this));
        window.addEventListener('thread-create', this.onThreadCreate);
        window.addEventListener('thread-open', this.onThreadOpen.bind(this));
    }
    removeEvents() {
        window.removeEventListener('thread-create', this.onThreadCreate);
        window.removeEventListener('thread-change', this.onThreadChange.bind(this));
        window.removeEventListener('thread-open', this.onThreadOpen.bind(this));
    }
    renderHeader() {
        if (this.modeMenu === 'custom')
            return nothing;
        return html `
          <collab-messages-tab-menu-102025
            style="width: var(--collab-messages-width, 375px);"
            .items=${this.menuItems}
            activeId="${this.activeTab}"
            @tab-change=${(e) => { this.onTabChange(e); }}
            @button-click=${(e) => { this.onButtonClick(e); }}
        ></collab-messages-tab-menu-102025>`;
    }
    renderTabs() {
        switch (this.activeTab) {
            case 'CRM':
                return this.renderCRM();
            case 'TASK':
                return this.renderTasks();
            case 'MOMENTS':
                return this.renderMoments();
            case 'APPS':
                return this.renderApps();
            case 'CONNECT':
                return this.renderConnect();
            case 'SETTINGS':
                return this.renderSettings();
            case 'Loading':
                return html `${this.msg.loading}`;
            default:
                return html ``;
        }
    }
    renderAlert() {
        if (!this.showNotificationAlert)
            return html ``;
        const isOffer = this.notificationAlertKind === 'offer';
        const title = isOffer ? this.msg.offerMsgTitle : this.msg.alertMsgTitle;
        const body = isOffer ? this.msg.offerMsgBody : this.msg.alertMsgBody;
        return html `  
            <div class="alert-notification">
                ${collab_bell_slash}
                <div>
                    <strong>${title}</strong><br>
                    ${body}
                    ${isOffer ? html `<button class="alert-enable" @click=${this.onAlertEnable}>${this.msg.offerEnable}</button>` : nothing}
                </div>
                <button class="alert-close" @click=${this.onAlertClose}>${collab_xmark}</button>
            </div>
        `;
    }
    async onAlertEnable() {
        this.showNotificationAlert = false;
        await acceptNotificationOffer();
    }
    onAlertClose() {
        if (this.notificationAlertKind === 'offer') {
            dismissNotificationOffer();
        }
        this.showNotificationAlert = false;
    }
    renderCRM() {
        this.groupSelected = 'CRM';
        // this.execCoachMarks('CRM');
        return html `
        ${this.renderAlert()}
        <collab-messages-chat-102025 
            .isLoadingThread= ${this.isLoadingThread}
            group="CRM"
            .userThreads=${{
            CRM: Object.keys(this.userThreads)
                .filter((key) => this.userThreads[key].thread.group === 'CRM')
                .map((key) => this.userThreads[key])
        }} 
            .allThreads=${Object.keys(this.userThreads).map((key) => this.userThreads[key].thread)}
            
            userId=${this.userPerfil?.userId} 
            .e01RootSessionKey=${this.e01RootSessionKey}
        ></collab-messages-chat-102025>`;
    }
    renderTasks() {
        this.groupSelected = 'TASK';
        // this.execCoachMarks('Tasks');
        return html `<collab-messages-tasks-102025></collab-messages-tasks-102025>`;
    }
    renderMoments() {
        this.groupSelected = 'MOMENTS';
        // this.execCoachMarks('Moments');
        return html `<collab-messages-moments-102025 ></collab-messages-moments-102025>`;
    }
    renderApps() {
        this.groupSelected = 'APPS';
        // this.execCoachMarks('Apps');
        return html `<collab-messages-apps-102025 ></collab-messages-apps-102025>`;
    }
    renderSettings() {
        this.groupSelected = 'SETTINGS';
        return html `<collab-messages-settings-geral-102025 ></collab-messages-settings-geral-102025>`;
    }
    renderConnect() {
        this.groupSelected = 'CONNECT';
        // this.execCoachMarks('Connect');
        return html `
        ${this.renderAlert()}
        <collab-messages-chat-102025 
            class=${this.modeMenu}
            .isLoadingThread= ${this.isLoadingThread}
            group="CONNECT"
            .userThreads=${{
            CONNECT: Object.keys(this.userThreads)
                .filter((key) => this.userThreads[key].thread.group === 'CONNECT')
                .map((key) => this.userThreads[key])
        }}
            .allThreads=${Object.keys(this.userThreads).map((key) => this.userThreads[key].thread)}
            threadToOpen=${ifDefined(this.threadToOpen || undefined)}
            taskToOpen=${ifDefined(this.taskToOpen || undefined)}

            userId=${this.userPerfil?.userId} 
            .e01RootSessionKey=${this.e01RootSessionKey}
        ></collab-messages-chat-102025>`;
    }
    newE01RootSessionKey() {
        return `e01-root-${crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`}`;
    }
    async getUser() {
        try {
            const result = await msgGetUserUpdate({ userId: "", name: environment.config.getDefaultUserName() });
            if (!result.success || !result.response?.user) {
                throw new Error(result.error || 'Failed to fetch user');
            }
            return result.response.user;
        }
        catch (err) {
            throw new Error(err?.message || 'Unexpected error while fetching user');
        }
    }
    async updateThreads() {
        if (!this.userPerfil?.userId) {
            // this.setError('Invalid userId');
            return;
        }
        this.isLoadingThread = true;
        const userId = this.userPerfil.userId;
        const userThreads = this.userPerfil.threads;
        for await (let threadId of userThreads) {
            if (this.userThreads[threadId]) {
                continue;
            }
            const threadInfo = await this.getThreadInfo(threadId, userId);
            this.userThreads[threadId] = threadInfo;
            addThread(threadInfo.thread);
            updateUsers(threadInfo.users);
        }
        await this.searchForDeletedThreadsPending();
        this.isLoadingThread = false;
        this.requestUpdate();
    }
    async searchForDeletedThreadsPending() {
        const allLocalThreads = await getAllThreads();
        const deletedThreadsPending = allLocalThreads.filter((thread) => thread.status === 'deleted' && thread.unreadCount && thread.unreadCount !== 0);
        for await (let thread of deletedThreadsPending) {
            this.userThreads[thread.threadId] = {
                thread,
                users: []
            };
        }
    }
    async updateUsersThread(thread) {
        if (!this.userPerfil?.userId) {
            // this.setError('Invalid userId');
            return;
        }
        const userId = this.userPerfil.userId;
        const threadInfo = await this.getThreadInfo(thread.threadId, userId);
        this.userThreads[thread.threadId] = {
            thread,
            users: threadInfo.users
        };
        addThread(thread);
        updateUsers(threadInfo.users);
        this.isLoadingThread = false;
        this.requestUpdate();
    }
    async getThreadFromLocalDB() {
        const threads = await listThreads();
        const users = await listUsers();
        for (let thread of threads) {
            if (this.userThreads[thread.threadId]) {
                return;
            }
            const threadUsers = [];
            thread.users.forEach((user) => {
                const userDB = users.find((us) => us.userId === user.userId);
                if (userDB)
                    threadUsers.push(userDB);
            });
            this.userThreads[thread.threadId] = {
                thread: thread,
                users: threadUsers
            };
        }
    }
    async getThreadInfo(threadId, userId) {
        try {
            const result = await msgGetThreadUpdates({
                threadId,
                userId
            });
            if (!result.success || !result.response) {
                throw new Error(result.error || 'Failed to fetch thread info');
            }
            return result.response;
        }
        catch (err) {
            throw new Error(err?.message || 'Unexpected error while fetching thread info');
        }
    }
    async checkNotificationPending() {
        const hasPendingMessages = await checkIfNotificationUnread();
        if (hasPendingMessages) {
            changeFavIcon(true);
        }
        else {
            changeFavIcon(false);
        }
    }
    async tryOpenFromHash() {
        if (this.hashOpenConsumed)
            return;
        const parsed = threadOpenFromHash(globalThis.location?.hash ?? '');
        if (!parsed) {
            this.hashOpenConsumed = true;
            return;
        }
        const thread = await getThread(parsed.threadId);
        if (!thread)
            return;
        this.hashOpenConsumed = true;
        this.threadToOpen = thread.threadId;
        if (thread.group && thread.group !== this.activeTab)
            this.activeTab = thread.group;
    }
    onTabChange(e) {
        if (!e.detail)
            return;
        const id = e.detail.id;
        if (!id)
            return;
        this.threadToOpen = '';
        this.taskToOpen = '';
        if (this.activeTab === id) {
            this.activeTab = 'Loading';
            setTimeout(() => {
                this.activeTab = id;
            }, 0);
            return;
        }
        ;
        this.activeTab = id;
        saveLastTab(this.activeTab);
    }
    onButtonClick(e) {
        if (!e.detail)
            return;
        const id = e.detail.id;
        if (!id)
            return;
        this.threadToOpen = '';
        this.taskToOpen = '';
        if (this.activeTab === id) {
            this.activeTab = 'Loading';
            setTimeout(() => {
                this.activeTab = id;
            }, 0);
            return;
        }
        ;
        this.activeTab = id;
    }
};
__decorate([
    property()
], CollabMessages.prototype, "dataLocal", void 0);
__decorate([
    property()
], CollabMessages.prototype, "activeTab", void 0);
__decorate([
    property()
], CollabMessages.prototype, "activeScenerie", void 0);
__decorate([
    state()
], CollabMessages.prototype, "isLoadingThread", void 0);
__decorate([
    state()
], CollabMessages.prototype, "userPerfil", void 0);
__decorate([
    state()
], CollabMessages.prototype, "userThreads", void 0);
__decorate([
    state()
], CollabMessages.prototype, "showNotificationAlert", void 0);
__decorate([
    state()
], CollabMessages.prototype, "notificationAlertKind", void 0);
__decorate([
    state()
], CollabMessages.prototype, "threadToOpen", void 0);
__decorate([
    state()
], CollabMessages.prototype, "taskToOpen", void 0);
__decorate([
    state()
], CollabMessages.prototype, "lastLevel", void 0);
__decorate([
    state()
], CollabMessages.prototype, "modeMenu", void 0);
__decorate([
    state()
], CollabMessages.prototype, "e01RootSessionKey", void 0);
CollabMessages = __decorate([
    customElement('collab-messages-102025')
], CollabMessages);
export { CollabMessages };
