/// <mls fileReference="_102025_/l2/collabMessagesMomentsApi.ts" enhancement="_blank" />
import { post } from '/_102036_/l2/shared/api.js';
function errorText(value) {
    if (typeof value === 'object' && value !== null) {
        const record = value;
        if (typeof record.msg === 'string' && record.msg)
            return record.msg;
        if (typeof record.message === 'string' && record.message)
            return record.message;
    }
    return 'Request failed';
}
async function call(args) {
    try {
        const response = await post(args);
        if (typeof response?.statusCode === 'number' && response.statusCode >= 400) {
            return { ok: false, error: response.msg || 'Request failed' };
        }
        return { ok: true, response };
    }
    catch (err) {
        console.error(err);
        return { ok: false, error: errorText(err) };
    }
}
export function msgEnsureMomentsRoom(args) {
    return call({ action: 'ensureMomentsRoom', ...args });
}
export function msgSetMomentsReaders(args) {
    return call({ action: 'setMomentsReaders', ...args });
}
export function msgGetMomentsFeed(args) {
    return call({ action: 'getMomentsFeed', ...args });
}
export function msgMarkMomentSeen(args) {
    return call({ action: 'markMomentSeen', ...args });
}
export function msgSetMomentsMute(args) {
    return call({ action: 'setMomentsMute', ...args });
}
export function msgGetMomentsSubscriptions(args) {
    return call({ action: 'getMomentsSubscriptions', ...args });
}
export function msgGetMomentsStats(args) {
    return call({ action: 'getMomentsStats', ...args });
}
/** Índice do primeiro item não visto; se todos vistos, o comprimento (card de fim). */
export function momentsStartIndex(items) {
    const index = items.findIndex((item) => item.seen === false);
    return index === -1 ? items.length : index;
}
