/// <mls fileReference="_102025_/l2/collabMessagesFindtask.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { getUserId } from "/_102025_/l2/collabMessagesHelper.js";
import '/_102025_/l2/collabMessagesTaskDetails.js';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    find: 'Buscar',
};
const message_en = {
    loading: 'Loading...',
    find: 'Search',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesFindTask = class CollabMessagesFindTask extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-findtask-102025{font-family:Arial,sans-serif;padding:20px;font-size:var(--font-size-12);display:block}collab-messages-findtask-102025 input,collab-messages-findtask-102025 select,collab-messages-findtask-102025 textarea{width:100%;display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}collab-messages-findtask-102025 button{background-color:var(--info-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;width:max-content;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer}collab-messages-findtask-102025 button .loader{display:inline-block;width:16px;height:16px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}collab-messages-findtask-102025 .section{margin-bottom:20px;padding:15px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1)}collab-messages-findtask-102025 .section>div{margin-bottom:1rem}`);
        this.msg = messages['en'];
        this.isLoading = false;
    }
    async firstUpdated(changedProperties) {
        super.updated(changedProperties);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${this.renderSearch()}
        `;
    }
    renderSearch() {
        return html `
            <div class="section">
                <div>
                    <label class="title">MessageId</label>
                    <input
                        type="text"
                        @input=${(e) => this.handleThreadChange(e)}
                    /input>
                </div>
                <div>
                    <label class="title">TaskId</label>
                    <input
                        type="text"
                        @input=${(e) => this.handleTaskChange(e)}
                    /input>
                </div>
                <div>
                <button
                    @click=${this.findThread}
                    ?disabled=${this.isLoading}
                >
                    ${this.isLoading ? html `<span class="loader"></span>` : this.msg.find}
                </button>
            </div>
            </div>
            

            <collab-messages-task-details-102025 .task=${this.actualTask} taskId=${this.actualTask?.PK}></collab-messages-task-details-102025>
        
        `;
    }
    handleThreadChange(e) {
        const target = e.target;
        this.threadId = target.value.trim();
    }
    handleTaskChange(e) {
        const target = e.target;
        this.taskId = target.value.trim();
    }
    async findThread() {
        this.isLoading = true;
        try {
            const user = getUserId();
            if (!this.taskId || !this.threadId || !user)
                return;
            const rc = await mls.api.msgGetTaskUpdate({
                messageId: this.threadId,
                taskId: this.taskId,
                userId: user
            });
            this.actualTask = rc.task;
        }
        catch (err) {
            this.actualTask = undefined;
            this.serviceBase?.setError(err.message);
        }
        finally {
            this.isLoading = false;
        }
    }
};
__decorate([
    state()
], CollabMessagesFindTask.prototype, "threadId", void 0);
__decorate([
    state()
], CollabMessagesFindTask.prototype, "taskId", void 0);
__decorate([
    property()
], CollabMessagesFindTask.prototype, "actualTask", void 0);
__decorate([
    property()
], CollabMessagesFindTask.prototype, "isLoading", void 0);
CollabMessagesFindTask = __decorate([
    customElement('collab-messages-findtask-102025')
], CollabMessagesFindTask);
export { CollabMessagesFindTask };
