/// <mls fileReference="_102025_/l2/collabMessagesE01Memory.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { post } from '/_102025_/l2/shared/api.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
const sectionOrder = ['identity_hints', 'communication_style', 'work_rhythm', 'decision_style', 'authority_hints', 'learned_preferences'];
const text = {
    en: {
        title: 'My memory', loading: 'Loading your private memory…', empty: 'No confirmed memory yet.', legacy: 'Earlier memory is waiting for your review and is not sent to John.',
        noAccess: 'This memory is available only in your protected private conversation with John.', error: 'Could not load your memory.', retry: 'Try again',
        proposals: 'Pending proposals', approve: 'Approve', reject: 'Reject', before: 'Before', after: 'Proposed', version: 'Version', sources: 'Sources',
        correction: 'Correct', save: 'Save correction', invalidate: 'Invalidate', invalidateAll: 'Invalidate all memory', cancel: 'Cancel',
        conflict: 'Your memory changed elsewhere. The latest version was loaded; review it before trying again.', saved: 'Memory updated.', rejected: 'Proposal rejected.',
        identity_hints: 'Identity hints', communication_style: 'Communication style', work_rhythm: 'Work rhythm', decision_style: 'Decision style', authority_hints: 'Authority hints', learned_preferences: 'Learned preferences',
    },
    pt: {
        title: 'Minha memória', loading: 'Carregando sua memória privada…', empty: 'Ainda não há memória confirmada.', legacy: 'Uma memória anterior aguarda sua revisão e não é enviada ao John.',
        noAccess: 'Esta memória só está disponível na sua conversa privada protegida com John.', error: 'Não foi possível carregar sua memória.', retry: 'Tentar novamente',
        proposals: 'Propostas pendentes', approve: 'Aprovar', reject: 'Rejeitar', before: 'Antes', after: 'Proposto', version: 'Versão', sources: 'Fontes',
        correction: 'Corrigir', save: 'Salvar correção', invalidate: 'Invalidar', invalidateAll: 'Invalidar toda a memória', cancel: 'Cancelar',
        conflict: 'Sua memória mudou em outro lugar. A versão mais recente foi carregada; revise antes de tentar novamente.', saved: 'Memória atualizada.', rejected: 'Proposta rejeitada.',
        identity_hints: 'Pistas de identidade', communication_style: 'Estilo de comunicação', work_rhythm: 'Ritmo de trabalho', decision_style: 'Estilo de decisão', authority_hints: 'Pistas de autoridade', learned_preferences: 'Preferências aprendidas',
    },
};
let CollabMessagesE01Memory = class CollabMessagesE01Memory extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-e01-memory-102025 {
  display: block;
  flex: 1;
  min-height: 0;
  overflow: auto;
  padding: 1rem;
  color: var(--cm-text, #111827);
  background: var(--cm-panel-bg, #fff);
}
collab-messages-e01-memory-102025 .e01-memory-state,
collab-messages-e01-memory-102025 .e01-memory-empty,
collab-messages-e01-memory-102025 .e01-memory-legacy,
collab-messages-e01-memory-102025 .e01-memory-notice {
  padding: 0.8rem;
  border-radius: 8px;
  background: var(--cm-panel-muted, #f3f7f4);
}
collab-messages-e01-memory-102025 .e01-memory-legacy .e01-memory-section {
  background: var(--cm-panel-bg, #fff);
}
collab-messages-e01-memory-102025 .e01-memory-state.error {
  color: var(--cm-danger, #b91c1c);
}
collab-messages-e01-memory-102025 .e01-memory-version {
  color: var(--cm-text-muted, #5b635f);
  font-size: 12px;
  margin-bottom: 0.6rem;
}
collab-messages-e01-memory-102025 .e01-memory-section,
collab-messages-e01-memory-102025 .e01-memory-proposal {
  border: 1px solid var(--cm-border, #e2e7e3);
  border-radius: 10px;
  padding: 0.75rem;
  margin: 0.7rem 0;
}
collab-messages-e01-memory-102025 h2,
collab-messages-e01-memory-102025 h3 {
  margin: 0 0 0.5rem;
}
collab-messages-e01-memory-102025 h2 {
  font-size: 16px;
}
collab-messages-e01-memory-102025 h3 {
  font-size: 14px;
}
collab-messages-e01-memory-102025 pre {
  margin: 0.2rem 0;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  font: inherit;
}
collab-messages-e01-memory-102025 textarea {
  box-sizing: border-box;
  width: 100%;
  min-height: 88px;
  padding: 0.55rem;
  border: 1px solid var(--cm-border, #d1d5db);
  border-radius: 6px;
  color: inherit;
  background: inherit;
}
collab-messages-e01-memory-102025 button {
  min-height: 34px;
  border: 1px solid var(--cm-green, #008f4c);
  border-radius: 6px;
  padding: 0.35rem 0.65rem;
  color: var(--cm-green-dark, #007a3d);
  background: var(--cm-panel-bg, #fff);
  cursor: pointer;
}
collab-messages-e01-memory-102025 button:focus-visible {
  outline: 3px solid var(--focus-ring, #2563eb);
  outline-offset: 2px;
}
collab-messages-e01-memory-102025 button:disabled {
  opacity: 0.55;
  cursor: wait;
}
collab-messages-e01-memory-102025 button.danger {
  border-color: var(--cm-danger, #b91c1c);
  color: var(--cm-danger, #b91c1c);
}
collab-messages-e01-memory-102025 .e01-memory-actions,
collab-messages-e01-memory-102025 .e01-memory-sources {
  display: flex;
  flex-wrap: wrap;
  gap: 0.4rem;
  margin-top: 0.55rem;
  align-items: center;
}
collab-messages-e01-memory-102025 .e01-memory-sources {
  font-size: 11px;
  color: var(--cm-text-muted, #5b635f);
}
collab-messages-e01-memory-102025 .e01-memory-sources button {
  min-height: 28px;
  padding: 0.2rem 0.45rem;
}
collab-messages-e01-memory-102025 .e01-memory-diff {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 0.45rem;
}
collab-messages-e01-memory-102025 .e01-memory-diff strong {
  grid-column: 1 / -1;
}
@media (max-width: 420px) {
  collab-messages-e01-memory-102025 {
    padding: 0.65rem;
  }
  collab-messages-e01-memory-102025 .e01-memory-diff {
    grid-template-columns: 1fr;
  }
  collab-messages-e01-memory-102025 .e01-memory-diff strong {
    grid-column: auto;
  }
}
`);
        this.userId = '';
        this.threadId = '';
        this.sessionKey = '';
        this.phase = 'loading';
        this.busy = '';
        this.notice = '';
        this.editValue = '';
        this.identity = '';
        this.operationKeys = new Map();
        this.reload = async () => {
            if (!this.userId || !this.threadId)
                return;
            const identity = this.identityToken();
            this.identity = identity;
            this.view = undefined;
            this.phase = 'loading';
            this.notice = '';
            try {
                const response = await post({ action: 'getUserMemory', userId: this.userId, threadId: this.threadId });
                if (identity !== this.identityToken())
                    return;
                this.view = response.memory;
                this.phase = 'ready';
            }
            catch (error) {
                if (identity !== this.identityToken())
                    return;
                this.view = undefined;
                this.phase = error.statusCode === 403 ? 'forbidden' : 'error';
            }
        };
    }
    connectedCallback() { super.connectedCallback(); void this.reload(); }
    updated(changed) {
        super.updated(changed);
        if (changed.has('userId') || changed.has('threadId') || changed.has('sessionKey')) {
            const next = this.identityToken();
            if (next !== this.identity) {
                this.clearPrivateState();
                void this.reload();
            }
        }
    }
    render() {
        const t = this.copy();
        if (this.phase === 'loading')
            return html `<section class="e01-memory-state" role="status">${t.loading}</section>`;
        if (this.phase === 'forbidden')
            return html `<section class="e01-memory-state error" role="alert">${t.noAccess}</section>`;
        if (this.phase === 'error')
            return html `<section class="e01-memory-state error" role="alert">${t.error}<button @click=${this.reload}>${t.retry}</button></section>`;
        const current = this.view?.current;
        const legacy = !current && this.view?.reviewCurrent;
        return html `<section class="e01-memory-panel" aria-label=${t.title}>
      ${this.notice ? html `<div class="e01-memory-notice" role="status" tabindex="-1">${this.notice}</div>` : nothing}
      ${legacy ? this.renderLegacy(legacy, t) : nothing}
      ${!current ? html `<p class="e01-memory-empty">${t.empty}</p>` : html `
        <div class="e01-memory-version">${t.version} ${current.record.version}</div>
        ${sectionOrder.map(section => this.renderSection(section, current, t))}
        <button class="danger" ?disabled=${!!this.busy} @click=${() => this.invalidate('all')}>${t.invalidateAll}</button>
      `}
      ${this.renderProposals(t)}
    </section>`;
    }
    renderLegacy(legacy, t) {
        return html `<section class="e01-memory-legacy" aria-label=${t.legacy}>
      <div role="status">${t.legacy}</div>
      <div class="e01-memory-version">${t.version} ${legacy.record.version}</div>
      ${sectionOrder.map(section => {
            const content = legacy.sections[section]?.trim();
            return content ? html `<article class="e01-memory-section legacy"><h3>${t[section]}</h3><pre>${content}</pre>${this.renderSources(legacy.record.sectionSources?.[section] || [], t)}</article>` : nothing;
        })}
    </section>`;
    }
    renderSection(section, current, t) {
        const content = current.sections[section]?.trim();
        if (!content)
            return nothing;
        const editing = this.editing === section;
        return html `<article class="e01-memory-section">
      <h3>${t[section]}</h3>
      ${editing ? html `
        <textarea data-section=${section} aria-label="${t.correction}: ${t[section]}" .value=${this.editValue} @input=${(e) => this.editValue = e.target.value}></textarea>
        <div class="e01-memory-actions"><button ?disabled=${!!this.busy || !this.editValue.trim()} @click=${() => this.correct(section)}>${t.save}</button><button @click=${() => this.stopEditing(section)}>${t.cancel}</button></div>
      ` : html `<pre>${content}</pre><div class="e01-memory-actions"><button class="e01-memory-correct" data-section=${section} aria-label="${t.correction}: ${t[section]}" @click=${() => this.startEditing(section, content)}>${t.correction}</button><button class="danger" ?disabled=${!!this.busy} @click=${() => this.invalidate(section)}>${t.invalidate}</button></div>`}
      ${this.renderSources(current.record.sectionSources?.[section] || [], t)}
    </article>`;
    }
    renderProposals(t) {
        const proposals = this.view?.proposals || [];
        if (!proposals.length)
            return nothing;
        const base = this.view?.current?.sections || this.view?.reviewCurrent?.sections;
        return html `<section class="e01-memory-proposals"><h2>${t.proposals}</h2>${proposals.map(proposal => html `
      <article class="e01-memory-proposal">
        <p>${proposal.reason}</p>
        ${Object.entries(proposal.updates).map(([name, after]) => html `<div class="e01-memory-diff"><strong>${t[name]}</strong><div><small>${t.before}</small><pre>${base?.[name] || '—'}</pre></div><div><small>${t.after}</small><pre>${after || '—'}</pre></div></div>`)}
        ${this.renderSources(Object.values(proposal.sources).flat(), t)}
        <div class="e01-memory-actions"><button ?disabled=${!!this.busy} @click=${() => this.decide(proposal, 'confirm')}>${t.approve}</button><button ?disabled=${!!this.busy} @click=${() => this.decide(proposal, 'reject')}>${t.reject}</button></div>
      </article>`)}</section>`;
    }
    renderSources(sources, t) {
        if (!sources.length)
            return nothing;
        return html `<div class="e01-memory-sources"><small>${t.sources}</small>${sources.map(source => source.kind === 'message'
            ? html `<button @click=${() => this.openSource(source.ref)}>${source.ref.split('/').pop()}</button>`
            : html `<span>${source.kind}: ${source.ref}</span>`)}</div>`;
    }
    async decide(proposal, decision) {
        await this.mutate(`proposal:${proposal.proposalId}:${decision}`, {
            action: 'decideUserMemoryProposal', userId: this.userId, threadId: this.threadId, proposalId: proposal.proposalId,
            decision, expectedVersion: proposal.baseVersion,
        }, decision === 'reject' ? this.copy().rejected : this.copy().saved);
    }
    async correct(section) {
        const identity = this.identityToken();
        const version = this.view?.current?.record.version;
        if (version === undefined || !this.editValue.trim())
            return;
        const saved = await this.mutate(`correct:${section}:${version}`, { action: 'correctUserMemory', userId: this.userId, threadId: this.threadId, section, content: this.editValue.trim(), expectedVersion: version }, this.copy().saved);
        if (saved && identity === this.identityToken())
            await this.stopEditing(section);
    }
    async invalidate(section) {
        const version = this.view?.current?.record.version;
        if (version === undefined)
            return;
        await this.mutate(`invalidate:${section}:${version}`, { action: 'invalidateUserMemory', userId: this.userId, threadId: this.threadId, section, expectedVersion: version }, this.copy().saved);
    }
    async mutate(key, request, success) {
        if (this.busy)
            return false;
        const identity = this.identityToken();
        const idempotencyKey = this.operationKeys.get(key) || this.newKey();
        this.operationKeys.set(key, idempotencyKey);
        this.busy = key;
        this.notice = '';
        try {
            await post({ ...request, idempotencyKey });
            if (identity !== this.identityToken())
                return false;
            this.operationKeys.delete(key);
            await this.reload();
            if (identity !== this.identityToken())
                return false;
            this.notice = success;
            return true;
        }
        catch (error) {
            if (identity !== this.identityToken())
                return false;
            if (error.statusCode === 409) {
                this.operationKeys.delete(key);
                await this.reload();
                if (identity !== this.identityToken())
                    return false;
                this.notice = this.copy().conflict;
                await this.updateComplete;
                this.querySelector('.e01-memory-notice')?.focus();
            }
            else
                this.notice = error.message || this.copy().error;
            return false;
        }
        finally {
            if (identity === this.identityToken())
                this.busy = '';
        }
    }
    async openSource(ref) {
        const identity = this.identityToken();
        try {
            await post({ action: 'getUserMemory', userId: this.userId, threadId: this.threadId, openSourceMessageId: ref });
            if (identity !== this.identityToken())
                return;
            this.dispatchEvent(new CustomEvent('e01-open-source', { detail: { messageId: ref }, bubbles: true, composed: true }));
        }
        catch {
            if (identity === this.identityToken())
                this.notice = this.copy().noAccess;
        }
    }
    async startEditing(section, value) {
        this.editing = section;
        this.editValue = value;
        await this.updateComplete;
        this.querySelector(`textarea[data-section="${section}"]`)?.focus();
    }
    async stopEditing(section) {
        this.editing = undefined;
        this.editValue = '';
        await this.updateComplete;
        if (section)
            this.querySelector(`button.e01-memory-correct[data-section="${section}"]`)?.focus();
    }
    clearPrivateState() { this.identity = ''; this.view = undefined; this.phase = 'loading'; this.busy = ''; this.notice = ''; this.editing = undefined; this.editValue = ''; this.operationKeys.clear(); }
    identityToken() { return `${this.sessionKey}|${this.userId}|${this.threadId}`; }
    newKey() { return `e01-ui-${crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`}`; }
    copy() { const lang = (document.documentElement.lang || 'en').toLowerCase(); return lang.startsWith('pt') ? text.pt : text.en; }
};
__decorate([
    property()
], CollabMessagesE01Memory.prototype, "userId", void 0);
__decorate([
    property()
], CollabMessagesE01Memory.prototype, "threadId", void 0);
__decorate([
    property()
], CollabMessagesE01Memory.prototype, "sessionKey", void 0);
__decorate([
    state()
], CollabMessagesE01Memory.prototype, "view", void 0);
__decorate([
    state()
], CollabMessagesE01Memory.prototype, "phase", void 0);
__decorate([
    state()
], CollabMessagesE01Memory.prototype, "busy", void 0);
__decorate([
    state()
], CollabMessagesE01Memory.prototype, "notice", void 0);
__decorate([
    state()
], CollabMessagesE01Memory.prototype, "editing", void 0);
__decorate([
    state()
], CollabMessagesE01Memory.prototype, "editValue", void 0);
CollabMessagesE01Memory = __decorate([
    customElement('collab-messages-e01-memory-102025')
], CollabMessagesE01Memory);
export { CollabMessagesE01Memory };
