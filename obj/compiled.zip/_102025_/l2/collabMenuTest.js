/// <mls fileReference="_102025_/l2/collabMenuTest.ts" enhancement="_100554_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { collab_arrow_up_long, collab_bell, collab_circle_exclamation, collab_link, collab_bug_x12, collab_magnifying_glass } from '/_102025_/l2/collabMessagesIcons.js';
import '/_102025_/l2/collabMessagesTabMenu.js';
let CollabMenuTest102025 = class CollabMenuTest102025 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.items = [
            { id: 'menu', icon: collab_arrow_up_long, label: 'Menu', type: 'tab' },
            { id: 'phone', icon: collab_bell, label: 'Phone', type: 'tab' },
            { id: 'list', icon: collab_circle_exclamation, label: 'List', type: 'tab' },
            { id: 'connect', icon: collab_link, label: 'Connect', type: 'tab', active: true },
            { id: 'file', icon: collab_bug_x12, label: 'File', type: 'tab' },
            { id: 'settings', icon: collab_magnifying_glass, label: 'Settigns', type: 'button' }
        ];
    }
    render() {
        return html `
    <collab-messages-tab-menu-102025
        .items=${this.items}
        activeId="connect"
        @tab-change=${(e) => console.log('Tab changed:', e.detail)}
        @button-click=${(e) => console.log('Button clicked:', e.detail)}
    ></collab-messages-tab-menu-102025>
`;
    }
};
CollabMenuTest102025 = __decorate([
    customElement('collab-menu-test-102025')
], CollabMenuTest102025);
export { CollabMenuTest102025 };
