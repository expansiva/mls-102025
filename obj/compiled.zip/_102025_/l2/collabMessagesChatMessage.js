/// <mls fileReference="_102025_/l2/collabMessagesChatMessage.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { until } from 'lit/directives/until.js';
import { customElement, property, state } from 'lit/decorators.js';
import { collab_translate, collab_circle_exclamation, collab_smile, collab_chevron_down, collab_reply, collab_copy, collab_pin, collab_star, collab_edit, collab_delete, collab_paperclip } from '/_102025_/l2/collabMessagesIcons.js';
import { loadChatPreferences, formatTimestamp } from '/_102025_/l2/collabMessagesHelper.js';
import { getMessage, updateMessage } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { msgGetAttachmentUrl, msgUpdateMessage } from '/_102025_/l2/shared/api.js';
import { hasTaskNotificationPending } from '/_102025_/l2/collabMessagesSyncNotifications.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    msgNotSend: 'Mensagem não enviada*',
    reply: 'Responder',
    copy: 'Copiar',
    pin: 'Fixar',
    unpin: 'Desfixar',
    favorite: 'Favoritar',
    unfavorite: 'Remover favorito',
    requestReadConfirmation: 'Confirmação de leitura',
    cancelReadConfirmation: 'Cancelar confirmação de leitura',
    confirmRead: 'Recebi e li a mensagem',
    allConfirmedRead: 'Confirmado que todos receberam',
    requestedReadConfirmation: 'pediu confirmação de leitura em',
    confirmedRead: 'confirmou leitura em',
    canceledReadConfirmation: 'cancelou confirmação de leitura em',
    notConfirmedRead: 'não confirmado',
    delete: 'Apagar',
    edit: 'Editar',
    you: 'Você',
    reactions: 'reações',
    reaction: 'reação',
    clickToRemove: 'Clique para remover',
    attachmentRemoved: 'Anexo removido por',
    openAttachment: 'Abrir anexo',
    deleteAttachment: 'Apagar anexo',
};
const message_en = {
    loading: 'Loading...',
    msgNotSend: 'Message not sent*',
    reply: 'Reply',
    copy: 'Copy',
    pin: 'Pin',
    unpin: 'Unpin',
    favorite: 'Favorite',
    unfavorite: 'Remove favorite',
    requestReadConfirmation: 'Read confirmation',
    cancelReadConfirmation: 'Cancel read confirmation',
    confirmRead: 'I received and read the message',
    allConfirmedRead: 'Confirmed that everyone received it',
    requestedReadConfirmation: 'requested read confirmation at',
    confirmedRead: 'confirmed reading at',
    canceledReadConfirmation: 'canceled read confirmation at',
    notConfirmedRead: 'not confirmed',
    delete: 'Delete',
    edit: 'Edit',
    you: 'You',
    reactions: 'reactions',
    reaction: 'reaction',
    clickToRemove: 'Click to remove',
    attachmentRemoved: 'Attachment removed by',
    openAttachment: 'Open attachment',
    deleteAttachment: 'Delete attachment',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesChatMessage102025 = class CollabMessagesChatMessage102025 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-chat-message-102025 {
  display: inline-flex;
}
collab-messages-chat-message-102025 .message {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  width: 100%;
  margin-top: 10px;
}
collab-messages-chat-message-102025 .message.reaction-on {
  margin-bottom: 20px;
}
collab-messages-chat-message-102025 .message.user {
  align-items: flex-end;
}
collab-messages-chat-message-102025 .message.same {
  margin-top: 0;
}
collab-messages-chat-message-102025 .message .message-row {
  display: flex;
  align-items: center;
  max-width: 80%;
  margin-bottom: 3px;
  margin-left: 50px;
  position: relative;
  gap: 0.2rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card {
  display: flex;
  flex-direction: column;
  background-color: #f5f5f5;
  border-radius: 8px;
  padding: 0.5rem;
  position: relative;
  font-size: 14px;
}
collab-messages-chat-message-102025 .message .message-row .message-card.system:not(.same) {
  border-top-left-radius: 0px;
}
collab-messages-chat-message-102025 .message .message-row .message-card.system:not(.same):before {
  content: '';
  position: absolute;
  top: 0px;
  left: -15px;
  width: 6px;
  height: 0;
  border-top: 0px solid transparent;
  border-right: 10px solid #f5f5f5;
  border-bottom: 12px solid transparent;
}
collab-messages-chat-message-102025 .message .message-row .message-card.user {
  background-color: #d9fdd3;
  align-self: flex-end;
}
collab-messages-chat-message-102025 .message .message-row .message-card.pinned {
  border: 1px solid var(--active-color);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-title {
  color: #be069c;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-ai {
  margin-top: 0.3rem;
  display: flex;
  margin-left: auto;
  width: 100%;
}
collab-messages-chat-message-102025 .message .message-row .message-card .failed {
  margin-top: 0.2rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .failed > div {
  display: flex;
  gap: 0.3rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .failed svg {
  fill: var(--error-color);
  width: 14px;
  height: 14px;
}
collab-messages-chat-message-102025 .message .message-row .message-card .failed small {
  color: #000000;
  font-style: italic;
  font-size: var(--font-size-12);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-content {
  margin-top: 0.4rem;
  color: #000;
  display: flex;
  align-items: flex-start;
  gap: 0.4rem;
  word-break: break-word;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-content collab-messages-rich-preview-text-102025 {
  flex: 1;
  min-width: 0;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-content collab-messages-rich-preview-text-102025 .inline-code {
  background-color: rgba(29, 28, 29, 0.07);
  color: #c2185b;
  border-radius: 3px;
  padding: 0 0.12em;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-content svg {
  flex-shrink: 0;
  width: 12px;
  fill: var(--active-color);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachments {
  display: flex;
  flex-direction: column;
  gap: 0.45rem;
  margin-top: 0.45rem;
  min-width: 220px;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment {
  border: 1px solid rgba(0, 0, 0, 0.08);
  border-radius: 6px;
  background: rgba(255, 255, 255, 0.72);
  color: #000;
  overflow: hidden;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment a {
  color: inherit;
  text-decoration: none;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment svg {
  width: 16px;
  height: 16px;
  flex-shrink: 0;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment.image img {
  display: block;
  width: 100%;
  max-width: 360px;
  max-height: 280px;
  object-fit: contain;
  background: #fff;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment.image .attachment-meta {
  display: flex;
  align-items: center;
  gap: 0.45rem;
  padding: 0.35rem 0.45rem;
  font-size: var(--font-size-12);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment.file,
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment.deleted {
  display: flex;
  align-items: center;
  gap: 0.45rem;
  padding: 0.45rem;
  font-size: var(--font-size-12);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment.file a,
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment.deleted a {
  display: flex;
  align-items: center;
  gap: 0.45rem;
  min-width: 0;
  flex: 1;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment span {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  min-width: 0;
  flex: 1;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment small {
  color: #5f6368;
  white-space: nowrap;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment.deleted {
  color: #5f6368;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment .attachment-delete {
  width: 24px;
  height: 24px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: none;
  border-radius: 4px;
  background: transparent;
  color: var(--text-primary-color);
  cursor: pointer;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment .attachment-delete:hover {
  background: rgba(0, 0, 0, 0.06);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-result .message-result-text {
  border-top: 1px solid var(--grey-color-dark);
  margin-top: 0.5rem;
  white-space: pre-line;
  color: #000;
  word-break: break-word;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-result .message-result-text widget-text2-collab-messages-m-d-102025 .collab-md-message {
  font-family: inherit;
  font-size: inherit;
  color: inherit;
  line-height: inherit;
  background: inherit;
  padding: inherit;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-result .message-result-text widget-text2-collab-messages-m-d-102025 .collab-md-message .mention-agent {
  color: var(--active-color);
  background-color: transparent;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-result .message-result-text widget-text2-collab-messages-m-d-102025 .collab-md-message .mention-agent:hover {
  color: var(--active-color-hover);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-read-confirmations {
  margin-top: 0.5rem;
  padding: 0.35rem 0.45rem;
  background: rgba(255, 255, 255, 0.72);
  border: 1px solid rgba(0, 0, 0, 0.08);
  border-radius: 6px;
  color: #000;
  font-size: var(--font-size-12);
  line-height: 1.35;
  word-break: break-word;
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-read-confirmation {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .read-confirmation-line {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 0.25rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .read-confirmation-line.pending {
  color: #5f6368;
}
collab-messages-chat-message-102025 .message .message-row .message-card .read-confirmation-line.canceled {
  border-top: 1px solid rgba(0, 0, 0, 0.08);
  margin-top: 0.15rem;
  padding-top: 0.25rem;
  color: #5f6368;
}
collab-messages-chat-message-102025 .message .message-row .message-card .read-confirmation-user {
  color: var(--active-color);
  font-weight: 600;
  background: rgba(255, 255, 255, 0.75);
  border-radius: 4px;
  padding: 0 0.2rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .read-confirmation-time {
  color: #5f6368;
  white-space: nowrap;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-content.trace {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-content.translate {
  padding: 0;
  margin: 0;
  font-size: 11px;
  font-style: italic;
  color: #717070;
  padding-inline-start: 6px;
  border-left: 2px solid #717070;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-footer {
  font-size: 0.75rem;
  color: gray;
  text-align: right;
}
collab-messages-chat-message-102025 .message .message-row > collab-messages-avatar-102025 {
  position: absolute;
  top: -3px;
  left: -40px;
}
collab-messages-chat-message-102025 .message .message-group {
  display: contents;
}
collab-messages-chat-message-102025 .message-reactions {
  display: flex;
  gap: 4px;
  margin-top: 4px;
  position: absolute;
  bottom: -15px;
  right: 10px;
}
collab-messages-chat-message-102025 .message-reactions .reactions-summary {
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 2px 8px;
  border-radius: 12px;
  background: #fff;
  border: 1px solid var(--grey-color-dark);
  cursor: pointer;
  font-size: 12px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
  transition: background 0.15s ease;
}
collab-messages-chat-message-102025 .message-reactions .reactions-summary:hover {
  background: var(--grey-color-lighter);
}
collab-messages-chat-message-102025 .message-reactions .reactions-summary .reaction-emoji {
  font-size: 14px;
  line-height: 1;
}
collab-messages-chat-message-102025 .message-reactions .reactions-summary .reaction-count {
  color: var(--grey-color-darker);
  font-size: 12px;
  margin-left: 2px;
}
collab-messages-chat-message-102025 .message-reactions .active {
  box-shadow: 0 1px #00000012, 0 0 3px #0000000a;
}
collab-messages-chat-message-102025 .reaction-list-popup {
  position: absolute;
  min-width: 230px;
  max-width: 240px;
  background: var(--bg-primary-color, #fff);
  border-radius: 8px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
  z-index: 40;
  opacity: 0;
  transform: scale(0.95);
  pointer-events: none;
  transition: opacity 150ms ease, transform 150ms ease;
}
collab-messages-chat-message-102025 .reaction-list-popup.open {
  opacity: 1;
  transform: scale(1);
  pointer-events: auto;
}
collab-messages-chat-message-102025 .reaction-list-popup.top {
  bottom: calc(100% + 8px);
  left: 0;
  transform-origin: bottom left;
}
collab-messages-chat-message-102025 .reaction-list-popup.bottom {
  top: calc(100% + 8px);
  left: 0;
  transform-origin: top left;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-header {
  padding: 10px 12px 8px;
  font-size: 13px;
  font-weight: 600;
  color: var(--text-primary-color);
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-divider {
  height: 1px;
  background: var(--grey-color);
  margin: 0 12px;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-content {
  padding: 8px 0;
  max-height: 200px;
  overflow-y: auto;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  font-size: 14px;
  color: var(--text-primary-color);
  transition: background 0.15s ease;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item.current-user {
  cursor: pointer;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item.current-user:hover {
  background: var(--grey-color-lighter);
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item.current-user .reaction-list-name {
  color: var(--active-color);
  font-weight: 500;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item .reaction-list-user {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 1;
  min-width: 0;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item .reaction-list-user collab-messages-avatar-102025 {
  flex-shrink: 0;
  width: 30px;
  height: 30px;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item .reaction-list-detail {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item .reaction-list-name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item .reaction-list-small {
  color: var(--grey-color-darker);
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item .reaction-list-emoji {
  font-size: 16px;
  margin-left: 8px;
  flex-shrink: 0;
}
collab-messages-chat-message-102025 .message.system .message-reactions {
  left: 10px;
  right: auto;
}
collab-messages-chat-message-102025 .message.system .reaction-list-popup.top {
  left: 0;
  right: auto;
}
collab-messages-chat-message-102025 .message.system .reaction-list-popup.bottom {
  left: 0;
  right: auto;
}
collab-messages-chat-message-102025 .message.user .reaction-list-popup.top {
  right: 0;
  left: auto;
  transform-origin: bottom right;
}
collab-messages-chat-message-102025 .message.user .reaction-list-popup.bottom {
  right: 0;
  left: auto;
  transform-origin: top right;
}
collab-messages-chat-message-102025 .reaction {
  display: flex;
  align-items: center;
  gap: 4px;
  border-radius: 12px;
  padding: 2px 6px;
  font-size: 12px;
  cursor: pointer;
  background: #f5f5f5;
  border: none;
}
collab-messages-chat-message-102025 .reaction-picker {
  position: absolute;
  display: flex;
  gap: 6px;
  padding: 6px 8px;
  border-radius: 16px;
  background: var(--bg-primary-color-darker-hover);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  z-index: 10;
  opacity: 0;
  transform: scaleX(0.6) scaleY(0.4);
  pointer-events: none;
  transition: opacity 180ms ease-out, transform 320ms cubic-bezier(0.18, 0.89, 0.32, 1.28);
}
collab-messages-chat-message-102025 .reaction-picker.open {
  opacity: 1;
  transform: scale(1);
  pointer-events: auto;
}
collab-messages-chat-message-102025 .message.user .reaction-picker {
  right: 0;
}
collab-messages-chat-message-102025 .message.system .reaction-picker {
  left: 0;
}
collab-messages-chat-message-102025 .message.user .reaction-picker {
  transform-origin: bottom right;
}
collab-messages-chat-message-102025 .message.system .reaction-picker {
  transform-origin: bottom left;
}
collab-messages-chat-message-102025 .message.user .message-reactions {
  right: 10px;
}
collab-messages-chat-message-102025 .message.system .message-reactions {
  left: 10px;
}
collab-messages-chat-message-102025 .reaction-picker-item {
  font-size: 18px;
  background: none;
  border: none;
  cursor: pointer;
  opacity: 0;
  transform: scale(0.6);
  transition: opacity 180ms ease-out, transform 2200ms cubic-bezier(0.2, 0.8, 0.2, 1);
}
collab-messages-chat-message-102025 .reaction-picker.open .reaction-picker-item.show {
  opacity: 1;
  transform: scale(1);
}
collab-messages-chat-message-102025 .reaction-picker-item:hover {
  transform: scale(1.25);
}
collab-messages-chat-message-102025 .reaction-picker-item {
  font-size: 18px;
  cursor: pointer;
  border: none;
  background: transparent;
  transition: transform 0.1s ease;
}
collab-messages-chat-message-102025 .reaction-picker-item:hover {
  transform: scale(1.2);
}
collab-messages-chat-message-102025 .message:hover .reaction.add {
  opacity: 1;
  pointer-events: auto;
  transform: scale(1);
}
collab-messages-chat-message-102025 .reaction.add {
  opacity: 0;
  pointer-events: none;
  transform: scale(0.9);
  transition: opacity 0.15s ease, transform 0.15s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  filter: grayscale(100%) brightness(100%) opacity(90%);
  border-radius: 20px;
  background: #f5f5f5;
  width: 29px;
  height: 29px;
}
collab-messages-chat-message-102025 .message-action.submenu {
  opacity: 0;
  pointer-events: none;
  position: absolute;
  right: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border-radius: 50%;
  border: 1px solid rgba(255, 255, 255, 0.25);
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
  color: var(--text-primary-color);
  cursor: pointer;
  transition: opacity 0.15s ease, transform 0.15s ease, background 0.15s ease;
}
collab-messages-chat-message-102025 .message:hover .message-action.submenu {
  opacity: 1;
  pointer-events: auto;
  transform: scale(1);
}
collab-messages-chat-message-102025 .message-menu {
  position: absolute;
  min-width: 180px;
  background: var(--bg-primary-color);
  border-radius: 6px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  padding: 4px;
  z-index: 30;
  max-width: 240px;
  opacity: 0;
  transform: scale(0.95);
  transition: opacity 120ms ease,
            transform 120ms ease;
}
collab-messages-chat-message-102025 .message-menu.open {
  opacity: 1;
  transform: scale(1);
}
collab-messages-chat-message-102025 .message-menu.bottom {
  top: 15%;
  margin-top: 6px;
}
collab-messages-chat-message-102025 .message-menu.top {
  bottom: 100%;
  margin-bottom: 6px;
}
collab-messages-chat-message-102025 .message-menu button {
  border: none;
  background: transparent;
  padding: 6px 12px;
  cursor: pointer;
  font-size: 13px;
  width: 100%;
  text-align: left;
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;
  color: var(--text-primary-color);
}
collab-messages-chat-message-102025 .message-menu button:hover {
  background: var(--grey-color-lighter);
}
collab-messages-chat-message-102025 .message-menu button:disabled {
  cursor: default;
  opacity: 0.45;
}
collab-messages-chat-message-102025 .message-menu button:disabled:hover {
  background: transparent;
}
collab-messages-chat-message-102025 .message-reply-preview {
  display: flex;
  gap: 6px;
  padding: 6px;
  margin-bottom: 6px;
  border-radius: 6px;
  background-color: rgba(194, 189, 184, 0.15);
  cursor: pointer;
}
collab-messages-chat-message-102025 .message-reply-bar {
  width: 3px;
  border-radius: 2px;
  flex-shrink: 0;
}
collab-messages-chat-message-102025 .message.user .message-reply-bar {
  background: var(--success-color);
}
collab-messages-chat-message-102025 .message.system .message-reply-bar {
  background: var(--grey-color);
}
collab-messages-chat-message-102025 .message-reply-content {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
  color: #000;
  opacity: 0.7;
}
collab-messages-chat-message-102025 .message-reply-user {
  font-size: 11px;
  font-weight: 600;
  opacity: 0.8;
}
collab-messages-chat-message-102025 .message-reply-text {
  font-size: 12px;
  overflow: hidden;
  text-overflow: ellipsis;
  opacity: 0.85;
}
`);
        this.allThreads = [];
        this.usersAvaliables = [];
        this.messageMenuPlacement = 'bottom';
        this.reactionListPlacement = 'top';
        this.msg = messages['en'];
        this.reactionEmojis = {
            thumbs_up: '👍',
            laugh: '😂',
            heart: '❤️',
            wow: '😮',
            sad: '😢',
            angry: '😡'
        };
        this.replyCache = new Map();
    }
    updated() {
        this.positionReactionPicker();
        this.positionMessageMenu();
        this.animateReactionPicker();
        this.updateMessageMenuPlacement();
        // this.positionReactionListPopup();
        this.updateReactionListPlacement();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.userPreferenceChat = loadChatPreferences();
        return this.renderMessage();
    }
    renderMessage() {
        const message = this.message;
        if (!message)
            return html `${nothing}`;
        const isSame = message.isSame;
        const dateFormated = formatTimestamp(message.createAt);
        const userToFind = [
            ...this.usersAvaliables,
            ...(this.actualThread?.users || [])
        ].filter((user, index, self) => index === self.findIndex(u => u.userId === user.userId));
        const userName = userToFind.find((user) => user.userId === message.senderId)?.name || message.senderId;
        const userAvatar = userToFind.find((user) => user.userId === message.senderId)?.avatar_url || '';
        const cls = message.senderId === this.userId ? 'user' : 'system';
        const titleTranslated = this.getTitleMessageTranslated(message);
        const hasReactions = message.reactions ? Object.keys(message.reactions).length > 0 : false;
        return html `
            <div class="message ${cls} ${isSame ? 'same' : ''} ${hasReactions ? 'reaction-on' : ''}">
                <div class="message-group">
                    <div class="message-row">
                        ${cls === 'user' ? this.renderReactionButtonAdd(message) : nothing}
                    
                        <div class="message-card ${cls} ${isSame ? 'same' : ''} ${this.isPinned(message) ? 'pinned' : ''}">

                            ${this.renderSubMenuButton(message)}
                            ${this.renderMessageMenu(message)}
                            ${!isSame ? html `<div class="message-title">@${userName}</div>` : ``}
                            ${message.replyTo ? this.renderReplyPreview(message.replyTo) : nothing}
                            ${this.renderMessageByLanguage(message)}
                            ${this.renderAttachments(message)}
                            ${message.isLoading ? html `<span class="loader"></span>` : ''}
                            ${message.isFailed ? html `<div class="failed">
                            <div>
                                <span>${collab_circle_exclamation}</span>
                                <small>${this.msg.msgNotSend}</small>
                            </div>
                            <small>${message.isFailedError}</small>
                        </div>` : ''}
                        
                        ${message.taskId ? html `
                            <div class="message-ai">
                                <collab-messages-task-102025
                                    messageId=${this.getMessageOrderAt(message)}
                                    .context= ${message.context}
                                    lastChanged= ${message.lastChanged}
                                    taskId=${message.taskId}
                                    threadId=${this.actualThread?.thread.threadId}
                                    userId=${this.userId}
                                    title=${titleTranslated}
                                    status=${message.taskStatus}
                                    .notificationPending=${hasTaskNotificationPending(message.taskId)}
                                    @taskclick=${() => { if (this.onTaskClick)
            this.onTaskClick(message?.taskId || '', this.getMessageOrderAt(message), message.threadId, message); }}
                                >
                                </collab-messages-task-102025>
                            </div> ` : html ``}
                            ${this.renderMessageResultByLanguage(message)}
                            ${this.renderReadConfirmations(message)}
                            ${this.renderMessageFooterResult(message)}
                            ${this.renderReactions(message)}
                            ${this.renderReactionPicker(message)}
                            <div class="message-footer">${dateFormated?.timeShort}</div>
                        </div>
                        ${cls === 'system' ? this.renderReactionButtonAdd(message) : nothing}
                        ${cls === 'system' && !isSame ? html `<collab-messages-avatar-102025 avatar=${userAvatar} alt=${userName} ></collab-messages-avatar-102025>` : ''}
                    </div>
                </div>
            </div>

         `;
    }
    renderMessageByLanguage(message) {
        const mode = this.userPreferenceChat?.translationMode || 'icon';
        if (!this.userPreferenceChat || mode === 'none' || !message.translations) {
            return html `
            <div class="message-content">
                ${this.renderCollabMessagesRichPreview(message.content)} 
            </div>`;
        }
        const { language } = this.userPreferenceChat;
        const messageByLanguagePref = message.translations ? message.translations[language] : '';
        const isSameLanguege = language === message.language_detected;
        switch (mode) {
            case 'icon':
                return html `
                <div class="message-content">
                    ${this.renderCollabMessagesRichPreview(messageByLanguagePref || message.content)} 
                     ${!isSameLanguege ? collab_translate : ''}
                </div>`;
            case 'text':
                return html `
                <div class="message-content">
                    ${this.renderCollabMessagesRichPreview(messageByLanguagePref || message.content)}   
                </div>
                ${!isSameLanguege ?
                    html `<small class="message-content translate">
                            ${this.renderCollabMessagesRichPreview(message.content)}   
                        </small>`
                    : ''}`;
            case 'iconText':
                return html `
                    <div class="message-content">
                        ${this.renderCollabMessagesRichPreview(messageByLanguagePref || message.content)}   
                        ${!isSameLanguege ? collab_translate : ''}
                    </div>
                ${!isSameLanguege ?
                    html `<small class="message-content translate">
                        ${this.renderCollabMessagesRichPreview(message.content)}    
                    </small>`
                    : ''}`;
            case 'trace':
                return html `
                <div class="message-content trace">
                    <div>
                        <b>[LanguageDetected: ${message.language_detected}]</b>
                        ${this.renderCollabMessagesRichPreview(message.content)}   
                    </div>
                    ${Object.keys(message.translations).map((key) => {
                    if (key === 'language_detected')
                        return '';
                    if (key === message.language_detected)
                        return '';
                    return html `
                            <div>
                                <b>[${key}]</b>
                                ${this.renderCollabMessagesRichPreview(message.translations ? message.translations[key] : '')}                        
                            </div>`;
                })}
                </div>`;
            default:
                return null;
        }
    }
    renderAttachments(message) {
        if (!message.attachments?.length)
            return nothing;
        return html `
            <div class="message-attachments">
                ${message.attachments.map(attachment => this.renderAttachment(message, attachment))}
            </div>
        `;
    }
    renderAttachment(message, attachment) {
        if (attachment.status === 'deleted') {
            return html `
                <div class="message-attachment deleted">
                    ${collab_paperclip}
                    <span>${attachment.fileName}</span>
                    <small>
                        ${this.msg.attachmentRemoved}
                        @${this.getUserName(attachment.deletedBy)}
                        ${attachment.deletedAt ? this.formatLocalDateTime(attachment.deletedAt) : ''}
                    </small>
                </div>
            `;
        }
        const canDelete = this.canDeleteAttachment(attachment);
        if (attachment.kind === 'image') {
            return html `
                <div class="message-attachment image">
                    <a
                        href=${attachment.url || '#'}
                        target="_blank"
                        rel="noopener noreferrer"
                        title=${this.msg.openAttachment}
                        @click=${(ev) => this.openAttachment(ev, message, attachment)}
                    >
                        <img
                            src=${attachment.url || ''}
                            alt=${attachment.fileName}
                            loading="lazy"
                            @error=${(ev) => this.refreshAttachmentImage(ev, message, attachment)}
                        />
                    </a>
                    <div class="attachment-meta">
                        <span>${attachment.fileName}</span>
                        <small>${this.formatFileSize(attachment.sizeBytes)}</small>
                        ${canDelete ? this.renderDeleteAttachmentButton(message, attachment) : nothing}
                    </div>
                </div>
            `;
        }
        return html `
            <div class="message-attachment file">
                <a
                    href=${attachment.url || '#'}
                    target="_blank"
                    rel="noopener noreferrer"
                    title=${this.msg.openAttachment}
                    @click=${(ev) => this.openAttachment(ev, message, attachment)}
                >
                    ${collab_paperclip}
                    <span>${attachment.fileName}</span>
                    <small>${this.formatFileSize(attachment.sizeBytes)}</small>
                </a>
                ${canDelete ? this.renderDeleteAttachmentButton(message, attachment) : nothing}
            </div>
        `;
    }
    renderDeleteAttachmentButton(message, attachment) {
        return html `
            <button
                class="attachment-delete"
                title=${this.msg.deleteAttachment}
                aria-label=${this.msg.deleteAttachment}
                @click=${(ev) => this.onDeleteAttachmentClick(ev, message, attachment)}
            >
                ${collab_delete}
            </button>
        `;
    }
    async openAttachment(ev, message, attachment) {
        ev.preventDefault();
        const url = await this.loadAttachmentUrl(message, attachment);
        window.open(url, '_blank', 'noopener,noreferrer');
    }
    async refreshAttachmentImage(ev, message, attachment) {
        const image = ev.currentTarget;
        if (!image || image.dataset.refreshing === 'true')
            return;
        image.dataset.refreshing = 'true';
        try {
            image.src = await this.loadAttachmentUrl(message, attachment);
        }
        finally {
            image.dataset.refreshing = 'false';
        }
    }
    async loadAttachmentUrl(message, attachment) {
        if (!this.userId)
            throw new Error('User not found');
        const result = await msgGetAttachmentUrl({
            userId: this.userId,
            threadId: message.threadId,
            messageId: message.orderAt || message.createAt,
            attachmentId: attachment.attachmentId
        });
        if (!result.success || !result.response?.url) {
            throw new Error(result.error || 'Failed to open attachment');
        }
        attachment.url = result.response.url;
        return result.response.url;
    }
    onDeleteAttachmentClick(ev, message, attachment) {
        ev.preventDefault();
        ev.stopPropagation();
        this.dispatchEvent(new CustomEvent('delete-attachment-message', {
            detail: {
                message,
                attachmentId: attachment.attachmentId
            },
            bubbles: true,
            composed: true
        }));
    }
    canDeleteAttachment(attachment) {
        if (attachment.uploadedBy === this.userId)
            return true;
        const currentThreadUser = this.actualThread?.thread.users.find(user => user.userId === this.userId);
        return currentThreadUser?.auth === 'admin' || currentThreadUser?.auth === 'moderator';
    }
    getUserName(userId) {
        if (!userId)
            return '';
        return this.usersAvaliables.find(user => user.userId === userId)?.name || userId;
    }
    formatFileSize(size) {
        if (size < 1024)
            return `${size} B`;
        if (size < 1024 * 1024)
            return `${Math.round(size / 1024)} KB`;
        return `${(size / (1024 * 1024)).toFixed(1)} MB`;
    }
    renderReplyPreview(replyId) {
        if (!this.replyCache.has(replyId)) {
            this.replyCache.set(replyId, this.loadReplyPreview(replyId));
        }
        return until(this.replyCache.get(replyId), html `<div class="message-reply-preview loading">${this.msg.loading}</div>`);
    }
    async loadReplyPreview(replyId) {
        if (!this.actualThread)
            return html `${nothing}`;
        const messageId = this.normalizeMessageId(this.actualThread.thread.threadId, replyId);
        const reply = await getMessage(messageId);
        if (!reply)
            return html `${nothing}`;
        const user = this.usersAvaliables.find(u => u.userId === reply.senderId) ||
            this.actualThread?.users?.find(u => u.userId === reply.senderId);
        let name = reply.senderId;
        if (user?.name) {
            name = user.userId === this.userId ? this.msg.you : '@' + user.name;
        }
        return html `
        <div
            class="message-reply-preview"
            @click=${() => this.onReplyPreviewClick(reply.createAt)}
        >
            <div class="message-reply-bar"></div>

            <div class="message-reply-content">
                <div class="message-reply-user">
                    ${name}
                </div>

                <div class="message-reply-text">
                    ${this.renderCollabMessagesRichPreview(reply.content)}  
                </div>
            </div>
        </div>
    `;
    }
    onReplyPreviewClick(messageId) {
        this.dispatchEvent(new CustomEvent('reply-preview-click', {
            detail: { messageId },
            bubbles: true,
            composed: true
        }));
    }
    renderMessageResultByLanguage(message) {
        if (!message.taskResults || message.taskResults.length === 0 || message.taskStatus !== 'done')
            return html ``;
        const mode = this.userPreferenceChat?.translationMode || 'icon';
        if (!this.userPreferenceChat || mode === 'none') {
            return html `<div class="message-content">${message.taskResults[0]}</div>`;
        }
        const response = message.taskResults[0];
        const { language } = this.userPreferenceChat;
        const messageByLanguagePref = message.taskResultsTranslated ? message.taskResultsTranslated[language] : '';
        const isSameLanguege = language === message.taskResultsTranslated?.language_detected;
        switch (mode) {
            case 'icon':
                return html `<div class="message-content">${messageByLanguagePref || response} ${!isSameLanguege ? collab_translate : ''}</div>`;
            case 'text':
                return html `
                <div class="message-content">${messageByLanguagePref || response}</div>
                ${!isSameLanguege ? html `<small class="message-content translate">${response}</small>` : ''}`;
            case 'iconText':
                return html `<div class="message-content">${messageByLanguagePref || response} ${!isSameLanguege ? collab_translate : ''}</div>
                ${!isSameLanguege ? html `<small class="message-content translate">${response}</small>` : ''}`;
            case 'trace':
                return html `<div class="message-content trace">
                <div><b>[LanguageDetected: ${message.language_detected}]</b> ${response}</div>
                ${Object.keys(message.taskResultsTranslated || {}).map((key) => {
                    if (key === 'language_detected')
                        return '';
                    if (key === message.taskResultsTranslated?.language_detected)
                        return '';
                    return html `<div><b>[${key}]</b> ${message.taskResultsTranslated ? message.taskResultsTranslated[key] : ''}</div>`;
                })}
                </div>`;
            default:
                return null;
        }
    }
    renderReadConfirmations(message) {
        if (!message.readConfirmations || message.readConfirmations.length === 0)
            return nothing;
        const statusByUser = this.getReadConfirmationStatusByUser(message.readConfirmations);
        return html `
            <div class="message-read-confirmations">
                <div class="message-read-confirmation">
                    ${message.readConfirmations.map(request => html `
                        <div class="read-confirmation-line">
                            ${this.renderUserLabel(request.requestedBy)}
                            <span>${this.msg.requestedReadConfirmation}</span>
                            <span class="read-confirmation-time">${this.formatLocalDateTime(request.requestedAt)}</span>
                        </div>
                    `)}
                    ${statusByUser.map(({ userId, confirmedAt }) => html `
                        <div class="read-confirmation-line ${confirmedAt ? 'confirmed' : 'pending'}">
                            ${this.renderUserLabel(userId)}
                            ${confirmedAt ? html `
                                <span>${this.msg.confirmedRead}</span>
                                <span class="read-confirmation-time">${this.formatLocalDateTime(confirmedAt)}</span>
                            ` : html `<span>${this.msg.notConfirmedRead}</span>`}
                        </div>
                    `)}
                    ${message.readConfirmations.map(request => request.canceledAt ? html `
                        <div class="read-confirmation-line canceled">
                            ${this.renderUserLabel(request.canceledBy || request.requestedBy)}
                            <span>${this.msg.canceledReadConfirmation}</span>
                            <span class="read-confirmation-time">${this.formatLocalDateTime(request.canceledAt)}</span>
                        </div>
                    ` : nothing)}
                </div>
            </div>
        `;
    }
    getReadConfirmationStatusByUser(readConfirmations) {
        const statusByUser = new Map();
        for (const request of readConfirmations) {
            for (const userId of request.targetUserIds) {
                const confirmedAt = request.confirmedBy?.[userId];
                const current = statusByUser.get(userId);
                if (!current) {
                    statusByUser.set(userId, { userId, confirmedAt });
                    continue;
                }
                if (!current.confirmedAt && confirmedAt) {
                    statusByUser.set(userId, { userId, confirmedAt });
                }
            }
        }
        return [...statusByUser.values()];
    }
    renderUserLabel(userId) {
        const user = this.findUser(userId);
        return html `<span class="read-confirmation-user">@${user?.name || userId}</span>`;
    }
    formatLocalDateTime(timestamp) {
        return formatTimestamp(timestamp)?.dateFull || timestamp;
    }
    renderMessageFooterResult(message) {
        if (!message.footers || message.footers.length === 0)
            return html ``;
        return html `<div class="message-result">
            ${message.footers?.map((footer) => {
            const content = footer.lines.join('\n').trim();
            if (!content)
                return html ``;
            return html `
                <div class="message-result-text">
                    <b>${footer.title?.trim()}</b>
                    <div>
                        ${this.renderCollabMessagesRichPreview(footer.lines.join('\n').trim())}                    
                    </div>
                </div>`;
        })}
        </div>`;
    }
    renderCollabMessagesRichPreview(text) {
        if (text.trim().startsWith('@@'))
            text = text.slice(0, 300) + (text.length > 300 ? '...' : '');
        return html `
        <collab-messages-rich-preview-text-102025 
            @mention-click=${this.onMentionClick}
            @channel-hover=${this.onChannelHover}
            .allUsers=${this.usersAvaliables} 
            .allThreads=${this.allThreads}
            text="${text}"
        ></collab-messages-rich-preview-text-102025>`;
    }
    async onMentionClick(ev) {
        this.removeAllUserModal();
        if (!ev.detail || !ev.detail.userId || !ev.detail.element)
            return;
        const actualUserModal = this.usersAvaliables.find((user) => user.userId === ev.detail.userId);
        if (!actualUserModal)
            return;
        const rects = ev.detail.element.getBoundingClientRect();
        const modal = document.createElement('collab-messages-user-modal-102025');
        modal.user = actualUserModal;
        modal.setAttribute('actualUserId', this.userId);
        modal.isDirectMessage = this.isCurrentThreadDirectMessage();
        this.appendChild(modal);
        await modal.updateComplete;
        const rectsModal = modal.getBoundingClientRect();
        this.positionModalByTarget(modal, rects, rectsModal);
    }
    positionModalByTarget(modal, targetRect, modalRect) {
        const margin = 8;
        const width = modalRect.width || 280;
        const height = modalRect.height || 0;
        const maxLeft = Math.max(margin, window.innerWidth - width - margin);
        const maxTop = Math.max(margin, window.innerHeight - height - margin);
        let left = targetRect.left + (targetRect.width / 2) - (width / 2);
        let top = targetRect.bottom + margin;
        if (top + height > window.innerHeight - margin) {
            top = targetRect.top - height - margin;
        }
        modal.style.position = 'fixed';
        modal.style.left = `${Math.min(Math.max(left, margin), maxLeft)}px`;
        modal.style.top = `${Math.min(Math.max(top, margin), maxTop)}px`;
    }
    isCurrentThreadDirectMessage() {
        const thread = this.actualThread?.thread;
        return Boolean(thread?.name?.startsWith('@') && thread.users?.length === 2);
    }
    async onChannelHover(ev) {
        this.removeAllChannelModal();
        if (!ev.detail || !ev.detail.threadId || !ev.detail.element)
            return;
        const actualThreadModal = this.allThreads.find((thread) => thread.threadId === `${ev.detail.threadId}`);
        if (!actualThreadModal)
            return;
        const rects = ev.detail.element.getBoundingClientRect();
        const modal = document.createElement('collab-messages-thread-modal-102025');
        modal.thread = actualThreadModal;
        this.appendChild(modal);
        await modal.updateComplete;
        const rectsModal = modal.getBoundingClientRect();
        modal.style.top = (rects.top - rectsModal.height - rects.height - 70) + 'px';
        modal.style.left = '20px';
    }
    removeAllUserModal() {
        const all = this.querySelectorAll('collab-messages-user-modal-102025');
        all.forEach((item) => item.remove());
    }
    removeAllChannelModal() {
        const all = this.querySelectorAll('collab-messages-thread-modal-102025');
        all.forEach((item) => item.remove());
    }
    getTitleMessageTranslated(message) {
        const mode = this.userPreferenceChat?.translationMode || 'icon';
        if (!this.userPreferenceChat || mode === 'none' || !message.taskTitleTranslated) {
            return message.taskTitle;
        }
        const { language } = this.userPreferenceChat;
        const titleByLanguagePref = message.taskTitleTranslated ? (message.taskTitleTranslated[language] ? message.taskTitleTranslated[language] : message.taskTitle) : message.taskTitle;
        return titleByLanguagePref;
    }
    //Reactions
    renderReactions(message) {
        if (!message.reactions)
            return nothing;
        const totalReactions = Object.values(message.reactions).reduce((acc, users) => acc + users.length, 0);
        if (totalReactions === 0)
            return nothing;
        return html `
        <div class="message-reactions">
            <button 
                class="reactions-summary"
                @click=${(ev) => this.openReactionList(message, ev)}
            >
                ${Object.entries(message.reactions).map(([name, users]) => {
            const emoji = this.reactionEmojis[name];
            if (!emoji || users.length === 0)
                return nothing;
            return html `<span class="reaction-emoji">${emoji}</span>`;
        })}
                <span class="reaction-count">${totalReactions}</span>
            </button>
            ${this.renderReactionListPopup(message)}
        </div>
    `;
    }
    renderReactionListPopup(message) {
        if (this.openedReactionListMessageId !== message.createAt)
            return nothing;
        if (!message.reactions)
            return nothing;
        const allReactions = [];
        Object.entries(message.reactions).forEach(([name, users]) => {
            const emoji = this.reactionEmojis[name];
            if (emoji) {
                users.forEach(userId => {
                    allReactions.push({ userId, emoji, reactionName: name });
                });
            }
        });
        allReactions.sort((a, b) => {
            if (a.userId === this.userId)
                return -1;
            if (b.userId === this.userId)
                return 1;
            return 0;
        });
        const totalCount = allReactions.length;
        const reactionWord = totalCount === 1 ? this.msg.reaction : this.msg.reactions;
        return html `
        <div class="reaction-list-popup ${this.reactionListPlacement}">
            <div class="reaction-list-header">
                ${totalCount} ${reactionWord}
            </div>
            <div class="reaction-list-divider"></div>
            <div class="reaction-list-content">
                ${allReactions.map(({ userId, emoji, reactionName }) => {
            const user = this.findUser(userId);
            const userName = user?.name || userId;
            const userAvatar = user?.avatar_url || '';
            const isCurrentUser = userId === this.userId;
            return html `
                        <div 
                            class="reaction-list-item ${isCurrentUser ? 'current-user' : ''}"
                            @click=${() => isCurrentUser ? this.removeReactionFromList(message, reactionName) : null}
                        >
                            <div class="reaction-list-user">
                                <collab-messages-avatar-102025 
                                    avatar=${userAvatar}
                                    alt=${userName}
                                ></collab-messages-avatar-102025>
                                <div class="reaction-list-detail">
                                    <span class="reaction-list-name">
                                        ${isCurrentUser ? this.msg.you : userName}
                                    </span>
                                    ${isCurrentUser ? html `<small class="reaction-list-small">${this.msg.clickToRemove}</small>` : nothing}
                                </div>

                            </div>
                            <span class="reaction-list-emoji">${emoji}</span>
                        </div>
                    `;
        })}
            </div>
        </div>
    `;
    }
    findUser(userId) {
        return [
            ...this.usersAvaliables,
            ...(this.actualThread?.users || [])
        ].find(user => user.userId === userId);
    }
    openReactionList(message, ev) {
        ev.stopPropagation();
        if (this.openedReactionListMessageId === message.createAt) {
            this.closeReactionList();
            return;
        }
        this.closeAllPopups();
        this.openedReactionListMessageId = message.createAt;
        this.reactionListTarget = ev.currentTarget;
        this.updateReactionListPlacement();
    }
    updateReactionListPlacement() {
        if (!this.reactionListTarget)
            return;
        const popup = this.renderRoot.querySelector('.reaction-list-popup');
        if (!popup)
            return;
        const targetRect = this.reactionListTarget.getBoundingClientRect();
        const popupRect = popup.getBoundingClientRect();
        const viewportHeight = window.innerHeight;
        const spaceBelow = viewportHeight - targetRect.bottom;
        const spaceAbove = targetRect.top;
        const shouldOpenTop = spaceBelow < popupRect.height && spaceAbove > spaceBelow;
        this.reactionListPlacement = shouldOpenTop ? 'top' : 'bottom';
        requestAnimationFrame(() => {
            popup.classList.add('open');
        });
    }
    removeReactionFromList(message, reactionName) {
        if (!this.userId)
            return;
        const updated = this.toggleReaction(message, reactionName, this.userId);
        this.message = updated;
        const totalReactions = updated.reactions
            ? Object.values(updated.reactions).reduce((acc, users) => acc + users.length, 0)
            : 0;
        if (totalReactions === 0) {
            this.closeReactionList();
        }
    }
    closeReactionList() {
        this.openedReactionListMessageId = undefined;
        this.reactionListTarget = undefined;
    }
    renderReactionButtonAdd(message) {
        return html `
            <button
                class="reaction add"
                @click=${(ev) => this.openReactionPicker(message, ev)}
            >
                ${collab_smile}
            </button>
        `;
    }
    renderReactionPicker(message) {
        if (this.openedReactionMessageId !== message.createAt)
            return nothing;
        return html `
        <div class="reaction-picker">
            ${Object.entries(this.reactionEmojis).map(([name, emoji]) => html `
                <button
                    class="reaction-picker-item"
                    @click=${() => this.onPickerEmojiSelect(message, name)}
                >
                    ${emoji}
                </button>
            `)}
        </div>
    `;
    }
    onPickerEmojiSelect(message, emoji) {
        if (!this.userId)
            return;
        const updated = this.toggleReaction(message, emoji, this.userId);
        this.message = updated;
        this.closeReactionPicker();
    }
    openReactionPicker(message, ev) {
        ev?.stopPropagation();
        if (this.openedReactionMessageId === message.createAt) {
            this.closeReactionPicker();
            return;
        }
        this.closeReactionPicker();
        this.openedReactionMessageId = message.createAt;
        this.reactionPickerTarget = ev?.currentTarget;
    }
    closeReactionPicker() {
        this.openedReactionMessageId = undefined;
        this.reactionPickerTarget = undefined;
        this.closeAllPopups();
    }
    toggleReaction(message, reaction, userId) {
        const current = message.reactions ?? {};
        const next = {};
        for (const [name, users] of Object.entries(current)) {
            const filtered = users.filter(id => id !== userId);
            if (filtered.length) {
                next[name] = filtered;
            }
        }
        if (!current[reaction]?.includes(userId)) {
            next[reaction] = [...(next[reaction] ?? []), userId];
        }
        this.updateReactionOnDb(message, reaction);
        return {
            ...message,
            reactions: Object.keys(next).length ? next : undefined,
            lastChanged: Date.now()
        };
    }
    async updateReactionOnDb(message, reaction) {
        if (!this.actualThread?.thread.threadId)
            throw new Error('Invalid thread id');
        if (!this.userId)
            throw new Error('Invalid user id');
        const result = await msgUpdateMessage({
            messageId: message.createAt,
            threadId: this.actualThread.thread.threadId,
            userId: this.userId,
            reaction,
        });
        if (!result.success || !result.response?.message) {
            throw new Error(result.error || 'Failed to update message reaction');
        }
        this.message = {
            ...result.response.message,
            footers: message.footers
        };
        await updateMessage(this.message);
    }
    animateReactionPicker() {
        const picker = this.querySelector('.reaction-picker');
        if (!picker)
            return;
        const items = Array.from(picker.querySelectorAll('.reaction-picker-item'));
        requestAnimationFrame(() => {
            picker.classList.add('open');
            items.forEach((el, i) => {
                setTimeout(() => {
                    el.classList.add('show');
                }, 65 * i);
            });
        });
    }
    positionReactionPicker() {
        if (!this.reactionPickerTarget)
            return;
        const picker = this.querySelector('.reaction-picker');
        if (!picker)
            return;
        const btnRect = this.reactionPickerTarget.getBoundingClientRect();
        const pickerRect = picker.getBoundingClientRect();
        const parent = picker.offsetParent;
        const parentRect = parent.getBoundingClientRect();
        const GAP = 8;
        const top = btnRect.top -
            parentRect.top -
            pickerRect.height -
            GAP;
        picker.style.top = `${Math.max(top, 4)}px`;
        picker.style.bottom = 'auto';
        if (parent.classList.contains('user')) {
            picker.style.right = '0';
            picker.style.left = 'auto';
        }
        else {
            picker.style.left = '0';
            picker.style.right = 'auto';
        }
    }
    // REPLY
    renderSubMenuButton(message) {
        return html `
        <button
            class="message-action submenu"
            @click=${(ev) => this.openMessageMenu(message, ev)}
        >
            ${collab_chevron_down}
        </button>
    `;
    }
    openMessageMenu(message, ev) {
        ev.stopPropagation();
        if (this.openedMenuFor === message.createAt) {
            this.closeMessageMenu();
            return;
        }
        this.closeMessageMenu();
        this.openedMenuFor = message.createAt;
        this.messageMenuTarget = ev.currentTarget;
    }
    positionMessageMenu() {
        if (!this.messageMenuTarget)
            return;
        const submenu = this.querySelector('.message-menu');
        if (!submenu)
            return;
        const btnRect = this.messageMenuTarget.getBoundingClientRect();
        const pickerRect = submenu.getBoundingClientRect();
        const parent = submenu.offsetParent;
        const parentRect = parent.getBoundingClientRect();
        const GAP = 8;
        const VIEWPORT_GAP = 8;
        const spaceBelow = window.innerHeight - btnRect.bottom;
        let top;
        if (spaceBelow >= pickerRect.height + GAP) {
            top =
                btnRect.bottom -
                    parentRect.top +
                    GAP;
        }
        else {
            top =
                btnRect.top -
                    parentRect.top -
                    pickerRect.height -
                    GAP;
        }
        submenu.style.top = `${top}px`;
        submenu.style.bottom = 'auto';
        if (parent.classList.contains('user')) {
            submenu.style.right = '10px';
            submenu.style.left = 'auto';
        }
        else {
            submenu.style.left = '10px';
            submenu.style.right = 'auto';
        }
        const menuRect = submenu.getBoundingClientRect();
        if (menuRect.left < VIEWPORT_GAP) {
            const currentLeft = parseFloat(submenu.style.left || '0') || 0;
            submenu.style.left = `${currentLeft + VIEWPORT_GAP - menuRect.left}px`;
            submenu.style.right = 'auto';
        }
        else if (menuRect.right > window.innerWidth - VIEWPORT_GAP) {
            const currentRight = parseFloat(submenu.style.right || '0') || 0;
            submenu.style.right = `${currentRight + menuRect.right - (window.innerWidth - VIEWPORT_GAP)}px`;
            submenu.style.left = 'auto';
        }
    }
    closeMessageMenu() {
        this.openedMenuFor = undefined;
        this.messageMenuTarget = undefined;
        this.closeAllPopups();
    }
    renderMessageMenu(message) {
        if (this.openedMenuFor !== message.createAt)
            return nothing;
        const canCancelReadConfirmation = this.canCancelReadConfirmation(message);
        const canRequestReadConfirmation = this.getMentionedUserIds(message).length > 0 && !this.hasReadConfirmation(message);
        const canConfirmRead = this.hasPendingReadConfirmation(message);
        const allConfirmedRead = this.hasAllReadConfirmationsConfirmed(message);
        return html `
        <div class="message-menu ${this.messageMenuPlacement}">
            <button>
                ${collab_copy}
                ${this.msg.copy}
            </button>
            <button @click=${() => this.onReplyClick(message)}>
                ${collab_reply}
                ${this.msg.reply}
            </button>
            <button @click=${() => this.onPinClick(message)}>
                ${collab_pin}
                ${this.isPinned(message) ? this.msg.unpin : this.msg.pin}
            </button>
            <button @click=${() => this.onFavoriteClick(message)}>
                ${collab_star}
                ${this.isFavorite(message) ? this.msg.unfavorite : this.msg.favorite}
            </button>
            <button
                ?disabled=${!canRequestReadConfirmation && !canCancelReadConfirmation}
                @click=${() => this.onReadConfirmationClick(message, canCancelReadConfirmation ? 'cancel' : 'request')}
            >
                ${collab_circle_exclamation}
                ${canCancelReadConfirmation ? this.msg.cancelReadConfirmation : this.msg.requestReadConfirmation}
            </button>
            <button ?disabled=${!canConfirmRead} @click=${() => this.onReadConfirmationClick(message, 'confirm')}>
                ${collab_circle_exclamation}
                ${this.msg.confirmRead}
            </button>
            ${allConfirmedRead ? html `
                <button disabled>
                    ${collab_circle_exclamation}
                    ${this.msg.allConfirmedRead}
                </button>
            ` : nothing}
            <button>
                ${collab_edit}
                ${this.msg.edit}
            </button>
            <button>
                ${collab_delete}
                ${this.msg.delete}
            </button>
        
        </div>
    `;
    }
    onReplyClick(message) {
        this.closeMessageMenu();
        this.dispatchEvent(new CustomEvent('reply-message', {
            detail: message,
            bubbles: true,
            composed: true
        }));
    }
    onPinClick(message) {
        this.closeMessageMenu();
        this.dispatchEvent(new CustomEvent('pin-message', {
            detail: {
                message,
                pin: !this.isPinned(message)
            },
            bubbles: true,
            composed: true
        }));
    }
    onFavoriteClick(message) {
        this.closeMessageMenu();
        this.dispatchEvent(new CustomEvent('favorite-message', {
            detail: {
                message,
                favorite: !this.isFavorite(message)
            },
            bubbles: true,
            composed: true
        }));
    }
    onReadConfirmationClick(message, action) {
        this.closeMessageMenu();
        this.dispatchEvent(new CustomEvent('read-confirmation-message', {
            detail: {
                message,
                action
            },
            bubbles: true,
            composed: true
        }));
    }
    isPinned(message) {
        const messageId = `${message.threadId}/${message.orderAt || message.createAt}`;
        return !!this.actualThread?.thread.pinnedMessages?.some(item => item.messageId === messageId);
    }
    isFavorite(message) {
        const messageId = `${message.threadId}/${message.orderAt || message.createAt}`;
        return !!this.currentUser?.favorites?.includes(messageId);
    }
    getMentionedUserIds(message) {
        if (!this.userId)
            return [];
        const usersInThread = new Set(this.actualThread?.thread.users.map(user => user.userId) || []);
        return [...message.content.matchAll(/\[@[^\]]+\]\(([^)]+)\)/g)]
            .map(match => match[1])
            .filter(userId => userId !== this.userId && usersInThread.has(userId))
            .filter((userId, index, items) => items.indexOf(userId) === index);
    }
    hasReadConfirmation(message) {
        return !!message.readConfirmations?.length;
    }
    hasPendingReadConfirmation(message) {
        if (!this.userId)
            return false;
        return !!message.readConfirmations?.some(request => !request.canceledAt &&
            request.targetUserIds.includes(this.userId) && !request.confirmedBy?.[this.userId]);
    }
    hasAllReadConfirmationsConfirmed(message) {
        if (!this.userId)
            return false;
        return !!message.readConfirmations?.some(request => !request.canceledAt &&
            request.requestedBy === this.userId && request.targetUserIds.length > 0 &&
            request.targetUserIds.every(userId => !!request.confirmedBy?.[userId]));
    }
    canCancelReadConfirmation(message) {
        if (!this.userId)
            return false;
        return !!message.readConfirmations?.some(request => !request.canceledAt &&
            request.requestedBy === this.userId &&
            request.targetUserIds.some(userId => !request.confirmedBy?.[userId]));
    }
    closeAllPopups() {
        if (!this.parentElement)
            return;
        const all = Array.from(this.parentElement.querySelectorAll('collab-messages-chat-message-102025'));
        all.forEach((item) => {
            item.openedReactionMessageId = undefined;
            item.reactionPickerTarget = undefined;
            item.openedMenuFor = undefined;
            item.messageMenuTarget = undefined;
            item.openedReactionListMessageId = undefined;
            item.reactionListTarget = undefined;
        });
    }
    updateMessageMenuPlacement() {
        if (!this.messageMenuTarget)
            return;
        const menu = this.renderRoot.querySelector('.message-menu');
        if (!menu)
            return;
        const targetRect = this.messageMenuTarget.getBoundingClientRect();
        const menuRect = menu.getBoundingClientRect();
        const viewportHeight = window.innerHeight;
        const spaceBelow = viewportHeight - targetRect.bottom;
        const spaceAbove = targetRect.top;
        const shouldOpenTop = spaceBelow < menuRect.height && spaceAbove > spaceBelow;
        this.messageMenuPlacement = shouldOpenTop ? 'top' : 'bottom';
        requestAnimationFrame(() => {
            menu.classList.add('open');
        });
    }
    getMessageOrderAt(message) {
        const value = message.orderAt || message.createAt || '';
        const parts = value.split('/').filter(Boolean);
        return parts[parts.length - 1] || value;
    }
    normalizeMessageId(threadId, messageIdOrOrderAt) {
        const parts = messageIdOrOrderAt.split('/').filter(Boolean);
        const orderAt = parts[parts.length - 1] || messageIdOrOrderAt;
        return `${threadId}/${orderAt}`;
    }
};
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "message", void 0);
__decorate([
    property({ reflect: true })
], CollabMessagesChatMessage102025.prototype, "messageId", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesChatMessage102025.prototype, "allThreads", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "actualThread", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "usersAvaliables", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "currentUser", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "userId", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesChatMessage102025.prototype, "openedReactionMessageId", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesChatMessage102025.prototype, "reactionPickerTarget", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "openedMenuFor", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "messageMenuTarget", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "openedReactionListMessageId", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "reactionListTarget", void 0);
__decorate([
    state()
], CollabMessagesChatMessage102025.prototype, "userPreferenceChat", void 0);
__decorate([
    state()
], CollabMessagesChatMessage102025.prototype, "messageMenuPlacement", void 0);
__decorate([
    state()
], CollabMessagesChatMessage102025.prototype, "reactionListPlacement", void 0);
CollabMessagesChatMessage102025 = __decorate([
    customElement('collab-messages-chat-message-102025')
], CollabMessagesChatMessage102025);
export { CollabMessagesChatMessage102025 };
