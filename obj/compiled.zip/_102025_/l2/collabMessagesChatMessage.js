/// <mls fileReference="_102025_/l2/collabMessagesChatMessage.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { until } from 'lit/directives/until.js';
import { customElement, property, state } from 'lit/decorators.js';
import { collab_translate, collab_circle_exclamation, collab_smile, collab_chevron_down, collab_reply, collab_copy, collab_pin, collab_star, collab_edit, collab_delete, collab_paperclip, collab_ban, collab_link, collab_tasks, collab_bell_slash, collab_chevron_right, collab_clock_static, collab_xmark, collab_check, collab_play, collab_eye } from '/_102025_/l2/collabMessagesIcons.js';
import { loadChatPreferences, formatTimestamp } from '/_102025_/l2/collabMessagesHelper.js';
import { getMessage, updateMessage } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { msgGetAttachmentUrl, msgUpdateMessage } from '/_102025_/l2/shared/api.js';
import { hasTaskNotificationPending } from '/_102025_/l2/collabMessagesSyncNotifications.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    msgNotSend: 'Mensagem não enviada*',
    reply: 'Responder',
    copy: 'Copiar',
    copyLink: 'Copiar link',
    markUnread: 'Marcar como não lida',
    createTask: 'Criar task',
    forward: 'Encaminhar',
    pin: 'Fixar',
    unpin: 'Desfixar',
    favorite: 'Favoritar',
    unfavorite: 'Remover favorito',
    requestReadConfirmation: 'Confirmação de leitura',
    requestExecutionConfirmation: 'Confirmação de execução',
    followupActions: 'Follow-up ações',
    cancelReadConfirmation: 'Cancelar confirmação de leitura',
    confirmRead: 'Recebi e li a mensagem',
    allConfirmedRead: 'Confirmado que todos receberam',
    deletedMessage: 'Mensagem deletada',
    moderatedMessage: 'Mensagem moderada',
    deletedBy: 'deletada por',
    moderatedBy: 'moderada por',
    originalVisibleToModerators: 'conteúdo original visível para admins e moderadores',
    requestedReadConfirmation: 'pediu confirmação de leitura em',
    requestedExecutionConfirmation: 'pediu confirmação de execução em',
    confirmedRead: 'confirmou leitura em',
    canceledReadConfirmation: 'cancelou confirmação de leitura em',
    notConfirmedRead: 'não confirmado',
    followupPending: 'pendente',
    followupLido: 'Lido',
    followupVouFazer: 'Vou fazer',
    followupConcluido: 'Concluído',
    followupBloqueado: 'Bloqueado',
    followupCancelado: 'Cancelado',
    followupRevisado: 'Revisado',
    delete: 'Apagar',
    moderate: 'Moderar',
    edit: 'Editar',
    edited: 'editado',
    save: 'Salvar',
    cancel: 'Cancelar',
    viewHistory: 'Ver histórico',
    showHistory: 'ver mais',
    hideHistory: 'ver menos',
    editHistory: 'Histórico de edições',
    originalMessage: 'Mensagem original',
    editedBy: 'Editada por',
    currentMessage: 'Mensagem atual',
    you: 'Você',
    reactions: 'reações',
    reaction: 'reação',
    clickToRemove: 'Clique para remover',
    attachmentRemoved: 'Anexo removido por',
    openAttachment: 'Abrir anexo',
    deleteAttachment: 'Apagar anexo',
};
const message_en = {
    loading: 'Loading...',
    msgNotSend: 'Message not sent*',
    reply: 'Reply',
    copy: 'Copy',
    copyLink: 'Copy link',
    markUnread: 'Mark as unread',
    createTask: 'Create task',
    forward: 'Forward',
    pin: 'Pin',
    unpin: 'Unpin',
    favorite: 'Favorite',
    unfavorite: 'Remove favorite',
    requestReadConfirmation: 'Read confirmation',
    requestExecutionConfirmation: 'Execution confirmation',
    followupActions: 'Follow-up actions',
    cancelReadConfirmation: 'Cancel read confirmation',
    confirmRead: 'I received and read the message',
    allConfirmedRead: 'Confirmed that everyone received it',
    deletedMessage: 'Deleted message',
    moderatedMessage: 'Moderated message',
    deletedBy: 'deleted by',
    moderatedBy: 'moderated by',
    originalVisibleToModerators: 'original content visible to admins and moderators',
    requestedReadConfirmation: 'requested read confirmation at',
    requestedExecutionConfirmation: 'requested execution confirmation at',
    confirmedRead: 'confirmed reading at',
    canceledReadConfirmation: 'canceled read confirmation at',
    notConfirmedRead: 'not confirmed',
    followupPending: 'pending',
    followupLido: 'Read',
    followupVouFazer: 'Will do',
    followupConcluido: 'Done',
    followupBloqueado: 'Blocked',
    followupCancelado: 'Canceled',
    followupRevisado: 'Reviewed',
    delete: 'Delete',
    moderate: 'Moderate',
    edit: 'Edit',
    edited: 'edited',
    save: 'Save',
    cancel: 'Cancel',
    viewHistory: 'View history',
    showHistory: 'show more',
    hideHistory: 'show less',
    editHistory: 'Edit history',
    originalMessage: 'Original message',
    editedBy: 'Edited by',
    currentMessage: 'Current message',
    you: 'You',
    reactions: 'reactions',
    reaction: 'reaction',
    clickToRemove: 'Click to remove',
    attachmentRemoved: 'Attachment removed by',
    openAttachment: 'Open attachment',
    deleteAttachment: 'Delete attachment',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
let CollabMessagesChatMessage102025 = class CollabMessagesChatMessage102025 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-chat-message-102025 {
  display: block;
  font-family: var(--font-family-primary);
}
collab-messages-chat-message-102025 .message {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  width: 100%;
  margin-top: 8px;
}
collab-messages-chat-message-102025 .message.reaction-on {
  margin-bottom: 16px;
}
collab-messages-chat-message-102025 .message.user {
  align-items: flex-end;
}
collab-messages-chat-message-102025 .message.same {
  margin-top: 0;
}
collab-messages-chat-message-102025 .message .message-row {
  display: flex;
  align-items: center;
  max-width: 76%;
  min-width: 0;
  margin-bottom: 2px;
  margin-left: 40px;
  position: relative;
  gap: 0.25rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card {
  display: flex;
  flex-direction: column;
  background-color: var(--cm-bubble-in, #ffffff);
  border-radius: 10px;
  padding: 0.42rem 0.58rem 0.32rem;
  position: relative;
  font-size: 13px;
  line-height: 1.34;
  box-sizing: border-box;
  max-width: 100%;
  min-width: 0;
  color: var(--cm-text, #111827);
  box-shadow: var(--cm-shadow-sm, 0 1px 3px rgba(0, 0, 0, 0.14));
}
collab-messages-chat-message-102025 .message .message-row .message-card.system:not(.same) {
  border-top-left-radius: 3px;
}
collab-messages-chat-message-102025 .message .message-row .message-card.system:not(.same):before {
  content: '';
  position: absolute;
  top: 0;
  left: -6px;
  width: 0;
  height: 0;
  border-top: 0 solid transparent;
  border-right: 7px solid var(--cm-bubble-in, #ffffff);
  border-bottom: 9px solid transparent;
}
collab-messages-chat-message-102025 .message .message-row .message-card.user {
  background-color: var(--cm-bubble-out, #aee8c4);
  align-self: flex-end;
}
collab-messages-chat-message-102025 .message .message-row .message-card.user:not(.same) {
  border-top-right-radius: 3px;
}
collab-messages-chat-message-102025 .message .message-row .message-card.user:not(.same):before {
  content: '';
  position: absolute;
  top: 0;
  right: -6px;
  width: 0;
  height: 0;
  border-top: 0 solid transparent;
  border-left: 7px solid var(--cm-bubble-out, #aee8c4);
  border-bottom: 9px solid transparent;
}
collab-messages-chat-message-102025 .message .message-row .message-card.pinned {
  border: 1px solid var(--active-color);
}
collab-messages-chat-message-102025 .message .message-row .message-card.toolbar-highlighted {
  border: 2px solid var(--active-color);
  box-shadow: 0 0 0 2px rgba(24, 144, 255, 0.18);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-title {
  color: var(--cm-green-dark, #007a3d);
  font-size: 12px;
  font-weight: 700;
  margin-bottom: 0.06rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-ai {
  margin-top: 0.25rem;
  display: flex;
  margin-left: auto;
  width: 100%;
}
collab-messages-chat-message-102025 .message .message-row .message-card .failed {
  margin-top: 0.2rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .failed > div {
  display: flex;
  gap: 0.3rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .failed svg {
  fill: var(--error-color);
  width: 14px;
  height: 14px;
}
collab-messages-chat-message-102025 .message .message-row .message-card .failed small {
  color: var(--cm-text, #111827);
  font-style: italic;
  font-size: var(--font-size-12);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-content {
  margin-top: 0.18rem;
  color: var(--cm-text, #111827);
  display: flex;
  align-items: flex-start;
  gap: 0.4rem;
  word-break: break-word;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-content collab-messages-rich-preview-text-102025 {
  flex: 1;
  min-width: 0;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-content collab-messages-rich-preview-text-102025 .inline-code {
  background-color: var(--cm-soft-overlay, rgba(29, 28, 29, 0.07));
  color: #c2185b;
  border-radius: 3px;
  padding: 0 0.12em;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-content svg {
  flex-shrink: 0;
  width: 12px;
  fill: var(--cm-green, #008f4c);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-moderation-notice {
  display: flex;
  align-items: flex-start;
  gap: 0.45rem;
  margin-top: 0.25rem;
  padding: 0.45rem 0.55rem;
  border: 1px solid var(--cm-border-soft, rgba(0, 0, 0, 0.08));
  border-radius: 6px;
  background: var(--cm-soft-overlay, rgba(255, 255, 255, 0.76));
  color: var(--cm-text-muted, #5b635f);
  font-size: var(--font-size-12);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-moderation-notice svg {
  width: 14px;
  height: 14px;
  flex-shrink: 0;
  margin-top: 1px;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-moderation-notice > div {
  display: flex;
  flex-direction: column;
  gap: 0.1rem;
  min-width: 0;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-moderation-notice span {
  color: var(--cm-text, #111827);
  font-weight: 600;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-moderation-notice small {
  color: var(--cm-text-muted, #5b635f);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-moderation-notice.moderated svg {
  color: var(--error-color);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-edit-form {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
  margin-top: 0.35rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-edit-form textarea {
  min-width: 260px;
  min-height: 82px;
  max-width: 100%;
  resize: vertical;
  border: 1px solid var(--cm-border, rgba(0, 0, 0, 0.18));
  background: var(--cm-input-bg, #ffffff);
  color: var(--cm-text, #111827);
  border-radius: 6px;
  padding: 0.45rem;
  font: inherit;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-edit-actions {
  display: flex;
  justify-content: flex-end;
  gap: 0.4rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-edit-actions button {
  border: 1px solid var(--cm-border, rgba(0, 0, 0, 0.16));
  border-radius: 4px;
  background: var(--cm-soft-overlay, rgba(255, 255, 255, 0.78));
  color: var(--cm-text, #111827);
  padding: 0.25rem 0.5rem;
  cursor: pointer;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-edit-history {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
  margin-top: 0.35rem;
  padding: 0.38rem;
  border: 1px solid var(--cm-border-soft, rgba(0, 0, 0, 0.08));
  border-radius: 6px;
  background: var(--cm-soft-overlay, rgba(255, 255, 255, 0.72));
  color: var(--cm-text, #111827);
  font-size: var(--font-size-12);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-edit-history-title {
  font-weight: 600;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-edit-history-item {
  display: flex;
  flex-direction: column;
  gap: 0.15rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-edit-history-item small {
  color: var(--cm-text-muted, #5b635f);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachments {
  display: flex;
  flex-direction: column;
  gap: 0.35rem;
  margin-top: 0.35rem;
  width: min(360px, 100%);
  max-width: 100%;
  min-width: 0;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment {
  border: 1px solid var(--cm-border-soft, rgba(0, 0, 0, 0.08));
  border-radius: var(--cm-radius-sm, 8px);
  background: var(--cm-attachment-bg, rgba(255, 255, 255, 0.78));
  color: var(--cm-text, #111827);
  overflow: hidden;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment a {
  color: inherit;
  text-decoration: none;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment svg {
  width: 16px;
  height: 16px;
  flex-shrink: 0;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment.image {
  width: 100%;
  max-width: 100%;
  background: var(--cm-input-bg, #ffffff);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment.image a {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  background: var(--cm-input-bg, #ffffff);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment.image img {
  display: block;
  width: 100%;
  height: auto;
  max-width: 100%;
  max-height: 360px;
  object-fit: contain;
  background: var(--cm-input-bg, #ffffff);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment.image .attachment-meta {
  display: flex;
  align-items: center;
  gap: 0.35rem;
  padding: 0.3rem 0.4rem;
  font-size: var(--font-size-12);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment.file,
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment.deleted {
  display: flex;
  align-items: center;
  gap: 0.35rem;
  padding: 0.38rem 0.42rem;
  font-size: var(--font-size-12);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment.file a,
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment.deleted a {
  display: flex;
  align-items: center;
  gap: 0.35rem;
  min-width: 0;
  flex: 1;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment span {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  min-width: 0;
  flex: 1;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment small {
  color: var(--cm-text-muted, #5b635f);
  white-space: nowrap;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment.deleted {
  color: var(--cm-text-muted, #5b635f);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment .attachment-delete {
  width: 22px;
  height: 22px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: none;
  border-radius: 4px;
  background: transparent;
  color: var(--cm-text, #111827);
  cursor: pointer;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-attachment .attachment-delete:hover {
  background: var(--cm-soft-overlay, rgba(0, 0, 0, 0.06));
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-result .message-result-text {
  border-top: 1px solid var(--cm-border-soft, rgba(0, 0, 0, 0.1));
  margin-top: 0.4rem;
  white-space: pre-line;
  color: var(--cm-text, #111827);
  word-break: break-word;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-result .message-result-text widget-text2-collab-messages-m-d-102025 .collab-md-message {
  font-family: inherit;
  font-size: inherit;
  color: inherit;
  line-height: inherit;
  background: inherit;
  padding: inherit;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-result .message-result-text widget-text2-collab-messages-m-d-102025 .collab-md-message .mention-agent {
  color: var(--active-color);
  background-color: transparent;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-result .message-result-text widget-text2-collab-messages-m-d-102025 .collab-md-message .mention-agent:hover {
  color: var(--active-color-hover);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-read-confirmations {
  margin-top: 0.4rem;
  padding: 0.3rem 0.4rem;
  background: var(--cm-soft-overlay, rgba(255, 255, 255, 0.72));
  border: 1px solid var(--cm-border-soft, rgba(0, 0, 0, 0.08));
  border-radius: var(--cm-radius-sm, 8px);
  color: var(--cm-text, #111827);
  font-size: 11px;
  line-height: 1.35;
  word-break: break-word;
  display: flex;
  flex-direction: column;
  gap: 0.25rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-read-confirmation {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .read-confirmation-line {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 0.25rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .read-confirmation-line.pending {
  color: var(--cm-text-muted, #5b635f);
}
collab-messages-chat-message-102025 .message .message-row .message-card .read-confirmation-line.canceled {
  border-top: 1px solid var(--cm-border-soft, rgba(0, 0, 0, 0.08));
  margin-top: 0.15rem;
  padding-top: 0.25rem;
  color: var(--cm-text-muted, #5b635f);
}
collab-messages-chat-message-102025 .message .message-row .message-card .read-confirmation-user {
  color: var(--active-color);
  font-weight: 600;
  background: var(--cm-soft-overlay, rgba(255, 255, 255, 0.75));
  border-radius: 4px;
  padding: 0 0.2rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .read-confirmation-time {
  color: var(--cm-text-muted, #5b635f);
  white-space: nowrap;
}
collab-messages-chat-message-102025 .message .message-row .message-card .execution-followup {
  border-top: 1px solid var(--cm-border-soft, rgba(0, 0, 0, 0.08));
  margin-top: 0.15rem;
  padding-top: 0.25rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .followup-status-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 14px;
  height: 14px;
}
collab-messages-chat-message-102025 .message .message-row .message-card .followup-status-icon svg {
  width: 12px;
  height: 12px;
  color: var(--active-color);
  fill: currentColor;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-content.trace {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-content.translate {
  padding: 0;
  margin: 0;
  font-size: 11px;
  font-style: italic;
  color: var(--cm-text-muted, #5b635f);
  padding-inline-start: 6px;
  border-left: 2px solid var(--cm-text-muted, #5b635f);
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-footer {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 0.25rem;
  font-size: 0.68rem;
  color: var(--cm-text-muted, #5b635f);
  text-align: right;
  margin-top: 0.08rem;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-footer small {
  font-size: 0.66rem;
  font-style: italic;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-footer .message-history-toggle {
  border: none;
  background: transparent;
  color: var(--cm-green-dark, #007a3d);
  font: inherit;
  font-size: 11px;
  font-weight: 700;
  padding: 0 2px;
  cursor: pointer;
  line-height: 1;
  white-space: nowrap;
}
collab-messages-chat-message-102025 .message .message-row .message-card .message-footer .message-history-toggle:hover {
  text-decoration: underline;
  text-underline-offset: 2px;
}
collab-messages-chat-message-102025 .message .message-row > collab-messages-avatar-102025 {
  position: absolute;
  top: 1px;
  left: -35px;
  width: 28px;
  height: 28px;
  --avatar-width: 28px;
  --avatar-height: 28px;
}
collab-messages-chat-message-102025 .message .message-group {
  display: contents;
}
collab-messages-chat-message-102025 .message.user .message-row {
  margin-left: 0;
  margin-right: 6px;
  justify-content: flex-end;
}
collab-messages-chat-message-102025 .message.system .message-row {
  margin-right: 6px;
}
collab-messages-chat-message-102025 .message-reactions {
  display: flex;
  gap: 4px;
  margin-top: 4px;
  position: absolute;
  bottom: -12px;
  right: 8px;
}
collab-messages-chat-message-102025 .message-reactions .reactions-summary {
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 1px 7px;
  border-radius: 12px;
  background: var(--cm-panel-bg, #ffffff);
  border: 1px solid var(--cm-border, #e2e7e3);
  cursor: pointer;
  font-size: 11px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.08);
  transition: background 0.15s ease;
}
collab-messages-chat-message-102025 .message-reactions .reactions-summary:hover {
  background: var(--cm-panel-muted, #f3f7f4);
}
collab-messages-chat-message-102025 .message-reactions .reactions-summary .reaction-emoji {
  font-size: 13px;
  line-height: 1;
}
collab-messages-chat-message-102025 .message-reactions .reactions-summary .reaction-count {
  color: var(--cm-text-muted, #5b635f);
  font-size: 11px;
  margin-left: 2px;
}
collab-messages-chat-message-102025 .message-reactions .active {
  box-shadow: 0 1px #00000012, 0 0 3px #0000000a;
}
collab-messages-chat-message-102025 .reaction-list-popup {
  position: absolute;
  min-width: 220px;
  max-width: 240px;
  background: var(--cm-panel-bg, #ffffff);
  border-radius: 8px;
  box-shadow: 0 3px 12px rgba(0, 0, 0, 0.12);
  z-index: 40;
  opacity: 0;
  transform: scale(0.95);
  pointer-events: none;
  transition: opacity 150ms ease, transform 150ms ease;
}
collab-messages-chat-message-102025 .reaction-list-popup.open {
  opacity: 1;
  transform: scale(1);
  pointer-events: auto;
}
collab-messages-chat-message-102025 .reaction-list-popup.top {
  bottom: calc(100% + 8px);
  left: 0;
  transform-origin: bottom left;
}
collab-messages-chat-message-102025 .reaction-list-popup.bottom {
  top: calc(100% + 8px);
  left: 0;
  transform-origin: top left;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-header {
  padding: 8px 10px 7px;
  font-size: 12px;
  font-weight: 600;
  color: var(--cm-text, #111827);
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-divider {
  height: 1px;
  background: var(--cm-border, #e2e7e3);
  margin: 0 10px;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-content {
  padding: 6px 0;
  max-height: 200px;
  overflow-y: auto;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 7px 10px;
  font-size: 13px;
  color: var(--cm-text, #111827);
  transition: background 0.15s ease;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item.current-user {
  cursor: pointer;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item.current-user:hover {
  background: var(--cm-panel-muted, #f3f7f4);
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item.current-user .reaction-list-name {
  color: var(--active-color);
  font-weight: 500;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item .reaction-list-user {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: 1;
  min-width: 0;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item .reaction-list-user collab-messages-avatar-102025 {
  flex-shrink: 0;
  width: 30px;
  height: 30px;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item .reaction-list-detail {
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item .reaction-list-name {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item .reaction-list-small {
  color: var(--cm-text-muted, #5b635f);
}
collab-messages-chat-message-102025 .reaction-list-popup .reaction-list-item .reaction-list-emoji {
  font-size: 16px;
  margin-left: 8px;
  flex-shrink: 0;
}
collab-messages-chat-message-102025 .message.system .message-reactions {
  left: 8px;
  right: auto;
}
collab-messages-chat-message-102025 .message.system .reaction-list-popup.top {
  left: 0;
  right: auto;
}
collab-messages-chat-message-102025 .message.system .reaction-list-popup.bottom {
  left: 0;
  right: auto;
}
collab-messages-chat-message-102025 .message.user .reaction-list-popup.top {
  right: 0;
  left: auto;
  transform-origin: bottom right;
}
collab-messages-chat-message-102025 .message.user .reaction-list-popup.bottom {
  right: 0;
  left: auto;
  transform-origin: top right;
}
collab-messages-chat-message-102025 .reaction {
  display: flex;
  align-items: center;
  gap: 4px;
  border-radius: 12px;
  padding: 1px 6px;
  font-size: 11px;
  cursor: pointer;
  background: var(--cm-panel-bg, #ffffff);
  border: none;
}
collab-messages-chat-message-102025 .reaction-picker {
  position: absolute;
  display: flex;
  gap: 5px;
  padding: 5px 7px;
  border-radius: 16px;
  background: var(--cm-panel-muted, #f3f7f4);
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.12);
  z-index: 10;
  opacity: 0;
  transform: scaleX(0.6) scaleY(0.4);
  pointer-events: none;
  transition: opacity 180ms ease-out, transform 320ms cubic-bezier(0.18, 0.89, 0.32, 1.28);
}
collab-messages-chat-message-102025 .reaction-picker.open {
  opacity: 1;
  transform: scale(1);
  pointer-events: auto;
}
collab-messages-chat-message-102025 .message.user .reaction-picker {
  right: 0;
}
collab-messages-chat-message-102025 .message.system .reaction-picker {
  left: 0;
}
collab-messages-chat-message-102025 .message.user .reaction-picker {
  transform-origin: bottom right;
}
collab-messages-chat-message-102025 .message.system .reaction-picker {
  transform-origin: bottom left;
}
collab-messages-chat-message-102025 .message.user .message-reactions {
  right: 8px;
}
collab-messages-chat-message-102025 .message.system .message-reactions {
  left: 8px;
}
collab-messages-chat-message-102025 .followup-summary {
  align-items: center;
}
collab-messages-chat-message-102025 .followup-summary .followup-reactions-summary {
  color: var(--active-color);
}
collab-messages-chat-message-102025 .followup-summary .followup-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
}
collab-messages-chat-message-102025 .followup-summary .followup-icon svg {
  width: 12px;
  height: 12px;
  fill: currentColor;
}
collab-messages-chat-message-102025 .followup-action-wrapper {
  position: relative;
  display: inline-flex;
  flex: 0 0 auto;
}
collab-messages-chat-message-102025 .followup-action-trigger {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 26px;
  height: 26px;
  padding: 0;
  border: none;
  border-radius: 50%;
  background: var(--cm-panel-bg, #ffffff);
  color: var(--cm-text-muted, #5b635f);
  box-shadow: var(--cm-shadow-sm, 0 1px 3px rgba(0, 0, 0, 0.14));
  cursor: pointer;
  transition: background 0.15s ease, color 0.15s ease, transform 0.15s ease;
}
collab-messages-chat-message-102025 .followup-action-trigger svg {
  width: 13px;
  height: 13px;
  fill: currentColor;
}
collab-messages-chat-message-102025 .followup-action-trigger:hover,
collab-messages-chat-message-102025 .followup-action-trigger.active {
  color: var(--active-color);
  background: var(--cm-panel-muted, #f3f7f4);
  transform: translateY(-1px);
}
collab-messages-chat-message-102025 .followup-action-menu {
  position: fixed;
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 152px;
  padding: 5px;
  border: 1px solid var(--cm-border, #e2e7e3);
  border-radius: 10px;
  background: var(--cm-panel-bg, #ffffff);
  box-shadow: 0 4px 14px rgba(0, 0, 0, 0.14);
  z-index: 45;
}
collab-messages-chat-message-102025 .followup-action {
  display: inline-flex;
  align-items: center;
  justify-content: flex-start;
  gap: 7px;
  width: 100%;
  min-height: 28px;
  padding: 4px 8px;
  border: none;
  border-radius: 7px;
  background: transparent;
  color: var(--cm-text-muted, #5b635f);
  font-size: 12px;
  text-align: left;
  cursor: pointer;
}
collab-messages-chat-message-102025 .followup-action svg {
  width: 13px;
  height: 13px;
  fill: currentColor;
  flex: 0 0 13px;
}
collab-messages-chat-message-102025 .followup-action span {
  white-space: nowrap;
}
collab-messages-chat-message-102025 .followup-action:hover,
collab-messages-chat-message-102025 .followup-action.active {
  color: var(--active-color);
  background: var(--cm-soft-overlay, rgba(0, 0, 0, 0.06));
}
collab-messages-chat-message-102025 .reaction-picker-item {
  font-size: 16px;
  background: none;
  border: none;
  cursor: pointer;
  opacity: 0;
  transform: scale(0.6);
  transition: opacity 180ms ease-out, transform 2200ms cubic-bezier(0.2, 0.8, 0.2, 1);
}
collab-messages-chat-message-102025 .reaction-picker.open .reaction-picker-item.show {
  opacity: 1;
  transform: scale(1);
}
collab-messages-chat-message-102025 .reaction-picker-item:hover {
  transform: scale(1.25);
}
collab-messages-chat-message-102025 .reaction-picker-item {
  font-size: 16px;
  cursor: pointer;
  border: none;
  background: transparent;
  transition: transform 0.1s ease;
}
collab-messages-chat-message-102025 .reaction-picker-item:hover {
  transform: scale(1.2);
}
collab-messages-chat-message-102025 .message:hover .reaction.add {
  opacity: 1;
  pointer-events: auto;
  transform: scale(1);
}
collab-messages-chat-message-102025 .reaction.add {
  opacity: 0;
  pointer-events: none;
  transform: scale(0.9);
  transition: opacity 0.15s ease, transform 0.15s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  filter: grayscale(100%) brightness(100%) opacity(90%);
  border-radius: 20px;
  background: var(--cm-panel-bg, #ffffff);
  box-shadow: var(--cm-shadow-sm, 0 1px 3px rgba(0, 0, 0, 0.14));
  width: 26px;
  height: 26px;
}
collab-messages-chat-message-102025 .message-action.submenu {
  opacity: 0;
  pointer-events: none;
  position: absolute;
  right: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 26px;
  height: 26px;
  border-radius: 50%;
  border: 1px solid rgba(255, 255, 255, 0.25);
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
  color: var(--cm-text, #111827);
  cursor: pointer;
  transition: opacity 0.15s ease, transform 0.15s ease, background 0.15s ease;
}
collab-messages-chat-message-102025 .message:hover .message-action.submenu {
  opacity: 1;
  pointer-events: auto;
  transform: scale(1);
}
collab-messages-chat-message-102025 .message-menu {
  position: absolute;
  min-width: 180px;
  background: var(--cm-panel-bg, #ffffff);
  border-radius: var(--cm-radius-sm, 8px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  padding: 4px;
  z-index: 30;
  max-width: 240px;
  opacity: 0;
  transform: scale(0.95);
  transition: opacity 120ms ease,
            transform 120ms ease;
}
collab-messages-chat-message-102025 .message-menu.open {
  opacity: 1;
  transform: scale(1);
}
collab-messages-chat-message-102025 .message-menu.bottom {
  top: 15%;
  margin-top: 6px;
}
collab-messages-chat-message-102025 .message-menu.top {
  bottom: 100%;
  margin-bottom: 6px;
}
collab-messages-chat-message-102025 .message-menu button {
  border: none;
  background: transparent;
  padding: 6px 12px;
  cursor: pointer;
  font-size: 13px;
  width: 100%;
  text-align: left;
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;
  color: var(--cm-text, #111827);
}
collab-messages-chat-message-102025 .message-menu button svg {
  width: 16px;
  height: 16px;
  flex: 0 0 16px;
  fill: currentColor;
}
collab-messages-chat-message-102025 .message-menu button:hover {
  background: var(--cm-panel-muted, #f3f7f4);
}
collab-messages-chat-message-102025 .message-menu button:disabled {
  cursor: default;
  opacity: 0.45;
}
collab-messages-chat-message-102025 .message-menu button:disabled:hover {
  background: transparent;
}
collab-messages-chat-message-102025 .message-reply-preview {
  display: flex;
  gap: 6px;
  padding: 6px;
  margin-bottom: 6px;
  border-radius: 6px;
  background-color: rgba(194, 189, 184, 0.15);
  cursor: pointer;
}
collab-messages-chat-message-102025 .message-reply-bar {
  width: 3px;
  border-radius: 2px;
  flex-shrink: 0;
}
collab-messages-chat-message-102025 .message.user .message-reply-bar {
  background: var(--success-color);
}
collab-messages-chat-message-102025 .message.system .message-reply-bar {
  background: var(--grey-color);
}
collab-messages-chat-message-102025 .message-reply-content {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
  color: var(--cm-text, #111827);
  opacity: 0.7;
}
collab-messages-chat-message-102025 .message-reply-user {
  font-size: 11px;
  font-weight: 600;
  opacity: 0.8;
}
collab-messages-chat-message-102025 .message-reply-text {
  font-size: 12px;
  overflow: hidden;
  text-overflow: ellipsis;
  opacity: 0.85;
}
`);
        this.allThreads = [];
        this.usersAvaliables = [];
        this.toolbarHighlighted = false;
        this.messageMenuPlacement = 'bottom';
        this.reactionListPlacement = 'top';
        this.isEditingMessage = false;
        this.editContent = '';
        this.showEditHistory = false;
        this.msg = messages['en'];
        this.documentClickHandler = (ev) => this.onDocumentClick(ev);
        this.documentScrollHandler = () => this.closeLocalPopups();
        this.reactionEmojis = {
            thumbs_up: '👍',
            laugh: '😂',
            heart: '❤️',
            wow: '😮',
            sad: '😢',
            angry: '😡'
        };
        this.replyCache = new Map();
    }
    connectedCallback() {
        super.connectedCallback();
        document.addEventListener('click', this.documentClickHandler, true);
        document.addEventListener('scroll', this.documentScrollHandler, true);
    }
    disconnectedCallback() {
        document.removeEventListener('click', this.documentClickHandler, true);
        document.removeEventListener('scroll', this.documentScrollHandler, true);
        super.disconnectedCallback();
    }
    updated() {
        this.positionReactionPicker();
        this.positionMessageMenu();
        this.animateReactionPicker();
        this.updateMessageMenuPlacement();
        // this.positionReactionListPopup();
        this.updateReactionListPlacement();
        this.positionFollowupActionMenu();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.userPreferenceChat = loadChatPreferences();
        return this.renderMessage();
    }
    renderMessage() {
        const message = this.message;
        if (!message)
            return html `${nothing}`;
        const isSame = message.isSame;
        const dateFormated = formatTimestamp(message.createAt);
        const userToFind = [
            ...this.usersAvaliables,
            ...(this.actualThread?.users || [])
        ].filter((user, index, self) => index === self.findIndex(u => u.userId === user.userId));
        const userName = userToFind.find((user) => user.userId === message.senderId)?.name || message.senderId;
        const userAvatar = userToFind.find((user) => user.userId === message.senderId)?.avatar_url || '';
        const cls = message.senderId === this.userId ? 'user' : 'system';
        const titleTranslated = this.getTitleMessageTranslated(message);
        const hasReactions = this.hasExecutionFollowup(message) || (message.reactions ? Object.keys(message.reactions).length > 0 : false);
        const isMessageContentHidden = this.isMessageContentHidden(message);
        return html `
            <div class="message ${cls} ${isSame ? 'same' : ''} ${hasReactions ? 'reaction-on' : ''}">
                <div class="message-group">
                    <div class="message-row">
                        ${cls === 'user' ? this.renderSideAction(message) : nothing}
                    
                        <div class="message-card ${cls} ${isSame ? 'same' : ''} ${this.isPinned(message) ? 'pinned' : ''} ${this.toolbarHighlighted ? 'toolbar-highlighted' : ''}">

                            ${this.renderSubMenuButton(message)}
                            ${this.renderMessageMenu(message)}
                            ${!isSame ? html `<div class="message-title">@${userName}</div>` : ``}
                            ${message.replyTo && !isMessageContentHidden ? this.renderReplyPreview(message.replyTo) : nothing}
                            ${this.isEditingMessage ? this.renderEditMessageForm(message) : this.renderMessageByLanguage(message)}
                            ${!isMessageContentHidden ? this.renderAttachments(message) : nothing}
                            ${message.isLoading ? html `<span class="loader"></span>` : ''}
                            ${message.isFailed ? html `<div class="failed">
                            <div>
                                <span>${collab_circle_exclamation}</span>
                                <small>${this.msg.msgNotSend}</small>
                            </div>
                            <small>${message.isFailedError}</small>
                        </div>` : ''}
                        
                        ${message.taskId && !isMessageContentHidden ? html `
                            <div class="message-ai">
                                <collab-messages-task-102025
                                    messageId=${this.getMessageOrderAt(message)}
                                    .context= ${message.context}
                                    lastChanged= ${message.lastChanged}
                                    taskId=${message.taskId}
                                    threadId=${this.actualThread?.thread.threadId}
                                    userId=${this.userId}
                                    title=${titleTranslated}
                                    status=${message.taskStatus}
                                    .notificationPending=${hasTaskNotificationPending(message.taskId)}
                                    @taskclick=${() => { if (this.onTaskClick)
            this.onTaskClick(message?.taskId || '', this.getMessageOrderAt(message), message.threadId, message); }}
                                >
                                </collab-messages-task-102025>
                            </div> ` : html ``}
                            ${!isMessageContentHidden ? this.renderMessageResultByLanguage(message) : nothing}
                            ${!isMessageContentHidden && this.showEditHistory ? this.renderReadConfirmations(message) : nothing}
                            ${!isMessageContentHidden ? this.renderMessageFooterResult(message) : nothing}
                            ${!isMessageContentHidden ? this.renderReactions(message) : nothing}
                            ${!isMessageContentHidden ? this.renderReactionPicker(message) : nothing}
                            ${this.renderEditHistory(message)}
                            <div class="message-footer">
                                ${this.renderHistoryToggle(message)}
                                <span>${dateFormated?.timeShort}</span>
                                ${message.editedAt ? html `<small>${this.msg.edited}</small>` : nothing}
                            </div>
                        </div>
                        ${cls === 'system' ? this.renderSideAction(message) : nothing}
                        ${cls === 'system' && !isSame && !this.isCurrentThreadDirectMessage() ? html `<collab-messages-avatar-102025 avatar=${userAvatar} alt=${userName} ></collab-messages-avatar-102025>` : ''}
                    </div>
                </div>
            </div>

         `;
    }
    renderMessageByLanguage(message) {
        if (message.moderation) {
            const notice = this.renderModerationNotice(message);
            if (this.isMessageContentHidden(message))
                return notice;
            return html `${notice}${this.renderMessageContentByLanguage(message)}`;
        }
        return this.renderMessageContentByLanguage(message);
    }
    renderMessageContentByLanguage(message) {
        const mode = this.userPreferenceChat?.translationMode || 'icon';
        if (!this.userPreferenceChat || mode === 'none' || !message.translations) {
            return html `
            <div class="message-content">
                ${this.renderCollabMessagesRichPreview(message.content)} 
            </div>`;
        }
        const { language } = this.userPreferenceChat;
        const messageByLanguagePref = message.translations ? message.translations[language] : '';
        const isSameLanguege = language === message.language_detected;
        switch (mode) {
            case 'icon':
                return html `
                <div class="message-content">
                    ${this.renderCollabMessagesRichPreview(messageByLanguagePref || message.content)} 
                     ${!isSameLanguege ? collab_translate : ''}
                </div>`;
            case 'text':
                return html `
                <div class="message-content">
                    ${this.renderCollabMessagesRichPreview(messageByLanguagePref || message.content)}   
                </div>
                ${!isSameLanguege ?
                    html `<small class="message-content translate">
                            ${this.renderCollabMessagesRichPreview(message.content)}   
                        </small>`
                    : ''}`;
            case 'iconText':
                return html `
                    <div class="message-content">
                        ${this.renderCollabMessagesRichPreview(messageByLanguagePref || message.content)}   
                        ${!isSameLanguege ? collab_translate : ''}
                    </div>
                ${!isSameLanguege ?
                    html `<small class="message-content translate">
                        ${this.renderCollabMessagesRichPreview(message.content)}    
                    </small>`
                    : ''}`;
            case 'trace':
                return html `
                <div class="message-content trace">
                    <div>
                        <b>[LanguageDetected: ${message.language_detected}]</b>
                        ${this.renderCollabMessagesRichPreview(message.content)}   
                    </div>
                    ${Object.keys(message.translations).map((key) => {
                    if (key === 'language_detected')
                        return '';
                    if (key === message.language_detected)
                        return '';
                    return html `
                            <div>
                                <b>[${key}]</b>
                                ${this.renderCollabMessagesRichPreview(message.translations ? message.translations[key] : '')}                        
                            </div>`;
                })}
                </div>`;
            default:
                return null;
        }
    }
    renderModerationNotice(message) {
        const moderation = message.moderation;
        if (!moderation)
            return nothing;
        const isDeleted = moderation.status === 'deleted';
        return html `
            <div class="message-moderation-notice ${moderation.status}">
                ${isDeleted ? collab_delete : collab_ban}
                <div>
                    <span>${isDeleted ? this.msg.deletedMessage : this.msg.moderatedMessage}</span>
                    <small>
                        ${isDeleted ? this.msg.deletedBy : this.msg.moderatedBy}
                        @${this.getUserName(moderation.by)}
                        ${this.formatLocalDateTime(moderation.at)}
                    </small>
                    ${!this.isMessageContentHidden(message) ? html `<small>${this.msg.originalVisibleToModerators}</small>` : nothing}
                </div>
            </div>
        `;
    }
    renderEditMessageForm(message) {
        return html `
            <div class="message-edit-form">
                <textarea
                    .value=${this.editContent}
                    @input=${(ev) => this.editContent = ev.target.value}
                ></textarea>
                <div class="message-edit-actions">
                    <button @click=${() => this.onEditCancelClick()}>${this.msg.cancel}</button>
                    <button @click=${() => this.onEditSaveClick(message)}>${this.msg.save}</button>
                </div>
            </div>
        `;
    }
    renderEditHistory(message) {
        if (!this.showEditHistory || !message.edits?.length || this.isMessageContentHidden(message))
            return nothing;
        return html `
            <div class="message-edit-history">
                <div class="message-edit-history-title">${this.msg.editHistory}</div>
                ${message.edits.map((edit, index) => {
            const previousEdit = message.edits?.[index - 1];
            return html `
                        <div class="message-edit-history-item">
                            <small>
                                ${index === 0
                ? html `${this.msg.originalMessage} @${this.getUserName(message.senderId)} ${this.formatLocalDateTime(message.createAt)}`
                : html `${this.msg.editedBy} @${this.getUserName(previousEdit?.editedBy)} ${this.formatLocalDateTime(previousEdit?.editedAt || '')}`}
                            </small>
                            <div>${this.renderCollabMessagesRichPreview(edit.content)}</div>
                        </div>
                    `;
        })}
                <div class="message-edit-history-item current">
                    <small>
                        ${message.editedBy && message.editedAt
            ? html `${this.msg.currentMessage} - ${this.msg.editedBy} @${this.getUserName(message.editedBy)} ${this.formatLocalDateTime(message.editedAt)}`
            : this.msg.currentMessage}
                    </small>
                    <div>${this.renderCollabMessagesRichPreview(message.content)}</div>
                </div>
            </div>
        `;
    }
    renderHistoryToggle(message) {
        if (!this.hasMessageHistory(message) || this.isMessageContentHidden(message))
            return nothing;
        return html `
            <button
                class="message-history-toggle"
                @click=${(ev) => this.onHistoryToggleClick(ev)}
            >
                ${this.showEditHistory ? this.msg.hideHistory : this.msg.showHistory}
            </button>
        `;
    }
    hasMessageHistory(message) {
        return !!message.edits?.length || this.hasReadConfirmationHistory(message);
    }
    hasReadConfirmationHistory(message) {
        if (!message.readConfirmations?.length)
            return false;
        return message.readConfirmations.some(item => {
            const kind = this.getReadConfirmationKind(item);
            return kind === 'read' || kind === 'execution';
        });
    }
    renderAttachments(message) {
        if (!message.attachments?.length)
            return nothing;
        return html `
            <div class="message-attachments">
                ${message.attachments.map(attachment => this.renderAttachment(message, attachment))}
            </div>
        `;
    }
    renderAttachment(message, attachment) {
        if (attachment.status === 'deleted') {
            return html `
                <div class="message-attachment deleted">
                    ${collab_paperclip}
                    <span>${attachment.fileName}</span>
                    <small>
                        ${this.msg.attachmentRemoved}
                        @${this.getUserName(attachment.deletedBy)}
                        ${attachment.deletedAt ? this.formatLocalDateTime(attachment.deletedAt) : ''}
                    </small>
                </div>
            `;
        }
        const canDelete = this.canDeleteAttachment(attachment);
        if (attachment.kind === 'image') {
            return html `
                <div class="message-attachment image">
                    <a
                        href=${attachment.url || '#'}
                        target="_blank"
                        rel="noopener noreferrer"
                        title=${this.msg.openAttachment}
                        @click=${(ev) => this.openAttachment(ev, message, attachment)}
                    >
                        <img
                            src=${attachment.url || ''}
                            alt=${attachment.fileName}
                            loading="lazy"
                            @error=${(ev) => this.refreshAttachmentImage(ev, message, attachment)}
                        />
                    </a>
                    <div class="attachment-meta">
                        <span>${attachment.fileName}</span>
                        <small>${this.formatFileSize(attachment.sizeBytes)}</small>
                        ${canDelete ? this.renderDeleteAttachmentButton(message, attachment) : nothing}
                    </div>
                </div>
            `;
        }
        return html `
            <div class="message-attachment file">
                <a
                    href=${attachment.url || '#'}
                    target="_blank"
                    rel="noopener noreferrer"
                    title=${this.msg.openAttachment}
                    @click=${(ev) => this.openAttachment(ev, message, attachment)}
                >
                    ${collab_paperclip}
                    <span>${attachment.fileName}</span>
                    <small>${this.formatFileSize(attachment.sizeBytes)}</small>
                </a>
                ${canDelete ? this.renderDeleteAttachmentButton(message, attachment) : nothing}
            </div>
        `;
    }
    renderDeleteAttachmentButton(message, attachment) {
        return html `
            <button
                class="attachment-delete"
                title=${this.msg.deleteAttachment}
                aria-label=${this.msg.deleteAttachment}
                @click=${(ev) => this.onDeleteAttachmentClick(ev, message, attachment)}
            >
                ${collab_delete}
            </button>
        `;
    }
    async openAttachment(ev, message, attachment) {
        ev.preventDefault();
        const url = await this.loadAttachmentUrl(message, attachment);
        window.open(url, '_blank', 'noopener,noreferrer');
    }
    async refreshAttachmentImage(ev, message, attachment) {
        const image = ev.currentTarget;
        if (!image || image.dataset.refreshing === 'true')
            return;
        image.dataset.refreshing = 'true';
        try {
            image.src = await this.loadAttachmentUrl(message, attachment);
        }
        finally {
            image.dataset.refreshing = 'false';
        }
    }
    async loadAttachmentUrl(message, attachment) {
        if (!this.userId)
            throw new Error('User not found');
        const result = await msgGetAttachmentUrl({
            userId: this.userId,
            threadId: message.threadId,
            messageId: message.orderAt || message.createAt,
            attachmentId: attachment.attachmentId
        });
        if (!result.success || !result.response?.url) {
            throw new Error(result.error || 'Failed to open attachment');
        }
        attachment.url = result.response.url;
        return result.response.url;
    }
    onDeleteAttachmentClick(ev, message, attachment) {
        ev.preventDefault();
        ev.stopPropagation();
        this.dispatchEvent(new CustomEvent('delete-attachment-message', {
            detail: {
                message,
                attachmentId: attachment.attachmentId
            },
            bubbles: true,
            composed: true
        }));
    }
    canDeleteAttachment(attachment) {
        if (attachment.uploadedBy === this.userId && this.canWriteThread())
            return true;
        const currentThreadUser = this.actualThread?.thread.users.find(user => user.userId === this.userId);
        return currentThreadUser?.auth === 'admin' || currentThreadUser?.auth === 'moderator';
    }
    canWriteThread() {
        const currentThreadUser = this.actualThread?.thread.users.find(user => user.userId === this.userId);
        return currentThreadUser?.auth === 'admin' ||
            currentThreadUser?.auth === 'moderator' ||
            currentThreadUser?.auth === 'write';
    }
    canModerateThread() {
        const currentThreadUser = this.actualThread?.thread.users.find(user => user.userId === this.userId);
        return currentThreadUser?.auth === 'admin' || currentThreadUser?.auth === 'moderator';
    }
    isMessageContentHidden(message) {
        return !!message.moderation && !this.canModerateThread();
    }
    canDeleteMessage(message) {
        if (message.moderation)
            return false;
        return (message.senderId === this.userId && this.canWriteThread()) || this.canModerateThread();
    }
    canModerateMessage(message) {
        return !message.moderation && this.canModerateThread();
    }
    canEditMessage(message) {
        if (message.moderation || message.attachments?.length)
            return false;
        if (!(message.senderId === this.userId || this.canModerateThread()))
            return false;
        return Date.now() - this.parseCompactDate(message.createAt).getTime() <= 24 * 60 * 60 * 1000;
    }
    parseCompactDate(timestamp) {
        const year = Number(timestamp.slice(0, 4));
        const month = Number(timestamp.slice(4, 6)) - 1;
        const day = Number(timestamp.slice(6, 8));
        const hour = Number(timestamp.slice(8, 10));
        const minute = Number(timestamp.slice(10, 12));
        const second = Number(timestamp.slice(12, 14));
        return new Date(Date.UTC(year, month, day, hour, minute, second));
    }
    getUserName(userId) {
        if (!userId)
            return '';
        return this.usersAvaliables.find(user => user.userId === userId)?.name || userId;
    }
    formatFileSize(size) {
        if (size < 1024)
            return `${size} B`;
        if (size < 1024 * 1024)
            return `${Math.round(size / 1024)} KB`;
        return `${(size / (1024 * 1024)).toFixed(1)} MB`;
    }
    renderReplyPreview(replyId) {
        if (!this.replyCache.has(replyId)) {
            this.replyCache.set(replyId, this.loadReplyPreview(replyId));
        }
        return until(this.replyCache.get(replyId), html `<div class="message-reply-preview loading">${this.msg.loading}</div>`);
    }
    async loadReplyPreview(replyId) {
        if (!this.actualThread)
            return html `${nothing}`;
        const messageId = this.normalizeMessageId(this.actualThread.thread.threadId, replyId);
        const reply = await getMessage(messageId);
        if (!reply)
            return html `${nothing}`;
        const user = this.usersAvaliables.find(u => u.userId === reply.senderId) ||
            this.actualThread?.users?.find(u => u.userId === reply.senderId);
        let name = reply.senderId;
        if (user?.name) {
            name = user.userId === this.userId ? this.msg.you : '@' + user.name;
        }
        return html `
        <div
            class="message-reply-preview"
            @click=${() => this.onReplyPreviewClick(reply.createAt)}
        >
            <div class="message-reply-bar"></div>

            <div class="message-reply-content">
                <div class="message-reply-user">
                    ${name}
                </div>

                <div class="message-reply-text">
                    ${this.renderCollabMessagesRichPreview(reply.content)}  
                </div>
            </div>
        </div>
    `;
    }
    onReplyPreviewClick(messageId) {
        this.dispatchEvent(new CustomEvent('reply-preview-click', {
            detail: { messageId },
            bubbles: true,
            composed: true
        }));
    }
    renderMessageResultByLanguage(message) {
        if (!message.taskResults || message.taskResults.length === 0 || message.taskStatus !== 'done')
            return html ``;
        const mode = this.userPreferenceChat?.translationMode || 'icon';
        if (!this.userPreferenceChat || mode === 'none') {
            return html `<div class="message-content">${message.taskResults[0]}</div>`;
        }
        const response = message.taskResults[0];
        const { language } = this.userPreferenceChat;
        const messageByLanguagePref = message.taskResultsTranslated ? message.taskResultsTranslated[language] : '';
        const isSameLanguege = language === message.taskResultsTranslated?.language_detected;
        switch (mode) {
            case 'icon':
                return html `<div class="message-content">${messageByLanguagePref || response} ${!isSameLanguege ? collab_translate : ''}</div>`;
            case 'text':
                return html `
                <div class="message-content">${messageByLanguagePref || response}</div>
                ${!isSameLanguege ? html `<small class="message-content translate">${response}</small>` : ''}`;
            case 'iconText':
                return html `<div class="message-content">${messageByLanguagePref || response} ${!isSameLanguege ? collab_translate : ''}</div>
                ${!isSameLanguege ? html `<small class="message-content translate">${response}</small>` : ''}`;
            case 'trace':
                return html `<div class="message-content trace">
                <div><b>[LanguageDetected: ${message.language_detected}]</b> ${response}</div>
                ${Object.keys(message.taskResultsTranslated || {}).map((key) => {
                    if (key === 'language_detected')
                        return '';
                    if (key === message.taskResultsTranslated?.language_detected)
                        return '';
                    return html `<div><b>[${key}]</b> ${message.taskResultsTranslated ? message.taskResultsTranslated[key] : ''}</div>`;
                })}
                </div>`;
            default:
                return null;
        }
    }
    renderReadConfirmations(message) {
        if (!message.readConfirmations || message.readConfirmations.length === 0)
            return nothing;
        const readConfirmations = message.readConfirmations.filter(item => this.getReadConfirmationKind(item) === 'read');
        const executionFollowups = message.readConfirmations.filter(item => this.getReadConfirmationKind(item) === 'execution');
        if (readConfirmations.length === 0 && executionFollowups.length === 0)
            return nothing;
        const statusByUser = this.getReadConfirmationStatusByUser(readConfirmations);
        return html `
            <div class="message-read-confirmations">
                ${readConfirmations.length ? html `<div class="message-read-confirmation">
                    ${readConfirmations.map(request => html `
                        <div class="read-confirmation-line">
                            <span class="read-confirmation-time">${this.formatLocalDateTime(request.requestedAt)}</span>
                            ${this.renderUserLabel(request.requestedBy)}
                            <span>${this.msg.requestedReadConfirmation}</span>
                        </div>
                    `)}
                    ${statusByUser.map(({ userId, confirmedAt }) => html `
                        <div class="read-confirmation-line ${confirmedAt ? 'confirmed' : 'pending'}">
                            ${confirmedAt ? html `
                                <span class="read-confirmation-time">${this.formatLocalDateTime(confirmedAt)}</span>
                                ${this.renderUserLabel(userId)}
                                <span>${this.msg.confirmedRead}</span>
                            ` : html `${this.renderUserLabel(userId)} <span>${this.msg.notConfirmedRead}</span>`}
                        </div>
                    `)}
                    ${readConfirmations.map(request => request.canceledAt ? html `
                        <div class="read-confirmation-line canceled">
                            <span class="read-confirmation-time">${this.formatLocalDateTime(request.canceledAt)}</span>
                            ${this.renderUserLabel(request.canceledBy || request.requestedBy)}
                            <span>${this.msg.canceledReadConfirmation}</span>
                        </div>
                    ` : nothing)}
                </div>` : nothing}
                ${executionFollowups.map(request => this.renderExecutionFollowup(request))}
            </div>
        `;
    }
    renderExecutionFollowup(request) {
        const events = [
            {
                at: request.requestedAt,
                userId: request.requestedBy,
                label: this.msg.requestedExecutionConfirmation,
                reaction: undefined,
            },
            ...(request.followupHistory || []).map(item => ({
                at: item.at,
                userId: item.userId,
                label: this.getFollowupLabel(this.isFollowupReaction(item.reaction) ? item.reaction : undefined),
                reaction: this.isFollowupReaction(item.reaction) ? item.reaction : undefined,
            })),
        ].sort((a, b) => a.at.localeCompare(b.at));
        return html `
            <div class="message-read-confirmation execution-followup">
                ${events.map(event => html `
                    <div class="read-confirmation-line confirmed">
                        <span class="read-confirmation-time">${this.formatLocalDateTime(event.at)}</span>
                        ${this.renderUserLabel(event.userId)}
                        ${event.reaction ? html `<span class="followup-status-icon">${this.renderFollowupIcon(event.reaction)}</span>` : nothing}
                        <span>${event.label}</span>
                    </div>
                `)}
            </div>
        `;
    }
    getReadConfirmationStatusByUser(readConfirmations) {
        const statusByUser = new Map();
        for (const request of readConfirmations) {
            for (const userId of request.targetUserIds) {
                const confirmedAt = request.confirmedBy?.[userId];
                const current = statusByUser.get(userId);
                if (!current) {
                    statusByUser.set(userId, { userId, confirmedAt });
                    continue;
                }
                if (!current.confirmedAt && confirmedAt) {
                    statusByUser.set(userId, { userId, confirmedAt });
                }
            }
        }
        return [...statusByUser.values()];
    }
    getReadConfirmationKind(request) {
        return request.kind || 'read';
    }
    getActiveExecutionFollowup(message) {
        return message.readConfirmations?.find(request => !request.canceledAt && this.getReadConfirmationKind(request) === 'execution');
    }
    getFollowupStatusItems(message, request) {
        return request.targetUserIds.map(userId => ({
            userId,
            reaction: this.getFollowupReactionForUser(message, userId)
        }));
    }
    hasExecutionFollowup(message) {
        return !!this.getActiveExecutionFollowup(message);
    }
    isFollowupReaction(reaction) {
        return [
            'followup_lido',
            'followup_vou_fazer',
            'followup_concluido',
            'followup_bloqueado',
            'followup_cancelado',
            'followup_revisado',
        ].includes(reaction);
    }
    getFollowupReactionForUser(message, userId) {
        const reactions = message.reactions || {};
        for (const [reaction, users] of Object.entries(reactions)) {
            if (this.isFollowupReaction(reaction) && users.includes(userId))
                return reaction;
        }
        return undefined;
    }
    renderFollowupIcon(reaction) {
        switch (reaction) {
            case 'followup_lido': return collab_eye;
            case 'followup_vou_fazer': return collab_play;
            case 'followup_concluido': return collab_check;
            case 'followup_bloqueado': return collab_circle_exclamation;
            case 'followup_cancelado': return collab_xmark;
            case 'followup_revisado': return collab_check;
            default: return collab_clock_static;
        }
    }
    getFollowupLabel(reaction) {
        switch (reaction) {
            case 'followup_lido': return this.msg.followupLido;
            case 'followup_vou_fazer': return this.msg.followupVouFazer;
            case 'followup_concluido': return this.msg.followupConcluido;
            case 'followup_bloqueado': return this.msg.followupBloqueado;
            case 'followup_cancelado': return this.msg.followupCancelado;
            case 'followup_revisado': return this.msg.followupRevisado;
            default: return this.msg.followupPending;
        }
    }
    renderUserLabel(userId) {
        const user = this.findUser(userId);
        return html `<span class="read-confirmation-user">@${user?.name || userId}</span>`;
    }
    formatLocalDateTime(timestamp) {
        return formatTimestamp(timestamp)?.dateFull || timestamp;
    }
    renderMessageFooterResult(message) {
        if (!message.footers || message.footers.length === 0)
            return html ``;
        return html `<div class="message-result">
            ${message.footers?.map((footer) => {
            const content = footer.lines.join('\n').trim();
            if (!content)
                return html ``;
            return html `
                <div class="message-result-text">
                    <b>${footer.title?.trim()}</b>
                    <div>
                        ${this.renderCollabMessagesRichPreview(footer.lines.join('\n').trim())}                    
                    </div>
                </div>`;
        })}
        </div>`;
    }
    renderCollabMessagesRichPreview(text) {
        if (text.trim().startsWith('@@'))
            text = text.slice(0, 300) + (text.length > 300 ? '...' : '');
        return html `
        <collab-messages-rich-preview-text-102025 
            @mention-click=${this.onMentionClick}
            @channel-hover=${this.onChannelHover}
            .allUsers=${this.usersAvaliables} 
            .allThreads=${this.allThreads}
            text="${text}"
        ></collab-messages-rich-preview-text-102025>`;
    }
    async onMentionClick(ev) {
        this.removeAllUserModal();
        if (!ev.detail || !ev.detail.userId || !ev.detail.element)
            return;
        const actualUserModal = this.usersAvaliables.find((user) => user.userId === ev.detail.userId);
        if (!actualUserModal)
            return;
        const rects = ev.detail.element.getBoundingClientRect();
        const modal = document.createElement('collab-messages-user-modal-102025');
        modal.user = actualUserModal;
        modal.setAttribute('actualUserId', this.userId);
        modal.isDirectMessage = this.isCurrentThreadDirectMessage();
        this.appendChild(modal);
        await modal.updateComplete;
        const rectsModal = modal.getBoundingClientRect();
        this.positionModalByTarget(modal, rects, rectsModal);
    }
    positionModalByTarget(modal, targetRect, modalRect) {
        const margin = 8;
        const width = modalRect.width || 280;
        const height = modalRect.height || 0;
        const maxLeft = Math.max(margin, window.innerWidth - width - margin);
        const maxTop = Math.max(margin, window.innerHeight - height - margin);
        let left = targetRect.left + (targetRect.width / 2) - (width / 2);
        let top = targetRect.bottom + margin;
        if (top + height > window.innerHeight - margin) {
            top = targetRect.top - height - margin;
        }
        modal.style.position = 'fixed';
        modal.style.left = `${Math.min(Math.max(left, margin), maxLeft)}px`;
        modal.style.top = `${Math.min(Math.max(top, margin), maxTop)}px`;
    }
    isCurrentThreadDirectMessage() {
        const thread = this.actualThread?.thread;
        return Boolean(thread?.name?.startsWith('@') && thread.users?.length === 2);
    }
    async onChannelHover(ev) {
        this.removeAllChannelModal();
        if (!ev.detail || !ev.detail.threadId || !ev.detail.element)
            return;
        const actualThreadModal = this.allThreads.find((thread) => thread.threadId === `${ev.detail.threadId}`);
        if (!actualThreadModal)
            return;
        const rects = ev.detail.element.getBoundingClientRect();
        const modal = document.createElement('collab-messages-thread-modal-102025');
        modal.thread = actualThreadModal;
        this.appendChild(modal);
        await modal.updateComplete;
        const rectsModal = modal.getBoundingClientRect();
        modal.style.top = (rects.top - rectsModal.height - rects.height - 70) + 'px';
        modal.style.left = '20px';
    }
    removeAllUserModal() {
        const all = this.querySelectorAll('collab-messages-user-modal-102025');
        all.forEach((item) => item.remove());
    }
    removeAllChannelModal() {
        const all = this.querySelectorAll('collab-messages-thread-modal-102025');
        all.forEach((item) => item.remove());
    }
    getTitleMessageTranslated(message) {
        const mode = this.userPreferenceChat?.translationMode || 'icon';
        if (!this.userPreferenceChat || mode === 'none' || !message.taskTitleTranslated) {
            return message.taskTitle;
        }
        const { language } = this.userPreferenceChat;
        const titleByLanguagePref = message.taskTitleTranslated ? (message.taskTitleTranslated[language] ? message.taskTitleTranslated[language] : message.taskTitle) : message.taskTitle;
        return titleByLanguagePref;
    }
    //Reactions
    renderReactions(message) {
        const summaryItems = this.getReactionSummaryItems(message);
        const totalReactions = summaryItems.reduce((acc, item) => acc + item.count, 0);
        if (totalReactions === 0)
            return nothing;
        return html `
        <div class="message-reactions ${this.hasExecutionFollowup(message) ? 'followup-summary' : ''}">
            <button 
                class="reactions-summary"
                @click=${(ev) => this.openReactionList(message, ev)}
            >
                ${summaryItems.map(item => html `
                    <span class="reaction-emoji ${item.isFollowup ? 'followup-icon' : ''}">
                        ${item.icon}
                    </span>
                `)}
                <span class="reaction-count">${totalReactions}</span>
            </button>
            ${this.renderReactionListPopup(message)}
        </div>
    `;
    }
    renderReactionListPopup(message) {
        if (this.openedReactionListMessageId !== message.createAt)
            return nothing;
        const allReactions = this.getReactionListItems(message);
        if (allReactions.length === 0)
            return nothing;
        allReactions.sort((a, b) => {
            if (a.userId === this.userId)
                return -1;
            if (b.userId === this.userId)
                return 1;
            return 0;
        });
        const totalCount = allReactions.length;
        const reactionWord = totalCount === 1 ? this.msg.reaction : this.msg.reactions;
        return html `
        <div class="reaction-list-popup ${this.reactionListPlacement}">
            <div class="reaction-list-header">
                ${totalCount} ${reactionWord}
            </div>
            <div class="reaction-list-divider"></div>
            <div class="reaction-list-content">
                ${allReactions.map(({ userId, icon, label, reactionName }) => {
            const user = this.findUser(userId);
            const userName = user?.name || userId;
            const userAvatar = user?.avatar_url || '';
            const isCurrentUser = userId === this.userId && !!reactionName;
            return html `
                        <div 
                            class="reaction-list-item ${isCurrentUser ? 'current-user' : ''}"
                            @click=${() => isCurrentUser && reactionName ? this.removeReactionFromList(message, reactionName) : null}
                        >
                            <div class="reaction-list-user">
                                <collab-messages-avatar-102025 
                                    avatar=${userAvatar}
                                    alt=${userName}
                                ></collab-messages-avatar-102025>
                                <div class="reaction-list-detail">
                                    <span class="reaction-list-name">
                                        ${isCurrentUser ? this.msg.you : userName}
                                    </span>
                                    <small class="reaction-list-small">${label}</small>
                                    ${isCurrentUser ? html `<small class="reaction-list-small">${this.msg.clickToRemove}</small>` : nothing}
                                </div>

                            </div>
                            <span class="reaction-list-emoji">${icon}</span>
                        </div>
                    `;
        })}
            </div>
        </div>
    `;
    }
    findUser(userId) {
        return [
            ...this.usersAvaliables,
            ...(this.actualThread?.users || [])
        ].find(user => user.userId === userId);
    }
    getEmojiReactionListItems(message) {
        if (!message.reactions)
            return [];
        const allReactions = [];
        Object.entries(message.reactions).forEach(([name, users]) => {
            const icon = this.getReactionIcon(name);
            const label = this.getReactionLabel(name);
            if (!icon || !label || this.isFollowupReaction(name))
                return;
            users.forEach(userId => {
                allReactions.push({ userId, icon, label, reactionName: name });
            });
        });
        return allReactions;
    }
    getFollowupReactionListItems(message) {
        if (!message.reactions)
            return [];
        const allReactions = [];
        Object.entries(message.reactions).forEach(([name, users]) => {
            if (!this.isFollowupReaction(name))
                return;
            const icon = this.getReactionIcon(name);
            const label = this.getReactionLabel(name);
            if (!icon || !label)
                return;
            users.forEach(userId => {
                allReactions.push({ userId, icon, label, reactionName: name });
            });
        });
        return allReactions;
    }
    getReactionListItems(message) {
        return [
            ...this.getEmojiReactionListItems(message),
            ...this.getFollowupReactionListItems(message),
        ];
    }
    getReactionSummaryItems(message) {
        if (!message.reactions)
            return [];
        return Object.entries(message.reactions)
            .map(([name, users]) => {
            const icon = this.getReactionIcon(name);
            if (!icon || users.length === 0)
                return undefined;
            return {
                reactionName: name,
                icon,
                count: users.length,
                isFollowup: this.isFollowupReaction(name),
            };
        })
            .filter((item) => !!item);
    }
    getReactionIcon(name) {
        if (this.reactionEmojis[name])
            return this.reactionEmojis[name];
        if (this.isFollowupReaction(name))
            return this.renderFollowupIcon(name);
        return undefined;
    }
    getReactionLabel(name) {
        if (this.reactionEmojis[name])
            return this.reactionEmojis[name];
        if (this.isFollowupReaction(name))
            return this.getFollowupLabel(name);
        return undefined;
    }
    openReactionList(message, ev) {
        ev.stopPropagation();
        if (this.openedReactionListMessageId === message.createAt) {
            this.closeReactionList();
            return;
        }
        this.closeAllPopups();
        this.openedReactionListMessageId = message.createAt;
        this.reactionListTarget = ev.currentTarget;
        this.updateReactionListPlacement();
    }
    updateReactionListPlacement() {
        if (!this.reactionListTarget)
            return;
        const popup = this.renderRoot.querySelector('.reaction-list-popup');
        if (!popup)
            return;
        const targetRect = this.reactionListTarget.getBoundingClientRect();
        const popupRect = popup.getBoundingClientRect();
        const viewportHeight = window.innerHeight;
        const spaceBelow = viewportHeight - targetRect.bottom;
        const spaceAbove = targetRect.top;
        const shouldOpenTop = spaceBelow < popupRect.height && spaceAbove > spaceBelow;
        this.reactionListPlacement = shouldOpenTop ? 'top' : 'bottom';
        requestAnimationFrame(() => {
            popup.classList.add('open');
        });
    }
    removeReactionFromList(message, reactionName) {
        if (!this.userId)
            return;
        if (!this.canWriteThread())
            return;
        const updated = this.toggleReaction(message, reactionName, this.userId);
        this.message = updated;
        const totalReactions = updated.reactions
            ? Object.values(updated.reactions).reduce((acc, users) => acc + users.length, 0)
            : 0;
        if (totalReactions === 0) {
            this.closeReactionList();
        }
    }
    closeReactionList() {
        this.openedReactionListMessageId = undefined;
        this.reactionListTarget = undefined;
    }
    renderSideAction(message) {
        if (this.hasExecutionFollowup(message))
            return this.renderFollowupQuickActions(message);
        return this.renderReactionButtonAdd(message);
    }
    renderFollowupQuickActions(message) {
        if (!this.canWriteThread() || !this.userId)
            return nothing;
        const request = this.getActiveExecutionFollowup(message);
        if (!request)
            return nothing;
        const actions = this.getFollowupActions(message);
        if (actions.length === 0)
            return nothing;
        const current = this.getFollowupReactionForUser(message, this.userId);
        return html `
            <div class="followup-action-wrapper">
                <button
                    class="followup-action-trigger ${current ? 'active' : ''}"
                    title=${current ? this.getFollowupLabel(current) : this.msg.requestExecutionConfirmation}
                    aria-label=${current ? this.getFollowupLabel(current) : this.msg.requestExecutionConfirmation}
                    @click=${(ev) => this.openFollowupActionMenu(message, ev)}
                >
                    ${this.renderFollowupIcon(current || actions[0])}
                </button>
                ${this.openedFollowupActionsMessageId === message.createAt ? html `
                <div class="followup-action-menu" role="menu">
                    ${actions.map(reaction => html `
                    <button
                        class="followup-action ${current === reaction ? 'active' : ''}"
                        title=${this.getFollowupLabel(reaction)}
                        aria-label=${this.getFollowupLabel(reaction)}
                        @click=${(ev) => this.onFollowupActionClick(ev, message, reaction)}
                    >
                        ${this.renderFollowupIcon(reaction)}
                        <span>${this.getFollowupLabel(reaction)}</span>
                    </button>
                    `)}
                </div>
                ` : nothing}
            </div>
        `;
    }
    getFollowupActions(message) {
        if (!this.userId)
            return [];
        const request = this.getActiveExecutionFollowup(message);
        if (!request)
            return [];
        if (request.requestedBy === this.userId)
            return ['followup_revisado'];
        if (request.targetUserIds.includes(this.userId)) {
            return ['followup_lido', 'followup_vou_fazer', 'followup_concluido', 'followup_bloqueado', 'followup_cancelado'];
        }
        return [];
    }
    renderReactionButtonAdd(message) {
        if (!this.canWriteThread())
            return nothing;
        return html `
            <button
                class="reaction add"
                @click=${(ev) => this.openReactionPicker(message, ev)}
            >
                ${collab_smile}
            </button>
        `;
    }
    renderReactionPicker(message) {
        if (!this.canWriteThread())
            return nothing;
        if (this.hasExecutionFollowup(message))
            return nothing;
        if (this.openedReactionMessageId !== message.createAt)
            return nothing;
        return html `
        <div class="reaction-picker">
            ${Object.entries(this.reactionEmojis).map(([name, emoji]) => html `
                <button
                    class="reaction-picker-item"
                    @click=${() => this.onPickerEmojiSelect(message, name)}
                >
                    ${emoji}
                </button>
            `)}
        </div>
    `;
    }
    onPickerEmojiSelect(message, emoji) {
        if (!this.userId)
            return;
        if (!this.canWriteThread())
            return;
        const updated = this.toggleReaction(message, emoji, this.userId);
        this.message = updated;
        this.closeReactionPicker();
    }
    onFollowupActionClick(ev, message, reaction) {
        ev.stopPropagation();
        if (!this.userId)
            return;
        if (!this.canWriteThread())
            return;
        const updated = this.toggleReaction(message, reaction, this.userId);
        this.message = updated;
        this.closeFollowupActionMenu();
    }
    openFollowupActionMenu(message, ev) {
        ev.stopPropagation();
        if (this.openedFollowupActionsMessageId === message.createAt) {
            this.closeFollowupActionMenu();
            return;
        }
        this.closeAllPopups();
        this.openedFollowupActionsMessageId = message.createAt;
        this.followupActionTarget = ev.currentTarget;
        this.followupActionAnchor = undefined;
    }
    closeFollowupActionMenu() {
        this.openedFollowupActionsMessageId = undefined;
        this.followupActionTarget = undefined;
        this.followupActionAnchor = undefined;
    }
    onDocumentClick(ev) {
        const target = ev.target;
        if (!(target instanceof Node))
            return;
        if (this.contains(target) && this.isPopupInteractionTarget(target))
            return;
        this.closeLocalPopups();
    }
    isPopupInteractionTarget(target) {
        const element = target instanceof Element ? target : target.parentElement;
        return !!element?.closest([
            '.message-menu',
            '.message-action.submenu',
            '.reaction-picker',
            '.reaction.add',
            '.message-reactions',
            '.followup-action-menu',
            '.followup-action-trigger',
        ].join(','));
    }
    closeLocalPopups() {
        this.openedReactionMessageId = undefined;
        this.reactionPickerTarget = undefined;
        this.openedMenuFor = undefined;
        this.messageMenuTarget = undefined;
        this.openedReactionListMessageId = undefined;
        this.reactionListTarget = undefined;
        this.openedFollowupActionsMessageId = undefined;
        this.followupActionTarget = undefined;
        this.followupActionAnchor = undefined;
    }
    openReactionPicker(message, ev) {
        ev?.stopPropagation();
        if (!this.canWriteThread())
            return;
        if (this.hasExecutionFollowup(message))
            return;
        if (this.openedReactionMessageId === message.createAt) {
            this.closeReactionPicker();
            return;
        }
        this.closeReactionPicker();
        this.openedReactionMessageId = message.createAt;
        this.reactionPickerTarget = ev?.currentTarget;
    }
    closeReactionPicker() {
        this.openedReactionMessageId = undefined;
        this.reactionPickerTarget = undefined;
        this.closeAllPopups();
    }
    toggleReaction(message, reaction, userId) {
        const current = message.reactions ?? {};
        if (this.isFollowupReaction(reaction) && current[reaction]?.includes(userId)) {
            this.updateReactionOnDb(message, reaction);
            return {
                ...message,
                lastChanged: Date.now()
            };
        }
        const next = {};
        for (const [name, users] of Object.entries(current)) {
            const filtered = users.filter(id => id !== userId);
            if (filtered.length) {
                next[name] = filtered;
            }
        }
        if (!current[reaction]?.includes(userId)) {
            next[reaction] = [...(next[reaction] ?? []), userId];
        }
        this.updateReactionOnDb(message, reaction);
        return {
            ...message,
            reactions: Object.keys(next).length ? next : undefined,
            lastChanged: Date.now()
        };
    }
    async updateReactionOnDb(message, reaction) {
        if (!this.actualThread?.thread.threadId)
            throw new Error('Invalid thread id');
        if (!this.userId)
            throw new Error('Invalid user id');
        const result = await msgUpdateMessage({
            messageId: message.createAt,
            threadId: this.actualThread.thread.threadId,
            userId: this.userId,
            reaction,
        });
        if (!result.success || !result.response?.message) {
            throw new Error(result.error || 'Failed to update message reaction');
        }
        this.message = {
            ...result.response.message,
            footers: message.footers
        };
        await updateMessage(this.message);
    }
    animateReactionPicker() {
        const picker = this.querySelector('.reaction-picker');
        if (!picker)
            return;
        const items = Array.from(picker.querySelectorAll('.reaction-picker-item'));
        requestAnimationFrame(() => {
            picker.classList.add('open');
            items.forEach((el, i) => {
                setTimeout(() => {
                    el.classList.add('show');
                }, 65 * i);
            });
        });
    }
    positionReactionPicker() {
        if (!this.reactionPickerTarget)
            return;
        const picker = this.querySelector('.reaction-picker');
        if (!picker)
            return;
        const btnRect = this.reactionPickerTarget.getBoundingClientRect();
        const pickerRect = picker.getBoundingClientRect();
        const GAP = 8;
        const VIEWPORT_GAP = 8;
        const top = btnRect.top - pickerRect.height - GAP;
        const fallbackTop = btnRect.bottom + GAP;
        const left = btnRect.left + (btnRect.width / 2) - (pickerRect.width / 2);
        picker.style.position = 'fixed';
        picker.style.top = `${Math.max(top > VIEWPORT_GAP ? top : fallbackTop, VIEWPORT_GAP)}px`;
        picker.style.bottom = 'auto';
        picker.style.left = `${Math.min(Math.max(left, VIEWPORT_GAP), window.innerWidth - pickerRect.width - VIEWPORT_GAP)}px`;
        picker.style.right = 'auto';
    }
    positionFollowupActionMenu() {
        if (!this.followupActionTarget && !this.followupActionAnchor)
            return;
        const menu = this.querySelector('.followup-action-menu');
        if (!menu)
            return;
        const targetRect = this.followupActionAnchor || this.followupActionTarget.getBoundingClientRect();
        const menuRect = menu.getBoundingClientRect();
        const GAP = 8;
        const VIEWPORT_GAP = 8;
        const spaceBelow = window.innerHeight - targetRect.bottom;
        const top = spaceBelow >= menuRect.height + GAP
            ? targetRect.bottom + GAP
            : targetRect.top - menuRect.height - GAP;
        const left = targetRect.left + (targetRect.width / 2) - (menuRect.width / 2);
        menu.style.position = 'fixed';
        menu.style.top = `${Math.min(Math.max(top, VIEWPORT_GAP), window.innerHeight - menuRect.height - VIEWPORT_GAP)}px`;
        menu.style.left = `${Math.min(Math.max(left, VIEWPORT_GAP), window.innerWidth - menuRect.width - VIEWPORT_GAP)}px`;
        menu.style.right = 'auto';
    }
    // REPLY
    renderSubMenuButton(message) {
        return html `
        <button
            class="message-action submenu"
            @click=${(ev) => this.openMessageMenu(message, ev)}
        >
            ${collab_chevron_down}
        </button>
    `;
    }
    openMessageMenu(message, ev) {
        ev.stopPropagation();
        if (this.openedMenuFor === message.createAt) {
            this.closeMessageMenu();
            return;
        }
        this.closeMessageMenu();
        this.openedMenuFor = message.createAt;
        this.messageMenuTarget = ev.currentTarget;
    }
    positionMessageMenu() {
        if (!this.messageMenuTarget)
            return;
        const submenu = this.querySelector('.message-menu');
        if (!submenu)
            return;
        const btnRect = this.messageMenuTarget.getBoundingClientRect();
        const pickerRect = submenu.getBoundingClientRect();
        const parent = submenu.offsetParent;
        const parentRect = parent.getBoundingClientRect();
        const GAP = 8;
        const VIEWPORT_GAP = 8;
        const spaceBelow = window.innerHeight - btnRect.bottom;
        let top;
        if (spaceBelow >= pickerRect.height + GAP) {
            top =
                btnRect.bottom -
                    parentRect.top +
                    GAP;
        }
        else {
            top =
                btnRect.top -
                    parentRect.top -
                    pickerRect.height -
                    GAP;
        }
        submenu.style.top = `${top}px`;
        submenu.style.bottom = 'auto';
        if (parent.classList.contains('user')) {
            submenu.style.right = '10px';
            submenu.style.left = 'auto';
        }
        else {
            submenu.style.left = '10px';
            submenu.style.right = 'auto';
        }
        const menuRect = submenu.getBoundingClientRect();
        if (menuRect.left < VIEWPORT_GAP) {
            const currentLeft = parseFloat(submenu.style.left || '0') || 0;
            submenu.style.left = `${currentLeft + VIEWPORT_GAP - menuRect.left}px`;
            submenu.style.right = 'auto';
        }
        else if (menuRect.right > window.innerWidth - VIEWPORT_GAP) {
            const currentRight = parseFloat(submenu.style.right || '0') || 0;
            submenu.style.right = `${currentRight + menuRect.right - (window.innerWidth - VIEWPORT_GAP)}px`;
            submenu.style.left = 'auto';
        }
    }
    closeMessageMenu() {
        this.openedMenuFor = undefined;
        this.messageMenuTarget = undefined;
        this.closeAllPopups();
    }
    renderMessageMenu(message) {
        if (this.openedMenuFor !== message.createAt)
            return nothing;
        const canWrite = this.canWriteThread();
        const canUseMessageActions = canWrite && !message.moderation;
        const canCancelReadConfirmation = canUseMessageActions && this.canCancelReadConfirmation(message);
        const canRequestReadConfirmation = canUseMessageActions && this.getMentionedUserIds(message).length > 0 && !this.hasReadConfirmation(message);
        const canRequestExecutionConfirmation = canUseMessageActions && this.getMentionedUserIds(message).length > 0 && !this.hasExecutionFollowup(message);
        const canOpenFollowupActions = canUseMessageActions && this.hasExecutionFollowup(message) && this.getFollowupActions(message).length > 0;
        const canConfirmRead = canUseMessageActions && this.hasPendingReadConfirmation(message);
        const allConfirmedRead = this.hasAllReadConfirmationsConfirmed(message);
        const canDeleteMessage = this.canDeleteMessage(message);
        const canModerateMessage = this.canModerateMessage(message);
        const canEditMessage = this.canEditMessage(message);
        const canReadContent = !this.isMessageContentHidden(message);
        return html `
        <div class="message-menu ${this.messageMenuPlacement}">
            <button ?disabled=${!canReadContent} @click=${() => this.onCopyTextClick(message)}>
                ${collab_copy}
                ${this.msg.copy}
            </button>
            <button @click=${() => this.onCopyLinkClick(message)}>
                ${collab_link}
                ${this.msg.copyLink}
            </button>
            <button ?disabled=${!canReadContent} @click=${() => this.onReplyClick(message)}>
                ${collab_reply}
                ${this.msg.reply}
            </button>
            <button @click=${() => this.onMarkUnreadClick(message)}>
                ${collab_bell_slash}
                ${this.msg.markUnread}
            </button>
            <button ?disabled=${!canUseMessageActions} @click=${() => this.onPinClick(message)}>
                ${collab_pin}
                ${this.isPinned(message) ? this.msg.unpin : this.msg.pin}
            </button>
            <button @click=${() => this.onFavoriteClick(message)}>
                ${collab_star}
                ${this.isFavorite(message) ? this.msg.unfavorite : this.msg.favorite}
            </button>
            <button
                ?disabled=${!canRequestReadConfirmation && !canCancelReadConfirmation}
                @click=${() => this.onReadConfirmationClick(message, canCancelReadConfirmation ? 'cancel' : 'request')}
            >
                ${canCancelReadConfirmation ? collab_xmark : collab_circle_exclamation}
                ${canCancelReadConfirmation ? this.msg.cancelReadConfirmation : this.msg.requestReadConfirmation}
            </button>
            <button ?disabled=${!canConfirmRead} @click=${() => this.onReadConfirmationClick(message, 'confirm')}>
                ${collab_check}
                ${this.msg.confirmRead}
            </button>
            <button
                ?disabled=${!canRequestExecutionConfirmation}
                @click=${() => this.onReadConfirmationClick(message, 'requestExecution')}
            >
                ${collab_play}
                ${this.msg.requestExecutionConfirmation}
            </button>
            ${this.hasExecutionFollowup(message) ? html `
                <button
                    ?disabled=${!canOpenFollowupActions}
                    @click=${(ev) => this.onFollowupActionsMenuClick(ev, message)}
                >
                    ${collab_play}
                    ${this.msg.followupActions}
                </button>
            ` : nothing}
            ${allConfirmedRead ? html `
                <button disabled>
                    ${collab_check}
                    ${this.msg.allConfirmedRead}
                </button>
            ` : nothing}
            <button ?disabled=${!canUseMessageActions || !!message.taskId} @click=${() => this.onMessageActionClick(message, 'createTask')}>
                ${collab_tasks}
                ${this.msg.createTask}
            </button>
            <button ?disabled=${!canReadContent} @click=${() => this.onForwardClick(message)}>
                ${collab_chevron_right}
                ${this.msg.forward}
            </button>
            <button ?disabled=${!canEditMessage} @click=${() => this.onEditClick(message)}>
                ${collab_edit}
                ${this.msg.edit}
            </button>
            ${message.edits?.length ? html `
                <button ?disabled=${!canReadContent} @click=${() => this.onViewHistoryClick()}>
                    ${collab_clock_static}
                    ${this.msg.viewHistory}
                </button>
            ` : nothing}
            <button ?disabled=${!canDeleteMessage} @click=${() => this.onMessageActionClick(message, 'delete')}>
                ${collab_delete}
                ${this.msg.delete}
            </button>
            <button ?disabled=${!canModerateMessage} @click=${() => this.onMessageActionClick(message, 'moderate')}>
                ${collab_ban}
                ${this.msg.moderate}
            </button>
        
        </div>
    `;
    }
    onReplyClick(message) {
        this.closeMessageMenu();
        this.dispatchEvent(new CustomEvent('reply-message', {
            detail: message,
            bubbles: true,
            composed: true
        }));
    }
    async onCopyTextClick(message) {
        if (this.isMessageContentHidden(message))
            return;
        this.closeMessageMenu();
        await navigator.clipboard?.writeText(message.content || '');
    }
    async onCopyLinkClick(message) {
        this.closeMessageMenu();
        await navigator.clipboard?.writeText(this.getMessageLink(message));
    }
    getMessageLink(message) {
        const messageId = encodeURIComponent(message.orderAt || message.createAt);
        const threadId = encodeURIComponent(message.threadId);
        const url = new URL(window.location.href);
        url.hash = `message/${threadId}/${messageId}`;
        return url.toString();
    }
    onMarkUnreadClick(message) {
        this.closeMessageMenu();
        this.dispatchEvent(new CustomEvent('mark-unread-message', {
            detail: { message },
            bubbles: true,
            composed: true
        }));
    }
    onForwardClick(message) {
        if (this.isMessageContentHidden(message))
            return;
        this.closeMessageMenu();
        this.dispatchEvent(new CustomEvent('forward-message', {
            detail: { message },
            bubbles: true,
            composed: true
        }));
    }
    onEditClick(message) {
        if (!this.canEditMessage(message))
            return;
        this.closeMessageMenu();
        this.editContent = message.content || '';
        this.isEditingMessage = true;
    }
    onEditCancelClick() {
        this.isEditingMessage = false;
        this.editContent = '';
    }
    onEditSaveClick(message) {
        const content = this.editContent.trim();
        if (!content || content === message.content)
            return;
        this.isEditingMessage = false;
        this.dispatchEvent(new CustomEvent('edit-message', {
            detail: { message, content },
            bubbles: true,
            composed: true
        }));
    }
    onViewHistoryClick() {
        this.closeMessageMenu();
        this.showEditHistory = !this.showEditHistory;
    }
    onHistoryToggleClick(ev) {
        ev.preventDefault();
        ev.stopPropagation();
        this.showEditHistory = !this.showEditHistory;
    }
    onPinClick(message) {
        if (!this.canWriteThread())
            return;
        this.closeMessageMenu();
        this.dispatchEvent(new CustomEvent('pin-message', {
            detail: {
                message,
                pin: !this.isPinned(message)
            },
            bubbles: true,
            composed: true
        }));
    }
    onFavoriteClick(message) {
        this.closeMessageMenu();
        this.dispatchEvent(new CustomEvent('favorite-message', {
            detail: {
                message,
                favorite: !this.isFavorite(message)
            },
            bubbles: true,
            composed: true
        }));
    }
    onReadConfirmationClick(message, action) {
        if (!this.canWriteThread())
            return;
        this.closeMessageMenu();
        this.dispatchEvent(new CustomEvent('read-confirmation-message', {
            detail: {
                message,
                action
            },
            bubbles: true,
            composed: true
        }));
    }
    onFollowupActionsMenuClick(ev, message) {
        ev.preventDefault();
        ev.stopPropagation();
        if (!this.getFollowupActions(message).length)
            return;
        const target = ev.currentTarget;
        const followupTrigger = this.querySelector('.followup-action-trigger');
        this.openedMenuFor = undefined;
        this.messageMenuTarget = undefined;
        this.openedReactionMessageId = undefined;
        this.reactionPickerTarget = undefined;
        this.openedReactionListMessageId = undefined;
        this.reactionListTarget = undefined;
        this.openedFollowupActionsMessageId = message.createAt;
        this.followupActionTarget = followupTrigger || undefined;
        this.followupActionAnchor = followupTrigger ? undefined : target.getBoundingClientRect();
    }
    onMessageActionClick(message, action) {
        if (action === 'delete' && !this.canDeleteMessage(message))
            return;
        if (action === 'moderate' && !this.canModerateMessage(message))
            return;
        if (action === 'createTask' && (message.moderation || message.taskId || !this.canWriteThread()))
            return;
        this.closeMessageMenu();
        this.dispatchEvent(new CustomEvent('message-action-message', {
            detail: {
                message,
                action
            },
            bubbles: true,
            composed: true
        }));
    }
    isPinned(message) {
        const messageId = `${message.threadId}/${message.orderAt || message.createAt}`;
        return !!this.actualThread?.thread.pinnedMessages?.some(item => item.messageId === messageId);
    }
    isFavorite(message) {
        const messageId = `${message.threadId}/${message.orderAt || message.createAt}`;
        return !!this.currentUser?.favorites?.includes(messageId);
    }
    getMentionedUserIds(message) {
        if (!this.userId)
            return [];
        const usersInThread = new Set(this.actualThread?.thread.users.map(user => user.userId) || []);
        return [...message.content.matchAll(/\[@[^\]]+\]\(([^)]+)\)/g)]
            .map(match => match[1])
            .filter(userId => userId !== this.userId && usersInThread.has(userId))
            .filter((userId, index, items) => items.indexOf(userId) === index);
    }
    hasReadConfirmation(message) {
        return !!message.readConfirmations?.some(request => this.getReadConfirmationKind(request) === 'read');
    }
    hasPendingReadConfirmation(message) {
        if (!this.userId)
            return false;
        return !!message.readConfirmations?.some(request => this.getReadConfirmationKind(request) === 'read' &&
            !request.canceledAt &&
            request.targetUserIds.includes(this.userId) && !request.confirmedBy?.[this.userId]);
    }
    hasAllReadConfirmationsConfirmed(message) {
        if (!this.userId)
            return false;
        return !!message.readConfirmations?.some(request => this.getReadConfirmationKind(request) === 'read' &&
            !request.canceledAt &&
            request.requestedBy === this.userId && request.targetUserIds.length > 0 &&
            request.targetUserIds.every(userId => !!request.confirmedBy?.[userId]));
    }
    canCancelReadConfirmation(message) {
        if (!this.userId)
            return false;
        return !!message.readConfirmations?.some(request => this.getReadConfirmationKind(request) === 'read' &&
            !request.canceledAt &&
            request.requestedBy === this.userId &&
            request.targetUserIds.some(userId => !request.confirmedBy?.[userId]));
    }
    closeAllPopups() {
        if (!this.parentElement)
            return;
        const all = Array.from(this.parentElement.querySelectorAll('collab-messages-chat-message-102025'));
        all.forEach((item) => {
            item.openedReactionMessageId = undefined;
            item.reactionPickerTarget = undefined;
            item.openedMenuFor = undefined;
            item.messageMenuTarget = undefined;
            item.openedReactionListMessageId = undefined;
            item.reactionListTarget = undefined;
            item.openedFollowupActionsMessageId = undefined;
            item.followupActionTarget = undefined;
        });
    }
    updateMessageMenuPlacement() {
        if (!this.messageMenuTarget)
            return;
        const menu = this.renderRoot.querySelector('.message-menu');
        if (!menu)
            return;
        const targetRect = this.messageMenuTarget.getBoundingClientRect();
        const menuRect = menu.getBoundingClientRect();
        const viewportHeight = window.innerHeight;
        const spaceBelow = viewportHeight - targetRect.bottom;
        const spaceAbove = targetRect.top;
        const shouldOpenTop = spaceBelow < menuRect.height && spaceAbove > spaceBelow;
        this.messageMenuPlacement = shouldOpenTop ? 'top' : 'bottom';
        requestAnimationFrame(() => {
            menu.classList.add('open');
        });
    }
    getMessageOrderAt(message) {
        const value = message.orderAt || message.createAt || '';
        const parts = value.split('/').filter(Boolean);
        return parts[parts.length - 1] || value;
    }
    normalizeMessageId(threadId, messageIdOrOrderAt) {
        const parts = messageIdOrOrderAt.split('/').filter(Boolean);
        const orderAt = parts[parts.length - 1] || messageIdOrOrderAt;
        return `${threadId}/${orderAt}`;
    }
};
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "message", void 0);
__decorate([
    property({ reflect: true })
], CollabMessagesChatMessage102025.prototype, "messageId", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesChatMessage102025.prototype, "allThreads", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "actualThread", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "usersAvaliables", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "currentUser", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "userId", void 0);
__decorate([
    property({ type: Boolean })
], CollabMessagesChatMessage102025.prototype, "toolbarHighlighted", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesChatMessage102025.prototype, "openedReactionMessageId", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesChatMessage102025.prototype, "reactionPickerTarget", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "openedMenuFor", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "messageMenuTarget", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "openedReactionListMessageId", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "reactionListTarget", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "openedFollowupActionsMessageId", void 0);
__decorate([
    property()
], CollabMessagesChatMessage102025.prototype, "followupActionTarget", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesChatMessage102025.prototype, "followupActionAnchor", void 0);
__decorate([
    state()
], CollabMessagesChatMessage102025.prototype, "userPreferenceChat", void 0);
__decorate([
    state()
], CollabMessagesChatMessage102025.prototype, "messageMenuPlacement", void 0);
__decorate([
    state()
], CollabMessagesChatMessage102025.prototype, "reactionListPlacement", void 0);
__decorate([
    state()
], CollabMessagesChatMessage102025.prototype, "isEditingMessage", void 0);
__decorate([
    state()
], CollabMessagesChatMessage102025.prototype, "editContent", void 0);
__decorate([
    state()
], CollabMessagesChatMessage102025.prototype, "showEditHistory", void 0);
CollabMessagesChatMessage102025 = __decorate([
    customElement('collab-messages-chat-message-102025')
], CollabMessagesChatMessage102025);
export { CollabMessagesChatMessage102025 };
