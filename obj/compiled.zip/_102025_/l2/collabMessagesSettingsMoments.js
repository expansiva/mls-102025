/// <mls fileReference="_102025_/l2/collabMessagesSettingsMoments.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { msgGetMomentsSubscriptions, msgSetMomentsMute, } from '/_102025_/l2/collabMessagesMomentsApi.js';
import { msgGetUserUpdate } from '/_102025_/l2/shared/api.js';
import { collab_gear } from '/_102025_/l2/collabMessagesIcons.js';
/// **collab_i18n_start**
const message_pt = {
    title: 'Publicadores',
    hint: 'Silenciar esconde os moments deste publicador no seu feed. O publicador não é avisado.',
    mute: 'Silenciar',
    loading: 'Carregando...',
    empty: 'Ninguém publicou moments para você.',
    retry: 'Tentar de novo',
    error: 'Não foi possível carregar os publicadores.',
};
const message_en = {
    title: 'Publishers',
    hint: 'Mute hides this publisher’s moments from your feed. The publisher is not notified.',
    mute: 'Mute',
    loading: 'Loading...',
    empty: 'No one has published moments for you.',
    retry: 'Try again',
    error: 'Could not load publishers.',
};
const messages = {
    'en': message_en,
    'pt': message_pt,
};
/// **collab_i18n_end**
let CollabMessagesSettingsMoments = class CollabMessagesSettingsMoments extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-settings-moments-102025 {
  display: block;
}
collab-messages-settings-moments-102025 .section {
  padding: 1.4rem 0.75rem;
  border-radius: 10px;
  box-shadow: #e7e3e3 0px 1px 4px;
  background-color: var(--surface-alt-bg);
  margin-bottom: 1.5rem;
}
collab-messages-settings-moments-102025 .section h4 {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 0.75rem;
  margin-block-start: 0;
  padding-bottom: 0.4rem;
  border-bottom: 1px solid #d2d2d2;
}
collab-messages-settings-moments-102025 .section h4 svg {
  fill: currentColor;
  width: 20px;
  height: 20px;
}
collab-messages-settings-moments-102025 .hint,
collab-messages-settings-moments-102025 .empty {
  margin: 0 0 0.75rem;
  font-size: var(--font-size-12);
  color: var(--text-muted);
}
collab-messages-settings-moments-102025 .saving-error {
  color: var(--status-error-text);
  font-size: var(--font-size-12);
}
collab-messages-settings-moments-102025 .publisher-list {
  list-style: none;
  margin: 0;
  padding: 0;
}
collab-messages-settings-moments-102025 .publisher-row {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.5rem 0;
  border-bottom: 1px solid #e6e6e6;
}
collab-messages-settings-moments-102025 .avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  object-fit: cover;
  background: #d8d8d8;
  flex: 0 0 auto;
}
collab-messages-settings-moments-102025 .name {
  flex: 1;
  min-width: 0;
}
collab-messages-settings-moments-102025 .mute {
  display: flex;
  align-items: center;
  gap: 0.35rem;
  font-size: var(--font-size-12);
  white-space: nowrap;
}
`);
        this.msg = messages['en'];
        this.userId = '';
        this.items = [];
        this.loading = true;
        this.error = '';
        this.pending = new Set();
    }
    async firstUpdated() {
        await this.load();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <div class="section moments-publishers">
            <h4>${collab_gear} ${this.msg.title}</h4>
            <p class="hint">${this.msg.hint}</p>
            ${this.loading ? html `<div>${this.msg.loading}</div>` : ''}
            ${this.error ? html `
                <p class="saving-error">${this.error}</p>
                <button type="button" @click=${() => { void this.load(); }}>${this.msg.retry}</button>
            ` : ''}
            ${!this.loading && !this.error && this.items.length === 0
            ? html `<p class="empty">${this.msg.empty}</p>`
            : ''}
            <ul class="publisher-list">
                ${this.items.map((item) => html `
                    <li class="publisher-row">
                        ${item.publisher.avatar_url
            ? html `<img class="avatar" src=${item.publisher.avatar_url} alt="">`
            : html `<span class="avatar"></span>`}
                        <span class="name">${item.publisher.name}</span>
                        <label class="mute">
                            <input
                                type="checkbox"
                                .checked=${item.muted}
                                ?disabled=${this.pending.has(item.threadId)}
                                @change=${(ev) => { void this.onMute(item, ev.target.checked); }}
                            >
                            ${this.msg.mute}
                        </label>
                    </li>
                `)}
            </ul>
        </div>
        `;
    }
    async load() {
        this.loading = true;
        this.error = '';
        try {
            if (!this.userId) {
                const userResult = await msgGetUserUpdate({ userId: '' });
                if (!userResult.success || !userResult.response?.user?.userId) {
                    throw new Error(userResult.error || 'Failed to fetch user');
                }
                this.userId = userResult.response.user.userId;
            }
            const result = await msgGetMomentsSubscriptions({ userId: this.userId });
            if (!result.ok) {
                console.error(result.error);
                this.error = result.error || this.msg.error;
                this.items = [];
                return;
            }
            this.items = result.response.items ?? [];
        }
        catch (err) {
            console.error(err);
            this.error = err instanceof Error ? err.message : this.msg.error;
            this.items = [];
        }
        finally {
            this.loading = false;
        }
    }
    async onMute(item, muted) {
        const previous = item.muted;
        this.items = this.items.map((row) => row.threadId === item.threadId ? { ...row, muted } : row);
        this.pending = new Set(this.pending).add(item.threadId);
        try {
            const result = await msgSetMomentsMute({ userId: this.userId, threadId: item.threadId, muted });
            if (!result.ok) {
                console.error(result.error);
                this.items = this.items.map((row) => row.threadId === item.threadId ? { ...row, muted: previous } : row);
                this.error = result.error;
            }
        }
        catch (err) {
            console.error(err);
            this.items = this.items.map((row) => row.threadId === item.threadId ? { ...row, muted: previous } : row);
            this.error = err instanceof Error ? err.message : this.msg.error;
        }
        finally {
            const next = new Set(this.pending);
            next.delete(item.threadId);
            this.pending = next;
        }
    }
};
__decorate([
    state()
], CollabMessagesSettingsMoments.prototype, "userId", void 0);
__decorate([
    state()
], CollabMessagesSettingsMoments.prototype, "items", void 0);
__decorate([
    state()
], CollabMessagesSettingsMoments.prototype, "loading", void 0);
__decorate([
    state()
], CollabMessagesSettingsMoments.prototype, "error", void 0);
__decorate([
    state()
], CollabMessagesSettingsMoments.prototype, "pending", void 0);
CollabMessagesSettingsMoments = __decorate([
    customElement('collab-messages-settings-moments-102025')
], CollabMessagesSettingsMoments);
export { CollabMessagesSettingsMoments };
