/// <mls fileReference="_102025_/l2/collabMessagesInputTag.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, ifDefined } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
let CollabMessagesInputTag = class CollabMessagesInputTag extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-input-tag-102025{font-family:var(--font-family-primary)}collab-messages-input-tag-102025[haserror="true"] .collab-tag-input{border:1px solid var(--error-color-hover) !important}collab-messages-input-tag-102025 .invalid{border:1px solid var(--error-color) !important;animation:shake .3s}@keyframes shake{0%{transform:translateX(0)}25%{transform:translateX(-4px)}50%{transform:translateX(4px)}75%{transform:translateX(-4px)}100%{transform:translateX(0)}}collab-messages-input-tag-102025 .collab-tag-input{max-width:100%;display:flex;align-content:flex-start;flex-wrap:wrap;background-color:#FFF;border:solid 1px #CCC;border-radius:2px;min-height:33px;padding:0 5px}collab-messages-input-tag-102025 .collab-tag-input input{flex-grow:1;display:inline-block;order:200;border:none;height:33px;line-height:33px;font-size:14px;margin:0;width:auto}collab-messages-input-tag-102025 .collab-tag-input input:focus{outline:none}collab-messages-input-tag-102025 .collab-tag-input div.tag{display:inline-block;flex-grow:0;margin:5px 5px 5px 0;padding:0 20px 0 10px;height:25px;line-height:25px;background-color:#E1E1E1;color:#333;font-size:14px;order:100;border-radius:2px;position:relative;overflow:hidden}collab-messages-input-tag-102025 .collab-tag-input div.tag.duplicate{background-color:rgba(255,64,27,0.71);transition:all .3s linear}collab-messages-input-tag-102025 .collab-tag-input div.tag:last-child{margin-right:5px}collab-messages-input-tag-102025 .collab-tag-input div.tag .remove{display:inline-block;color:#000000;padding-left:.45rem;position:absolute;text-align:center;border-top-right-radius:2px;border-bottom-right-radius:2px;transition:all .3s ease;cursor:pointer;top:0;right:5px}`);
        this.tags = [];
        this.pattern = null;
        this.placeholder = null;
        this.allowDelete = false;
        this.hasError = false;
    }
    get value() {
        return this.tags.join(',');
    }
    set value(val) {
        if (!val) {
            this.empty();
            return;
        }
        const arrTags = val.split(',');
        this.tags = arrTags;
    }
    addTag(tag) { return this._addTag(tag); }
    deleteTag(index) { return this._deleteTag(index); }
    empty() { return this._empty(); }
    _addTag(tag) {
        if (!tag)
            return;
        if (!this.isValidTag(tag)) {
            this.input?.parentElement?.classList.add('invalid');
            setTimeout(() => this.input?.parentElement?.classList.remove('invalid'), 500);
            this.hasError = true;
            return;
        }
        if (this.tags.indexOf(tag) === -1) {
            this.tags.push(tag);
            if (this.input)
                this.input.value = '';
            this.requestUpdate();
        }
        else {
            const element = this.querySelector(`[data-index="${this.tags.indexOf(tag)}"]`);
            element.classList.add('duplicate');
            setTimeout(() => element.classList.remove('duplicate'), 500);
            this.hasError = true;
        }
    }
    _deleteTag(index) {
        const newTags = [];
        this.tags.forEach((tag, idx) => {
            if (idx !== index) {
                newTags.push(tag);
            }
        });
        this.tags = newTags;
        this.requestUpdate();
    }
    _empty() {
        this.tags = [];
        this.requestUpdate();
    }
    onInputLeave() {
        if (!this.input)
            return;
        const { value } = this.input;
        this._addTag(value);
        if (this.onValueChanged)
            this.onValueChanged(this.value);
    }
    onInputKeyDown(event) {
        event.stopImmediatePropagation();
        if (!this.input)
            return;
        const { value } = this.input;
        this.hasError = false;
        if (event.keyCode === 13) {
            this._addTag(value);
            if (this.onValueChanged)
                this.onValueChanged(this.value);
        }
        else if (event.keyCode === 188) {
            event.preventDefault();
            this._addTag(value);
            if (this.onValueChanged)
                this.onValueChanged(this.value);
        }
        else if (event.keyCode === 8 && value.length === 0) {
            if (this.allowDelete) {
                this._deleteTag(this.tags.length - 1);
                if (this.onValueChanged)
                    this.onValueChanged(this.value);
                this.allowDelete = false;
            }
            else {
                this.allowDelete = true;
            }
        }
    }
    isValidTag(tag) {
        if (this.pattern) {
            const regex = new RegExp(this.pattern);
            if (!regex.test(tag))
                return false;
        }
        return true;
    }
    render() {
        return html `<div class="collab-tag-input">
                <input
                    id="tag-input"
                    placeholder=${ifDefined(!this.value ? this.placeholder : undefined)}
                    autocomplete="off"
                    @blur=${this.onInputLeave}
                    @keydown=${(ev) => { this.onInputKeyDown(ev); }}
                ></input>
                ${this.tags.map((tag, index) => {
            return html `
                    <div data-index=${index} class="tag">
                        ${tag}
                    </div>
                    `;
        })}
        </div>`;
    }
};
__decorate([
    property()
], CollabMessagesInputTag.prototype, "tags", void 0);
__decorate([
    query('#tag-input')
], CollabMessagesInputTag.prototype, "input", void 0);
__decorate([
    property({ type: String })
], CollabMessagesInputTag.prototype, "pattern", void 0);
__decorate([
    property({ type: String })
], CollabMessagesInputTag.prototype, "placeholder", void 0);
__decorate([
    property({ attribute: true, reflect: true })
], CollabMessagesInputTag.prototype, "hasError", void 0);
CollabMessagesInputTag = __decorate([
    customElement('collab-messages-input-tag-102025')
], CollabMessagesInputTag);
export { CollabMessagesInputTag };
