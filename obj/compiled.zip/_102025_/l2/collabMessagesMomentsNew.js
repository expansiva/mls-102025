/// <mls fileReference="_102025_/l2/collabMessagesMomentsNew.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { getUserId, loadNotificationDeviceId } from '/_102025_/l2/collabMessagesHelper.js';
import { msgEnsureMomentsRoom } from '/_102025_/l2/collabMessagesMomentsApi.js';
import { msgAddMessage } from '/_102025_/l2/shared/api.js';
import '/_102025_/l2/collabMessagesPrompt.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    audienceAll: 'Público: todos',
    audienceCount: 'Público: N pessoas',
    changeAudience: 'alterar',
    publishError: 'Não foi possível publicar.',
    roomError: 'Não foi possível abrir a sala de moments.',
    empty: 'Escreva algo para publicar.',
};
const message_en = {
    loading: 'Loading...',
    audienceAll: 'Audience: everyone',
    audienceCount: 'Audience: N people',
    changeAudience: 'change',
    publishError: 'Could not publish.',
    roomError: 'Could not open the moments room.',
    empty: 'Write something to publish.',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesMomentsNew102025 = class CollabMessagesMomentsNew102025 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-moments-new-102025 {
  display: block;
  flex: 1;
  min-height: 0;
  overflow: auto;
  box-sizing: border-box;
}
collab-messages-moments-new-102025 .moments-new-editor,
collab-messages-moments-new-102025 .moments-new-status {
  padding: 0.75rem 1rem 1.5rem;
}
collab-messages-moments-new-102025 .moments-new-error {
  color: var(--status-error-text);
}
collab-messages-moments-new-102025 .moments-audience {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  margin: 1rem 0 0;
}
collab-messages-moments-new-102025 .moments-audience button {
  border: 0;
  padding: 0;
  background: transparent;
  color: inherit;
  text-decoration: underline;
  cursor: pointer;
}
`);
        this.msg = messages['en'];
        this.userId = '';
        this.threadId = '';
        this.audience = 'selected';
        this.readerCount = 0;
        this.loading = true;
        this.error = '';
    }
    firstUpdated() {
        void this.open();
    }
    currentUserId() {
        return this.userId || getUserId() || '';
    }
    async open() {
        const userId = this.currentUserId();
        this.loading = true;
        this.error = '';
        if (!userId) {
            this.loading = false;
            this.error = this.msg.roomError;
            return;
        }
        try {
            const room = await msgEnsureMomentsRoom({ userId });
            if (!room.ok || !room.response.thread) {
                console.error(room.ok ? this.msg.roomError : room.error);
                this.error = room.ok ? this.msg.roomError : room.error;
                return;
            }
            this.threadId = room.response.thread.threadId;
            this.audience = room.response.audience === 'all' ? 'all' : 'selected';
            this.readerCount = room.response.thread.users.filter((user) => user.userId !== userId).length;
        }
        catch (err) {
            console.error(err);
            this.error = err instanceof Error ? err.message : this.msg.roomError;
        }
        finally {
            this.loading = false;
        }
    }
    audienceSummary() {
        if (this.audience === 'all')
            return this.msg.audienceAll;
        return this.msg.audienceCount.replace('N', String(this.readerCount));
    }
    openSettings() {
        this.dispatchEvent(new CustomEvent('moments-open-settings', { bubbles: true }));
    }
    async onSend(value) {
        const content = value.trim();
        const userId = this.currentUserId();
        this.error = '';
        if (!content) {
            this.error = this.msg.empty;
            return;
        }
        if (!userId || !this.threadId) {
            this.error = this.msg.roomError;
            return;
        }
        try {
            const result = await msgAddMessage({
                content,
                threadId: this.threadId,
                userId,
                senderDeviceId: loadNotificationDeviceId() || undefined,
            });
            if (!result.success || !result.response?.message) {
                const cause = result.error || this.msg.publishError;
                console.error(cause);
                this.error = cause;
                return;
            }
            this.dispatchEvent(new CustomEvent('moments-published', { bubbles: true }));
        }
        catch (err) {
            console.error(err);
            this.error = err instanceof Error ? err.message : this.msg.publishError;
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading)
            return html `<p class="moments-new-status">${this.msg.loading}</p>`;
        return html `
            <div class="moments-new-editor">
                ${this.error ? html `<p class="moments-new-error">${this.error}</p>` : ''}
                <collab-messages-prompt-102025
                    enableRichPreview="true"
                    allowAttachments="false"
                    submitOnEnter="false"
                    threadId=${this.threadId}
                    .onSend=${(value) => { void this.onSend(value); }}
                ></collab-messages-prompt-102025>
                <p class="moments-audience">
                    <span>${this.audienceSummary()}</span>
                    <button type="button" @click=${() => this.openSettings()}>${this.msg.changeAudience}</button>
                </p>
            </div>
        `;
    }
};
__decorate([
    property({ type: String })
], CollabMessagesMomentsNew102025.prototype, "userId", void 0);
__decorate([
    state()
], CollabMessagesMomentsNew102025.prototype, "threadId", void 0);
__decorate([
    state()
], CollabMessagesMomentsNew102025.prototype, "audience", void 0);
__decorate([
    state()
], CollabMessagesMomentsNew102025.prototype, "readerCount", void 0);
__decorate([
    state()
], CollabMessagesMomentsNew102025.prototype, "loading", void 0);
__decorate([
    state()
], CollabMessagesMomentsNew102025.prototype, "error", void 0);
CollabMessagesMomentsNew102025 = __decorate([
    customElement('collab-messages-moments-new-102025')
], CollabMessagesMomentsNew102025);
export { CollabMessagesMomentsNew102025 };
