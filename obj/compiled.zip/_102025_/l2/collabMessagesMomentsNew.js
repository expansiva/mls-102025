/// <mls fileReference="_102025_/l2/collabMessagesMomentsNew.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { getUserId, loadNotificationDeviceId } from '/_102025_/l2/collabMessagesHelper.js';
import { msgEnsureMomentsRoom, msgSetMomentsReaders } from '/_102025_/l2/collabMessagesMomentsApi.js';
import { msgAddMessage, msgGetUsers } from '/_102025_/l2/shared/api.js';
import '/_102025_/l2/collabMessagesPrompt.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    readers: 'Leitores',
    saveReaders: 'Salvar leitores',
    readersSaved: 'Leitores atualizados.',
    publishError: 'Não foi possível publicar.',
    roomError: 'Não foi possível abrir a sala de moments.',
    empty: 'Escreva algo para publicar.',
};
const message_en = {
    loading: 'Loading...',
    readers: 'Readers',
    saveReaders: 'Save readers',
    readersSaved: 'Readers updated.',
    publishError: 'Could not publish.',
    roomError: 'Could not open the moments room.',
    empty: 'Write something to publish.',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesMomentsNew102025 = class CollabMessagesMomentsNew102025 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.userId = '';
        this.threadId = '';
        this.users = [];
        this.selected = new Set();
        this.loading = true;
        this.saving = false;
        this.error = '';
        this.notice = '';
        this.initialReaders = new Set();
    }
    firstUpdated() {
        void this.open();
    }
    currentUserId() {
        return this.userId || getUserId() || '';
    }
    async open() {
        const userId = this.currentUserId();
        this.loading = true;
        this.error = '';
        if (!userId) {
            this.loading = false;
            this.error = this.msg.roomError;
            return;
        }
        try {
            const [room, people] = await Promise.all([
                msgEnsureMomentsRoom({ userId }),
                msgGetUsers({ status: 'active', prefixName: '', userId }),
            ]);
            if (!room.ok || !room.response.thread) {
                console.error(room.ok ? this.msg.roomError : room.error);
                this.error = room.ok ? this.msg.roomError : room.error;
                return;
            }
            this.threadId = room.response.thread.threadId;
            const readers = new Set(room.response.thread.users.map((user) => user.userId).filter((id) => id !== userId));
            this.initialReaders = readers;
            this.selected = new Set(readers);
            if (!people.success || !people.response?.users) {
                console.error(people.error);
                this.users = [];
            }
            else {
                this.users = people.response.users.filter((user) => user.userId !== userId);
            }
        }
        catch (err) {
            console.error(err);
            this.error = err instanceof Error ? err.message : this.msg.roomError;
        }
        finally {
            this.loading = false;
        }
    }
    toggleReader(userId) {
        const next = new Set(this.selected);
        if (next.has(userId))
            next.delete(userId);
        else
            next.add(userId);
        this.selected = next;
    }
    async saveReaders() {
        const userId = this.currentUserId();
        if (!userId || this.saving)
            return;
        const add = [...this.selected].filter((id) => !this.initialReaders.has(id));
        const remove = [...this.initialReaders].filter((id) => !this.selected.has(id));
        this.saving = true;
        this.notice = '';
        this.error = '';
        try {
            const result = await msgSetMomentsReaders({ userId, add, remove });
            if (!result.ok) {
                console.error(result.error);
                this.error = result.error;
                return;
            }
            this.initialReaders = new Set(this.selected);
            this.notice = this.msg.readersSaved;
        }
        catch (err) {
            console.error(err);
            this.error = err instanceof Error ? err.message : this.msg.roomError;
        }
        finally {
            this.saving = false;
        }
    }
    async onSend(value) {
        const content = value.trim();
        const userId = this.currentUserId();
        this.error = '';
        if (!content) {
            this.error = this.msg.empty;
            return;
        }
        if (!userId || !this.threadId) {
            this.error = this.msg.roomError;
            return;
        }
        try {
            const result = await msgAddMessage({
                content,
                threadId: this.threadId,
                userId,
                senderDeviceId: loadNotificationDeviceId() || undefined,
            });
            if (!result.success || !result.response?.message) {
                const cause = result.error || this.msg.publishError;
                console.error(cause);
                this.error = cause;
                return;
            }
            this.dispatchEvent(new CustomEvent('moments-published', { bubbles: true }));
        }
        catch (err) {
            console.error(err);
            this.error = err instanceof Error ? err.message : this.msg.publishError;
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading)
            return html `<p class="moments-new-status">${this.msg.loading}</p>`;
        return html `
            <div class="moments-new-editor">
                ${this.error ? html `<p class="moments-new-error">${this.error}</p>` : ''}
                <collab-messages-prompt-102025
                    enableRichPreview="true"
                    allowAttachments="false"
                    submitOnEnter="false"
                    threadId=${this.threadId}
                    .onSend=${(value) => { void this.onSend(value); }}
                ></collab-messages-prompt-102025>
                <section class="moments-readers">
                    <h3>${this.msg.readers}</h3>
                    ${this.notice ? html `<p class="moments-new-notice">${this.notice}</p>` : ''}
                    <ul>
                        ${this.users.map((user) => html `
                            <li>
                                <label>
                                    <input
                                        type="checkbox"
                                        .checked=${this.selected.has(user.userId)}
                                        @change=${() => this.toggleReader(user.userId)}
                                    >
                                    <span>${user.name}</span>
                                </label>
                            </li>
                        `)}
                    </ul>
                    <button type="button" ?disabled=${this.saving} @click=${() => { void this.saveReaders(); }}>
                        ${this.msg.saveReaders}
                    </button>
                </section>
            </div>
        `;
    }
};
__decorate([
    property({ type: String })
], CollabMessagesMomentsNew102025.prototype, "userId", void 0);
__decorate([
    state()
], CollabMessagesMomentsNew102025.prototype, "threadId", void 0);
__decorate([
    state()
], CollabMessagesMomentsNew102025.prototype, "users", void 0);
__decorate([
    state()
], CollabMessagesMomentsNew102025.prototype, "selected", void 0);
__decorate([
    state()
], CollabMessagesMomentsNew102025.prototype, "loading", void 0);
__decorate([
    state()
], CollabMessagesMomentsNew102025.prototype, "saving", void 0);
__decorate([
    state()
], CollabMessagesMomentsNew102025.prototype, "error", void 0);
__decorate([
    state()
], CollabMessagesMomentsNew102025.prototype, "notice", void 0);
CollabMessagesMomentsNew102025 = __decorate([
    customElement('collab-messages-moments-new-102025')
], CollabMessagesMomentsNew102025);
export { CollabMessagesMomentsNew102025 };
