/// <mls fileReference="_102025_/l2/collabMessagesApps.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { environment, } from '/_102036_/l2/environmentContract.js';
import '/_102025_/l2/collabMessagesAppsMenu.js';
export const SITES_MENU_CHANGED = 'SitesMenuChanged';
const MENU_LEVELS = [0, 1, 2, 3, 4, 5, 6, 7];
function menuEvents() {
    const events = globalThis.mls?.events;
    if (!events?.addEventListener)
        return undefined;
    return events;
}
let CollabMessagesApps = class CollabMessagesApps extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-apps-102025 {
  display: block;
  padding: 1rem;
}
collab-messages-apps-102025 .menu-container {
  font-family: var(--font-family-primary);
  color: var(--text-default);
  background-color: var(--surface-bg);
  font-size: var(--font-size-16);
  line-height: var(--line-height-medium);
}
`);
        this.menuModules = [];
        /** Stable reference: mls.events removes a subscriber by identity. */
        this.onSitesMenuChanged = () => { void this.loadMenu(); };
        this.menuFlight = null;
        this.menuQueued = false;
    }
    connectedCallback() {
        super.connectedCallback();
        const events = menuEvents();
        if (!events)
            return;
        events.addEventListener(MENU_LEVELS, [SITES_MENU_CHANGED], this.onSitesMenuChanged);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        menuEvents()?.removeEventListener(undefined, undefined, this.onSitesMenuChanged);
    }
    async firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        await this.loadMenu();
    }
    async loadMenu() {
        if (this.menuFlight) {
            this.menuQueued = true;
            return;
        }
        do {
            this.menuQueued = false;
            this.menuFlight = this.pullMenu();
            try {
                await this.menuFlight;
            }
            finally {
                this.menuFlight = null;
            }
        } while (this.menuQueued);
    }
    async pullMenu() {
        try {
            this.menuModules = await environment.apps.getProgramMenu();
        }
        catch (err) {
            console.error('[appsMenu] reload failed', err);
        }
    }
    render() {
        return html `
            <div class="menu-container">
                <collab-messages-apps-menu-102025
                    .menuModules=${this.menuModules}
                    menuTitle="Modulos"
                    keyFavoritesLocalStorage="modulesMenuFavorites"
                    keyHistoryLocalStorage="modulesMenuHistory"
                    identifier="client-shell"
                    @menu-selected=${(e) => this.handleMenuClick(e)}
                ></collab-messages-apps-menu-102025>
            </div>
        `;
    }
    async handleMenuClick(ev) {
        const item = ev.detail;
        await environment.apps.openProgram(item);
    }
};
__decorate([
    state()
], CollabMessagesApps.prototype, "menuModules", void 0);
CollabMessagesApps = __decorate([
    customElement('collab-messages-apps-102025')
], CollabMessagesApps);
export { CollabMessagesApps };
