/// <mls fileReference="_102025_/l2/collabMessagesApps.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { getProjectConfig } from '/_100554_/l2/libCommom.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
import { collabImport } from '/_100554_/l2/collabImport.js';
import '/_102025_/l2/collabMessagesAppsMenu.js';
let CollabMessagesApps = class CollabMessagesApps extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-apps-102025{display:block;padding:1rem}collab-messages-apps-102025 .menu-container{font-family:var(--font-family-primary);color:var(--text-primary-color);background-color:var(--bg-primary-color);font-size:var(--font-size-16);line-height:var(--line-height-medium)}`);
        this.menuModules = [];
    }
    async firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        await this.getModules();
    }
    render() {
        return html `
			<div class="menu-container">
				<collab-messages-apps-menu-102025
					.menuModules=${this.menuModules} 
					menuTitle="Módulos"
					keyFavoritesLocalStorage="modulesMenuFavorites"
					identifier=${mls.actualProject?.toString() || ''}
					@menu-selected=${(e) => this.handleMenuClick(e)}
				>
				</collab-messages-apps-menu-102025>
			</div>
		`;
    }
    handleMenuClick(ev) {
        const item = ev.detail;
        window.top?.postMessage({
            type: 'loadPage',
            target: item.target,
            project: item.project,
            moduleName: item.module,
            modulePath: item.path,
            pageName: item.pageName,
        });
    }
    async getModules() {
        const actualProject = mls.actualProject;
        if (!actualProject)
            return;
        const moduleProject = await getProjectConfig(actualProject);
        if (!moduleProject?.modules || !Array.isArray(moduleProject.modules))
            return;
        const modules = [];
        for await (let _module of moduleProject.modules) {
            if (!_module)
                continue;
            const moduleMenu = {
                menu: [],
                icon: _module.icon || '',
                name: _module.name,
                path: _module.path,
                project: 0
            };
            const isDep = _module.path.startsWith('_');
            let prjImport = actualProject;
            let pathImport = _module.path?.replace('/', '_');
            if (isDep) {
                const iPath = mls.l2.getPath(_module.path);
                if (!iPath.project)
                    continue;
                const { folder, project, shortName } = iPath;
                prjImport = project;
                pathImport = folder ? folder + '/' + shortName : shortName;
                moduleMenu.path = pathImport;
                pathImport = pathImport.replace('/', '_');
            }
            moduleMenu.project = prjImport;
            const moduleInstance = await collabImport({ folder: pathImport, project: prjImport, shortName: 'module', extension: '.ts' });
            const moduleConfig = moduleInstance?.moduleConfig;
            if (!moduleConfig?.menu || moduleConfig.menu.length === 0)
                continue;
            modules.push(moduleMenu);
            moduleConfig.menu.forEach((m) => {
                const buildUrls = (item) => {
                    const url = `_${actualProject}_${_module.path}/${item.pageName}`;
                    const newItem = { ...item, url };
                    if (item.children && item.children.length > 0) {
                        newItem.children = item.children.map(child => buildUrls(child));
                    }
                    return newItem;
                };
                const newItem = buildUrls(m);
                moduleMenu.menu.push(newItem);
            });
        }
        this.menuModules = [...modules];
    }
};
__decorate([
    state()
], CollabMessagesApps.prototype, "menuModules", void 0);
CollabMessagesApps = __decorate([
    customElement('collab-messages-apps-102025')
], CollabMessagesApps);
export { CollabMessagesApps };
