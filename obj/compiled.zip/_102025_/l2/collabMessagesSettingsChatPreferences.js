/// <mls fileReference="_102025_/l2/collabMessagesSettingsChatPreferences.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { loadChatPreferences, saveChatPreferences, } from '/_102025_/l2/collabMessagesHelper.js';
import { collab_message, collab_floppy_disk, } from '/_102025_/l2/collabMessagesIcons.js';
/// **collab_i18n_start**
const message_pt = {
    chatPref: 'Preferências do chat',
    translate: 'Tradução',
    preferLanguage: 'Idioma preferido',
    save: 'Salvar',
    successSavingChatPref: 'Preferências do chat atualizado com sucesso',
};
const message_en = {
    chatPref: 'Chat Preferences',
    translate: 'Translate',
    preferLanguage: 'Preferred language',
    save: 'Save',
    successSavingChatPref: 'Chat preferences updated successfully',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesSettingsChatPreferences = class CollabMessagesSettingsChatPreferences extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-settings-chat-preferences-102025{display:block}collab-messages-settings-chat-preferences-102025 .section{padding:1.4rem .75rem;border-radius:10px;box-shadow:#e7e3e3 0 1px 4px;background-color:var(--bg-primary-color-darker);margin-bottom:1.5rem}collab-messages-settings-chat-preferences-102025 .section h4{display:flex;align-items:center;gap:.5rem;margin-bottom:.75rem;margin-block-start:0;padding-bottom:.4rem;border-bottom:1px solid #d2d2d2}collab-messages-settings-chat-preferences-102025 .section h4 svg{fill:currentColor;width:20px;height:20px}collab-messages-settings-chat-preferences-102025 .section .loader{display:inline-block;width:16px;height:16px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}collab-messages-settings-chat-preferences-102025 .section .saving-ok{color:var(--success-color);font-size:var(--font-size-12)}collab-messages-settings-chat-preferences-102025 .section .saving-error{color:var(--error-color);font-size:var(--font-size-12)}collab-messages-settings-chat-preferences-102025 .section .form-field{margin-bottom:1rem}collab-messages-settings-chat-preferences-102025 .section .form-field label{display:block;font-size:var(--font-size-12);color:var(--text-primary-color-lighter);margin-bottom:.3rem}collab-messages-settings-chat-preferences-102025 .section input,collab-messages-settings-chat-preferences-102025 .section select{display:flex;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none;max-height:30px;height:30px;padding:0 .5rem}collab-messages-settings-chat-preferences-102025 .section select{width:100%;box-sizing:border-box}collab-messages-settings-chat-preferences-102025 .section input{width:100%;box-sizing:border-box}collab-messages-settings-chat-preferences-102025 .section button{background-color:var(--info-color);box-shadow:0 1px 3px 0 var(--grey-color);flex-direction:row;justify-content:center;width:max-content;transition:height .3s cubic-bezier(.25, .1, .25, 1);color:#ffffff;padding:.5rem 1rem;border:none;border-radius:6px;cursor:pointer;font-size:var(--font-size-12);font-weight:var(--font-weight-bold);display:flex;align-items:center;gap:.25rem;white-space:nowrap;flex-shrink:0}collab-messages-settings-chat-preferences-102025 .section button svg{flex-shrink:0;fill:currentColor}collab-messages-settings-chat-preferences-102025 .section button:hover{background-color:var(--info-color-hover)}collab-messages-settings-chat-preferences-102025 .section button:disabled{opacity:.6;cursor:not-allowed}collab-messages-settings-chat-preferences-102025 .chat-preferences .chat-config-item{display:flex;flex-direction:column;gap:.3rem;margin-bottom:1rem}collab-messages-settings-chat-preferences-102025 .chat-preferences .chat-config-item.action{display:flex;justify-content:flex-end;align-items:flex-end;margin-top:1.5rem;padding-top:1rem;border-top:1px solid var(--grey-color)}`);
        this.msg = messages['en'];
        this.chatPreferences = {
            translationMode: 'icon',
            language: '',
            threadMaintenance: ''
        };
        this.isSaving = false;
        this.labelOk = '';
        this.labelError = '';
    }
    async firstUpdated() {
        this.chatPreferences = loadChatPreferences();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <div class="section chat-preferences">
            <h4>${collab_message} ${this.msg.chatPref}</h4>
            
            <div class="chat-config-item form-field">
                <label for="translationMode">${this.msg.translate}:</label>
                <select 
                    id="translationMode" 
                    @change=${this.handleTranslationModeChange} 
                    .value=${this.chatPreferences?.translationMode ?? 'icon'}
                >
                    <option value="none">none</option>
                    <option value="icon">icon</option>
                    <option value="text">text</option>
                    <option value="iconText">icon + text</option>
                    <option value="trace">trace</option>
                </select>
            </div>
            
            <div class="chat-config-item form-field">
                <label>${this.msg.preferLanguage}:</label>
                <input 
                    @input=${this.handleLanguageInput} 
                    .value=${this.chatPreferences?.language ?? ''} 
                    type="text" 
                />
            </div>
            
            <div class="chat-config-item action">
                <button @click=${this.handleSave} ?disabled=${this.isSaving}>
                    ${this.isSaving
            ? html `<span class="loader"></span>`
            : html `${collab_floppy_disk} ${this.msg.save}`}
                </button>
            </div>
            
            ${this.labelOk ? html `<small class="saving-ok">${this.labelOk}</small>` : ''}
            ${this.labelError ? html `<small class="saving-error">${this.labelError}</small>` : ''}    
        </div>
        `;
    }
    // ========== HANDLERS ==========
    handleTranslationModeChange(e) {
        const select = e.target;
        this.chatPreferences = {
            ...this.chatPreferences,
            translationMode: select.value
        };
    }
    handleLanguageInput(e) {
        const target = e.target;
        this.chatPreferences = {
            ...this.chatPreferences,
            language: target.value
        };
    }
    async handleSave() {
        this.labelError = '';
        this.labelOk = '';
        this.isSaving = true;
        try {
            saveChatPreferences(this.chatPreferences);
            this.labelOk = this.msg.successSavingChatPref;
            this.dispatchEvent(new CustomEvent('preferences-saved', {
                detail: { preferences: this.chatPreferences },
                bubbles: true,
                composed: true
            }));
        }
        catch (error) {
            console.error('Error on update chat preferences:', error);
            this.labelError = error.message;
        }
        finally {
            this.isSaving = false;
        }
    }
};
__decorate([
    state()
], CollabMessagesSettingsChatPreferences.prototype, "chatPreferences", void 0);
__decorate([
    state()
], CollabMessagesSettingsChatPreferences.prototype, "isSaving", void 0);
__decorate([
    state()
], CollabMessagesSettingsChatPreferences.prototype, "labelOk", void 0);
__decorate([
    state()
], CollabMessagesSettingsChatPreferences.prototype, "labelError", void 0);
CollabMessagesSettingsChatPreferences = __decorate([
    customElement('collab-messages-settings-chat-preferences-102025')
], CollabMessagesSettingsChatPreferences);
export { CollabMessagesSettingsChatPreferences };
