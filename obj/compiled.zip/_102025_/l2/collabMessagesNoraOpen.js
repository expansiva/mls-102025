/// <mls fileReference="_102025_/l2/collabMessagesNoraOpen.ts" enhancement="_blank" />
/** Same address as the human step: `page` or `page?recordParam=recordId`. No page, no button. */
export function noraMessageScreenAddress(open) {
    const page = open?.page;
    if (!page)
        return undefined;
    if (!open?.recordParam)
        return page;
    return `${page}?${open.recordParam}=${encodeURIComponent(open.recordId ?? '')}`;
}
