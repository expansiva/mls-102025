/// <mls fileReference="_102025_/l2/collabMessagesReadState.ts" enhancement="_blank"/>
export function shouldMarkOpenThreadRead(s) {
    if (!s.hasOpenThread || !s.inDetails)
        return false;
    if (s.reason === 'leave')
        return true;
    return s.pageVisible;
}
