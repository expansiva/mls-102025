/// <mls fileReference="_102025_/l2/collabMessagesNoraConfirm.ts" enhancement="_blank" />
export function noraConfirmButtons(confirm, nowMs) {
    if (!confirm?.expiresAt)
        return undefined;
    if (confirm.answered)
        return 'answered';
    const expiresAt = Date.parse(confirm.expiresAt);
    if (!Number.isFinite(expiresAt))
        return undefined;
    if (nowMs >= expiresAt)
        return 'expired';
    return 'pending';
}
