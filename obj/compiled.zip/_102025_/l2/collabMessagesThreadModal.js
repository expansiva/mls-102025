/// <mls fileReference="_102025_/l2/collabMessagesThreadModal.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { getDateFormated } from '/_100554_/l2/libCommom.js';
import { formatTimestamp } from '/_100554_/l2/aiAgentHelper.js';
import { collab_clock_static, collab_users } from '/_102025_/l2/collabMessagesIcons.js';
import '/_102025_/l2/collabMessagesAvatar.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    userInThread: 'pessoas nesse canal',
    seeChannel: 'Ver canal',
};
const message_en = {
    loading: 'Loading...',
    userInThread: ' people in this channel',
    seeChannel: 'See channel',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesThreadModal = class CollabMessagesThreadModal extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-thread-modal-102025{z-index:9999;position:absolute}collab-messages-thread-modal-102025 .collab-messages-thread-modal-box{background:var(--bg-primary-color-darker);color:var(--text-primary-color);border-radius:8px;padding:16px;width:280px;font-family:sans-serif;box-shadow:0 4px 12px rgba(0,0,0,0.4)}collab-messages-thread-modal-102025 .collab-messages-thread-modal-header{display:flex;align-items:center;margin-bottom:12px}collab-messages-thread-modal-102025 collab-messages-avatar-100554{width:48px;height:48px;border-radius:4px;margin-right:12px}collab-messages-thread-modal-102025 collab-messages-avatar-100554 svg,collab-messages-thread-modal-102025 collab-messages-avatar-100554 img{width:48px;height:48px}collab-messages-thread-modal-102025 .collab-messages-thread-modal-title{font-weight:bold;font-size:var(--font-size-16)}collab-messages-thread-modal-102025 .collab-messages-thread-modal-subtitle{font-size:var(--font-size-12)}collab-messages-thread-modal-102025 .collab-messages-thread-modal-userStatus{margin-top:.5rem;font-size:var(--font-size-12);color:var(--grey-color-darker)}collab-messages-thread-modal-102025 .collab-messages-thread-modal-userStatus.active{color:var(--success-color)}collab-messages-thread-modal-102025 .user-message-error{color:var(--error-color);font-size:var(--font-size-12);display:flex;align-items:center}collab-messages-thread-modal-102025 .user-message-error svg{margin-right:.3rem;width:12px;fill:var(--error-color)}collab-messages-thread-modal-102025 .collab-messages-thread-modal-actions{display:flex;gap:8px}collab-messages-thread-modal-102025 .collab-messages-thread-modal-actions .loader{display:inline-block;width:16px;height:16px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}collab-messages-thread-modal-102025 .collab-messages-thread-modal-actions button{flex:1;display:flex;align-items:center;justify-content:center;gap:.5rem;padding:6px 8px;border:none;border-radius:4px;cursor:pointer;font-size:14px}collab-messages-thread-modal-102025 .collab-messages-thread-modal-actions button svg{fill:currentColor}collab-messages-thread-modal-102025 .collab-messages-thread-modal-message-btn{background:#3F46AD;color:white}`);
        this.msg = messages['en'];
        this.open = true;
        this.isLoading = false;
        this.errorMessage = '';
        this.handleGlobalMouseMove = (e) => {
            const modal = this.querySelector('collab-messages-thread-modal-102025');
            if (modal && !modal.contains(e.target)) {
                this.destroy();
            }
        };
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        document.addEventListener('mousemove', this.handleGlobalMouseMove);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        document.removeEventListener('mousemove', this.handleGlobalMouseMove);
    }
    destroy() {
        this.remove();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.open)
            return null;
        return html `
        <div class="collab-messages-thread-modal-box"
            @mouseover=${(e) => e.stopPropagation()}
            @mouseleave=${(e) => { e.stopPropagation(); this.destroy(); }}
            @click=${(e) => e.stopPropagation()}
        >
            <div class="collab-messages-thread-modal-header">
            <collab-messages-avatar-102025 avatar=${this.thread?.avatar_url} alt=${this.thread?.name} ></collab-messages-avatar-102025>
                <div>
                    <div class="collab-messages-thread-modal-title">${this.thread?.name}</div>
                    <div class="collab-messages-thread-modal-subtitle">${collab_users}${this.thread?.users.length || '0'} ${this.msg.userInThread}</div>
                    <div class="collab-messages-thread-modal-subtitle">${collab_clock_static} ${getDateFormated(formatTimestamp(this.thread?.lastMessageTime || '').dateFull)}</div>
                    <div class="collab-messages-thread-modal-userStatus ${this.thread?.status}"> ● ${this.thread?.status}</div>
                </div>
            </div>

            ${this.errorMessage ? html `<small class="user-message-error">${this.errorMessage}<small>` : ''}

      
            <div class="collab-messages-thread-modal-actions">
                <button
                    @click=${this.onClickThreadAction} 
                    class="collab-messages-thread-modal-message-btn"
                    ?disabled=${this.isLoading}
                >
                    ${this.isLoading ? html `<span class="loader"></span>` : html `${this.msg.seeChannel}`}
                </button>
            </div>
            
        
        </div>
    
    `;
    }
    async onClickThreadAction() {
        if (!this.thread)
            return;
        this.isLoading = true;
        try {
            await mls.events.fire([mls.actualLevel], 'collabMessages', JSON.stringify({ threadId: this.thread?.threadId, type: 'thread-open' }));
        }
        catch (err) {
            this.errorMessage = err.message;
        }
        finally {
            this.isLoading = false;
        }
        ;
    }
};
__decorate([
    property({ type: Boolean })
], CollabMessagesThreadModal.prototype, "open", void 0);
__decorate([
    property()
], CollabMessagesThreadModal.prototype, "thread", void 0);
__decorate([
    state()
], CollabMessagesThreadModal.prototype, "isLoading", void 0);
__decorate([
    state()
], CollabMessagesThreadModal.prototype, "errorMessage", void 0);
CollabMessagesThreadModal = __decorate([
    customElement('collab-messages-thread-modal-102025')
], CollabMessagesThreadModal);
export { CollabMessagesThreadModal };
