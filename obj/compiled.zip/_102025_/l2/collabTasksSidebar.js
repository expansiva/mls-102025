/// <mls fileReference="_102025_/l2/collabTasksSidebar.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    board: 'Board',
    myTasks: 'Minhas tasks',
    workflows: 'Workflows',
    simulator: 'Simulador',
    approvals: 'Aprovações',
    analytics: 'Analytics',
    settings: 'Configurações',
    tracking: 'Acompanhamento',
    manage: 'Gerenciar',
    workspace: 'Workspace',
};
const message_en = {
    board: 'Board',
    myTasks: 'My tasks',
    workflows: 'Workflows',
    simulator: 'Simulator',
    approvals: 'Approvals',
    analytics: 'Analytics',
    settings: 'Settings',
    tracking: 'Tracking',
    manage: 'Manage',
    workspace: 'Workspace',
};
/// **collab_i18n_end**
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { collab_tasks, collab_gear, } from '/_102025_/l2/collabMessagesIcons.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
let CollabTasksSidebar = class CollabTasksSidebar extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-tasks-sidebar-102025 {
  display: flex;
  flex-direction: column;
  background: var(--bg-secondary-color);
  border-right: 1px solid var(--grey-color-light);
  overflow: hidden;
}
collab-tasks-sidebar-102025 .sidebar-inner {
  display: flex;
  flex-direction: column;
  width: 200px;
  height: 100%;
  padding: 8px 0;
  transition: width 0.2s ease;
  overflow: hidden;
}
collab-tasks-sidebar-102025 .sidebar-inner.collapsed {
  width: 44px;
}
collab-tasks-sidebar-102025 .collapse-btn {
  background: none;
  border: none;
  cursor: pointer;
  padding: 8px 12px;
  display: flex;
  align-items: center;
  color: var(--grey-color-darker);
  font-size: 18px;
  margin-bottom: 4px;
}
collab-tasks-sidebar-102025 .collapse-btn:hover {
  color: var(--text-primary-color);
}
collab-tasks-sidebar-102025 .nav-section {
  padding: 0 0 8px;
}
collab-tasks-sidebar-102025 .nav-label {
  font-size: 10px;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--grey-color-darker);
  padding: 4px 16px 2px;
  white-space: nowrap;
  overflow: hidden;
}
collab-tasks-sidebar-102025 .nav-label.collapsed {
  opacity: 0;
}
collab-tasks-sidebar-102025 .nav-divider {
  height: 1px;
  background: var(--grey-color-light);
  margin: 8px 10px;
}
collab-tasks-sidebar-102025 .nav-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 7px 16px;
  cursor: pointer;
  border-radius: 6px;
  margin: 1px 6px;
  white-space: nowrap;
  overflow: hidden;
  font-size: 14px;
  color: var(--text-primary-color);
  transition: background 0.15s;
}
collab-tasks-sidebar-102025 .nav-item:hover {
  background: rgba(0, 0, 0, 0.06);
}
collab-tasks-sidebar-102025 .nav-item.active {
  background: rgba(99, 102, 241, 0.12);
  color: #6366f1;
  font-weight: 600;
}
collab-tasks-sidebar-102025 .nav-icon {
  flex-shrink: 0;
  display: flex;
  align-items: center;
}
collab-tasks-sidebar-102025 .nav-icon svg {
  width: 16px;
  height: 16px;
}
collab-tasks-sidebar-102025 .nav-label-text {
  overflow: hidden;
  text-overflow: ellipsis;
}
collab-tasks-sidebar-102025 .nav-label-text.hidden {
  display: none;
}
`);
        this.activeScreen = 'board';
        this.collapsed = false;
    }
    _emit(screen) {
        this.dispatchEvent(new CustomEvent('screen-change', { detail: screen, bubbles: true, composed: true }));
    }
    render() {
        const msg = getMsg();
        const c = this.collapsed;
        const item = (id, label, icon) => html `
      <div class="nav-item ${this.activeScreen === id ? 'active' : ''}" @click=${() => this._emit(id)}>
        ${icon ? html `<span class="nav-icon">${icon}</span>` : html `<span class="nav-icon" style="width:16px"></span>`}
        <span class="nav-label-text ${c ? 'hidden' : ''}">${label}</span>
      </div>
    `;
        return html `
      <div class="sidebar-inner ${c ? 'collapsed' : ''}">
        <button class="collapse-btn" @click=${() => { this.collapsed = !this.collapsed; }}>
          ${c ? '›' : '‹'}
        </button>

        <div class="nav-section">
          <div class="nav-label ${c ? 'collapsed' : ''}">${msg.tracking}</div>
          ${item('board', msg.board, collab_tasks)}
          ${item('mytasks', msg.myTasks, collab_tasks)}
        </div>

        <div class="nav-divider"></div>

        <div class="nav-section">
          <div class="nav-label ${c ? 'collapsed' : ''}">${msg.manage}</div>
          ${item('workflows', msg.workflows)}
          ${item('simulator', msg.simulator)}
          ${item('approvals', msg.approvals)}
          ${item('analytics', msg.analytics)}
        </div>

        <div class="nav-divider"></div>

        <div class="nav-section">
          <div class="nav-label ${c ? 'collapsed' : ''}">${msg.workspace}</div>
          ${item('settings', msg.settings, collab_gear)}
        </div>
      </div>
    `;
    }
};
__decorate([
    property({ type: String })
], CollabTasksSidebar.prototype, "activeScreen", void 0);
__decorate([
    state()
], CollabTasksSidebar.prototype, "collapsed", void 0);
CollabTasksSidebar = __decorate([
    customElement('collab-tasks-sidebar-102025')
], CollabTasksSidebar);
export { CollabTasksSidebar };
