/// <mls fileReference="_102025_/l2/aiAgentDefaultFeedbackLocalTitle.ts" enhancement="_blank" />
export function applyLocalStepTitle(current, shownTaskPK, event, stepStatus) {
    if (!shownTaskPK || event.taskPK !== shownTaskPK)
        return current;
    if (typeof event.stepId !== 'number' || !event.title)
        return current;
    const prev = current.get(event.stepId);
    if (prev && prev.title === event.title && prev.status === stepStatus)
        return current;
    const next = new Map(current);
    next.set(event.stepId, { title: event.title, status: stepStatus });
    return next;
}
export function dropLocalTitlesOnTaskChange(current, shownTaskPK, eventTaskPK) {
    if (!shownTaskPK || eventTaskPK !== shownTaskPK)
        return current;
    if (current.size === 0)
        return current;
    return new Map();
}
export function dropLocalTitleIfStatusChanged(current, stepId, status) {
    const entry = current.get(stepId);
    if (!entry)
        return current;
    if (entry.status === undefined || entry.status === status)
        return current;
    const next = new Map(current);
    next.delete(stepId);
    return next;
}
export function displayedStepTitle(step, local) {
    const entry = local.get(step.stepId);
    if (entry && (entry.status === undefined || entry.status === step.status))
        return entry.title;
    return step.stepTitle || step.agentName || step.toolName || step.type || 'step';
}
