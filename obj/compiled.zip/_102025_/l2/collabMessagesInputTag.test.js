/// <mls fileReference="_102025_/l2/collabMessagesInputTag.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
