/// <mls fileReference="_102025_/l2/shared/api.ts" enhancement="_blank"/>
import * as msg from '/_102025_/l2/shared/interfaces.js';
async function handleRequest(promise) {
    try {
        const res = await promise;
        if (res.statusCode >= 200 && res.statusCode < 300) {
            return {
                success: true,
                response: res,
                statusCode: res.statusCode
            };
        }
        return {
            success: false,
            error: res?.msg || 'Request failed',
            statusCode: res.statusCode
        };
    }
    catch (err) {
        return {
            success: false,
            error: err?.message || 'Unexpected error',
            statusCode: 500
        };
    }
}
export async function post(args) {
    let urlHttp = "https://on.collab.codes/exec";
    try {
        const response = await fetch(urlHttp, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(args),
            credentials: 'include'
        });
        if (response.status !== msg.HttpStatus.OK) {
            throw (await getPostError(response, args));
        }
        const data = await response.json();
        if (!data) {
            throw new Error("No data on cbePost");
        }
        return data;
    }
    catch (error) {
        console.info(error);
        throw error;
    }
}
export async function getPostError(response, args) {
    const data = await response.json()
        .catch(err => {
        console.error("Error on getPostError: ", err);
        return new Error(`No data on cbePost error: ${err}`);
    });
    const errorMsg = (typeof data.msg === 'string') ? data.msg : data.error || 'Unknown error';
    if (response.status === msg.HttpStatus.BAD_REQUEST) {
        console.error(`Error on cbePost, status: ${response.status}, msg: ${errorMsg}, invalid args: `, JSON.stringify(args));
        return new Error(`Invalid args, msg: ${errorMsg}`);
    }
    if (response.status === msg.HttpStatus.CONFLICT) {
        return new Error(`DomainError: ${errorMsg}`);
    }
    const msg2 = `Error on cbePost, status: ${response.status} - ${response.statusText}, error: ${errorMsg}`;
    console.error(msg2);
    return new Error(msg2);
}
export async function msgGetUsers(args) {
    return handleRequest(post({
        action: "getUsers",
        ...args
    }));
}
export function msgGetUserUpdate(args) {
    return handleRequest(post({
        action: "getUserUpdate",
        ...args
    }));
}
export function msgUpdateUserDetails(args) {
    return handleRequest(post({
        action: "updateUserDetails",
        ...args
    }));
}
export function msgAddThread(args) {
    return handleRequest(post({
        action: "addThread",
        ...args
    }));
}
export function msgUpdateThread(args) {
    return handleRequest(post({
        action: "updateThread",
        ...args
    }));
}
export function msgRemoveParticipantFromThread(args) {
    return handleRequest(post({
        action: "removeUserInThread",
        ...args
    }));
}
export function msgAddParticipantToThread(args) {
    return handleRequest(post({
        action: "addUserInThread",
        ...args
    }));
}
export function msgGetThreadUpdates(args) {
    return handleRequest(post({
        action: "getThreadUpdate",
        ...args
    }));
}
export function msgGetTaskUpdate(args) {
    return handleRequest(post({
        action: "getTaskUpdate",
        ...args
    }));
}
export function msgAddMessage(args) {
    return handleRequest(post({
        action: "addMessage",
        ...args
    }));
}
export function msgEnsureTaskRoom(args) {
    return handleRequest(post({
        action: "ensureTaskRoom",
        ...args
    }));
}
export function msgAddMessageAI(args) {
    return handleRequest(post({
        action: "addMessageAI",
        ...args
    }));
}
export function msgAddOrUpdateThreadBot(args) {
    return handleRequest(post({
        action: "addOrUpdateThreadBot",
        ...args
    }));
}
export function msgAddOrUpdateThreadIntegration(args) {
    return handleRequest(post({
        action: "addOrUpdateThreadIntegration",
        ...args
    }));
}
export function msgGetMessagesAfter(args) {
    return handleRequest(post({
        action: "getMessagesAfter",
        ...args
    }));
}
export function msgGetMessagesBefore(args) {
    return handleRequest(post({
        action: "getMessagesBefore",
        ...args
    }));
}
export function msgGetMessage(args) {
    return handleRequest(post({
        action: "getMessage",
        ...args
    }));
}
export function msgUpdateMessage(args) {
    return handleRequest(post({
        action: "updateMessage",
        ...args
    }));
}
export function msgAddOrUpdateOpenClawConnector(args) {
    return handleRequest(post({
        action: "addOrUpdateOpenClawConnector",
        ...args
    }));
}
export function msgRemoveOpenClawConnector(args) {
    return handleRequest(post({
        action: "removeOpenClawConnector",
        ...args
    }));
}
export function msgListOpenClawConnectors(args) {
    return handleRequest(post({
        action: "listOpenClawConnectors",
        ...args
    }));
}
export function msgListOpenClawConnectorAgents(args) {
    return handleRequest(post({
        action: "listOpenClawConnectors",
        ...args
    }));
}
export function msgListThreadOpenClawAgents(args) {
    return handleRequest(post({
        action: "listThreadOpenClawAgents",
        ...args
    }));
}
export function msgAddOrUpdateThreadOpenClawAgent(args) {
    return handleRequest(post({
        action: "addOrUpdateThreadOpenClawAgent",
        ...args
    }));
}
export function msgRemoveThreadOpenClawAgent(args) {
    return handleRequest(post({
        action: "removeThreadOpenClawAgent",
        ...args
    }));
}
export function msgCreateOpenClawAgent(args) {
    return handleRequest(post({
        action: "createOpenClawAgent",
        ...args
    }));
}
export function msgDeleteOpenClawAgent(args) {
    return handleRequest(post({
        action: "deleteOpenClawAgent",
        ...args
    }));
}
export function msgListOpenClawAvailableAgents(args) {
    return handleRequest(post({
        action: "listOpenClawAvailableAgents",
        ...args
    }));
}
