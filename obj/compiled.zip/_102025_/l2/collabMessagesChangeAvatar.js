/// <mls fileReference="_102025_/l2/collabMessagesChangeAvatar.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from "lit";
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, property, state } from "lit/decorators.js";
import { generateAgentAvatar } from '/_102025_/l2/collabMessagesHelper.js';
import { environment } from '/_102036_/l2/environmentContract.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
/// **collab_i18n_start** 
const message_pt = {
    changeAvatar: "Alterar avatar",
    changeButton: "Trocar imagem",
    generateButton: "Gerar com IA",
    panelTitle: "Gerar Avatar com IA",
    generateLabel: "Descreva o avatar",
    generatePlaceholder: "Digite aqui sua descrição...",
    actionGenerate: "Gerar",
    saveButton: "Salvar",
    cancelButton: "Cancelar",
    generating: "Gerando..."
};
const message_en = {
    changeAvatar: "Change avatar",
    changeButton: "Change image",
    generateButton: "Generate with AI",
    panelTitle: "Generate Avatar with AI",
    generateLabel: "Describe the avatar",
    generatePlaceholder: "Type your description here...",
    actionGenerate: "Generate",
    saveButton: "Save",
    cancelButton: "Cancel",
    generating: "Generating..."
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabChangeAvatar = class CollabChangeAvatar extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-change-avatar-102025 {
  display: block;
}
collab-messages-change-avatar-102025 .panel {
  border: 1px solid #ddd;
  padding: 12px;
  border-radius: 6px;
  margin: 8px 0;
}
collab-messages-change-avatar-102025 .preview img,
collab-messages-change-avatar-102025 .preview svg {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  object-fit: cover;
  border: 1px solid #ccc;
  fill: currentColor;
}
collab-messages-change-avatar-102025 textarea {
  width: 100%;
  min-height: 60px;
}
collab-messages-change-avatar-102025 .avatar-section {
  display: flex;
  flex-direction: column;
  align-items: center;
}
collab-messages-change-avatar-102025 .actions-avatar {
  display: flex;
  gap: 1rem;
}
collab-messages-change-avatar-102025 .actions-ia {
  margin-top: 10px;
  display: flex;
  gap: 10px;
  align-items: center;
}
collab-messages-change-avatar-102025 input,
collab-messages-change-avatar-102025 select,
collab-messages-change-avatar-102025 textarea {
  width: 100%;
  display: block;
  font-size: 1rem;
  line-height: 1.5;
  height: 33px;
  color: #000000;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  outline: none;
}
collab-messages-change-avatar-102025 input[disabled],
collab-messages-change-avatar-102025 select[disabled],
collab-messages-change-avatar-102025 textarea[disabled] {
  background-color: var(--surface-alt-bg);
}
collab-messages-change-avatar-102025 button {
  background-color: var(--button-primary-bg);
  border-radius: 8px;
  border: none;
  box-shadow: 0px 1px 3px 0px var(--border-default);
  display: flex;
  flex-direction: row;
  justify-content: center;
  gap: 0.2rem;
  font-weight: 700;
  align-items: center;
  height: 40px;
  transition: height 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
  padding: 0.5rem;
  color: #ffffff;
  cursor: pointer;
  max-width: 200px;
  text-overflow: ellipsis;
  white-space: nowrap;
}
collab-messages-change-avatar-102025 button:hover {
  background-color: var(--button-primary-bg-hover);
}
collab-messages-change-avatar-102025 .loader {
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid #ccc;
  border-top: 2px solid #000;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}
collab-messages-change-avatar-102025 .upload-wrapper {
  position: relative;
  display: inline-block;
}
collab-messages-change-avatar-102025 .upload-btn {
  background-color: #007bff;
  color: #fff;
  border: none;
  padding: 8px 14px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.2s ease;
}
collab-messages-change-avatar-102025 .upload-btn:hover {
  background-color: #0056b3;
}
collab-messages-change-avatar-102025 .hidden-file-input {
  display: none;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
`);
        this.msg = messages['en'];
        this.userId = "20250417120841.1000";
        this.threadId = "20250825143728.1000";
        this.avatarPrompt = "";
        this.isOpen = false;
        this.generating = false;
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        this.preview = this.value || generateAgentAvatar(this.nameValue || '');
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const svgGenerateEnabled = environment.config.generateSvgAvatarEnabled();
        return html `
    <div class="avatar-section">
      <div class="preview">
        ${this.preview
            ? this.preview.startsWith("<svg")
                ? html `${this.safeSvg(this.preview)}`
                : html `<img src="${this.preview}" alt="Avatar" />`
            : this.value
                ? this.value.startsWith("<svg")
                    ? html `${this.safeSvg(this.value)}`
                    : html `<img src="${this.value}" alt="Avatar" />`
                : html `<div class="placeholder">?</div>`}
      </div>

      <div class="actions-avatar">
        <a style="display:none"  href="#" class="btn" @click=${this.triggerFileInput}>${this.msg.changeButton}</a>
        <input 
          type="file" 
          accept="image/*" 
          class="hidden-file-input"
          @change=${this.onFileSelect}
        />
        ${svgGenerateEnabled ? html `  <a href="#" class="btn" @click=${(e) => { e.preventDefault(); this.isOpen = true; }}>
          ${this.msg.generateButton}
        </a>` : nothing}
      
      </div>
    </div>

    ${this.isOpen ? html `
      <div class="panel">
        <h4>${this.msg.panelTitle}</h4>

        <label>${this.msg.generateLabel}</label>
        <textarea
          placeholder=${this.msg.generatePlaceholder}
          .value=${this.avatarPrompt}
          @input=${(e) => this.avatarPrompt = e.target.value}
        ></textarea>

        <div class="actions-ia">
          <button ?disabled=${this.generating} @click=${this.generateAvatarFromPrompt}>
            ${this.generating ? html `<span class="loader"></span>` : this.msg.actionGenerate}
          </button>
          <button @click=${() => this.isOpen = false}>${this.msg.cancelButton}</button>
        </div>
      </div>
    ` : ""}
  `;
    }
    onFileSelect(e) {
        const input = e.target;
        if (input.files && input.files[0]) {
            this.avatarFile = input.files[0];
            this.preview = URL.createObjectURL(this.avatarFile);
        }
    }
    triggerFileInput(e) {
        e.preventDefault();
        const input = this.querySelector(".hidden-file-input");
        input?.click();
    }
    async generateAvatarFromPrompt() {
        if (!this.avatarPrompt)
            return;
        this.generating = true;
        try {
            const svgStr = await environment.agents.generateSvgAvatar(this.threadId, this.userId, this.avatarPrompt);
            if (!svgStr)
                return;
            this.preview = svgStr;
            this.emitValueChanged(this.preview);
        }
        catch (err) {
            console.error("Erro ao gerar avatar via IA", err);
        }
        finally {
            this.generating = false;
        }
    }
    emitValueChanged(value) {
        this.dispatchEvent(new CustomEvent('value-changed', {
            detail: value,
            bubbles: true,
            composed: true
        }));
    }
    safeSvg(svg) {
        return html `${unsafeHTML(svg)}`;
    }
};
__decorate([
    property({ type: String })
], CollabChangeAvatar.prototype, "value", void 0);
__decorate([
    property({ type: String })
], CollabChangeAvatar.prototype, "nameValue", void 0);
__decorate([
    property({ type: String })
], CollabChangeAvatar.prototype, "userId", void 0);
__decorate([
    property({ type: String })
], CollabChangeAvatar.prototype, "threadId", void 0);
__decorate([
    state()
], CollabChangeAvatar.prototype, "avatarPrompt", void 0);
__decorate([
    state()
], CollabChangeAvatar.prototype, "avatarFile", void 0);
__decorate([
    state()
], CollabChangeAvatar.prototype, "isOpen", void 0);
__decorate([
    state()
], CollabChangeAvatar.prototype, "generating", void 0);
__decorate([
    state()
], CollabChangeAvatar.prototype, "preview", void 0);
CollabChangeAvatar = __decorate([
    customElement("collab-messages-change-avatar-102025")
], CollabChangeAvatar);
export { CollabChangeAvatar };
