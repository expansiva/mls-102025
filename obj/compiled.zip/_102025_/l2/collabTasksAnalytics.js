/// <mls fileReference="_102025_/l2/collabTasksAnalytics.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    title: 'Analytics',
    subtitle: 'últimos 30 dias',
    reload: 'Recarregar',
    loadError: 'Não consegui carregar.',
    retry: 'Tentar de novo',
    totalActive: 'tarefas ativas',
    completedMonth: 'concluídas (30d)',
    workflows: 'workflows em uso',
    highPriority: 'alta prioridade',
    byStatus: 'Por status',
    byPriority: 'Por prioridade',
    topWorkflows: 'Top workflows',
    recentDone: 'Concluídas recentes',
    todo: 'A fazer',
    inProgress: 'Em andamento',
    paused: 'Pausado',
    done: 'Concluído',
    failed: 'Falhou',
    urgent: 'Urgente',
    high: 'Alta',
    normal: 'Normal',
    low: 'Baixa',
    tasks: 'tasks',
    noData: 'Sem dados suficientes.',
    efficiencyPct: 'taxa de sucesso',
};
const message_en = {
    title: 'Analytics',
    subtitle: 'last 30 days',
    reload: 'Reload',
    loadError: 'Could not load.',
    retry: 'Retry',
    totalActive: 'active tasks',
    completedMonth: 'completed (30d)',
    workflows: 'workflows in use',
    highPriority: 'high priority',
    byStatus: 'By status',
    byPriority: 'By priority',
    topWorkflows: 'Top workflows',
    recentDone: 'Recently done',
    todo: 'To do',
    inProgress: 'In progress',
    paused: 'Paused',
    done: 'Done',
    failed: 'Failed',
    urgent: 'Urgent',
    high: 'High',
    normal: 'Normal',
    low: 'Low',
    tasks: 'tasks',
    noData: 'Not enough data yet.',
    efficiencyPct: 'success rate',
};
/// **collab_i18n_end**
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { msgListTasks } from '/_102025_/l2/shared/api.js';
import { getUserId } from '/_102025_/l2/collabMessagesHelper.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
const THIRTY_DAYS = 30 * 24 * 3600 * 1000;
function compute(active, closed) {
    const now = Date.now();
    const thirtyAgo = now - THIRTY_DAYS;
    // Metrics
    const completedMonth = closed.filter(t => t.status === 'done' && (t.last_updated ?? 0) >= thirtyAgo).length;
    const allDoneEver = closed.filter(t => t.status === 'done').length;
    const allFailedEver = closed.filter(t => t.status === 'failed').length;
    const efficiencyPct = (allDoneEver + allFailedEver) > 0
        ? Math.round((allDoneEver / (allDoneEver + allFailedEver)) * 100)
        : 0;
    const allTasks = [...active, ...closed];
    const pmaIdSet = new Set(allTasks.map(t => t.taskRoom?.pmaId).filter(Boolean));
    const highPri = active.filter(t => t.priority === 'high' || t.priority === 'urgent').length;
    // By status (active only)
    const byStatus = {};
    for (const t of active)
        byStatus[t.status] = (byStatus[t.status] ?? 0) + 1;
    // By priority (active only)
    const byPriority = {};
    for (const t of active) {
        const p = t.priority ?? 'normal';
        byPriority[p] = (byPriority[p] ?? 0) + 1;
    }
    // Top workflows: count ALL tasks per pmaId
    const pmaCount = new Map();
    for (const t of allTasks) {
        if (t.taskRoom?.pmaId)
            pmaCount.set(t.taskRoom.pmaId, (pmaCount.get(t.taskRoom.pmaId) ?? 0) + 1);
    }
    const topWorkflows = [...pmaCount.entries()]
        .sort((a, b) => b[1] - a[1])
        .slice(0, 5)
        .map(([pmaId, count]) => ({ pmaId, count }));
    return {
        totalActive: active.length,
        completedMonth,
        workflowCount: pmaIdSet.size,
        highPriority: highPri,
        efficiencyPct,
        byStatus,
        byPriority,
        topWorkflows,
    };
}
let CollabTasksAnalytics = class CollabTasksAnalytics extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-tasks-analytics-102025 {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  --an-text-primary: var(--color-text-primary, #1a1a18);
  --an-text-secondary: var(--color-text-secondary, #5f5e5a);
  --an-text-tertiary: var(--color-text-tertiary, #888780);
  --an-bg: var(--color-background-primary, #ffffff);
  --an-card-bg: var(--color-background-secondary, #f5f4f0);
  --an-border: var(--color-border-tertiary, rgba(0, 0, 0, 0.08));
  --an-track-bg: var(--color-background-tertiary, #eceae3);
}
@media (prefers-color-scheme: dark) {
  collab-tasks-analytics-102025 {
    --an-text-primary: #e8e6dc;
    --an-text-secondary: #b8b5ac;
    --an-text-tertiary: #8a8880;
    --an-bg: #1e1e1c;
    --an-card-bg: #28281f;
    --an-border: rgba(255, 255, 255, 0.08);
    --an-track-bg: #303028;
  }
}
collab-tasks-analytics-102025 .an-header {
  display: flex;
  align-items: center;
  height: 44px;
  padding: 0 16px;
  gap: 8px;
  flex-shrink: 0;
  background: var(--an-bg);
  border-bottom: 0.5px solid var(--an-border);
}
collab-tasks-analytics-102025 .an-header-left {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: 1;
  min-width: 0;
}
collab-tasks-analytics-102025 .an-title {
  font-size: 14px;
  font-weight: 500;
  color: var(--an-text-primary);
  white-space: nowrap;
}
collab-tasks-analytics-102025 .an-sep {
  font-size: 13px;
  color: var(--an-text-tertiary);
}
collab-tasks-analytics-102025 .an-sub {
  font-size: 12px;
  color: var(--an-text-tertiary);
  white-space: nowrap;
}
collab-tasks-analytics-102025 .an-icon-btn {
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: none;
  border: 0.5px solid transparent;
  border-radius: 7px;
  cursor: pointer;
  color: var(--an-text-tertiary);
  transition: background 0.12s, border-color 0.12s;
}
collab-tasks-analytics-102025 .an-icon-btn:hover {
  background: var(--an-card-bg);
  border-color: var(--an-border);
}
collab-tasks-analytics-102025 .an-body {
  flex: 1;
  overflow-y: auto;
  padding: 14px 16px 20px;
  background: var(--an-bg);
  display: flex;
  flex-direction: column;
  gap: 12px;
}
collab-tasks-analytics-102025 .an-error {
  background: var(--color-background-danger, #fcebeb);
  color: var(--color-text-danger, #a32d2d);
  border-radius: 8px;
  padding: 10px 14px;
  font-size: 13px;
  display: flex;
  align-items: center;
  gap: 10px;
}
collab-tasks-analytics-102025 .an-error button {
  background: none;
  border: none;
  cursor: pointer;
  color: inherit;
  text-decoration: underline;
  font-size: 13px;
  padding: 0;
}
collab-tasks-analytics-102025 .tiles {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 8px;
}
@media (max-width: 480px) {
  collab-tasks-analytics-102025 .tiles {
    grid-template-columns: repeat(2, 1fr);
  }
}
collab-tasks-analytics-102025 .tile {
  border-radius: 10px;
  padding: 12px 13px;
  display: flex;
  flex-direction: column;
  gap: 3px;
  border: 0.5px solid var(--an-border);
}
collab-tasks-analytics-102025 .tile-value {
  font-size: 22px;
  font-weight: 600;
  line-height: 1;
}
collab-tasks-analytics-102025 .tile-label {
  font-size: 10px;
  color: var(--an-text-tertiary);
  line-height: 1.3;
}
collab-tasks-analytics-102025 .tile-blue {
  background: var(--color-background-info, #e6f1fb);
  border-color: #c0d8f2;
}
collab-tasks-analytics-102025 .tile-blue .tile-value {
  color: var(--color-text-info, #185fa5);
}
collab-tasks-analytics-102025 .tile-green {
  background: var(--color-background-success, #eaf3de);
  border-color: #b2d893;
}
collab-tasks-analytics-102025 .tile-green .tile-value {
  color: var(--color-text-success, #3b6d11);
}
collab-tasks-analytics-102025 .tile-purple {
  background: #ede9fe;
  border-color: #c4b5fd;
}
collab-tasks-analytics-102025 .tile-purple .tile-value {
  color: #5b21b6;
}
collab-tasks-analytics-102025 .tile-neutral {
  background: var(--an-card-bg);
}
collab-tasks-analytics-102025 .tile-neutral .tile-value {
  color: var(--an-text-primary);
}
@media (prefers-color-scheme: dark) {
  collab-tasks-analytics-102025 .tile-blue {
    background: rgba(24, 95, 165, 0.13);
    border-color: rgba(24, 95, 165, 0.22);
  }
  collab-tasks-analytics-102025 .tile-blue .tile-value {
    color: #85b7eb;
  }
  collab-tasks-analytics-102025 .tile-green {
    background: rgba(59, 109, 17, 0.13);
    border-color: rgba(59, 109, 17, 0.22);
  }
  collab-tasks-analytics-102025 .tile-green .tile-value {
    color: #97c459;
  }
  collab-tasks-analytics-102025 .tile-purple {
    background: rgba(91, 33, 182, 0.13);
    border-color: rgba(91, 33, 182, 0.22);
  }
  collab-tasks-analytics-102025 .tile-purple .tile-value {
    color: #a78bfa;
  }
  collab-tasks-analytics-102025 .tile-neutral .tile-value {
    color: var(--an-text-primary);
  }
}
collab-tasks-analytics-102025 .tile-skeleton {
  background: var(--an-card-bg);
}
collab-tasks-analytics-102025 .an-card {
  background: var(--an-card-bg);
  border: 0.5px solid var(--an-border);
  border-radius: 10px;
  padding: 12px 14px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
collab-tasks-analytics-102025 .an-card-title {
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--an-text-tertiary);
  margin-bottom: 2px;
}
collab-tasks-analytics-102025 .bar-row {
  display: flex;
  align-items: center;
  gap: 8px;
}
collab-tasks-analytics-102025 .bar-label {
  font-size: 11px;
  color: var(--an-text-secondary);
  width: 80px;
  flex-shrink: 0;
  text-align: right;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
collab-tasks-analytics-102025 .bar-label.wf-label {
  font-weight: 500;
}
collab-tasks-analytics-102025 .bar-track {
  flex: 1;
  height: 20px;
  background: var(--an-track-bg);
  border-radius: 4px;
  overflow: hidden;
}
collab-tasks-analytics-102025 .bar-fill {
  height: 100%;
  border-radius: 4px;
  display: flex;
  align-items: center;
  padding: 0 7px;
  min-width: 28px;
  transition: width 0.5s cubic-bezier(0.22, 1, 0.36, 1);
}
collab-tasks-analytics-102025 .bar-val {
  font-size: 10px;
  font-weight: 600;
  white-space: nowrap;
}
collab-tasks-analytics-102025 .bar-todo {
  background: #e6f1fb;
}
collab-tasks-analytics-102025 .bar-todo .bar-val {
  color: #185fa5;
}
collab-tasks-analytics-102025 .bar-in-progress {
  background: #faeeda;
}
collab-tasks-analytics-102025 .bar-in-progress .bar-val {
  color: #854f0b;
}
collab-tasks-analytics-102025 .bar-paused {
  background: #f3f4f6;
}
collab-tasks-analytics-102025 .bar-paused .bar-val {
  color: #6b7280;
}
collab-tasks-analytics-102025 .bar-done {
  background: #eaf3de;
}
collab-tasks-analytics-102025 .bar-done .bar-val {
  color: #3b6d11;
}
collab-tasks-analytics-102025 .bar-failed {
  background: #fcebeb;
}
collab-tasks-analytics-102025 .bar-failed .bar-val {
  color: #a32d2d;
}
collab-tasks-analytics-102025 .bar-urgent {
  background: #fcebeb;
}
collab-tasks-analytics-102025 .bar-urgent .bar-val {
  color: #a32d2d;
}
collab-tasks-analytics-102025 .bar-high {
  background: #faeeda;
}
collab-tasks-analytics-102025 .bar-high .bar-val {
  color: #854f0b;
}
collab-tasks-analytics-102025 .bar-normal {
  background: var(--an-track-bg);
}
collab-tasks-analytics-102025 .bar-normal .bar-val {
  color: var(--an-text-secondary);
}
collab-tasks-analytics-102025 .bar-low {
  background: var(--an-track-bg);
  opacity: 0.7;
}
collab-tasks-analytics-102025 .bar-low .bar-val {
  color: var(--an-text-tertiary);
}
collab-tasks-analytics-102025 .bar-wf {
  background: #ede9fe;
}
collab-tasks-analytics-102025 .bar-wf .bar-val {
  color: #5b21b6;
}
@media (prefers-color-scheme: dark) {
  collab-tasks-analytics-102025 .bar-todo {
    background: rgba(24, 95, 165, 0.15);
  }
  collab-tasks-analytics-102025 .bar-todo .bar-val {
    color: #85b7eb;
  }
  collab-tasks-analytics-102025 .bar-in-progress {
    background: rgba(133, 79, 11, 0.18);
  }
  collab-tasks-analytics-102025 .bar-in-progress .bar-val {
    color: #fac775;
  }
  collab-tasks-analytics-102025 .bar-paused {
    background: rgba(107, 114, 128, 0.15);
  }
  collab-tasks-analytics-102025 .bar-paused .bar-val {
    color: #9ca3af;
  }
  collab-tasks-analytics-102025 .bar-done {
    background: rgba(59, 109, 17, 0.15);
  }
  collab-tasks-analytics-102025 .bar-done .bar-val {
    color: #97c459;
  }
  collab-tasks-analytics-102025 .bar-failed {
    background: rgba(163, 45, 45, 0.15);
  }
  collab-tasks-analytics-102025 .bar-failed .bar-val {
    color: #f09595;
  }
  collab-tasks-analytics-102025 .bar-urgent {
    background: rgba(163, 45, 45, 0.18);
  }
  collab-tasks-analytics-102025 .bar-urgent .bar-val {
    color: #fca5a5;
  }
  collab-tasks-analytics-102025 .bar-high {
    background: rgba(133, 79, 11, 0.18);
  }
  collab-tasks-analytics-102025 .bar-high .bar-val {
    color: #fac775;
  }
  collab-tasks-analytics-102025 .bar-wf {
    background: rgba(91, 33, 182, 0.15);
  }
  collab-tasks-analytics-102025 .bar-wf .bar-val {
    color: #a78bfa;
  }
}
@keyframes shimmer {
  0% {
    background-position: -200% 0;
  }
  100% {
    background-position: 200% 0;
  }
}
collab-tasks-analytics-102025 .skel {
  border-radius: 4px;
  background: linear-gradient(90deg, var(--an-track-bg) 0%, rgba(128, 128, 128, 0.12) 50%, var(--an-track-bg) 100%);
  background-size: 200% 100%;
  animation: shimmer 1.4s ease-in-out infinite;
}
collab-tasks-analytics-102025 .skel-val {
  width: 44px;
  height: 22px;
  margin-bottom: 4px;
  border-radius: 4px;
}
collab-tasks-analytics-102025 .skel-lbl {
  width: 70%;
  height: 10px;
  border-radius: 3px;
}
@media (prefers-reduced-motion: reduce) {
  collab-tasks-analytics-102025 .skel {
    animation: none;
  }
  collab-tasks-analytics-102025 .bar-fill {
    transition: none;
  }
}
`);
        this.userId = '';
        this.analytics = null;
        this.loading = true;
        this.error = null;
    }
    connectedCallback() {
        super.connectedCallback();
        if (!this.userId)
            this.userId = getUserId() || '';
        this._fetchAll();
    }
    async _fetchAll() {
        this.loading = true;
        this.error = null;
        try {
            const [activeRes, closedRes] = await Promise.all([
                msgListTasks({ userId: this.userId, view: 'active', pageSize: 200 }),
                msgListTasks({ userId: this.userId, view: 'closed', pageSize: 200 }),
            ]);
            if (!activeRes.success) {
                this.error = activeRes.error ?? 'error';
                this.loading = false;
                return;
            }
            this.analytics = compute(activeRes.response?.tasks ?? [], closedRes.response?.tasks ?? []);
        }
        catch (err) {
            this.error = err?.message ?? 'error';
        }
        this.loading = false;
    }
    render() {
        const m = getMsg();
        return html `
      <div class="an-header">
        <div class="an-header-left">
          <span class="an-title">${m.title}</span>
          <span class="an-sep">·</span>
          <span class="an-sub">${m.subtitle}</span>
        </div>
        <button class="an-icon-btn" title="${m.reload}" @click=${() => this._fetchAll()}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="23 4 23 10 17 10"></polyline>
            <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
          </svg>
        </button>
      </div>

      <div class="an-body">
        ${this.error ? html `
          <div class="an-error">
            <span>${m.loadError}</span>
            <button @click=${() => this._fetchAll()}>${m.retry}</button>
          </div>
        ` : nothing}

        ${this.loading
            ? this._renderLoadingTiles()
            : this.analytics
                ? this._renderDashboard(this.analytics, m)
                : nothing}
      </div>
    `;
    }
    _renderDashboard(a, m) {
        const maxStatus = Math.max(1, ...Object.values(a.byStatus));
        const maxPriority = Math.max(1, ...Object.values(a.byPriority));
        const maxWorkflow = a.topWorkflows[0]?.count ?? 1;
        const statusRows = [
            { key: 'in progress', label: m.inProgress, color: 'bar-in-progress' },
            { key: 'todo', label: m.todo, color: 'bar-todo' },
            { key: 'paused', label: m.paused, color: 'bar-paused' },
            { key: 'done', label: m.done, color: 'bar-done' },
            { key: 'failed', label: m.failed, color: 'bar-failed' },
        ].filter(r => (a.byStatus[r.key] ?? 0) > 0);
        const priRows = [
            { key: 'urgent', label: m.urgent, color: 'bar-urgent' },
            { key: 'high', label: m.high, color: 'bar-high' },
            { key: 'normal', label: m.normal, color: 'bar-normal' },
            { key: 'low', label: m.low, color: 'bar-low' },
        ].filter(r => (a.byPriority[r.key] ?? 0) > 0);
        return html `
      <!-- ── Metric tiles ── -->
      <div class="tiles">
        ${this._tile(String(a.totalActive), m.totalActive, 'tile-blue')}
        ${this._tile(String(a.completedMonth), m.completedMonth, 'tile-green')}
        ${this._tile(String(a.workflowCount), m.workflows, 'tile-purple')}
        ${this._tile(`${a.efficiencyPct}%`, m.efficiencyPct, 'tile-neutral')}
      </div>

      <!-- ── Status breakdown ── -->
      ${statusRows.length > 0 ? html `
        <div class="an-card">
          <div class="an-card-title">${m.byStatus}</div>
          ${statusRows.map(r => html `
            <div class="bar-row">
              <div class="bar-label">${r.label}</div>
              <div class="bar-track">
                <div class="bar-fill ${r.color}" style="width:${Math.round((a.byStatus[r.key] ?? 0) / maxStatus * 100)}%">
                  <span class="bar-val">${a.byStatus[r.key] ?? 0}</span>
                </div>
              </div>
            </div>
          `)}
        </div>
      ` : nothing}

      <!-- ── Priority breakdown ── -->
      ${priRows.length > 0 ? html `
        <div class="an-card">
          <div class="an-card-title">${m.byPriority}</div>
          ${priRows.map(r => html `
            <div class="bar-row">
              <div class="bar-label">${r.label}</div>
              <div class="bar-track">
                <div class="bar-fill ${r.color}" style="width:${Math.round((a.byPriority[r.key] ?? 0) / maxPriority * 100)}%">
                  <span class="bar-val">${a.byPriority[r.key] ?? 0}</span>
                </div>
              </div>
            </div>
          `)}
        </div>
      ` : nothing}

      <!-- ── Top workflows ── -->
      ${a.topWorkflows.length > 0 ? html `
        <div class="an-card">
          <div class="an-card-title">${m.topWorkflows}</div>
          ${a.topWorkflows.map(wf => html `
            <div class="bar-row">
              <div class="bar-label wf-label">${wf.pmaId}</div>
              <div class="bar-track">
                <div class="bar-fill bar-wf" style="width:${Math.round(wf.count / maxWorkflow * 100)}%">
                  <span class="bar-val">${wf.count} ${m.tasks}</span>
                </div>
              </div>
            </div>
          `)}
        </div>
      ` : nothing}
    `;
    }
    _tile(value, label, cls) {
        return html `
      <div class="tile ${cls}">
        <div class="tile-value">${value}</div>
        <div class="tile-label">${label}</div>
      </div>
    `;
    }
    _renderLoadingTiles() {
        return html `
      <div class="tiles">
        ${[0, 1, 2, 3].map(() => html `
          <div class="tile tile-skeleton">
            <div class="skel skel-val"></div>
            <div class="skel skel-lbl"></div>
          </div>
        `)}
      </div>
      <div class="an-card">
        ${[80, 60, 40, 70].map(w => html `
          <div class="bar-row">
            <div class="skel" style="width:72px;height:11px;border-radius:3px"></div>
            <div class="bar-track"><div class="skel" style="width:${w}%;height:100%;border-radius:4px"></div></div>
          </div>
        `)}
      </div>
    `;
    }
};
__decorate([
    property({ type: String })
], CollabTasksAnalytics.prototype, "userId", void 0);
__decorate([
    state()
], CollabTasksAnalytics.prototype, "analytics", void 0);
__decorate([
    state()
], CollabTasksAnalytics.prototype, "loading", void 0);
__decorate([
    state()
], CollabTasksAnalytics.prototype, "error", void 0);
CollabTasksAnalytics = __decorate([
    customElement('collab-tasks-analytics-102025')
], CollabTasksAnalytics);
export { CollabTasksAnalytics };
