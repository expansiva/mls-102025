/// <mls fileReference="_102025_/l2/collabMessagesHelper.ts" enhancement="_blank" />
import { msgGetUserUpdate, msgUpdateUserDetails, msgAddMessage, msgAddThread, msgAddParticipantToThread } from '/_102025_/l2/shared/api.js';
import { notifyMessageSendChange, notifyThreadChange, notifyThreadCreate, } from '/_102025_/l2/collabMessagesEvents.js';
import { addThread, listThreads, updateThread } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { environment } from '/_102036_/l2/environmentContract.js';
import { isNotificationPermissionDenied, MLS_LIB_RETRIES, MLS_LIB_RETRY_MS, } from '/_102025_/l2/notificationsRuntime.js';
import { getMessageKey } from '/_102029_/l2/libCommom.js';
/// **collab_i18n_start** 
const message_pt = {
    updatedToday: 'atualizado hoje',
    updated: 'atualizado',
    on: 'em',
    days: 'dias',
    day: 'dia',
    ago: 'atrás',
    jan: 'Jan',
    feb: 'Fev',
    mar: 'Mar',
    apr: 'Abr',
    may: 'Mai',
    june: 'Jun',
    july: 'Jul',
    aug: 'Ago',
    sept: 'Set',
    oct: 'Out',
    nov: 'Nov',
    dec: 'Dez',
};
const message_en = {
    updatedToday: 'updated today',
    updated: 'updated',
    on: 'on',
    days: 'days',
    day: 'day',
    ago: 'ago',
    jan: 'Jan',
    feb: 'Feb',
    mar: 'Mar',
    apr: 'Apr',
    may: 'May',
    june: 'June',
    july: 'July',
    aug: 'Aug',
    sept: 'Sept',
    oct: 'Oct',
    nov: 'Nov',
    dec: 'Dec',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const lang = getMessageKey(messages);
const i18n = messages[lang];
const LS_KEY_OLD = 'collabChatPreferences';
const LOCAL_STORAGE_KEY = 'serviceCollabMessages';
export const AGENTDEFAULT = 'agentPlanner1';
async function waitForDefinedSubscription() {
    let subscription = await environment.notifications.getPushSubscriptionForBackend();
    let left = MLS_LIB_RETRIES;
    while (subscription === undefined && left > 0) {
        left -= 1;
        await new Promise((resolve) => setTimeout(resolve, MLS_LIB_RETRY_MS));
        subscription = await environment.notifications.getPushSubscriptionForBackend();
    }
    return subscription;
}
export async function registerToken() {
    const subscription = await waitForDefinedSubscription();
    if (subscription == null) {
        if (isNotificationPermissionDenied()) {
            saveNotificationPreferences('denied');
        }
        return subscription ?? null;
    }
    const lastToken = loadNotificationToken();
    if (lastToken === subscription.endpoint)
        return subscription;
    saveNotificationToken(subscription.endpoint);
    try {
        const deviceId = loadNotificationDeviceId() || crypto.randomUUID();
        saveNotificationDeviceId(deviceId);
        const userResult = await msgGetUserUpdate({ userId: "" });
        if (!userResult.success || !userResult.response?.user) {
            throw new Error(userResult.error || 'Failed to fetch user data');
        }
        const user = userResult.response.user;
        const updateResult = await msgUpdateUserDetails({
            userId: user.userId,
            avatar_url: user.avatar_url,
            name: user.name,
            status: user.status,
            deviceId,
            subscription
        });
        if (!updateResult.success) {
            throw new Error(updateResult.error || 'Failed to update user details');
        }
        saveNotificationPreferences('granted');
        return subscription;
    }
    catch (err) {
        throw new Error('Error on register token: ' + err.message);
    }
}
export async function addMessage(threadId, messageContent, contextToBot) {
    const userId = getUserId() || '';
    if (!userId)
        throw new Error('Invalid user id');
    const context = getTemporaryContext(threadId, userId, messageContent);
    if (!messageContent.startsWith('@@')) {
        const result = await msgAddMessage({
            content: messageContent,
            threadId,
            userId,
            contextToBot,
            senderDeviceId: loadNotificationDeviceId() || undefined
        });
        if (!result.success || !result.response?.message) {
            throw new Error(result.error || 'Failed to send message');
        }
        notifyMessageSendChange({
            message: result.response.message,
            task: undefined,
            isTest: false
        });
        return;
    }
    const agentName = extractAgentName(messageContent) || AGENTDEFAULT;
    await environment.agents.executeAgent(agentName, context);
    return context;
}
export async function getArgsToBots() {
    const data = {};
    return data;
}
export async function getBotsContext(thread, prompt, context) {
    const argsToBot = await getArgsToBots();
    const botsVarsBefore = await environment.bots.getBotContextVarsBeforeMessageSend(thread, prompt);
    const botsVarsBefore2 = await environment.bots.getBotContextVarsBeforeMessageSend2(botsVarsBefore, argsToBot);
    const auxContextToBot = [];
    for await (let bot of botsVarsBefore2) {
        try {
            const moduleBot = await environment.agents.loadAgent(bot.toolName);
            if (moduleBot && moduleBot.beforeBot && typeof moduleBot.beforeBot === 'function') {
                const argsBot = await moduleBot.beforeBot(context, prompt, botsVarsBefore2);
                auxContextToBot.push(argsBot);
            }
        }
        catch (err) {
            console.error(err.message);
            continue;
        }
    }
    const merged = auxContextToBot.reduce((acc, curr) => {
        return { ...acc, ...curr };
    }, {});
    return merged;
}
export function saveNotificationDeviceId(deviceId) {
    let dataLocal = loadLocalStorage();
    if (!dataLocal)
        dataLocal = { deviceId };
    else
        dataLocal.deviceId = deviceId;
    saveLocalStorage(dataLocal);
}
export function loadNotificationDeviceId() {
    const lsData = loadLocalStorage();
    if (lsData && lsData.deviceId)
        return lsData.deviceId;
    return null;
}
export function saveNotificationToken(tokenFCM) {
    let dataLocal = loadLocalStorage();
    if (!dataLocal)
        dataLocal = { tokenFCM };
    else
        dataLocal.tokenFCM = tokenFCM;
    saveLocalStorage(dataLocal);
}
export function loadNotificationToken() {
    const lsData = loadLocalStorage();
    if (lsData && lsData.tokenFCM)
        return lsData.tokenFCM;
    return null;
}
export function saveNotificationPreferences(notificationPreference) {
    let dataLocal = loadLocalStorage();
    if (!dataLocal)
        dataLocal = { notificationPreference };
    else
        dataLocal.notificationPreference = notificationPreference;
    saveLocalStorage(dataLocal);
}
export function loadNotificationPreferences() {
    const lsData = loadLocalStorage();
    if (lsData && lsData.notificationPreference)
        return lsData.notificationPreference;
    return null;
}
export function saveNotificationPreferencesAudio(enable) {
    let dataLocal = loadLocalStorage();
    if (!dataLocal)
        dataLocal = { notificationAudio: enable };
    else
        dataLocal.notificationAudio = enable;
    saveLocalStorage(dataLocal);
}
export function loadNotificationPreferencesAudio() {
    const lsData = loadLocalStorage();
    if (lsData && typeof lsData.notificationAudio === 'boolean')
        return lsData.notificationAudio;
    return true;
}
export function saveLastAlertTime(time) {
    let dataLocal = loadLocalStorage();
    if (!dataLocal)
        dataLocal = { lastNotificationAlertTime: time };
    else
        dataLocal.lastNotificationAlertTime = time;
    saveLocalStorage(dataLocal);
}
export function loadLastAlertTime() {
    const lsData = loadLocalStorage();
    if (lsData && lsData.lastNotificationAlertTime)
        return lsData.lastNotificationAlertTime;
    return undefined;
}
export function saveLastTab(lastTab) {
    let dataLocal = loadLocalStorage();
    if (!dataLocal)
        dataLocal = { lastTab };
    else
        dataLocal.lastTab = lastTab;
    saveLocalStorage(dataLocal);
}
export function loadLastTab() {
    const lsData = loadLocalStorage();
    if (lsData && lsData.lastTab)
        return lsData.lastTab;
    return 'CRM';
}
export function saveUserId(userId) {
    let dataLocal = loadLocalStorage();
    if (!dataLocal)
        dataLocal = { userId };
    else
        dataLocal.userId = userId;
    saveLocalStorage(dataLocal);
}
export function getUserId() {
    const savedOld = localStorage.getItem('collabMessages_userId');
    if (savedOld) {
        saveUserId(savedOld);
        localStorage.removeItem('collabMessages_userId');
    }
    const lsData = loadLocalStorage();
    if (lsData && lsData.userId)
        return lsData.userId;
    return null;
}
export function loadChatPreferences() {
    const savedOld = localStorage.getItem(LS_KEY_OLD);
    if (savedOld) {
        try {
            const data = JSON.parse(savedOld);
            saveChatPreferences(data);
            localStorage.removeItem(LS_KEY_OLD);
        }
        catch (e) {
            localStorage.removeItem(LS_KEY_OLD);
            console.warn('Invalid preferences in localStorage');
        }
    }
    const lsData = loadLocalStorage();
    if (lsData && lsData.chatPreferences)
        return lsData.chatPreferences;
    return loadDefaultPreferences();
}
export function saveChatPreferences(chatPreferences) {
    let dataLocal = loadLocalStorage();
    if (!dataLocal) {
        dataLocal = { chatPreferences };
    }
    else {
        dataLocal.chatPreferences = chatPreferences;
    }
    saveLocalStorage(dataLocal);
}
export async function loadOpenClawIntegrations() {
    return environment.getIntegrationsOpenClaw();
}
export async function saveOpenClawIntegrations(integrations) {
    return environment.setIntegrationsOpenClaw(integrations);
}
function saveLocalStorage(data) {
    try {
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(data));
    }
    catch (e) {
        console.error('Erro ao salvar no localStorage:', e);
    }
}
function loadLocalStorage() {
    let dataLocal;
    try {
        const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
        if (stored)
            dataLocal = JSON.parse(stored);
        return dataLocal;
    }
    catch (e) {
        console.error('Erro ao carregar do localStorage:', e);
    }
}
function loadDefaultPreferences() {
    return {
        language: document.documentElement?.lang?.split('-')?.shift() || 'en',
        translationMode: 'icon',
        threadMaintenance: ''
    };
}
function extractAgentName(str) {
    const match = str.match(/^@@([a-zA-Z][a-zA-Z0-9]*)/);
    if (!match)
        return undefined;
    const name = match[1];
    if (name.toLowerCase().startsWith('agent')) {
        return name;
    }
    return 'agent' + name[0].toUpperCase() + name.slice(1);
}
export async function checkThreadAlreadyExist(threadName) {
    const userId = getUserId();
    if (!userId)
        throw new Error('No find user id');
}
export async function getDmThreadByUsers(userId1, userId2) {
    const allThreads = await listThreads();
    return allThreads.find(thread => {
        if (!thread.name.startsWith('@'))
            return false;
        if (thread.users.length !== 2)
            return false;
        const userIds = thread.users.map(u => u.userId);
        return userIds.includes(userId1) && userIds.includes(userId2);
    });
}
export async function createThread(threadName, languages, visibility, avatar_url = '') {
    const userId = getUserId();
    if (!userId)
        throw new Error('No find user id');
    try {
        const result = await msgAddThread({
            name: threadName,
            group: 'CONNECT',
            languages,
            userId,
            visibility,
            status: 'active',
            avatar_url
        });
        if (!result.success || !result.response?.thread) {
            throw new Error(result.error || 'Failed to create thread');
        }
        const thread = result.response.thread;
        const thr = await addThread(thread);
        notifyThreadCreate(thr);
        return thread;
    }
    catch (err) {
        console.error(err);
        throw new Error(err.message);
    }
}
export async function createThreadDM(threadName, dmUser, group) {
    const userId = getUserId();
    if (!userId)
        throw new Error('User not found');
    const alreadyExistThread = await getDmThreadByUsers(userId, dmUser);
    if (alreadyExistThread) {
        throw new Error('A direct message thread with this user already exists.');
    }
    try {
        // 1. Create thread
        const threadResult = await msgAddThread({
            name: threadName,
            group,
            languages: [],
            userId,
            visibility: 'private',
            status: 'active',
            avatar_url: ''
        });
        if (!threadResult.success || !threadResult.response?.thread) {
            throw new Error(threadResult.error || 'Failed to create thread');
        }
        const thread = threadResult.response.thread;
        const thr = await addThread(thread);
        notifyThreadCreate(thr);
        // 2. Add participant
        const participantResult = await msgAddParticipantToThread({
            auth: 'admin',
            userIdOrName: dmUser,
            threadId: thr.threadId,
            userId
        });
        if (participantResult.success && participantResult.response?.thread) {
            await updateThread(thread.threadId, participantResult.response.thread);
            notifyThreadChange(participantResult.response.thread);
            return participantResult.response.thread;
        }
        // fallback
        return thread;
    }
    catch (err) {
        console.error(err);
        throw new Error(err.message || 'Failed to create DM thread');
    }
}
export function formatTimestamp(timestamp) {
    if (!timestamp || timestamp.length < 14) {
        return;
    }
    const year = timestamp.slice(0, 4);
    const month = timestamp.slice(4, 6);
    const day = timestamp.slice(6, 8);
    const hour = timestamp.slice(8, 10);
    const minute = timestamp.slice(10, 12);
    const second = timestamp.slice(12, 14);
    const utcDate = new Date(Date.UTC(parseInt(year), parseInt(month) - 1, parseInt(day), parseInt(hour), parseInt(minute), parseInt(second)));
    const localYear = utcDate.getFullYear();
    const localMonth = (utcDate.getMonth() + 1).toString().padStart(2, '0');
    const localDay = utcDate.getDate().toString().padStart(2, '0');
    const localHour = utcDate.getHours().toString().padStart(2, '0');
    const localMinute = utcDate.getMinutes().toString().padStart(2, '0');
    const localSecond = utcDate.getSeconds().toString().padStart(2, '0');
    const date = `${localYear}-${localMonth}-${localDay}`;
    const time = `${localHour}:${localMinute}:${localSecond}`;
    const timeShort = `${localHour}:${localMinute}`;
    const dateFull = `${date} ${time}`;
    return { dateFull, date, time, timeShort };
}
export function getDateFormated(dt) {
    let lastUpdated;
    const dateToday = new Date();
    const dtLastWrite = new Date(dt);
    const _MS_PER_DAY = 1000 * 60 * 60 * 24;
    // a and b are javascript Date objects
    function dateDiffInDays(a, b) {
        // Discard the time and time-zone information.
        const utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
        const utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
        return Math.floor((utc2 - utc1) / _MS_PER_DAY);
    }
    const diffDays = dateDiffInDays(dtLastWrite, dateToday);
    const moreThanTwoDays = diffDays > 1;
    if (diffDays === 0) {
        lastUpdated = i18n.updatedToday;
    }
    else if (diffDays < 30) {
        lastUpdated = `${i18n.updated} ${diffDays} ${moreThanTwoDays ? i18n.days : i18n.day} ${i18n.ago}`;
    }
    else {
        const lastWriteYear = dtLastWrite.getFullYear();
        const lastWriteMounth = dtLastWrite.getMonth();
        const lastWriteDay = dtLastWrite.getDate();
        const mounthFilter = {
            0: i18n.jan,
            1: i18n.feb,
            2: i18n.mar,
            3: i18n.apr,
            4: i18n.may,
            5: i18n.june,
            6: i18n.july,
            7: i18n.aug,
            8: i18n.sept,
            9: i18n.oct,
            10: i18n.nov,
            11: i18n.dec,
        };
        lastUpdated = `${i18n.updated} ${i18n.on} ${lastWriteYear}, ${lastWriteDay} ${mounthFilter[lastWriteMounth]} `;
    }
    return lastUpdated;
}
export const getTemporaryContext = (threadId, userId, prompt) => {
    // create temporary context
    const now = new Date();
    const formattedDate = now.getUTCFullYear().toString()
        + String(now.getUTCMonth() + 1).padStart(2, '0')
        + String(now.getUTCDate()).padStart(2, '0')
        + String(now.getUTCHours()).padStart(2, '0')
        + String(now.getUTCMinutes()).padStart(2, '0')
        + String(now.getUTCSeconds()).padStart(2, '0')
        + "." + Math.floor(1000 + Math.random() * 9000);
    const context = {
        task: undefined,
        message: {
            threadId: threadId,
            orderAt: "",
            createAt: formattedDate,
            senderId: userId,
            content: prompt.trim(),
        },
        isTest: false
    };
    return context;
};
export async function findAgentInIntegrationsByUserId(collabUserId) {
    try {
        const integrations = await loadOpenClawIntegrations();
        for (const integration of integrations) {
            const agent = integration.agents?.find(a => a.collabUserId === collabUserId);
            if (agent) {
                return {
                    name: agent.name,
                    agentId: agent.id,
                    connectorId: integration.connectorId
                };
            }
        }
        return null;
    }
    catch (err) {
        console.error('Error on search user in integrations:', err);
        return null;
    }
}
export function generateUUIDv7() {
    const timestamp = Date.now();
    const timestampHex = timestamp.toString(16).padStart(12, '0');
    const randomBytes = new Uint8Array(10);
    crypto.getRandomValues(randomBytes);
    randomBytes[0] = (randomBytes[0] & 0x0f) | 0x70;
    randomBytes[2] = (randomBytes[2] & 0x3f) | 0x80;
    const randomHex = Array.from(randomBytes).map(b => b.toString(16).padStart(2, '0')).join('');
    return `${timestampHex.slice(0, 8)}-${timestampHex.slice(8, 12)}-${randomHex.slice(0, 4)}-${randomHex.slice(4, 8)}-${randomHex.slice(8, 20)}`;
}
export function generateAgentAvatar(name) {
    const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9'];
    const colorIndex = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) % colors.length;
    const bgColor = colors[colorIndex];
    const initials = name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
    return `data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><rect width="80" height="80" fill="${bgColor}"/><text x="40" y="40" font-family="Arial" font-size="28" fill="white" text-anchor="middle" dy=".35em">${initials}</text></svg>`)}`;
}
function isCrossOriginIconSrc(src) {
    if (!src || src.startsWith('data:') || src.startsWith('/'))
        return false;
    try {
        const origin = typeof location !== 'undefined' ? location.origin : '';
        if (!origin)
            return false;
        return new URL(src, origin).origin !== origin;
    }
    catch {
        return false;
    }
}
function traceBadge(event, fields) {
    try {
        const enabled = (typeof window !== 'undefined' && window.isTraceNotification)
            || (typeof localStorage !== 'undefined' && localStorage.getItem('collabTraceNotification') === 'true');
        if (!enabled)
            return;
        console.info(`[NOTIFICATION] ${event}`, fields ?? '');
    }
    catch {
        // private mode / missing storage
    }
}
export async function changeFavIcon(notification) {
    try {
        const link = document.querySelector("[rel~='icon']");
        if (!link) {
            traceBadge('badge.skipped', { reason: 'no-icon-link' });
            return;
        }
        if (!notification) {
            link.href = link.dataset.original || link.href;
            return;
        }
        if (!link.dataset.original) {
            link.dataset.original = link.href;
        }
        const img = new Image();
        const src = link.dataset.original;
        if (isCrossOriginIconSrc(src))
            img.crossOrigin = 'anonymous';
        await new Promise((resolve, reject) => {
            img.onload = () => resolve();
            img.onerror = () => reject(new Error('favicon-load-failed'));
            img.src = src;
        });
        const size = 64;
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            return;
        ctx.drawImage(img, 0, 0, size, size);
        const radius = size * 0.2;
        ctx.beginPath();
        ctx.arc(size - radius, radius, radius, 0, Math.PI * 2);
        ctx.fillStyle = '#FF0000';
        ctx.fill();
        ctx.lineWidth = 2;
        ctx.strokeStyle = '#FFF';
        ctx.stroke();
        try {
            link.href = canvas.toDataURL('image/png');
        }
        catch (err) {
            const name = err instanceof Error ? err.name : undefined;
            traceBadge('badge.blocked', { reason: 'canvas-tainted', name });
        }
    }
    catch (err) {
        const name = err instanceof Error ? err.name : undefined;
        traceBadge('badge.blocked', { name });
    }
}
