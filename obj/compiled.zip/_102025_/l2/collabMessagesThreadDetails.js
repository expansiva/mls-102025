/// <mls fileReference="_102025_/l2/collabMessagesThreadDetails.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat, ifDefined } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { updateThread, getUser, deleteAllMessagesFromThread } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { collab_triangle_exclamation, collab_floppy_disk, collab_edit } from '/_102025_/l2/collabMessagesIcons.js';
import { notifyThreadChange } from '/_102025_/l2/collabMessagesEvents.js';
import { addMessage, loadOpenClawIntegrations, generateUUIDv7, generateDefaultAvatar } from "/_102025_/l2/collabMessagesHelper.js";
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { msgGetThreadUpdates, msgRemoveParticipantFromThread, msgAddOrUpdateThreadIntegration, msgAddOrUpdateThreadBot, msgUpdateThread } from '/_102025_/l2/shared/api.js';
import '/_102025_/l2/collabMessagesInputTag.js';
import '/_102025_/l2/collabMessagesAddParticipant.js';
import '/_102025_/l2/collabMessagesChangeAvatar.js';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    threadName: 'Nome da thread',
    visibility: 'Visibilidade',
    visibilityPublic: 'Pública',
    visibilityPrivate: 'Privada',
    visibilityCompany: 'Empresa',
    visibilityTeam: 'Time',
    status: 'Status',
    statusActive: 'Ativo',
    statusArchived: 'Arquivado',
    statusDeleted: 'Deletado',
    statusDeleting: 'Deletando',
    topicsDefault: 'Tópicos',
    welcomeMessage: 'Mensagem de boas-vindas',
    remove: 'Remover',
    disable: 'Desabilitar',
    active: 'Ativar',
    users: 'Usuários',
    bots: 'Bots',
    agents: 'Agents',
    group: 'Grupo',
    details: 'Detalhes',
    languages: 'Tradução automática nos idiomas',
    languagesHint: 'A cada mensagem será verificado o idioma da mensagem e feito a tradução para os idiomas acima, deixe em branco para não gastar créditos.',
    validateFormError: 'Preencha todos os campos obrigatórios.',
    userError: 'ID de usuário inválido.',
    btnSave: 'Salvar alterações',
    btnSaveAgent: 'Adicionar agente',
    btnCancel: 'Cancelar',
    btnEdit: 'Editar',
    successSaving: 'Alterações salvas com sucesso!',
    noChanges: 'Nenhuma alteração detectada.',
    addParticipant: 'Adicionar participante',
    addAgent: 'Adicionar Agent',
    labelUserId: 'Nome do usuario ou Id',
    labelPermission: 'Autoridade:',
    errorFieldsAddParticipant: 'Preencha todos os campos!',
    errorRemoveUser: 'Erro ao remover usuário',
    errorRemoveAgent: 'Erro ao remover agent',
    successAddAgent: 'Agent adicionado com sucesso',
    successRemoveAgent: 'Agent removido com sucesso',
    threadDetails: 'Detalhes da sala',
    changeAvatar: 'Alterar avatar',
    errorSaveThreadDeletStatus: 'A thread não pode ser alterada enquanto status "deleting"',
    threadNameInvalid: 'The name must start with #',
    selectIntegration: 'Selecione a integração',
    selectAgent: 'Selecione o agent',
    noIntegrations: 'Nenhuma integração encontrada',
    noAgentsInIntegration: 'Nenhum agent nesta integração',
    allAgentsAdded: 'Todos os agents já foram adicionados',
    agentAlreadyAdded: 'Já adicionado',
    cancel: 'Cancelar',
    save: 'Salvar',
    noAgents: 'Nenhum agent adicionado',
    noTopics: 'Nenhum tópico definido',
    noLanguages: 'Nenhum idioma definido',
    noWelcomeMessage: 'Nenhuma mensagem definida',
};
const message_en = {
    loading: 'Loading...',
    threadName: 'Thread name',
    visibility: 'Visibility',
    visibilityPublic: 'Public',
    visibilityPrivate: 'Private',
    visibilityCompany: 'Company',
    visibilityTeam: 'Team',
    status: 'Status',
    statusActive: 'Active',
    statusArchived: 'Archived',
    statusDeleted: 'Deleted',
    statusDeleting: 'Deleting',
    topicsDefault: 'Topics',
    welcomeMessage: 'Welcome message',
    remove: 'Remove',
    disable: 'Disable',
    active: 'Active',
    group: 'Group',
    users: 'Users',
    bots: 'Bots',
    agents: 'Agents',
    languages: 'Automatic translation in multiple languages',
    details: 'Details',
    languagesHint: 'For each message, the language will be detected and translated into the languages above. Leave blank to avoid spending credits.',
    validateFormError: 'Please fill in all required fields.',
    userError: 'Invalid user ID.',
    btnSave: 'Save changes',
    btnSaveAgent: 'Add agent',
    btnCancel: 'Cancel',
    btnEdit: 'Edit',
    successSaving: 'Saved successfully',
    noChanges: 'No changes.',
    addParticipant: 'Add Participant',
    addAgent: 'Add Agent',
    labelUserId: 'User id or name',
    labelPermission: 'Auth:',
    errorFieldsAddParticipant: 'Fill in all fields!',
    errorRemoveUser: 'Error on remove user',
    errorRemoveAgent: 'Error on remove agent',
    successAddAgent: 'Agent added successfully',
    successRemoveAgent: 'Agent removed successfully',
    threadDetails: 'Thread details',
    changeAvatar: 'Change avatar',
    errorSaveThreadDeletStatus: 'The thread cannot be changed when status is "deleting"',
    threadNameInvalid: 'The name must start with #',
    selectIntegration: 'Select integration',
    selectAgent: 'Select agent',
    noIntegrations: 'No integrations found',
    noAgentsInIntegration: 'No agents in this integration',
    allAgentsAdded: 'All agents already added',
    agentAlreadyAdded: 'Already added',
    cancel: 'Cancel',
    save: 'Save',
    noAgents: 'No agents added',
    noTopics: 'No topics defined',
    noLanguages: 'No languages defined',
    noWelcomeMessage: 'No message defined',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesThreadDetails = class CollabMessagesThreadDetails extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-thread-details-102025{display:block;overflow:auto;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);padding:1rem}@keyframes spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}collab-messages-thread-details-102025 .saving-ok{color:var(--success-color);font-size:var(--font-size-12)}collab-messages-thread-details-102025 .saving-error{color:var(--error-color);font-size:var(--font-size-12);display:flex;align-items:center}collab-messages-thread-details-102025 .saving-error svg{margin-right:.3rem;width:12px;fill:var(--error-color)}collab-messages-thread-details-102025 .content{display:flex;flex-direction:column;gap:1rem}collab-messages-thread-details-102025 .section{padding:1.4rem .75rem;border-radius:10px;box-shadow:#e7e3e3 0 1px 4px;background-color:var(--bg-primary-color-darker)}collab-messages-thread-details-102025 .section .details-header h3{display:flex;align-items:center;gap:.5rem;margin-bottom:.75rem;margin-block-start:0;padding-bottom:.4rem;border-bottom:1px solid #d2d2d2;width:100%}collab-messages-thread-details-102025 .section .details-header h3 svg{fill:currentColor;width:20px;height:20px}collab-messages-thread-details-102025 .bots button.remove,collab-messages-thread-details-102025 .users button.remove,collab-messages-thread-details-102025 .agents button.remove{margin-left:auto;padding:.25rem .5rem;background:var(--error-color);color:white;border:none;border-radius:4px;cursor:pointer;font-size:var(--font-size-12)}collab-messages-thread-details-102025 .bots button.remove:hover,collab-messages-thread-details-102025 .users button.remove:hover,collab-messages-thread-details-102025 .agents button.remove:hover{background:var(--error-color-hover)}collab-messages-thread-details-102025 .bots button.activate,collab-messages-thread-details-102025 .users button.activate,collab-messages-thread-details-102025 .agents button.activate{margin-left:auto;padding:.25rem .5rem;background:var(--info-color);color:white;border:none;border-radius:4px;cursor:pointer;font-size:var(--font-size-12)}collab-messages-thread-details-102025 .bots button.activate:hover,collab-messages-thread-details-102025 .users button.activate:hover,collab-messages-thread-details-102025 .agents button.activate:hover{background:var(--info-color-hover)}collab-messages-thread-details-102025 .bots button.edit,collab-messages-thread-details-102025 .users button.edit,collab-messages-thread-details-102025 .agents button.edit{padding:.25rem .5rem;background:var(--info-color);color:white;border:none;border-radius:4px;cursor:pointer;display:flex;align-items:center;justify-content:center}collab-messages-thread-details-102025 .bots button.edit svg,collab-messages-thread-details-102025 .users button.edit svg,collab-messages-thread-details-102025 .agents button.edit svg{width:14px;height:14px;fill:white}collab-messages-thread-details-102025 .bots button.edit:hover,collab-messages-thread-details-102025 .users button.edit:hover,collab-messages-thread-details-102025 .agents button.edit:hover{background:var(--info-color-hover)}collab-messages-thread-details-102025 .bots button.loading,collab-messages-thread-details-102025 .users button.loading,collab-messages-thread-details-102025 .agents button.loading{position:relative;pointer-events:none}collab-messages-thread-details-102025 .bots button.loading::before,collab-messages-thread-details-102025 .users button.loading::before,collab-messages-thread-details-102025 .agents button.loading::before{content:'';display:inline-block;width:6px;height:6px;margin-right:8px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite;vertical-align:middle}collab-messages-thread-details-102025 .users .details-add-participant{cursor:pointer;margin-top:1rem}collab-messages-thread-details-102025 .users .details-add-participant>.add-participant{margin-top:.5rem;padding:1rem;border-top:1px solid var(--grey-color);border-radius:8px}collab-messages-thread-details-102025 .users img,collab-messages-thread-details-102025 .users svg{border-radius:50%}collab-messages-thread-details-102025 .agents h3{margin-bottom:.5rem;display:flex;align-items:center;gap:.5rem}collab-messages-thread-details-102025 .agents ul{list-style:none;padding:0;margin:0}collab-messages-thread-details-102025 .agents li{display:flex;align-items:center;gap:.5rem;margin-bottom:.5rem;padding:.5rem;border-radius:6px;background:var(--bg-secondary-color-lighter)}collab-messages-thread-details-102025 .agents li.empty-list{background:transparent;color:var(--text-primary-color-lighter);font-style:italic}collab-messages-thread-details-102025 .agents li img{border-radius:50%;object-fit:cover}collab-messages-thread-details-102025 .agents li .agent-info{display:flex;flex-direction:column;flex:1;min-width:0}collab-messages-thread-details-102025 .agents li .agent-info .agent-name{font-weight:var(--font-weight-bold);color:var(--text-primary-color)}collab-messages-thread-details-102025 .agents li .agent-info .agent-integration{color:var(--text-primary-color-lighter);font-size:var(--font-size-12)}collab-messages-thread-details-102025 .agents li .agent-actions{display:flex;gap:.5rem;margin-left:auto}collab-messages-thread-details-102025 .agents .details-add-agent{cursor:pointer;margin-top:1rem}collab-messages-thread-details-102025 .agents .agent-form-content{margin-top:.5rem;padding:1rem;border-top:1px solid var(--grey-color);border-radius:8px}collab-messages-thread-details-102025 .agents .agent-form-content label{display:block;margin-bottom:1rem;font-size:var(--font-size-12);color:var(--text-primary-color-lighter)}collab-messages-thread-details-102025 .agents .agent-form-content label select{width:100%;display:block;margin-top:.25rem;padding:.5rem;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}collab-messages-thread-details-102025 .agents .agent-form-content label select:focus{border-color:var(--info-color);box-shadow:0 0 0 2px rgba(10,109,201,0.1)}collab-messages-thread-details-102025 .agents .agent-form-content .agent-preview{display:flex;align-items:center;gap:1rem;padding:1rem;margin-bottom:1rem;background:var(--bg-primary-color);border-radius:8px;border:1px solid var(--grey-color-light)}collab-messages-thread-details-102025 .agents .agent-form-content .agent-preview img{border-radius:50%;object-fit:cover}collab-messages-thread-details-102025 .agents .agent-form-content .agent-preview div{display:flex;flex-direction:column}collab-messages-thread-details-102025 .agents .agent-form-content .agent-preview div strong{color:var(--text-primary-color);font-size:var(--font-size-16)}collab-messages-thread-details-102025 .agents .agent-form-content .agent-preview div small{color:var(--text-primary-color-lighter);font-size:var(--font-size-12)}collab-messages-thread-details-102025 .form-actions{display:flex;justify-content:flex-end;gap:.5rem}collab-messages-thread-details-102025 .form-actions button{padding:.5rem 1rem;border:none;border-radius:6px;cursor:pointer;font-size:var(--font-size-12);font-weight:var(--font-weight-bold);display:flex;align-items:center;gap:.25rem}collab-messages-thread-details-102025 .form-actions button .loader{display:inline-block;width:12px;height:12px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}collab-messages-thread-details-102025 .form-actions .btn-save{background:var(--info-color);color:white}collab-messages-thread-details-102025 .form-actions .btn-save svg{fill:currentColor}collab-messages-thread-details-102025 .form-actions .btn-save:hover{background:var(--info-color-hover)}collab-messages-thread-details-102025 .form-actions .btn-save:disabled{background:var(--info-color-disabled);cursor:not-allowed}collab-messages-thread-details-102025 .details small{font-size:var(--font-size-12)}collab-messages-thread-details-102025 .details .details-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem}collab-messages-thread-details-102025 .details .details-header h3{margin:0}collab-messages-thread-details-102025 .details .details-header .btn-edit{padding:.4rem .6rem;background:var(--bg-secondary-color-lighter);border:1px solid var(--grey-color);border-radius:6px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .2s ease}collab-messages-thread-details-102025 .details .details-header .btn-edit svg{width:16px;height:16px;fill:var(--text-primary-color-lighter)}collab-messages-thread-details-102025 .details .details-header .btn-edit:hover{background:var(--bg-secondary-color);border-color:var(--grey-color-dark)}collab-messages-thread-details-102025 .details .details-header .btn-edit:hover svg{fill:var(--text-primary-color)}collab-messages-thread-details-102025 .details-view h3 button{margin-left:auto}collab-messages-thread-details-102025 .details-view .details-summary{display:flex;gap:1rem}collab-messages-thread-details-102025 .details-view .details-summary .summary-avatar img{border-radius:50%;object-fit:cover;border:2px solid var(--grey-color-light)}collab-messages-thread-details-102025 .details-view .details-summary .summary-grid{flex:1;display:grid;gap:1rem 1.5rem}@media (max-width:544px){collab-messages-thread-details-102025 .details-view .details-summary .summary-grid{grid-template-columns:1fr}}collab-messages-thread-details-102025 .details-view .details-summary .summary-item{display:flex;flex-direction:column;gap:.25rem}collab-messages-thread-details-102025 .details-view .details-summary .summary-item.summary-item-full{grid-column:1 / -1}collab-messages-thread-details-102025 .details-view .details-summary .summary-item .summary-label{font-size:var(--font-size-12);color:var(--text-primary-color-lighter);font-weight:var(--font-weight-bold);text-transform:uppercase;letter-spacing:.5px}collab-messages-thread-details-102025 .details-view .details-summary .summary-item .summary-value{font-size:var(--font-size-12);color:var(--text-primary-color)}collab-messages-thread-details-102025 .details-view .details-summary .summary-item .summary-value .tags-inline{display:inline;word-break:break-word}collab-messages-thread-details-102025 .details-view .details-summary .summary-item .summary-value .empty-value{color:var(--text-primary-color-lighter);font-style:italic;font-size:var(--font-size-12)}collab-messages-thread-details-102025 .details-view .details-summary .summary-item .summary-value .welcome-preview{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;font-size:var(--font-size-12);color:var(--text-primary-color-lighter);line-height:1.4}collab-messages-thread-details-102025 .details-view .details-summary .summary-item .status-badge{display:inline-block;padding:.15rem .5rem;border-radius:12px;font-size:var(--font-size-12);font-weight:var(--font-weight-bold);width:fit-content}collab-messages-thread-details-102025 .details-view .details-summary .summary-item .status-badge.status-active{background:rgba(82,196,26,0.15);color:var(--success-color-focus)}collab-messages-thread-details-102025 .details-view .details-summary .summary-item .status-badge.status-archived{background:rgba(250,173,20,0.15);color:var(--warning-color-focus)}collab-messages-thread-details-102025 .details-view .details-summary .summary-item .status-badge.status-deleted{background:rgba(255,77,79,0.15);color:var(--error-color-focus)}collab-messages-thread-details-102025 .details-view .details-summary .summary-item .status-badge.status-deleting{background:rgba(255,77,79,0.15);color:var(--error-color)}collab-messages-thread-details-102025 .details-edit>label{display:block;margin-bottom:.4rem;font-size:var(--font-size-12);color:var(--text-primary-color-lighter)}collab-messages-thread-details-102025 .details-edit>label input,collab-messages-thread-details-102025 .details-edit>label select,collab-messages-thread-details-102025 .details-edit>label textarea{width:100%;display:block;font-size:1rem;line-height:1.5;height:33px;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}collab-messages-thread-details-102025 .details-edit>label input[disabled],collab-messages-thread-details-102025 .details-edit>label select[disabled],collab-messages-thread-details-102025 .details-edit>label textarea[disabled]{background-color:var(--grey-color-light)}collab-messages-thread-details-102025 .details-edit collab-messages-input-tag-102025{display:block;margin-bottom:.4rem}collab-messages-thread-details-102025 .details-edit small{font-style:italic}collab-messages-thread-details-102025 .details-edit input:invalid{border-color:var(--error-color)}collab-messages-thread-details-102025 .details-edit input:invalid+.field-thread-name-error{display:block;color:var(--error-color);font-size:.9em}collab-messages-thread-details-102025 .details-edit .field-thread-name-error{display:none}collab-messages-thread-details-102025 .details-edit textarea{width:100%;display:block;font-size:1rem;line-height:1.5;height:80px;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none;resize:vertical}collab-messages-thread-details-102025 .details-edit textarea[disabled]{background-color:var(--grey-color-light)}collab-messages-thread-details-102025 .details-edit .actions{display:flex;flex-direction:column;align-items:flex-end;gap:.5rem;margin-top:1rem;padding-top:1rem;border-top:1px solid var(--grey-color-light)}collab-messages-thread-details-102025 h2,collab-messages-thread-details-102025 h3{margin-bottom:.5rem}collab-messages-thread-details-102025 ul{list-style:none;padding:0}collab-messages-thread-details-102025 li{display:flex;align-items:center;gap:.5rem;margin-bottom:.5rem}`);
        this.msg = messages['en'];
        this.userId = '20250417120841.1000';
        this.threadDetails = { "thread": {} };
        this.labelOk = '';
        this.labelError = '';
        this.labelErrorRemoveUser = '';
        this.labelErrorRemoveBoot = '';
        this.labelErrorAgent = '';
        this.labelOkAgent = '';
        this.isLoading = false;
        this.isDirectMessage = false;
        this.isChannel = false;
        this.isFileChannel = false;
        // Details edit mode
        this.isEditingDetails = false;
        // Agent states
        this.showAgentForm = false;
        this.integrations = [];
        this.selectedIntegrationId = '';
        this.selectedAgentId = '';
        this.isLoadingAgents = false;
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        this.editedThreadDetails = JSON.parse(JSON.stringify(this.threadDetails));
        this.loadIntegrations();
    }
    async loadIntegrations() {
        try {
            this.integrations = await loadOpenClawIntegrations();
        }
        catch (err) {
            console.error('Error loading integrations:', err.message);
            this.integrations = [];
        }
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('threadDetails') && this.threadDetails && this.userId) {
            for (const user of this.threadDetails?.thread.users || []) {
                const find = this.threadDetails?.users.find((u) => u.userId === user.userId);
                if (!find) {
                    const resUser = await getUser(user.userId);
                    if (resUser) {
                        this.threadDetails.users.push(resUser);
                        if (this.editedThreadDetails)
                            this.editedThreadDetails.users = [...this.threadDetails.users];
                        this.requestUpdate();
                    }
                    else {
                        const data = await this.getThreadInfo(this.threadDetails.thread.threadId, this.userId);
                        this.threadDetails = data;
                        this.editedThreadDetails = JSON.parse(JSON.stringify(this.threadDetails));
                    }
                }
            }
        }
    }
    getAddedAgentIds() {
        const integrations = this.editedThreadDetails?.thread.integrations || [];
        const addedIds = new Set();
        for (const integration of integrations) {
            if (integration.config?.agentId && integration.status === 'active') {
                addedIds.add(integration.config.agentId);
            }
        }
        return addedIds;
    }
    getAvailableAgents(integrationId) {
        const integration = this.integrations.find(i => i.id === integrationId);
        if (!integration)
            return [];
        const addedIds = this.getAddedAgentIds();
        return integration.agents.map(agent => ({
            agent,
            isAdded: addedIds.has(agent.id)
        }));
    }
    getVisibilityLabel(visibility) {
        switch (visibility) {
            case 'public': return this.msg.visibilityPublic;
            case 'private': return this.msg.visibilityPrivate;
            case 'company': return this.msg.visibilityCompany;
            case 'team': return this.msg.visibilityTeam;
            default: return visibility || '-';
        }
    }
    getStatusLabel(status) {
        switch (status) {
            case 'active': return this.msg.statusActive;
            case 'archived': return this.msg.statusArchived;
            case 'deleted': return this.msg.statusDeleted;
            case 'deleting': return this.msg.statusDeleting;
            default: return status || '-';
        }
    }
    enterEditMode() {
        this.editedThreadDetails = JSON.parse(JSON.stringify(this.threadDetails));
        this.isEditingDetails = true;
        this.labelOk = '';
        this.labelError = '';
    }
    cancelEditMode() {
        this.editedThreadDetails = JSON.parse(JSON.stringify(this.threadDetails));
        this.isEditingDetails = false;
        this.labelOk = '';
        this.labelError = '';
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.isDirectMessage = this.threadDetails?.thread?.name?.startsWith('@');
        this.isChannel = this.threadDetails?.thread?.name?.startsWith('#');
        this.isFileChannel = this.threadDetails?.thread?.name?.startsWith('_');
        return html `
        <div class="content">
            ${this.isEditingDetails ? this.renderDetailsEditMode() : this.renderDetailsViewMode()}
            ${this.renderUsers()}
            ${this.renderAgents()}
            ${this.renderBots()}
        </div>
        `;
    }
    renderDetailsViewMode() {
        const thread = this.threadDetails?.thread;
        const topics = thread?.defaultTopics?.filter(t => t && t.trim()) || [];
        const languages = thread?.languages?.filter(l => l && l.trim()) || [];
        return html `
        <div class="section details details-view">
            <div class="details-header">
                <h3>${this.msg.details}
                    <button class="btn-edit" @click=${this.enterEditMode} title="${this.msg.btnEdit}">
                    ${collab_edit}
                    </button>
                </h3>
            
            </div>

            <div class="details-summary">
                ${this.isChannel ? html `
                    <div class="summary-avatar">
                        <img src="${thread?.avatar_url || generateDefaultAvatar(thread?.name || '')}" 
                             alt="${thread?.name}" 
                             width="48" 
                             height="48" />
                    </div>
                ` : ''}

                <div class="summary-grid">
                    <div class="summary-item">
                        <span class="summary-label">${this.msg.threadName}</span>
                        <span class="summary-value">${thread?.name || '-'}</span>
                    </div>

                    <div class="summary-item">
                        <span class="summary-label">${this.msg.status}</span>
                        <span class="summary-value status-badge status-${thread?.status}">
                            ${this.getStatusLabel(thread?.status)}
                        </span>
                    </div>

                    <div class="summary-item">
                        <span class="summary-label">${this.msg.visibility}</span>
                        <span class="summary-value">${this.getVisibilityLabel(thread?.visibility)}</span>
                    </div>

                    <div class="summary-item">
                        <span class="summary-label">${this.msg.topicsDefault}</span>
                        <span class="summary-value">
                            ${topics.length > 0
            ? html `<span class="tags-inline">${topics.join(', ')}</span>`
            : html `<span class="empty-value">${this.msg.noTopics}</span>`}
                        </span>
                    </div>

                    ${this.isChannel ? html `
                        <div class="summary-item summary-item-full">
                            <span class="summary-label">${this.msg.welcomeMessage}</span>
                            <span class="summary-value">
                                ${thread?.welcomeMessage
            ? html `<span class="welcome-preview">${thread.welcomeMessage}</span>`
            : html `<span class="empty-value">${this.msg.noWelcomeMessage}</span>`}
                            </span>
                        </div>
                    ` : ''}

                    <div class="summary-item">
                        <span class="summary-label">${this.msg.languages}</span>
                        <span class="summary-value">
                            ${languages.length > 0
            ? html `<span class="tags-inline">${languages.join(', ')}</span>`
            : html `<span class="empty-value">${this.msg.noLanguages}</span>`}
                        </span>
                    </div>
                </div>
            </div>
        </div>
        `;
    }
    renderDetailsEditMode() {
        return html `
        <div class="section details details-edit">
            <div class="details-header">
                <h3>${this.msg.details}: ${this.threadDetails?.thread.threadId}</h3>
            </div>

            ${this.isChannel ? html `
                <collab-messages-change-avatar-102025
                    ?disabled
                    userId=${this.userId}
                    threadId=${this.threadDetails?.thread.threadId}
                    value=${ifDefined(this.editedThreadDetails?.thread.avatar_url)}
                    nameValue=${ifDefined(this.editedThreadDetails?.thread.name)}
                    @value-changed=${(e) => {
            if (this.editedThreadDetails) {
                this.editedThreadDetails.thread.avatar_url = e.detail;
            }
        }}
                ></collab-messages-change-avatar-102025>
            ` : ''}

            <label>${this.msg.threadName}
                <input type="text" required
                    .value=${this.editedThreadDetails?.thread.name}
                    pattern=${ifDefined(this.isChannel ? "^#.*" : undefined)}
                    ?disabled=${this.isDirectMessage || this.isFileChannel}
                    @input=${(e) => { if (this.editedThreadDetails && !this.isChannel)
            this.editedThreadDetails.thread.name = e.target.value; }}
                >
                <span class="field-thread-name-error">${this.msg.threadNameInvalid}</span>
            </label>

            <label>${this.msg.status}
                <select 
                    name="status" 
                    required
                    .disabled=${['deleting'].includes(this.editedThreadDetails?.thread.status || '')}
                    .value=${this.editedThreadDetails?.thread.status}
                    @change=${(e) => {
            if (this.editedThreadDetails) {
                this.editedThreadDetails.thread.status =
                    e.target.value;
            }
        }}
                >
                    <option value="active">${this.msg.statusActive}</option>
                    <option value="archived">${this.msg.statusArchived}</option>
                    <option 
                        value="deleting" 
                        ?hidden=${this.editedThreadDetails?.thread.status !== 'deleting'}
                    >
                        ${this.msg.statusDeleting}
                    </option>
                    <option value="deleted">${this.msg.statusDeleted}</option>
                </select>
            </label>

            <label>${this.msg.visibility}
                <select name="visibility" required
                    ?disabled=${this.isDirectMessage || this.isFileChannel}
                    .value=${this.editedThreadDetails?.thread.visibility}
                    @change=${(e) => { if (this.editedThreadDetails && this.isChannel)
            this.editedThreadDetails.thread.visibility = e.target.value; }}>
                    <option value="public">${this.msg.visibilityPublic}</option>
                    <option value="private">${this.msg.visibilityPrivate}</option>
                    <option value="company">${this.msg.visibilityCompany}</option>
                    <option value="team">${this.msg.visibilityTeam}</option>
                </select>
            </label>
            
            <label>${this.msg.topicsDefault}</label>
            <collab-messages-input-tag-102025 
                pattern="^\\+[a-zA-Z0-9-]+$"
                .value=${this.editedThreadDetails?.thread.defaultTopics?.join(',')}
                placeholder="+topic"
                .onValueChanged=${(value) => {
            if (this.editedThreadDetails) {
                this.editedThreadDetails.thread.defaultTopics = value.split(',');
            }
        }}
                id="topicsInput"
            ></collab-messages-input-tag-102025>

            ${this.isChannel ? html `
                <label>${this.msg.welcomeMessage}</label>
                <textarea 
                    name="welcomemessage"
                    rows="5" 
                    .value=${this.editedThreadDetails?.thread?.welcomeMessage || ''}
                    @input=${(e) => { if (this.editedThreadDetails && this.isChannel)
            this.editedThreadDetails.thread.welcomeMessage = e.target.value; }}
                ></textarea>  
            ` : ''}
                
            <label>${this.msg.languages}</label>
            <collab-messages-input-tag-102025 
                pattern="^[a-z]{2}$|^[a-z]{2}-[A-Z]{2}$"
                .value=${this.editedThreadDetails?.thread?.languages?.join(',')}
                .onValueChanged=${(value) => { if (this.editedThreadDetails)
            this.editedThreadDetails.thread.languages = value.split(','); }}
                id="languageInput"
            ></collab-messages-input-tag-102025>
            <small>${this.msg.languagesHint}</small>
    
            <div class="actions">
                <div class="form-actions">
                    <button class="btn-cancel" @click=${this.cancelEditMode}>
                        ${this.msg.btnCancel}
                    </button>
                    <button class="btn-save" @click=${this.saveChanges} ?disabled=${this.isLoading}>
                        ${this.isLoading ? html `<span class="loader"></span>` : html `${collab_floppy_disk} ${this.msg.btnSave}`}
                    </button>
                </div>
                ${this.labelOk ? html `<small class="saving-ok">${this.labelOk}</small>` : ''}
                ${this.labelError ? html `<small class="saving-error">${this.labelError}</small>` : ''}   
            </div>
        </div>
        `;
    }
    renderUsers() {
        const users = this.editedThreadDetails?.users || [];
        const isDm = this.threadDetails?.thread?.name?.startsWith('@');
        return html `
        <div class="section users">
            <div class="details-header">
                <h3>${this.msg.users}</h3>
            </div>
            <ul>
                ${repeat(this.editedThreadDetails?.thread.users || [], ((user) => user.userId), ((user) => {
            const details = users.find((us) => us.userId === user.userId);
            return html `
                                <li>
                                    <img src="${details?.avatar_url}" alt="${details?.name}" width="32" height="32" />
                                    <small>${details?.name}<b>(${user.auth})</b> - ${user.userId}</small>

                                    ${!isDm
                ? html `<button class="remove" @click="${(e) => this.removeUser(e, user.userId)}">${this.msg.remove}</button>`
                : ''}
                                    
                                </li>
                    `;
        }))}
            </ul>
            ${this.labelErrorRemoveUser ? html `<small class="saving-error">${collab_triangle_exclamation} ${this.labelErrorRemoveUser}<small>` : ''}   

            ${!isDm
            ? html `<details class="details-add-participant">
                            <summary>${this.msg.addParticipant}</summary>
                            <div class="add-participant">
                                <collab-messages-add-participant-102025
                                    userId=${this.userId} 
                                    .actualThread=${{ ...this.threadDetails }}
                                    @add-participant=${this.onAddParticipant}
                                    
                                    ></collab-messages-add-participant-102025>
                            </div>
                        </details>`
            : ''}
            
        </div>
        `;
    }
    renderAgents() {
        const threadIntegrations = this.editedThreadDetails?.thread.integrations || [];
        return html `
    <div class="section agents">
        <div class="details-header">
            <h3>${this.msg.agents}</h3>
        </div>
    
        <ul>
            ${threadIntegrations.length === 0
            ? html `<li class="empty-list"><small>${this.msg.noAgents}</small></li>`
            : repeat(threadIntegrations, ((integration) => integration.integrationId), ((integration) => {
                const agentInfo = this.findAgentInfo(integration.config?.agentId || '');
                const agentName = agentInfo?.agent?.name || integration.config?.agentId || 'Unknown';
                const integrationName = agentInfo?.integrationName || 'OpenClaw';
                const avatarUrl = agentInfo?.agent?.avatarUrl || this.generateAgentAvatar(agentName);
                return html `
                            <li>
                                <img src="${avatarUrl}" 
                                     alt="${agentName}" 
                                     width="32" 
                                     height="32" />
                                <div class="agent-info">
                                    <small class="agent-name">${agentName}</small>
                                    <small class="agent-integration">${integrationName} <b>(${integration.status})</b></small>
                                </div>
                                <div class="agent-actions">
                                    <button
                                        class=${integration?.status === 'active' ? 'remove' : 'activate'}
                                        @click=${(e) => this.updateStatusAgent(e, integration.integrationId, integration.status === 'active' ? 'disabled' : 'active')}
                                        >
                                        ${integration?.status === 'active' ? this.msg.disable : this.msg.active}
                                        </button>
                                </div>
                            </li>
                        `;
            }))}
        </ul>
        
        ${this.labelErrorAgent ? html `<small class="saving-error">${collab_triangle_exclamation} ${this.labelErrorAgent}</small>` : ''}
        ${this.labelOkAgent ? html `<small class="saving-ok">${this.labelOkAgent}</small>` : ''}
        
        <details class="details-add-agent" ?open=${this.showAgentForm}>
            <summary @click=${(e) => {
            const details = e.target.closest('details');
            if (details) {
                e.preventDefault();
                this.showAgentForm = !this.showAgentForm;
                if (this.showAgentForm) {
                    this.openAgentForm();
                }
                else {
                    this.closeAgentForm();
                }
            }
        }}>${this.msg.addAgent}</summary>
            <div class="agent-form-content">
                ${this.renderAgentFormContent()}
            </div>
        </details>
    </div>
    `;
    }
    renderAgentFormContent() {
        const availableAgents = this.selectedIntegrationId
            ? this.getAvailableAgents(this.selectedIntegrationId)
            : [];
        const threadIntegrations = this.threadDetails?.thread?.integrations || [];
        const hasAvailableAgents = availableAgents.some(agent => !threadIntegrations.some(ti => ti.config.agentId === agent.agent.id));
        return html `
        <label>${this.msg.selectIntegration}
            <select 
                .value=${this.selectedIntegrationId}
                @change=${(e) => {
            this.selectedIntegrationId = e.target.value;
            this.selectedAgentId = '';
        }}
            >
                <option value="">${this.msg.selectIntegration}</option>
                ${this.integrations.length === 0
            ? html `<option value="" disabled>${this.msg.noIntegrations}</option>`
            : this.integrations.map(integration => html `
                        <option value="${integration.id}">${integration.name}</option>
                    `)}
            </select>
        </label>

        ${this.selectedIntegrationId ? html `
            <label>${this.msg.selectAgent}
                <select 
                    .value=${this.selectedAgentId}
                    @change=${(e) => {
            this.selectedAgentId = e.target.value;
        }}
                >
                    <option value="">${this.msg.selectAgent}</option>
                    ${availableAgents.length === 0
            ? html `<option value="" disabled>${this.msg.noAgentsInIntegration}</option>`
            : !hasAvailableAgents
                ? html `<option value="" disabled>${this.msg.allAgentsAdded}</option>`
                : availableAgents.map(({ agent, isAdded }) => html `
                                <option 
                                    value="${agent.id}" 
                                    ?disabled=${isAdded}
                                >
                                    ${agent.name}${isAdded ? ` (${this.msg.agentAlreadyAdded})` : ''}
                                </option>
                            `)}
                </select>
            </label>

            ${this.selectedAgentId ? html `
                <div class="agent-preview">
                    ${(() => {
            const agentData = availableAgents.find(a => a.agent.id === this.selectedAgentId);
            if (!agentData)
                return '';
            const { agent } = agentData;
            return html `
                            <img src="${agent.avatarUrl || this.generateAgentAvatar(agent.name)}" 
                                 alt="${agent.name}" 
                                 width="48" 
                                 height="48" />
                            <div>
                                <strong>${agent.name}</strong>
                                <small>ID: ${agent.senderId}</small>
                            </div>
                        `;
        })()}
                </div>
            ` : ''}
        ` : ''}

        <div class="form-actions">
            <button 
                class="btn-save" 
                @click=${this.saveAgent}
                ?disabled=${!this.selectedIntegrationId || !this.selectedAgentId || this.isLoadingAgents}
            >
                ${this.isLoadingAgents ? html `<span class="loader"></span>` : html `${collab_floppy_disk} ${this.msg.btnSaveAgent}`}
            </button>
        </div>
    `;
    }
    findAgentInfo(agentId) {
        for (const integration of this.integrations) {
            const agent = integration.agents.find(a => a.id === agentId);
            if (agent) {
                return { agent, integrationName: integration.name };
            }
        }
        return null;
    }
    generateAgentAvatar(name) {
        const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E9'];
        const colorIndex = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0) % colors.length;
        const bgColor = colors[colorIndex];
        const initials = name.split(' ').map(w => w[0]).join('').toUpperCase().slice(0, 2);
        return `data:image/svg+xml,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><rect width="80" height="80" fill="${bgColor}"/><text x="40" y="40" font-family="Arial" font-size="28" fill="white" text-anchor="middle" dy=".35em">${initials}</text></svg>`)}`;
    }
    openAgentForm() {
        this.showAgentForm = true;
        this.selectedIntegrationId = '';
        this.selectedAgentId = '';
        this.labelErrorAgent = '';
        this.labelOkAgent = '';
    }
    closeAgentForm() {
        this.showAgentForm = false;
        this.selectedIntegrationId = '';
        this.selectedAgentId = '';
    }
    async saveAgent() {
        this.labelErrorAgent = '';
        this.labelOkAgent = '';
        if (!this.selectedIntegrationId || !this.selectedAgentId)
            return;
        if (!this.editedThreadDetails || !this.threadDetails || !this.userId)
            return;
        const integration = this.integrations.find(i => i.id === this.selectedIntegrationId);
        const agent = integration?.agents.find(a => a.id === this.selectedAgentId);
        if (!integration || !agent)
            return;
        const addedIds = this.getAddedAgentIds();
        if (addedIds.has(agent.id)) {
            this.labelErrorAgent = this.msg.agentAlreadyAdded;
            return;
        }
        this.isLoadingAgents = true;
        try {
            const inboundToken = generateUUIDv7();
            const integrationId = generateUUIDv7();
            const threadIntegration = {
                integrationId,
                type: 'openclaw',
                status: 'active',
                config: {
                    url: integration.url,
                    bearerToken: integration.bearerToken,
                    inboundToken,
                    agentId: agent.id,
                    sessionId: undefined
                },
                triggers: []
            };
            const result = await msgAddOrUpdateThreadIntegration({
                threadId: this.threadDetails.thread.threadId,
                userId: this.userId,
                ...threadIntegration
            });
            if (!result.success || !result.response?.thread) {
                throw new Error(result.error || 'Failed to add agent to thread.');
            }
            const thread = result.response.thread;
            this.editedThreadDetails.thread = { ...thread };
            const threadCache = await updateThread(thread.threadId, thread);
            notifyThreadChange(threadCache);
            this.labelOkAgent =
                this.msg.successAddAgent || 'Agent added successfully.';
            this.closeAgentForm();
            this.requestUpdate();
        }
        catch (err) {
            this.labelErrorAgent =
                err?.message || 'An unexpected error occurred while adding the agent.';
        }
        finally {
            this.isLoadingAgents = false;
        }
    }
    async updateStatusAgent(e, integrationId, status) {
        this.labelErrorAgent = '';
        this.labelOkAgent = '';
        if (!this.editedThreadDetails || !this.threadDetails || !this.userId)
            return;
        if (['deleting'].includes(this.editedThreadDetails.thread.status || '')) {
            this.labelErrorAgent = this.msg.errorSaveThreadDeletStatus;
            return;
        }
        const button = e.target.closest('button');
        try {
            button?.classList.add('loading');
            const currentIntegrations = this.editedThreadDetails.thread.integrations || [];
            const integrationToUpdate = currentIntegrations.find(i => i.integrationId === integrationId);
            if (!integrationToUpdate) {
                throw new Error('Integration not found');
            }
            const updatedIntegration = {
                ...integrationToUpdate,
                status
            };
            const result = await msgAddOrUpdateThreadIntegration({
                threadId: this.threadDetails.thread.threadId,
                userId: this.userId,
                ...updatedIntegration
            });
            if (!result.success || !result.response?.thread) {
                throw new Error(result.error || 'Failed to update agent status.');
            }
            const thread = result.response.thread;
            this.editedThreadDetails.thread = { ...thread };
            const threadCache = await updateThread(thread.threadId, thread);
            notifyThreadChange(threadCache);
            this.labelOkAgent =
                this.msg.successRemoveAgent ||
                    'Agent status updated successfully.';
            this.requestUpdate();
        }
        catch (err) {
            this.labelErrorAgent =
                ('Failed to update agent status') +
                    ': ' +
                    (err?.message || 'Unexpected error');
        }
        finally {
            button?.classList.remove('loading');
        }
    }
    renderBots() {
        return html `
        <div class="section bots">
            <div class="details-header">
                <h3>${this.msg.bots}</h3>
            </div>
            <ul>
                ${repeat(this.editedThreadDetails?.thread.bots || [], ((bot) => bot.botId), ((bot) => {
            return html `
                        <li>
                            <small>${bot?.botId}<b>(${bot.status})</b></small>
            
                            ${bot.status !== "disabled"
                ? html `<button class="remove" @click="${(e) => this.removeBot(e, bot.botId)}">${this.msg.disable}</button>`
                : ""}                            
                        </li>
                    `;
        }))}
            </ul>
            ${this.labelErrorRemoveBoot ? html `<small class="saving-error">${collab_triangle_exclamation} ${this.labelErrorRemoveBoot}<small>` : ''}   

        </div>
        `;
    }
    async removeUser(e, userId) {
        this.labelErrorRemoveUser = '';
        if (!this.threadDetails || !this.userId || !this.editedThreadDetails)
            return;
        if (['deleting'].includes(this.editedThreadDetails?.thread.status || '')) {
            this.labelErrorRemoveUser = this.msg.errorSaveThreadDeletStatus;
            return;
        }
        const button = e.target.closest('button');
        try {
            button?.classList.add('loading');
            const newThread = await this.removeUserFromThread(this.threadDetails.thread.threadId, this.userId, userId);
            if (newThread) {
                this.threadDetails = JSON.parse(JSON.stringify(this.editedThreadDetails));
                this.editedThreadDetails.thread = { ...newThread };
                const threadCache = await updateThread(newThread.threadId, newThread);
                notifyThreadChange(threadCache);
            }
        }
        catch (err) {
            this.labelErrorRemoveUser = this.msg.errorRemoveUser + ':' + err.message;
        }
        finally {
            button?.classList.remove('loading');
        }
    }
    async removeBot(e, botName) {
        this.labelErrorRemoveBoot = '';
        if (!this.threadDetails || !this.userId || !this.editedThreadDetails)
            return;
        if (['deleting'].includes(this.editedThreadDetails?.thread.status || '')) {
            this.labelErrorRemoveBoot = this.msg.errorSaveThreadDeletStatus;
            return;
        }
        const button = e.target.closest('button');
        try {
            button?.classList.add('loading');
            const newThread = await this.disableBot(botName, this.threadDetails.thread.threadId, this.userId);
            this.threadDetails = JSON.parse(JSON.stringify(this.editedThreadDetails));
            this.editedThreadDetails.thread = { ...newThread };
        }
        catch (err) {
            this.labelErrorRemoveBoot = err.message;
        }
        finally {
            button?.classList.remove('loading');
        }
    }
    async disableBot(botId, threadId, userId) {
        try {
            const result = await msgAddOrUpdateThreadBot({
                botId,
                llmPrompt: "",
                status: "disabled",
                threadId,
                userId,
                config: undefined
            });
            if (!result.success || !result.response?.thread) {
                throw new Error(result.error || 'Failed to disable bot');
            }
            const thread = result.response.thread;
            this.threadDetails = JSON.parse(JSON.stringify(this.editedThreadDetails));
            const threadCache = await updateThread(threadId, thread);
            notifyThreadChange(threadCache);
            await addMessage(threadId, `Bot ${botId} disabled successfully.`);
            return thread;
        }
        catch (err) {
            throw new Error(err?.message || 'Unexpected error while disabling bot');
        }
    }
    getChangedFields() {
        if (!this.threadDetails || !this.editedThreadDetails)
            return undefined;
        const original = this.threadDetails.thread;
        const edited = this.editedThreadDetails.thread;
        const fields = ['group', 'languages', 'name', 'status', 'visibility', 'welcomeMessage', 'defaultTopics', 'avatar_url'];
        const changed = {
            action: 'updateThread',
            threadId: original.threadId,
            userId: this.userId,
        };
        for (const field of fields) {
            const origVal = JSON.stringify(original[field]);
            const editVal = JSON.stringify(edited[field]);
            if (origVal !== editVal) {
                changed[field] = edited[field];
            }
        }
        return changed;
    }
    onAddParticipant(ev) {
        const thread = ev.detail.thread;
        if (thread && this.threadDetails) {
            this.threadDetails.thread = { ...thread };
            this.editedThreadDetails = { ...this.threadDetails };
            this.requestUpdate();
        }
    }
    async saveChanges() {
        this.labelError = '';
        this.labelOk = '';
        if (!this.editedThreadDetails || !this.userId)
            return;
        if (['deleting'].includes(this.editedThreadDetails.thread.status || '')) {
            this.labelError = this.msg.errorSaveThreadDeletStatus;
            return;
        }
        const changes = this.getChangedFields();
        if (!changes)
            return;
        const needUpdateThread = Object.keys(changes).length > 3;
        if (!needUpdateThread) {
            this.labelError = this.msg.noChanges;
            return;
        }
        this.isLoading = true;
        try {
            const result = await msgUpdateThread(changes);
            if (!result.success || !result.response?.thread) {
                this.labelError =
                    result.error || 'Failed to update thread.';
                return;
            }
            const newThread = result.response.thread;
            const oldStatus = this.threadDetails?.thread.status;
            this.threadDetails = JSON.parse(JSON.stringify(this.editedThreadDetails));
            let threadCache;
            if (['deleted', 'archived'].includes(newThread.status) &&
                newThread.status !== oldStatus) {
                await deleteAllMessagesFromThread(newThread.threadId);
                threadCache = await updateThread(newThread.threadId, newThread, '', '', 0, '');
            }
            else {
                threadCache = await updateThread(newThread.threadId, newThread);
            }
            notifyThreadChange(threadCache);
            this.labelOk =
                this.msg.successSaving || 'Thread updated successfully.';
            // Exit edit mode after successful save
            this.isEditingDetails = false;
        }
        catch (err) {
            console.error(err);
            this.labelError =
                err?.message || 'An unexpected error occurred while saving changes.';
        }
        finally {
            this.isLoading = false;
        }
    }
    async removeUserFromThread(threadId, userId, userIdOrName) {
        try {
            const result = await msgRemoveParticipantFromThread({
                threadId,
                userId,
                userIdOrName
            });
            if (!result.success || !result.response?.thread) {
                throw new Error(result.error || 'Failed to remove participant from thread');
            }
            return result.response.thread;
        }
        catch (err) {
            throw new Error(err?.message || 'Unexpected error while removing participant');
        }
    }
    async getThreadInfo(threadId, userId) {
        try {
            const result = await msgGetThreadUpdates({
                threadId,
                userId
            });
            if (!result.success || !result.response) {
                throw new Error(result.error || 'Failed to fetch thread details');
            }
            return result.response;
        }
        catch (err) {
            throw new Error(err?.message || 'Unexpected error while fetching thread details');
        }
    }
};
__decorate([
    property()
], CollabMessagesThreadDetails.prototype, "userId", void 0);
__decorate([
    property()
], CollabMessagesThreadDetails.prototype, "threadDetails", void 0);
__decorate([
    query('collab-messages-change-avatar-102025')
], CollabMessagesThreadDetails.prototype, "avatarEl", void 0);
__decorate([
    property()
], CollabMessagesThreadDetails.prototype, "labelOk", void 0);
__decorate([
    property()
], CollabMessagesThreadDetails.prototype, "labelError", void 0);
__decorate([
    property()
], CollabMessagesThreadDetails.prototype, "labelErrorRemoveUser", void 0);
__decorate([
    property()
], CollabMessagesThreadDetails.prototype, "labelErrorRemoveBoot", void 0);
__decorate([
    property()
], CollabMessagesThreadDetails.prototype, "labelErrorAgent", void 0);
__decorate([
    property()
], CollabMessagesThreadDetails.prototype, "labelOkAgent", void 0);
__decorate([
    state()
], CollabMessagesThreadDetails.prototype, "isLoading", void 0);
__decorate([
    state()
], CollabMessagesThreadDetails.prototype, "editedThreadDetails", void 0);
__decorate([
    state()
], CollabMessagesThreadDetails.prototype, "isDirectMessage", void 0);
__decorate([
    state()
], CollabMessagesThreadDetails.prototype, "isChannel", void 0);
__decorate([
    state()
], CollabMessagesThreadDetails.prototype, "isFileChannel", void 0);
__decorate([
    state()
], CollabMessagesThreadDetails.prototype, "isEditingDetails", void 0);
__decorate([
    state()
], CollabMessagesThreadDetails.prototype, "showAgentForm", void 0);
__decorate([
    state()
], CollabMessagesThreadDetails.prototype, "integrations", void 0);
__decorate([
    state()
], CollabMessagesThreadDetails.prototype, "selectedIntegrationId", void 0);
__decorate([
    state()
], CollabMessagesThreadDetails.prototype, "selectedAgentId", void 0);
__decorate([
    state()
], CollabMessagesThreadDetails.prototype, "isLoadingAgents", void 0);
CollabMessagesThreadDetails = __decorate([
    customElement('collab-messages-thread-details-102025')
], CollabMessagesThreadDetails);
export { CollabMessagesThreadDetails };
