/// <mls fileReference="_102025_/l2/collabTasksBoard.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    todo: 'A fazer',
    inProgress: 'Em andamento',
    paused: 'Pausado',
    done: 'Concluído',
    failed: 'Falhou',
    emptyColumn: 'Nada por aqui ainda.',
    boardEmptyTitle: 'Sem tarefas de workflow.',
    boardEmptySubtitle: 'Crie uma com /createNewChat kai: <título> em qualquer thread.',
    loadError: 'Não consegui carregar as tarefas.',
    retry: 'Tentar de novo',
    board: 'Board',
    allProcesses: 'todos os processos',
    appearance: 'Aparência',
    themes: 'Tema do board',
    themeClean: 'Limpo',
    themeAmber: 'Âmbar',
    themeForest: 'Floresta',
    themeCleanDesc: 'Visual neutro e minimalista',
    themeAmberDesc: 'Tons quentes e aconchegantes',
    themeForestDesc: 'Natureza com imagem de fundo',
    reload: 'Recarregar',
    filterByTag: 'Tag',
    filterByWorkflow: 'Workflow',
    clearFilters: 'limpar',
    noResults: 'Nenhuma task encontrada para os filtros selecionados.',
};
const message_en = {
    todo: 'To do',
    inProgress: 'In progress',
    paused: 'Paused',
    done: 'Done',
    failed: 'Failed',
    emptyColumn: 'Nothing here yet.',
    boardEmptyTitle: 'No workflow tasks yet.',
    boardEmptySubtitle: 'Create one with /createNewChat kai: <title> from any thread.',
    loadError: 'Could not load tasks.',
    retry: 'Retry',
    board: 'Board',
    allProcesses: 'all processes',
    appearance: 'Appearance',
    themes: 'Board theme',
    themeClean: 'Clean',
    themeAmber: 'Amber',
    themeForest: 'Forest',
    themeCleanDesc: 'Neutral and minimal',
    themeAmberDesc: 'Warm and cozy tones',
    themeForestDesc: 'Nature background image',
    reload: 'Reload',
    filterByTag: 'Tag',
    filterByWorkflow: 'Workflow',
    clearFilters: 'clear',
    noResults: 'No tasks match the selected filters.',
};
/// **collab_i18n_end**
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { msgListTasks, msgGetOrgPreferences } from '/_102025_/l2/shared/api.js';
import { THEME_BG_OPTIONS, loadTasksTheme, loadThemeBgUrl, saveTasksTheme, saveThemeBgUrl, applyThemeToHost, renderThemeCards, renderImagePicker, } from '/_102025_/l2/collabTasksTheme.js';
import '/_102025_/l2/collabTasksCard.js';
import '/_102025_/l2/collabTasksEmptyState.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
// ── Module-level tag vocabulary cache ─────────────────────────────────────
let _tagCache = null;
async function loadTagVocabulary(organizationId, userId) {
    if (_tagCache)
        return _tagCache;
    const result = await msgGetOrgPreferences({ organizationId, userId });
    if (result.success && result.response) {
        _tagCache = result.response.tagVocabulary ?? [];
    }
    else {
        _tagCache = [];
    }
    return _tagCache;
}
const ALWAYS_COLUMNS = ['todo', 'in progress', 'paused', 'done'];
const STAGGER_CAP = 8;
let CollabTasksBoard = class CollabTasksBoard extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-tasks-board-102025 {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  --status-todo-accent: #185fa5;
  --status-todo-soft-bg: #e6f1fb;
  --status-todo-text: #185fa5;
  --status-in-progress-accent: #854f0b;
  --status-in-progress-soft-bg: #faeeda;
  --status-in-progress-text: #854f0b;
  --status-paused-accent: #6b7280;
  --status-paused-soft-bg: #f3f4f6;
  --status-paused-text: #6b7280;
  --status-done-accent: #3b6d11;
  --status-done-soft-bg: #eaf3de;
  --status-done-text: #3b6d11;
  --status-failed-accent: #a32d2d;
  --status-failed-soft-bg: #fcebeb;
  --status-failed-text: #a32d2d;
  --board-bg: transparent;
  --board-col-bg: var(--color-background-secondary, #f5f4f0);
  --board-col-border: var(--color-border-tertiary, rgba(0, 0, 0, 0.08));
  --board-col-text: var(--color-text-secondary, #5f5e5a);
  --board-header-bg: var(--color-background-primary, #ffffff);
  --board-header-border: var(--color-border-tertiary, rgba(0, 0, 0, 0.08));
  --board-card-bg: var(--color-background-primary, #ffffff);
  --board-card-border: var(--color-border-tertiary, rgba(0, 0, 0, 0.08));
}
@media (prefers-color-scheme: dark) {
  collab-tasks-board-102025 {
    --status-todo-soft-bg: rgba(12, 68, 124, 0.13);
    --status-todo-text: #85b7eb;
    --status-in-progress-soft-bg: rgba(99, 56, 6, 0.13);
    --status-in-progress-text: #fac775;
    --status-paused-soft-bg: rgba(255, 255, 255, 0.06);
    --status-paused-text: #9c9a92;
    --status-done-soft-bg: rgba(39, 80, 10, 0.13);
    --status-done-text: #97c459;
    --status-failed-soft-bg: rgba(121, 31, 31, 0.13);
    --status-failed-text: #f09595;
  }
}
collab-tasks-board-102025 .board-header {
  display: flex;
  align-items: center;
  height: 44px;
  padding: 0 16px;
  gap: 8px;
  flex-shrink: 0;
  background: var(--board-header-bg);
  border-bottom: 0.5px solid var(--board-header-border);
  z-index: 10;
}
collab-tasks-board-102025 .board-header-left {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: 1;
  min-width: 0;
}
collab-tasks-board-102025 .board-header-title {
  font-size: 14px;
  font-weight: 500;
  color: var(--color-text-primary, #1a1a18);
  white-space: nowrap;
}
collab-tasks-board-102025 .board-header-sep {
  font-size: 13px;
  color: var(--color-text-tertiary, #888780);
}
collab-tasks-board-102025 .board-header-sub {
  font-size: 12px;
  color: var(--color-text-tertiary, #888780);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
collab-tasks-board-102025 .board-header-right {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
}
collab-tasks-board-102025 .board-icon-btn {
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: none;
  border: 0.5px solid transparent;
  border-radius: 7px;
  cursor: pointer;
  color: var(--color-text-tertiary, #888780);
  transition: background 0.12s, border-color 0.12s, color 0.12s;
}
collab-tasks-board-102025 .board-icon-btn:hover {
  background: var(--color-background-secondary, #f5f4f0);
  border-color: var(--board-col-border);
  color: var(--color-text-secondary, #5f5e5a);
}
collab-tasks-board-102025 .board-icon-btn.active {
  background: var(--color-background-secondary, #f5f4f0);
  border-color: var(--board-col-border);
  color: var(--color-text-primary, #1a1a18);
}
collab-tasks-board-102025 .settings-panel {
  padding: 12px 16px;
  border-bottom: 0.5px solid var(--board-header-border);
  background: var(--board-header-bg);
  flex-shrink: 0;
  animation: panel-slide-down 140ms ease-out both;
}
@keyframes panel-slide-down {
  from {
    opacity: 0;
    transform: translateY(-6px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
collab-tasks-board-102025 .settings-panel-title {
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--board-col-text, var(--color-text-tertiary, #888780));
  margin-bottom: 10px;
}
collab-tasks-board-102025 .theme-grid {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 5px;
}
collab-tasks-board-102025 .theme-card {
  display: flex;
  flex-direction: column;
  gap: 5px;
  padding: 7px;
  border: 0.5px solid var(--board-col-border);
  border-radius: 9px;
  cursor: pointer;
  background: var(--board-col-bg);
  font-family: inherit;
  text-align: left;
  transition: border-color 0.12s, box-shadow 0.12s;
}
collab-tasks-board-102025 .theme-card:hover {
  border-color: var(--color-border-secondary, rgba(0, 0, 0, 0.18));
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}
collab-tasks-board-102025 .theme-card.selected {
  border-color: var(--status-todo-accent, #185fa5);
  box-shadow: 0 0 0 2px rgba(24, 95, 165, 0.12);
}
collab-tasks-board-102025 .theme-board-preview {
  border-radius: 4px;
  overflow: hidden;
  border: 0.5px solid rgba(0, 0, 0, 0.06);
}
collab-tasks-board-102025 .theme-card-info {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 3px;
}
collab-tasks-board-102025 .theme-card-name {
  font-size: 11px;
  font-weight: 500;
  color: var(--color-text-primary, #1a1a18);
}
collab-tasks-board-102025 .theme-check-icon {
  color: var(--status-todo-accent, #185fa5);
  flex-shrink: 0;
}
collab-tasks-board-102025 .theme-card-desc {
  font-size: 9px;
  color: var(--board-col-text, var(--color-text-tertiary, #888780));
  line-height: 1.3;
}
collab-tasks-board-102025 .board-error {
  background: var(--color-background-danger, #fcebeb);
  color: var(--color-text-danger, #a32d2d);
  border-radius: 8px;
  padding: 10px 14px;
  margin: 12px 16px 0;
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 13px;
  flex-shrink: 0;
}
collab-tasks-board-102025 .board-error-retry {
  background: none;
  border: none;
  cursor: pointer;
  color: inherit;
  text-decoration: underline;
  font-size: 13px;
  padding: 0;
  flex-shrink: 0;
}
collab-tasks-board-102025 .board-no-results {
  padding: 20px 16px 0;
  font-size: 12px;
  color: var(--color-text-tertiary, #888780);
  text-align: center;
  flex-shrink: 0;
}
collab-tasks-board-102025 .filter-bar {
  display: flex;
  align-items: center;
  gap: 5px;
  padding: 8px 16px;
  border-bottom: 0.5px solid var(--board-header-border);
  background: var(--board-header-bg);
  flex-shrink: 0;
  overflow-x: auto;
  scrollbar-width: none;
}
collab-tasks-board-102025 .filter-bar::-webkit-scrollbar {
  display: none;
}
collab-tasks-board-102025 .filter-chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 3px 9px;
  border-radius: 20px;
  border: 0.5px solid var(--board-col-border);
  background: none;
  font-size: 11px;
  font-weight: 500;
  color: var(--board-col-text);
  cursor: pointer;
  white-space: nowrap;
  transition: background 0.1s, border-color 0.1s, color 0.1s;
  font-family: inherit;
}
collab-tasks-board-102025 .filter-chip:hover {
  background: var(--board-col-bg);
  border-color: var(--color-border-secondary, rgba(0, 0, 0, 0.18));
}
collab-tasks-board-102025 .filter-chip.active {
  border-color: currentColor;
}
collab-tasks-board-102025 .chip-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  flex-shrink: 0;
}
collab-tasks-board-102025 .chip-dot.b-bug {
  background: #a32d2d;
}
collab-tasks-board-102025 .chip-dot.b-feature {
  background: #185fa5;
}
collab-tasks-board-102025 .chip-dot.b-business {
  background: #854f0b;
}
collab-tasks-board-102025 .chip-dot.b-process {
  background: #3b6d11;
}
collab-tasks-board-102025 .chip-dot.b-neutral {
  background: var(--board-col-text);
  opacity: 0.5;
}
collab-tasks-board-102025 .tag-filter.active.b-bug {
  background: #fcebeb;
  color: #a32d2d;
  border-color: rgba(163, 45, 45, 0.35);
}
collab-tasks-board-102025 .tag-filter.active.b-feature {
  background: #e6f1fb;
  color: #185fa5;
  border-color: rgba(24, 95, 165, 0.35);
}
collab-tasks-board-102025 .tag-filter.active.b-business {
  background: #faeeda;
  color: #854f0b;
  border-color: rgba(133, 79, 11, 0.35);
}
collab-tasks-board-102025 .tag-filter.active.b-process {
  background: #e1f5ee;
  color: #085041;
  border-color: rgba(8, 80, 65, 0.35);
}
collab-tasks-board-102025 .tag-filter.active.b-neutral {
  background: var(--board-col-bg);
  border-color: var(--board-col-text);
}
@media (prefers-color-scheme: dark) {
  collab-tasks-board-102025 .tag-filter.active.b-bug {
    background: rgba(163, 45, 45, 0.15);
    color: #f09595;
    border-color: rgba(240, 149, 149, 0.3);
  }
  collab-tasks-board-102025 .tag-filter.active.b-feature {
    background: rgba(24, 95, 165, 0.15);
    color: #85b7eb;
    border-color: rgba(133, 183, 235, 0.3);
  }
  collab-tasks-board-102025 .tag-filter.active.b-business {
    background: rgba(133, 79, 11, 0.15);
    color: #fac775;
    border-color: rgba(250, 199, 117, 0.3);
  }
  collab-tasks-board-102025 .tag-filter.active.b-process {
    background: rgba(8, 80, 65, 0.15);
    color: #97c459;
    border-color: rgba(151, 196, 89, 0.3);
  }
}
collab-tasks-board-102025 .chip-icon {
  flex-shrink: 0;
  opacity: 0.65;
}
collab-tasks-board-102025 .pma-filter.active {
  background: rgba(88, 28, 135, 0.06);
  color: #5b21b6;
  border-color: rgba(91, 33, 182, 0.3);
}
collab-tasks-board-102025 .pma-filter.active .chip-icon {
  opacity: 1;
}
@media (prefers-color-scheme: dark) {
  collab-tasks-board-102025 .pma-filter.active {
    background: rgba(167, 139, 250, 0.12);
    color: #a78bfa;
    border-color: rgba(167, 139, 250, 0.3);
  }
}
collab-tasks-board-102025 .filter-sep {
  width: 0.5px;
  height: 18px;
  background: var(--board-col-border);
  flex-shrink: 0;
  margin: 0 2px;
}
collab-tasks-board-102025 .filter-clear {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 3px 8px;
  border-radius: 20px;
  border: none;
  background: none;
  font-size: 11px;
  color: var(--color-text-tertiary, #888780);
  cursor: pointer;
  white-space: nowrap;
  font-family: inherit;
  margin-left: 2px;
  transition: color 0.1s;
}
collab-tasks-board-102025 .filter-clear:hover {
  color: var(--color-text-danger, #a32d2d);
}
collab-tasks-board-102025.theme-forest .filter-bar {
  background: rgba(15, 35, 22, 0.97);
  border-color: rgba(255, 255, 255, 0.08);
}
collab-tasks-board-102025.theme-forest .filter-chip {
  color: rgba(200, 240, 210, 0.7);
  border-color: rgba(255, 255, 255, 0.1);
}
collab-tasks-board-102025.theme-forest .filter-chip:hover {
  background: rgba(255, 255, 255, 0.06);
}
collab-tasks-board-102025.theme-forest .filter-sep {
  background: rgba(255, 255, 255, 0.08);
}
collab-tasks-board-102025.theme-forest .filter-clear {
  color: rgba(200, 240, 210, 0.45);
}
collab-tasks-board-102025.theme-amber .filter-bar {
  background: var(--board-header-bg);
  border-color: rgba(120, 68, 8, 0.22);
}
collab-tasks-board-102025.theme-amber .filter-chip {
  color: var(--board-col-text);
  border-color: rgba(120, 68, 8, 0.2);
}
collab-tasks-board-102025.theme-amber .filter-chip:hover {
  background: rgba(133, 79, 11, 0.07);
}
collab-tasks-board-102025.theme-amber .filter-sep {
  background: rgba(120, 68, 8, 0.2);
}
collab-tasks-board-102025.theme-amber .filter-clear {
  color: #7a5a2e;
}
collab-tasks-board-102025 .board-columns {
  display: flex;
  flex-direction: row;
  gap: 10px;
  padding: 14px 16px;
  flex: 1;
  box-sizing: border-box;
  overflow-x: auto;
  overflow-y: hidden;
  background: var(--board-bg);
}
collab-tasks-board-102025 .board-column {
  flex: 1 1 0;
  min-width: 220px;
  max-width: 320px;
  background: var(--board-col-bg);
  border: 0.5px solid var(--board-col-border);
  border-radius: 10px;
  padding: 10px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
collab-tasks-board-102025 h2.col-header {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 34px;
  padding: 0 6px 6px;
  flex-shrink: 0;
  margin: 0;
  font-size: inherit;
  font-weight: inherit;
  border-bottom: 0.5px solid var(--board-col-border);
  margin-bottom: 2px;
}
collab-tasks-board-102025 .col-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  flex-shrink: 0;
}
collab-tasks-board-102025 .col-label {
  flex: 1;
  font-size: 11px;
  font-weight: 500;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--board-col-text);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
collab-tasks-board-102025 .col-count {
  font-size: 10px;
  font-weight: 500;
  padding: 1px 6px;
  border-radius: 8px;
  flex-shrink: 0;
}
collab-tasks-board-102025 .status-todo .col-dot {
  background: var(--status-todo-accent);
}
collab-tasks-board-102025 .status-todo .col-count {
  background: var(--status-todo-soft-bg);
  color: var(--status-todo-text);
}
collab-tasks-board-102025 .status-in-progress .col-dot {
  background: var(--status-in-progress-accent);
}
collab-tasks-board-102025 .status-in-progress .col-count {
  background: var(--status-in-progress-soft-bg);
  color: var(--status-in-progress-text);
}
collab-tasks-board-102025 .status-paused .col-dot {
  background: var(--status-paused-accent);
}
collab-tasks-board-102025 .status-paused .col-count {
  background: var(--status-paused-soft-bg);
  color: var(--status-paused-text);
}
collab-tasks-board-102025 .status-done .col-dot {
  background: var(--status-done-accent);
}
collab-tasks-board-102025 .status-done .col-count {
  background: var(--status-done-soft-bg);
  color: var(--status-done-text);
}
collab-tasks-board-102025 .status-failed .col-dot {
  background: var(--status-failed-accent);
}
collab-tasks-board-102025 .status-failed .col-count {
  background: var(--status-failed-soft-bg);
  color: var(--status-failed-text);
}
collab-tasks-board-102025 .col-stack {
  display: flex;
  flex-direction: column;
  gap: 6px;
  overflow-y: auto;
  flex: 1;
  padding-top: 8px;
  padding-bottom: 4px;
}
collab-tasks-board-102025 .col-empty {
  border: 0.5px dashed var(--board-col-border);
  border-radius: 7px;
  padding: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--color-text-tertiary, #9ca3af);
  font-size: 11px;
  text-align: center;
}
@keyframes shimmer {
  0% {
    background-position: -200% 0;
  }
  100% {
    background-position: 200% 0;
  }
}
collab-tasks-board-102025 .skeleton-card {
  background: var(--board-card-bg);
  border: 0.5px solid var(--board-col-border);
  border-radius: 8px;
  padding: 10px 12px;
}
collab-tasks-board-102025 .skeleton-card .skeleton-line {
  border-radius: 4px;
  background: linear-gradient(90deg, var(--color-background-secondary, #eceae3) 0%, rgba(255, 255, 255, 0.18) 50%, var(--color-background-secondary, #eceae3) 100%);
  background-size: 200% 100%;
  animation: shimmer 1.4s ease-in-out infinite;
}
collab-tasks-board-102025 .skeleton-card .skeleton-title {
  width: 70%;
  height: 11px;
  margin-bottom: 8px;
}
collab-tasks-board-102025 .skeleton-card .skeleton-meta {
  width: 45%;
  height: 9px;
}
@keyframes card-enter {
  from {
    opacity: 0;
    transform: translateY(4px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
collab-tasks-board-102025 .card-animate {
  animation: card-enter 200ms ease-out both;
}
@media (prefers-reduced-motion: reduce) {
  collab-tasks-board-102025 .skeleton-card .skeleton-line {
    animation: none;
  }
  collab-tasks-board-102025 .card-animate {
    animation: none;
    opacity: 1;
  }
  collab-tasks-board-102025 .settings-panel {
    animation: none;
  }
}
@keyframes col-enter {
  from {
    opacity: 0;
    transform: translateY(12px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
@keyframes cu-gradient {
  0%,
  100% {
    background-position: 0% 60%;
  }
  50% {
    background-position: 100% 40%;
  }
}
collab-tasks-board-102025 .img-picker-section {
  margin-top: 10px;
  border-top: 0.5px solid var(--board-header-border);
  padding-top: 10px;
}
collab-tasks-board-102025 .img-picker-label {
  font-size: 10px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--board-col-text, var(--color-text-tertiary, #888780));
  margin-bottom: 8px;
}
collab-tasks-board-102025 .img-picker-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 5px;
}
collab-tasks-board-102025 .img-thumb {
  aspect-ratio: 16/9;
  border-radius: 5px;
  border: 2px solid transparent;
  background-size: cover;
  background-position: center;
  cursor: pointer;
  position: relative;
  overflow: hidden;
  transition: border-color 0.12s, transform 0.1s;
  padding: 0;
}
collab-tasks-board-102025 .img-thumb:hover {
  transform: scale(1.03);
  border-color: rgba(255, 255, 255, 0.5);
}
collab-tasks-board-102025 .img-thumb.selected {
  border-color: #185fa5;
  box-shadow: 0 0 0 1px #185fa5;
}
collab-tasks-board-102025 .img-thumb-check {
  position: absolute;
  top: 3px;
  right: 3px;
  display: flex;
}
collab-tasks-board-102025.theme-clean {
  --board-bg: #e9e7e0;
  --board-col-bg: #f5f3ef;
  --board-col-border: rgba(0, 0, 0, 0.12);
  --board-col-text: #4a4a47;
  --board-header-bg: #ffffff;
  --board-header-border: rgba(0, 0, 0, 0.1);
  --board-card-bg: #ffffff;
}
collab-tasks-board-102025.theme-amber {
  --board-bg: transparent;
  --board-col-bg: #fef9ee;
  --board-col-border: rgba(100, 55, 5, 0.18);
  --board-col-text: #5a3812;
  --board-header-bg: #8c5116;
  --board-header-border: rgba(60, 30, 0, 0.35);
  --board-card-bg: #ffffff;
}
collab-tasks-board-102025.theme-amber .board-header-title {
  color: #fef0d4;
}
collab-tasks-board-102025.theme-amber .board-header-sep {
  color: rgba(254, 220, 160, 0.55);
}
collab-tasks-board-102025.theme-amber .board-header-sub {
  color: rgba(254, 220, 160, 0.65);
}
collab-tasks-board-102025.theme-amber .board-icon-btn {
  color: rgba(254, 220, 160, 0.7);
}
collab-tasks-board-102025.theme-amber .board-icon-btn:hover,
collab-tasks-board-102025.theme-amber .board-icon-btn.active {
  background: rgba(255, 255, 255, 0.12);
  border-color: rgba(255, 255, 255, 0.22);
  color: #fff7e6;
}
collab-tasks-board-102025.theme-amber .col-label {
  color: #5a3812;
  font-weight: 600;
}
collab-tasks-board-102025.theme-amber .col-empty {
  border-color: rgba(100, 55, 5, 0.18);
  color: #8a6030;
}
collab-tasks-board-102025.theme-amber .settings-panel {
  background: #8c5116;
  border-color: rgba(60, 30, 0, 0.35);
}
collab-tasks-board-102025.theme-amber .settings-panel-title {
  color: rgba(254, 220, 160, 0.75);
}
collab-tasks-board-102025.theme-amber .theme-card {
  background: rgba(255, 255, 255, 0.12);
  border-color: rgba(255, 255, 255, 0.18);
}
collab-tasks-board-102025.theme-amber .theme-card-name {
  color: #fef0d4;
}
collab-tasks-board-102025.theme-amber .theme-card-desc {
  color: rgba(254, 220, 160, 0.65);
}
collab-tasks-board-102025.theme-amber .theme-check-icon {
  color: #ffd87a;
}
collab-tasks-board-102025.theme-amber .img-picker-label {
  color: rgba(254, 220, 160, 0.65);
}
collab-tasks-board-102025.theme-amber .img-picker-section {
  border-color: rgba(255, 255, 255, 0.18);
}
collab-tasks-board-102025.theme-amber .filter-bar {
  background: #7a4510;
  border-color: rgba(60, 30, 0, 0.3);
}
collab-tasks-board-102025.theme-amber .filter-chip {
  color: rgba(254, 220, 160, 0.75);
  border-color: rgba(255, 255, 255, 0.18);
}
collab-tasks-board-102025.theme-amber .filter-chip:hover {
  background: rgba(255, 255, 255, 0.1);
}
collab-tasks-board-102025.theme-amber .filter-sep {
  background: rgba(255, 255, 255, 0.2);
}
collab-tasks-board-102025.theme-amber .filter-clear {
  color: rgba(254, 220, 160, 0.55);
}
collab-tasks-board-102025.theme-amber .board-columns {
  background: linear-gradient(150deg, #b87333 0%, #d4a53a 45%, #c07b28 100%);
}
@media (prefers-color-scheme: dark) {
  collab-tasks-board-102025.theme-amber {
    --board-col-bg: rgba(133, 79, 11, 0.22);
    --board-col-border: rgba(240, 163, 50, 0.18);
    --board-col-text: #f5c97a;
    --board-header-bg: #5c2e08;
    --board-header-border: rgba(240, 163, 50, 0.18);
    --board-card-bg: rgba(133, 79, 11, 0.14);
  }
}
collab-tasks-board-102025.theme-forest {
  --board-col-bg: rgba(255, 255, 255, 0.93);
  --board-col-border: rgba(0, 0, 0, 0.12);
  --board-col-text: #2a3a2c;
  --board-header-bg: rgba(8, 15, 9, 0.96);
  --board-header-border: rgba(255, 255, 255, 0.1);
  --board-card-bg: #ffffff;
}
collab-tasks-board-102025.theme-forest .board-header-title {
  color: rgba(230, 255, 235, 0.94);
}
collab-tasks-board-102025.theme-forest .board-header-sep {
  color: rgba(180, 230, 190, 0.45);
}
collab-tasks-board-102025.theme-forest .board-header-sub {
  color: rgba(180, 230, 190, 0.55);
}
collab-tasks-board-102025.theme-forest .board-icon-btn {
  color: rgba(180, 230, 190, 0.55);
}
collab-tasks-board-102025.theme-forest .board-icon-btn:hover,
collab-tasks-board-102025.theme-forest .board-icon-btn.active {
  background: rgba(255, 255, 255, 0.1);
  border-color: rgba(255, 255, 255, 0.15);
  color: rgba(230, 255, 235, 0.9);
}
collab-tasks-board-102025.theme-forest .col-label {
  color: #2a3a2c;
  font-weight: 600;
}
collab-tasks-board-102025.theme-forest .col-empty {
  border-color: rgba(0, 0, 0, 0.1);
  color: #5a7060;
}
collab-tasks-board-102025.theme-forest .settings-panel {
  background: rgba(8, 15, 9, 0.97);
  border-color: rgba(255, 255, 255, 0.1);
}
collab-tasks-board-102025.theme-forest .settings-panel-title {
  color: rgba(180, 230, 190, 0.55);
}
collab-tasks-board-102025.theme-forest .theme-card {
  background: rgba(255, 255, 255, 0.08);
  border-color: rgba(255, 255, 255, 0.12);
}
collab-tasks-board-102025.theme-forest .theme-card-name {
  color: rgba(230, 255, 235, 0.9);
}
collab-tasks-board-102025.theme-forest .theme-card-desc {
  color: rgba(180, 230, 190, 0.55);
}
collab-tasks-board-102025.theme-forest .theme-check-icon {
  color: #4ade80;
}
collab-tasks-board-102025.theme-forest .img-picker-label {
  color: rgba(180, 230, 190, 0.55);
}
collab-tasks-board-102025.theme-forest .img-picker-section {
  border-color: rgba(255, 255, 255, 0.1);
}
collab-tasks-board-102025.theme-forest .filter-bar {
  background: rgba(8, 15, 9, 0.96);
  border-color: rgba(255, 255, 255, 0.1);
}
collab-tasks-board-102025.theme-forest .filter-chip {
  color: rgba(210, 245, 220, 0.65);
  border-color: rgba(255, 255, 255, 0.12);
}
collab-tasks-board-102025.theme-forest .filter-chip:hover {
  background: rgba(255, 255, 255, 0.07);
}
collab-tasks-board-102025.theme-forest .filter-sep {
  background: rgba(255, 255, 255, 0.1);
}
collab-tasks-board-102025.theme-forest .filter-clear {
  color: rgba(180, 230, 190, 0.45);
}
collab-tasks-board-102025.theme-forest .board-columns {
  background: var(--theme-bg-url, linear-gradient(160deg, #0a1a0c 0%, #122016 50%, #0d1a10 100%)) center / cover;
}
collab-tasks-board-102025.theme-forest collab-tasks-card-102025 {
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.12), 0 1px 2px rgba(0, 0, 0, 0.08);
}
collab-tasks-board-102025.theme-forest collab-tasks-card-102025:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
}
collab-tasks-board-102025.theme-trello {
  --board-col-bg: #ebecf0;
  --board-col-border: transparent;
  --board-col-text: #172b4d;
  --board-header-bg: rgba(255, 255, 255, 0.96);
  --board-header-border: rgba(9, 30, 66, 0.12);
  --board-card-bg: #ffffff;
  --status-todo-accent: #0052cc;
  --status-todo-soft-bg: #deebff;
  --status-todo-text: #0047b3;
  --status-in-progress-accent: #ff8b00;
  --status-in-progress-soft-bg: #fff0b3;
  --status-in-progress-text: #974f0c;
  --status-done-accent: #006644;
  --status-done-soft-bg: #e3fcef;
  --status-done-text: #006644;
  --status-failed-accent: #de350b;
  --status-failed-soft-bg: #ffebe6;
  --status-failed-text: #bf2600;
}
collab-tasks-board-102025.theme-trello .board-column {
  border-radius: 3px;
  border: none;
}
collab-tasks-board-102025.theme-trello .col-label {
  color: #172b4d;
  font-size: 12px;
  text-transform: none;
  font-weight: 600;
  letter-spacing: 0;
}
collab-tasks-board-102025.theme-trello .col-empty {
  border: 1px dashed rgba(9, 30, 66, 0.15);
  color: #5e6c84;
}
collab-tasks-board-102025.theme-trello .board-header-title {
  color: #172b4d;
}
collab-tasks-board-102025.theme-trello .board-header-sep {
  color: #5e6c84;
}
collab-tasks-board-102025.theme-trello .board-header-sub {
  color: #5e6c84;
}
collab-tasks-board-102025.theme-trello .board-icon-btn {
  color: #5e6c84;
}
collab-tasks-board-102025.theme-trello .board-icon-btn:hover,
collab-tasks-board-102025.theme-trello .board-icon-btn.active {
  background: rgba(9, 30, 66, 0.07);
  border-color: rgba(9, 30, 66, 0.18);
  color: #172b4d;
}
collab-tasks-board-102025.theme-trello .settings-panel {
  background: rgba(255, 255, 255, 0.96);
  border-color: rgba(9, 30, 66, 0.12);
}
collab-tasks-board-102025.theme-trello .settings-panel-title {
  color: #5e6c84;
}
collab-tasks-board-102025.theme-trello .theme-card {
  background: #f4f5f7;
  border-color: rgba(9, 30, 66, 0.12);
}
collab-tasks-board-102025.theme-trello .theme-card-name {
  color: #172b4d;
}
collab-tasks-board-102025.theme-trello .theme-card-desc {
  color: #5e6c84;
}
collab-tasks-board-102025.theme-trello .theme-check-icon {
  color: #0052cc;
}
collab-tasks-board-102025.theme-trello .img-picker-label {
  color: #5e6c84;
}
collab-tasks-board-102025.theme-trello .img-picker-section {
  border-color: rgba(9, 30, 66, 0.12);
}
collab-tasks-board-102025.theme-trello .filter-bar {
  background: rgba(255, 255, 255, 0.95);
  border-color: rgba(9, 30, 66, 0.12);
}
collab-tasks-board-102025.theme-trello .filter-chip {
  color: #5e6c84;
  border-color: rgba(9, 30, 66, 0.15);
}
collab-tasks-board-102025.theme-trello .filter-chip:hover {
  background: rgba(9, 30, 66, 0.05);
}
collab-tasks-board-102025.theme-trello .filter-sep {
  background: rgba(9, 30, 66, 0.12);
}
collab-tasks-board-102025.theme-trello .filter-clear {
  color: #5e6c84;
}
collab-tasks-board-102025.theme-trello .board-columns {
  background: var(--theme-bg-url, linear-gradient(135deg, #1565C0 0%, #0D47A1 50%, #0A2E7A 100%)) center / cover;
  gap: 8px;
  padding: 12px;
}
collab-tasks-board-102025.theme-trello .board-column {
  animation: col-enter 280ms ease-out both;
  box-shadow: 0 1px 2px rgba(9, 30, 66, 0.1);
}
collab-tasks-board-102025.theme-trello .board-column:nth-child(1) {
  animation-delay: 0ms;
}
collab-tasks-board-102025.theme-trello .board-column:nth-child(2) {
  animation-delay: 55ms;
}
collab-tasks-board-102025.theme-trello .board-column:nth-child(3) {
  animation-delay: 110ms;
}
collab-tasks-board-102025.theme-trello .board-column:nth-child(4) {
  animation-delay: 165ms;
}
collab-tasks-board-102025.theme-trello .board-column:nth-child(5) {
  animation-delay: 220ms;
}
collab-tasks-board-102025.theme-trello collab-tasks-card-102025 {
  border-radius: 3px;
  border: none;
  box-shadow: 0 1px 0 rgba(9, 30, 66, 0.25);
}
collab-tasks-board-102025.theme-trello collab-tasks-card-102025:hover {
  box-shadow: 0 4px 8px rgba(9, 30, 66, 0.2);
}
collab-tasks-board-102025.theme-clickup {
  --board-col-bg: rgba(147, 51, 234, 0.16);
  --board-col-border: rgba(147, 51, 234, 0.28);
  --board-col-text: rgba(216, 195, 255, 0.85);
  --board-header-bg: rgba(10, 4, 24, 0.97);
  --board-header-border: rgba(147, 51, 234, 0.25);
  --board-card-bg: rgba(255, 255, 255, 0.09);
  --status-todo-accent: #818cf8;
  --status-todo-soft-bg: rgba(129, 140, 248, 0.18);
  --status-todo-text: #a5b4fc;
  --status-in-progress-accent: #fb923c;
  --status-in-progress-soft-bg: rgba(251, 146, 60, 0.18);
  --status-in-progress-text: #fdba74;
  --status-paused-accent: #94a3b8;
  --status-paused-soft-bg: rgba(148, 163, 184, 0.15);
  --status-paused-text: #cbd5e1;
  --status-done-accent: #34d399;
  --status-done-soft-bg: rgba(52, 211, 153, 0.18);
  --status-done-text: #6ee7b7;
  --status-failed-accent: #f87171;
  --status-failed-soft-bg: rgba(248, 113, 113, 0.18);
  --status-failed-text: #fca5a5;
}
collab-tasks-board-102025.theme-clickup .board-header-title {
  color: rgba(235, 225, 255, 0.96);
}
collab-tasks-board-102025.theme-clickup .board-header-sep {
  color: rgba(167, 139, 250, 0.4);
}
collab-tasks-board-102025.theme-clickup .board-header-sub {
  color: rgba(167, 139, 250, 0.55);
}
collab-tasks-board-102025.theme-clickup .board-icon-btn {
  color: rgba(167, 139, 250, 0.55);
}
collab-tasks-board-102025.theme-clickup .board-icon-btn:hover,
collab-tasks-board-102025.theme-clickup .board-icon-btn.active {
  background: rgba(147, 51, 234, 0.18);
  border-color: rgba(147, 51, 234, 0.35);
  color: rgba(235, 225, 255, 0.9);
}
collab-tasks-board-102025.theme-clickup .col-label {
  color: rgba(216, 195, 255, 0.8);
  font-weight: 600;
}
collab-tasks-board-102025.theme-clickup .col-empty {
  border-color: rgba(147, 51, 234, 0.25);
  color: rgba(167, 139, 250, 0.45);
}
collab-tasks-board-102025.theme-clickup .settings-panel {
  background: rgba(10, 4, 24, 0.97);
  border-color: rgba(147, 51, 234, 0.25);
}
collab-tasks-board-102025.theme-clickup .settings-panel-title {
  color: rgba(167, 139, 250, 0.55);
}
collab-tasks-board-102025.theme-clickup .theme-card {
  background: rgba(147, 51, 234, 0.14);
  border-color: rgba(147, 51, 234, 0.22);
}
collab-tasks-board-102025.theme-clickup .theme-card-name {
  color: rgba(235, 225, 255, 0.9);
}
collab-tasks-board-102025.theme-clickup .theme-card-desc {
  color: rgba(167, 139, 250, 0.55);
}
collab-tasks-board-102025.theme-clickup .theme-check-icon {
  color: #a78bfa;
}
collab-tasks-board-102025.theme-clickup .img-picker-label {
  color: rgba(167, 139, 250, 0.55);
}
collab-tasks-board-102025.theme-clickup .img-picker-section {
  border-color: rgba(147, 51, 234, 0.25);
}
collab-tasks-board-102025.theme-clickup .filter-bar {
  background: rgba(10, 4, 24, 0.97);
  border-color: rgba(147, 51, 234, 0.25);
}
collab-tasks-board-102025.theme-clickup .filter-chip {
  color: rgba(216, 195, 255, 0.7);
  border-color: rgba(147, 51, 234, 0.22);
}
collab-tasks-board-102025.theme-clickup .filter-chip:hover {
  background: rgba(147, 51, 234, 0.15);
}
collab-tasks-board-102025.theme-clickup .filter-sep {
  background: rgba(147, 51, 234, 0.25);
}
collab-tasks-board-102025.theme-clickup .filter-clear {
  color: rgba(167, 139, 250, 0.45);
}
collab-tasks-board-102025.theme-clickup .board-columns {
  background: var(--theme-bg-url, linear-gradient(270deg, #13042a, #1e1257, #0d0626, #1a0b3e, #0e0b2e)) center / cover;
}
collab-tasks-board-102025.theme-clickup:not([style*="--theme-bg-url"]) .board-columns {
  background-size: 400% 400%;
  animation: cu-gradient 14s ease infinite;
}
collab-tasks-board-102025.theme-clickup .board-column {
  animation: col-enter 300ms ease-out both;
  box-shadow: 0 0 0 1px rgba(147, 51, 234, 0.2), 0 4px 16px rgba(0, 0, 0, 0.35);
}
collab-tasks-board-102025.theme-clickup .board-column:nth-child(1) {
  animation-delay: 0ms;
}
collab-tasks-board-102025.theme-clickup .board-column:nth-child(2) {
  animation-delay: 60ms;
}
collab-tasks-board-102025.theme-clickup .board-column:nth-child(3) {
  animation-delay: 120ms;
}
collab-tasks-board-102025.theme-clickup .board-column:nth-child(4) {
  animation-delay: 180ms;
}
collab-tasks-board-102025.theme-clickup .board-column:nth-child(5) {
  animation-delay: 240ms;
}
collab-tasks-board-102025.theme-clickup collab-tasks-card-102025 {
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.4);
  backdrop-filter: blur(6px);
}
collab-tasks-board-102025.theme-clickup collab-tasks-card-102025:hover {
  box-shadow: 0 4px 16px rgba(147, 51, 234, 0.35);
  border-color: rgba(167, 139, 250, 0.45);
}
collab-tasks-board-102025.theme-clickup .skeleton-card {
  background: rgba(147, 51, 234, 0.12);
}
collab-tasks-board-102025.theme-clickup .skeleton-card .skeleton-line {
  background: linear-gradient(90deg, rgba(147, 51, 234, 0.15) 0%, rgba(167, 139, 250, 0.22) 50%, rgba(147, 51, 234, 0.15) 100%);
  background-size: 200% 100%;
}
`);
        this.reloadKey = 0;
        this.userId = '';
        this.organizationId = 'collabcodes';
        this.initialPmaFilter = '';
        this.activeTasks = [];
        this.closedTasks = [];
        this.tagVocabulary = [];
        this.loadingActive = true;
        this.loadingClosed = true;
        this.error = null;
        this._theme = 'clean';
        this._showSettings = false;
        this._filterTags = new Set();
        this._filterPmaIds = new Set();
        this._initialFetchDone = false;
        this._refetchTimer = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this._theme = loadTasksTheme();
        this._applyThemeClass();
        if (this.initialPmaFilter) {
            this._filterPmaIds = new Set([this.initialPmaFilter]);
        }
        this._onTaskChange = (e) => this._handleTaskChange(e);
        this._onThreadChange = (e) => this._handleThreadChange(e);
        this._onTaskMetaChanged = (e) => this._handleTaskMetaChanged(e);
        const w = window?.top ?? window;
        w.addEventListener('task-change', this._onTaskChange);
        w.addEventListener('thread-change', this._onThreadChange);
        w.addEventListener('task-meta-changed', this._onTaskMetaChanged);
        this._fetchAll();
        this._initialFetchDone = true;
    }
    _applyThemeClass() {
        applyThemeToHost(this._theme, this);
    }
    _setTheme(theme) {
        this._showSettings = false;
        saveTasksTheme(theme, this);
        this._theme = theme;
    }
    _setBgImage(url) {
        saveThemeBgUrl(this._theme, url);
        this.style.setProperty('--theme-bg-url', `url("${url}")`);
        // notify settings/other components
        const w = window?.top ?? window;
        w.dispatchEvent(new CustomEvent('tasks-bg-changed', {
            detail: { theme: this._theme, url },
            bubbles: true, composed: true,
        }));
    }
    // ── Filter helpers ─────────────────────────────────────────────────────
    _getFilterOptions() {
        const allTasks = [...this.activeTasks, ...this.closedTasks];
        const tagSet = new Set();
        const pmaSet = new Set();
        for (const t of allTasks) {
            t.tags?.forEach(tag => tagSet.add(tag));
            if (t.taskRoom?.pmaId)
                pmaSet.add(t.taskRoom.pmaId);
        }
        // Sort tags: known vocabulary order first, then alpha
        const vocabOrder = this.tagVocabulary.map(v => v.tag);
        const tags = [...tagSet].sort((a, b) => {
            const ai = vocabOrder.indexOf(a);
            const bi = vocabOrder.indexOf(b);
            if (ai >= 0 && bi >= 0)
                return ai - bi;
            if (ai >= 0)
                return -1;
            if (bi >= 0)
                return 1;
            return a.localeCompare(b);
        });
        return { tags, pmaIds: [...pmaSet].sort() };
    }
    _applyFilters(tasks) {
        if (this._filterTags.size === 0 && this._filterPmaIds.size === 0)
            return tasks;
        return tasks.filter(t => {
            const tagMatch = this._filterTags.size === 0
                || (t.tags?.some(tag => this._filterTags.has(tag)) ?? false);
            const pmaMatch = this._filterPmaIds.size === 0
                || (!!t.taskRoom?.pmaId && this._filterPmaIds.has(t.taskRoom.pmaId));
            return tagMatch && pmaMatch;
        });
    }
    _toggleTag(tag) {
        const next = new Set(this._filterTags);
        next.has(tag) ? next.delete(tag) : next.add(tag);
        this._filterTags = next;
    }
    _togglePmaId(pmaId) {
        const next = new Set(this._filterPmaIds);
        next.has(pmaId) ? next.delete(pmaId) : next.add(pmaId);
        this._filterPmaIds = next;
    }
    _clearFilters() {
        this._filterTags = new Set();
        this._filterPmaIds = new Set();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        const w = window?.top ?? window;
        w.removeEventListener('task-change', this._onTaskChange);
        w.removeEventListener('thread-change', this._onThreadChange);
        w.removeEventListener('task-meta-changed', this._onTaskMetaChanged);
        if (this._refetchTimer)
            clearTimeout(this._refetchTimer);
    }
    updated(changed) {
        super.updated(changed);
        if (this._initialFetchDone && changed.has('reloadKey')) {
            this._fetchAll();
        }
    }
    async _fetchAll() {
        this.loadingActive = true;
        this.loadingClosed = true;
        this.error = null;
        try {
            const [vocab, activeResult] = await Promise.all([
                loadTagVocabulary(this.organizationId, this.userId),
                msgListTasks({ userId: this.userId, view: 'active', pageSize: 200 }),
            ]);
            this.tagVocabulary = vocab;
            if (!activeResult.success) {
                this.error = activeResult.error ?? 'error';
                this.loadingActive = false;
                this.loadingClosed = false;
                return;
            }
            this.activeTasks = this._filterWorkflow(activeResult.response?.tasks ?? []);
            this.loadingActive = false;
            // Lazy: closed view
            this._fetchClosed();
        }
        catch (err) {
            this.error = err?.message ?? 'error';
            this.loadingActive = false;
            this.loadingClosed = false;
        }
    }
    async _fetchClosed() {
        this.loadingClosed = true;
        try {
            const result = await msgListTasks({ userId: this.userId, view: 'closed', pageSize: 100 });
            if (result.success) {
                this.closedTasks = this._filterWorkflow(result.response?.tasks ?? []);
            }
        }
        catch {
            // closed fetch errors are silent; keep what we had
        }
        this.loadingClosed = false;
    }
    _filterWorkflow(tasks) {
        return tasks.filter(t => {
            if (!t.taskRoom?.pmaId) {
                console.warn('[Board] non-workflow task slipped through:', t.PK);
                return false;
            }
            return true;
        });
    }
    _scheduleRefetch() {
        if (this._refetchTimer)
            clearTimeout(this._refetchTimer);
        this._refetchTimer = setTimeout(() => this._fetchAll(), 300);
    }
    _handleTaskChange(e) {
        const task = e.detail?.context?.task;
        if (!task) {
            this._scheduleRefetch();
            return;
        }
        if (!task.taskRoom?.pmaId)
            return;
        const isClosed = task.status === 'done' || task.status === 'failed';
        const activeIdx = this.activeTasks.findIndex(t => t.PK === task.PK);
        const closedIdx = this.closedTasks.findIndex(t => t.PK === task.PK);
        if (activeIdx >= 0) {
            if (isClosed) {
                this.activeTasks = this.activeTasks.filter(t => t.PK !== task.PK);
                this.closedTasks = [task, ...this.closedTasks];
            }
            else {
                const updated = [...this.activeTasks];
                updated[activeIdx] = task;
                this.activeTasks = updated;
            }
        }
        else if (closedIdx >= 0) {
            const updated = [...this.closedTasks];
            updated[closedIdx] = task;
            this.closedTasks = updated;
        }
        else {
            this._scheduleRefetch();
        }
    }
    _handleThreadChange(e) {
        const thread = e.detail;
        if (!thread?.threadId) {
            this._scheduleRefetch();
            return;
        }
        const threadId = thread.threadId;
        const activeIdx = this.activeTasks.findIndex(t => t.taskRoom?.threadId === threadId);
        const closedIdx = this.closedTasks.findIndex(t => t.taskRoom?.threadId === threadId);
        if (activeIdx < 0 && closedIdx < 0)
            return; // not our task
        this._scheduleRefetch();
    }
    _handleTaskMetaChanged(e) {
        const { taskId, taskTitle } = e.detail;
        const pk = `task/#${taskId}`;
        const activeIdx = this.activeTasks.findIndex(t => t.PK === pk);
        if (activeIdx >= 0) {
            const updated = [...this.activeTasks];
            updated[activeIdx] = { ...updated[activeIdx], title: taskTitle };
            this.activeTasks = updated;
            return;
        }
        const closedIdx = this.closedTasks.findIndex(t => t.PK === pk);
        if (closedIdx >= 0) {
            const updated = [...this.closedTasks];
            updated[closedIdx] = { ...updated[closedIdx], title: taskTitle };
            this.closedTasks = updated;
        }
    }
    _bucket() {
        const buckets = {
            'todo': [], 'in progress': [], 'paused': [], 'done': [], 'failed': [],
        };
        const filteredActive = this._applyFilters(this.activeTasks);
        const filteredClosed = this._applyFilters(this.closedTasks);
        for (const t of filteredActive) {
            if (t.status in buckets)
                buckets[t.status].push(t);
        }
        for (const t of filteredClosed) {
            if (t.status === 'done')
                buckets.done.push(t);
            else if (t.status === 'failed')
                buckets.failed.push(t);
        }
        return buckets;
    }
    render() {
        const m = getMsg();
        const header = html `
      <div class="board-header">
        <div class="board-header-left">
          <span class="board-header-title">${m.board}</span>
          <span class="board-header-sep">·</span>
          <span class="board-header-sub">${m.allProcesses}</span>
        </div>
        <div class="board-header-right">
          <button
            class="board-icon-btn ${this._showSettings ? 'active' : ''}"
            title="${m.appearance}"
            @click=${() => { this._showSettings = !this._showSettings; }}
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="3"></circle>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
            </svg>
          </button>
          <button
            class="board-icon-btn"
            title="${m.reload}"
            @click=${() => this._fetchAll()}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="23 4 23 10 17 10"></polyline>
              <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
            </svg>
          </button>
        </div>
      </div>
    `;
        if (this.error && this.activeTasks.length === 0 && this.closedTasks.length === 0) {
            return html `
        ${header}
        <div class="board-error">
          <span>${m.loadError}</span>
          <button class="board-error-retry" @click=${() => this._fetchAll()}>${m.retry}</button>
        </div>
      `;
        }
        const buckets = this._bucket();
        const totalActive = ALWAYS_COLUMNS.reduce((s, k) => s + buckets[k].length, 0);
        const hasFailed = buckets.failed.length > 0;
        const totalAll = totalActive + buckets.done.length + buckets.failed.length;
        const isLoading = this.loadingActive;
        const hasActiveFilters = this._filterTags.size > 0 || this._filterPmaIds.size > 0;
        if (!isLoading && !this.loadingClosed && totalAll === 0 && !hasActiveFilters) {
            return html `
        ${header}
        ${this._showSettings ? this._renderSettings(m) : nothing}
        <collab-tasks-empty-state-102025
          title=${m.boardEmptyTitle}
          subtitle=${m.boardEmptySubtitle}
        ></collab-tasks-empty-state-102025>
      `;
        }
        const columns = hasFailed ? [...ALWAYS_COLUMNS, 'failed'] : [...ALWAYS_COLUMNS];
        return html `
      ${header}
      ${this._showSettings ? this._renderSettings(m) : nothing}
      ${this._renderFilterBar(m)}
      ${this.error ? html `
        <div class="board-error">
          <span>${m.loadError}</span>
          <button class="board-error-retry" @click=${() => this._fetchAll()}>${m.retry}</button>
        </div>
      ` : nothing}
      ${!isLoading && totalAll === 0 && hasActiveFilters ? html `
        <div class="board-no-results">${m.noResults}</div>
      ` : nothing}
      <div class="board-columns">
        ${columns.map(status => this._renderColumn(status, buckets, m, isLoading, totalAll))}
      </div>
    `;
    }
    _renderFilterBar(m) {
        const { tags, pmaIds } = this._getFilterOptions();
        const hasFilters = this._filterTags.size > 0 || this._filterPmaIds.size > 0;
        // Only render if there are options to filter by
        if (tags.length === 0 && pmaIds.length === 0)
            return nothing;
        return html `
      <div class="filter-bar">
        ${tags.map(tag => {
            const vocab = this.tagVocabulary.find(v => v.tag === tag);
            const colorClass = vocab?.color ? `b-${vocab.color}` : 'b-neutral';
            const active = this._filterTags.has(tag);
            return html `
            <button
              class="filter-chip tag-filter ${active ? 'active' : ''} ${colorClass}"
              @click=${() => this._toggleTag(tag)}
              title="${m.filterByTag}: ${tag}"
            >
              <span class="chip-dot ${colorClass}"></span>
              ${tag}
            </button>
          `;
        })}

        ${tags.length > 0 && pmaIds.length > 0
            ? html `<div class="filter-sep" aria-hidden="true"></div>`
            : nothing}

        ${pmaIds.map(pmaId => {
            const active = this._filterPmaIds.has(pmaId);
            return html `
            <button
              class="filter-chip pma-filter ${active ? 'active' : ''}"
              @click=${() => this._togglePmaId(pmaId)}
              title="${m.filterByWorkflow}: ${pmaId}"
            >
              <svg width="10" height="10" viewBox="0 0 10 10" fill="none" class="chip-icon">
                <path d="M1 3h8M1 7h5" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/>
                <circle cx="8" cy="7" r="1.5" fill="currentColor" opacity=".7"/>
              </svg>
              ${pmaId}
            </button>
          `;
        })}

        ${hasFilters ? html `
          <button class="filter-clear" @click=${() => this._clearFilters()}>
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
              <path d="M2 2l6 6M8 2L2 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
            ${m.clearFilters}
          </button>
        ` : nothing}
      </div>
    `;
    }
    _renderSettings(m) {
        const lang = document.documentElement.lang ?? 'en';
        const bgUrl = loadThemeBgUrl(this._theme);
        return html `
      <div class="settings-panel">
        <div class="settings-panel-title">${m.themes}</div>
        ${renderThemeCards(this._theme, lang, (t) => this._setTheme(t))}
        ${THEME_BG_OPTIONS[this._theme]
            ? renderImagePicker(this._theme, bgUrl, lang, (url) => this._setBgImage(url))
            : nothing}
      </div>
    `;
    }
    _renderColumn(status, buckets, m, boardLoading, totalAll) {
        const tasks = buckets[status];
        const isClosedCol = status === 'done' || status === 'failed';
        const loading = isClosedCol ? this.loadingClosed : boardLoading;
        const skeletonCount = status === 'done' ? 1 : 3;
        const label = status === 'in progress' ? m.inProgress : m[status];
        const cssStatus = status.replace(' ', '-');
        return html `
      <div class="board-column status-${cssStatus}" aria-busy=${loading ? 'true' : 'false'}>
        <h2 class="col-header">
          <span class="col-dot"></span>
          <span class="col-label">${label}</span>
          <span class="col-count">${loading ? '…' : tasks.length}</span>
        </h2>
        <div class="col-stack">
          ${loading
            ? this._renderSkeletons(skeletonCount)
            : tasks.length === 0
                ? (totalAll > 0
                    ? html `<div class="col-empty">${m.emptyColumn}</div>`
                    : nothing)
                : tasks.map((task, i) => this._renderCard(task, status, i))}
        </div>
      </div>
    `;
    }
    _renderCard(task, status, index) {
        const delay = Math.min(index, STAGGER_CAP) * 30;
        return html `
      <collab-tasks-card-102025
        class="card-animate"
        style="animation-delay: ${delay}ms"
        .task=${task}
        .tagVocabulary=${this.tagVocabulary}
        .boardStatus=${status}
      ></collab-tasks-card-102025>
    `;
    }
    _renderSkeletons(count) {
        return Array.from({ length: count }, () => html `
      <div class="skeleton-card" aria-hidden="true">
        <div class="skeleton-line skeleton-title"></div>
        <div class="skeleton-line skeleton-meta"></div>
      </div>
    `);
    }
};
__decorate([
    property({ type: Number })
], CollabTasksBoard.prototype, "reloadKey", void 0);
__decorate([
    property({ type: String })
], CollabTasksBoard.prototype, "userId", void 0);
__decorate([
    property({ type: String })
], CollabTasksBoard.prototype, "organizationId", void 0);
__decorate([
    property({ type: String })
], CollabTasksBoard.prototype, "initialPmaFilter", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "activeTasks", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "closedTasks", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "tagVocabulary", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "loadingActive", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "loadingClosed", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "error", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "_theme", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "_showSettings", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "_filterTags", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "_filterPmaIds", void 0);
CollabTasksBoard = __decorate([
    customElement('collab-tasks-board-102025')
], CollabTasksBoard);
export { CollabTasksBoard };
