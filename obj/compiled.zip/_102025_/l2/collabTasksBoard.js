/// <mls fileReference="_102025_/l2/collabTasksBoard.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    todo: 'A fazer',
    inProgress: 'Em andamento',
    paused: 'Pausado',
    done: 'Concluído',
    failed: 'Falhou',
    emptyColumn: 'Nada por aqui ainda.',
    boardEmptyTitle: 'Sem tarefas de workflow.',
    boardEmptySubtitle: 'Crie uma com /createNewChat kai: <título> em qualquer thread.',
    loadError: 'Não consegui carregar as tarefas.',
    retry: 'Tentar de novo',
};
const message_en = {
    todo: 'To do',
    inProgress: 'In progress',
    paused: 'Paused',
    done: 'Done',
    failed: 'Failed',
    emptyColumn: 'Nothing here yet.',
    boardEmptyTitle: 'No workflow tasks yet.',
    boardEmptySubtitle: 'Create one with /createNewChat kai: <title> from any thread.',
    loadError: 'Could not load tasks.',
    retry: 'Retry',
};
/// **collab_i18n_end**
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { msgListTasks, msgGetOrgPreferences } from '/_102025_/l2/shared/api.js';
import '/_102025_/l2/collabTasksCard.js';
import '/_102025_/l2/collabTasksEmptyState.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
// ── Module-level tag vocabulary cache ─────────────────────────────────────
let _tagCache = null;
async function loadTagVocabulary(organizationId, userId) {
    if (_tagCache)
        return _tagCache;
    const result = await msgGetOrgPreferences({ organizationId, userId });
    if (result.success && result.response) {
        _tagCache = result.response.tagVocabulary ?? [];
    }
    else {
        _tagCache = [];
    }
    return _tagCache;
}
const ALWAYS_COLUMNS = ['todo', 'in progress', 'paused', 'done'];
const STAGGER_CAP = 8;
let CollabTasksBoard = class CollabTasksBoard extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-tasks-board-102025 {
  display: block;
  height: 100%;
  overflow: hidden;
  --status-todo-accent: #185fa5;
  --status-todo-soft-bg: #e6f1fb;
  --status-todo-text: #185fa5;
  --status-in-progress-accent: #854f0b;
  --status-in-progress-soft-bg: #faeeda;
  --status-in-progress-text: #854f0b;
  --status-paused-accent: #6b7280;
  --status-paused-soft-bg: #f3f4f6;
  --status-paused-text: #6b7280;
  --status-done-accent: #3b6d11;
  --status-done-soft-bg: #eaf3de;
  --status-done-text: #3b6d11;
  --status-failed-accent: #a32d2d;
  --status-failed-soft-bg: #fcebeb;
  --status-failed-text: #a32d2d;
}
@media (prefers-color-scheme: dark) {
  collab-tasks-board-102025 {
    --status-todo-soft-bg: rgba(12, 68, 124, 0.13);
    --status-todo-text: #85b7eb;
    --status-in-progress-soft-bg: rgba(99, 56, 6, 0.13);
    --status-in-progress-text: #fac775;
    --status-paused-soft-bg: rgba(255, 255, 255, 0.06);
    --status-paused-text: #9c9a92;
    --status-done-soft-bg: rgba(39, 80, 10, 0.13);
    --status-done-text: #97c459;
    --status-failed-soft-bg: rgba(121, 31, 31, 0.13);
    --status-failed-text: #f09595;
  }
}
collab-tasks-board-102025 .board-error {
  background: var(--color-background-danger, #fcebeb);
  color: var(--color-text-danger, #a32d2d);
  border-radius: 8px;
  padding: 10px 14px;
  margin: 16px 24px 0;
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 13px;
}
collab-tasks-board-102025 .board-error-retry {
  background: none;
  border: none;
  cursor: pointer;
  color: inherit;
  text-decoration: underline;
  font-size: 13px;
  padding: 0;
  flex-shrink: 0;
}
collab-tasks-board-102025 .board-columns {
  display: flex;
  flex-direction: row;
  gap: 16px;
  padding: 24px;
  height: 100%;
  box-sizing: border-box;
  overflow-x: auto;
  overflow-y: hidden;
}
collab-tasks-board-102025 .board-column {
  flex: 1 1 0;
  min-width: 260px;
  max-width: 360px;
  background: var(--color-background-secondary, #f9fafb);
  border: 1px solid var(--color-border, #e5e7eb);
  border-radius: 12px;
  padding: 12px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
collab-tasks-board-102025 h2.col-header {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 4px 8px;
  flex-shrink: 0;
  position: sticky;
  top: 0;
  margin: 0;
  font-size: inherit;
  font-weight: inherit;
}
collab-tasks-board-102025 .col-dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
}
collab-tasks-board-102025 .col-label {
  flex: 1;
  font-size: 13px;
  font-weight: 600;
  letter-spacing: 0.02em;
  text-transform: uppercase;
  color: var(--color-text-secondary, #6b7280);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
collab-tasks-board-102025 .col-count {
  font-size: 11px;
  font-weight: 600;
  padding: 2px 8px;
  border-radius: 9999px;
  flex-shrink: 0;
}
collab-tasks-board-102025 .status-todo .col-dot {
  background: var(--status-todo-accent);
}
collab-tasks-board-102025 .status-todo .col-count {
  background: var(--status-todo-soft-bg);
  color: var(--status-todo-text);
}
collab-tasks-board-102025 .status-in-progress .col-dot {
  background: var(--status-in-progress-accent);
}
collab-tasks-board-102025 .status-in-progress .col-count {
  background: var(--status-in-progress-soft-bg);
  color: var(--status-in-progress-text);
}
collab-tasks-board-102025 .status-paused .col-dot {
  background: var(--status-paused-accent);
}
collab-tasks-board-102025 .status-paused .col-count {
  background: var(--status-paused-soft-bg);
  color: var(--status-paused-text);
}
collab-tasks-board-102025 .status-done .col-dot {
  background: var(--status-done-accent);
}
collab-tasks-board-102025 .status-done .col-count {
  background: var(--status-done-soft-bg);
  color: var(--status-done-text);
}
collab-tasks-board-102025 .status-failed .col-dot {
  background: var(--status-failed-accent);
}
collab-tasks-board-102025 .status-failed .col-count {
  background: var(--status-failed-soft-bg);
  color: var(--status-failed-text);
}
collab-tasks-board-102025 .col-stack {
  display: flex;
  flex-direction: column;
  gap: 8px;
  overflow-y: auto;
  max-height: calc(100vh - 220px);
  padding-top: 8px;
  mask-image: linear-gradient(to bottom, transparent 0px, black 12px);
}
collab-tasks-board-102025 .col-empty {
  border: 1px dashed var(--color-border, #e5e7eb);
  border-radius: 8px;
  padding: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--color-text-tertiary, #9ca3af);
  font-size: 12px;
  text-align: center;
}
@keyframes shimmer {
  0% {
    background-position: -200% 0;
  }
  100% {
    background-position: 200% 0;
  }
}
collab-tasks-board-102025 .skeleton-card {
  background: var(--color-background-secondary, #f3f4f6);
  border: 1px solid var(--color-border, #e5e7eb);
  border-radius: 8px;
  padding: 10px 12px;
}
collab-tasks-board-102025 .skeleton-card .skeleton-line {
  border-radius: 4px;
  background: linear-gradient(90deg, var(--color-background-tertiary, #e5e7eb) 0%, rgba(255, 255, 255, 0.18) 50%, var(--color-background-tertiary, #e5e7eb) 100%);
  background-size: 200% 100%;
  animation: shimmer 1.4s ease-in-out infinite;
}
collab-tasks-board-102025 .skeleton-card .skeleton-title {
  width: 70%;
  height: 12px;
  margin-bottom: 8px;
}
collab-tasks-board-102025 .skeleton-card .skeleton-meta {
  width: 45%;
  height: 10px;
}
@keyframes card-enter {
  from {
    opacity: 0;
    transform: translateY(4px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
collab-tasks-board-102025 .card-animate {
  animation: card-enter 200ms ease-out both;
}
@media (prefers-reduced-motion: reduce) {
  collab-tasks-board-102025 .skeleton-card .skeleton-line {
    animation: none;
  }
  collab-tasks-board-102025 .card-animate {
    animation: none;
    opacity: 1;
  }
}
`);
        this.reloadKey = 0;
        this.userId = '';
        this.organizationId = 'collabcodes';
        this.activeTasks = [];
        this.closedTasks = [];
        this.tagVocabulary = [];
        this.loadingActive = true;
        this.loadingClosed = true;
        this.error = null;
        this._initialFetchDone = false;
        this._refetchTimer = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this._onTaskChange = (e) => this._handleTaskChange(e);
        this._onThreadChange = (e) => this._handleThreadChange(e);
        this._onTaskMetaChanged = (e) => this._handleTaskMetaChanged(e);
        const w = window?.top ?? window;
        w.addEventListener('task-change', this._onTaskChange);
        w.addEventListener('thread-change', this._onThreadChange);
        w.addEventListener('task-meta-changed', this._onTaskMetaChanged);
        this._fetchAll();
        this._initialFetchDone = true;
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        const w = window?.top ?? window;
        w.removeEventListener('task-change', this._onTaskChange);
        w.removeEventListener('thread-change', this._onThreadChange);
        w.removeEventListener('task-meta-changed', this._onTaskMetaChanged);
        if (this._refetchTimer)
            clearTimeout(this._refetchTimer);
    }
    updated(changed) {
        super.updated(changed);
        if (this._initialFetchDone && changed.has('reloadKey')) {
            this._fetchAll();
        }
    }
    async _fetchAll() {
        this.loadingActive = true;
        this.loadingClosed = true;
        this.error = null;
        try {
            const [vocab, activeResult] = await Promise.all([
                loadTagVocabulary(this.organizationId, this.userId),
                msgListTasks({ userId: this.userId, view: 'active', pageSize: 200 }),
            ]);
            this.tagVocabulary = vocab;
            if (!activeResult.success) {
                this.error = activeResult.error ?? 'error';
                this.loadingActive = false;
                this.loadingClosed = false;
                return;
            }
            this.activeTasks = this._filterWorkflow(activeResult.response?.tasks ?? []);
            this.loadingActive = false;
            // Lazy: closed view
            this._fetchClosed();
        }
        catch (err) {
            this.error = err?.message ?? 'error';
            this.loadingActive = false;
            this.loadingClosed = false;
        }
    }
    async _fetchClosed() {
        this.loadingClosed = true;
        try {
            const result = await msgListTasks({ userId: this.userId, view: 'closed', pageSize: 100 });
            if (result.success) {
                this.closedTasks = this._filterWorkflow(result.response?.tasks ?? []);
            }
        }
        catch {
            // closed fetch errors are silent; keep what we had
        }
        this.loadingClosed = false;
    }
    _filterWorkflow(tasks) {
        return tasks.filter(t => {
            if (!t.taskRoom?.pmaId) {
                console.warn('[Board] non-workflow task slipped through:', t.PK);
                return false;
            }
            return true;
        });
    }
    _scheduleRefetch() {
        if (this._refetchTimer)
            clearTimeout(this._refetchTimer);
        this._refetchTimer = setTimeout(() => this._fetchAll(), 300);
    }
    _handleTaskChange(e) {
        const task = e.detail?.context?.task;
        if (!task) {
            this._scheduleRefetch();
            return;
        }
        if (!task.taskRoom?.pmaId)
            return;
        const isClosed = task.status === 'done' || task.status === 'failed';
        const activeIdx = this.activeTasks.findIndex(t => t.PK === task.PK);
        const closedIdx = this.closedTasks.findIndex(t => t.PK === task.PK);
        if (activeIdx >= 0) {
            if (isClosed) {
                this.activeTasks = this.activeTasks.filter(t => t.PK !== task.PK);
                this.closedTasks = [task, ...this.closedTasks];
            }
            else {
                const updated = [...this.activeTasks];
                updated[activeIdx] = task;
                this.activeTasks = updated;
            }
        }
        else if (closedIdx >= 0) {
            const updated = [...this.closedTasks];
            updated[closedIdx] = task;
            this.closedTasks = updated;
        }
        else {
            this._scheduleRefetch();
        }
    }
    _handleThreadChange(e) {
        const thread = e.detail;
        if (!thread?.threadId) {
            this._scheduleRefetch();
            return;
        }
        const threadId = thread.threadId;
        const activeIdx = this.activeTasks.findIndex(t => t.taskRoom?.threadId === threadId);
        const closedIdx = this.closedTasks.findIndex(t => t.taskRoom?.threadId === threadId);
        if (activeIdx < 0 && closedIdx < 0)
            return; // not our task
        this._scheduleRefetch();
    }
    _handleTaskMetaChanged(e) {
        const { taskId, taskTitle } = e.detail;
        const pk = `task/#${taskId}`;
        const activeIdx = this.activeTasks.findIndex(t => t.PK === pk);
        if (activeIdx >= 0) {
            const updated = [...this.activeTasks];
            updated[activeIdx] = { ...updated[activeIdx], title: taskTitle };
            this.activeTasks = updated;
            return;
        }
        const closedIdx = this.closedTasks.findIndex(t => t.PK === pk);
        if (closedIdx >= 0) {
            const updated = [...this.closedTasks];
            updated[closedIdx] = { ...updated[closedIdx], title: taskTitle };
            this.closedTasks = updated;
        }
    }
    _bucket() {
        const buckets = {
            'todo': [], 'in progress': [], 'paused': [], 'done': [], 'failed': [],
        };
        for (const t of this.activeTasks) {
            if (t.status in buckets)
                buckets[t.status].push(t);
        }
        for (const t of this.closedTasks) {
            if (t.status === 'done')
                buckets.done.push(t);
            else if (t.status === 'failed')
                buckets.failed.push(t);
        }
        return buckets;
    }
    render() {
        const m = getMsg();
        if (this.error && this.activeTasks.length === 0 && this.closedTasks.length === 0) {
            return html `
        <div class="board-error">
          <span>${m.loadError}</span>
          <button class="board-error-retry" @click=${() => this._fetchAll()}>${m.retry}</button>
        </div>
      `;
        }
        const buckets = this._bucket();
        const totalActive = ALWAYS_COLUMNS.reduce((s, k) => s + buckets[k].length, 0);
        const hasFailed = buckets.failed.length > 0;
        const totalAll = totalActive + buckets.done.length + buckets.failed.length;
        const isLoading = this.loadingActive;
        if (!isLoading && !this.loadingClosed && totalAll === 0) {
            return html `
        <collab-tasks-empty-state-102025
          title=${m.boardEmptyTitle}
          subtitle=${m.boardEmptySubtitle}
        ></collab-tasks-empty-state-102025>
      `;
        }
        const columns = hasFailed ? [...ALWAYS_COLUMNS, 'failed'] : [...ALWAYS_COLUMNS];
        return html `
      ${this.error ? html `
        <div class="board-error">
          <span>${m.loadError}</span>
          <button class="board-error-retry" @click=${() => this._fetchAll()}>${m.retry}</button>
        </div>
      ` : nothing}
      <div class="board-columns">
        ${columns.map(status => this._renderColumn(status, buckets, m, isLoading, totalAll))}
      </div>
    `;
    }
    _renderColumn(status, buckets, m, boardLoading, totalAll) {
        const tasks = buckets[status];
        const isClosedCol = status === 'done' || status === 'failed';
        const loading = isClosedCol ? this.loadingClosed : boardLoading;
        const skeletonCount = status === 'done' ? 1 : 3;
        const label = status === 'in progress' ? m.inProgress : m[status];
        const cssStatus = status.replace(' ', '-');
        return html `
      <div class="board-column status-${cssStatus}" aria-busy=${loading ? 'true' : 'false'}>
        <h2 class="col-header">
          <span class="col-dot"></span>
          <span class="col-label">${label}</span>
          <span class="col-count">${loading ? '…' : tasks.length}</span>
        </h2>
        <div class="col-stack">
          ${loading
            ? this._renderSkeletons(skeletonCount)
            : tasks.length === 0
                ? (totalAll > 0
                    ? html `<div class="col-empty">${m.emptyColumn}</div>`
                    : nothing)
                : tasks.map((task, i) => this._renderCard(task, status, i))}
        </div>
      </div>
    `;
    }
    _renderCard(task, status, index) {
        const delay = Math.min(index, STAGGER_CAP) * 30;
        return html `
      <collab-tasks-card-102025
        class="card-animate"
        style="animation-delay: ${delay}ms"
        .task=${task}
        .tagVocabulary=${this.tagVocabulary}
        .boardStatus=${status}
      ></collab-tasks-card-102025>
    `;
    }
    _renderSkeletons(count) {
        return Array.from({ length: count }, () => html `
      <div class="skeleton-card" aria-hidden="true">
        <div class="skeleton-line skeleton-title"></div>
        <div class="skeleton-line skeleton-meta"></div>
      </div>
    `);
    }
};
__decorate([
    property({ type: Number })
], CollabTasksBoard.prototype, "reloadKey", void 0);
__decorate([
    property({ type: String })
], CollabTasksBoard.prototype, "userId", void 0);
__decorate([
    property({ type: String })
], CollabTasksBoard.prototype, "organizationId", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "activeTasks", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "closedTasks", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "tagVocabulary", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "loadingActive", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "loadingClosed", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "error", void 0);
CollabTasksBoard = __decorate([
    customElement('collab-tasks-board-102025')
], CollabTasksBoard);
export { CollabTasksBoard };
