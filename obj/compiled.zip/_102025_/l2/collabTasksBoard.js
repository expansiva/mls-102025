/// <mls fileReference="_102025_/l2/collabTasksBoard.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    todo: 'A fazer',
    inProgress: 'Em andamento',
    paused: 'Pausado',
    done: 'Concluído',
    failed: 'Falhou',
    emptyColumn: 'Nada por aqui ainda.',
    boardEmptyTitle: 'Sem tarefas de workflow.',
    boardEmptySubtitle: 'Crie uma com /createNewChat kai: <título> em qualquer thread.',
    loadError: 'Não consegui carregar as tarefas.',
    retry: 'Tentar de novo',
    board: 'Board',
    allProcesses: 'todos os processos',
    appearance: 'Aparência',
    themes: 'Tema do board',
    themeClean: 'Limpo',
    themeAmber: 'Âmbar',
    themeForest: 'Floresta',
    themeCleanDesc: 'Visual neutro e minimalista',
    themeAmberDesc: 'Tons quentes e aconchegantes',
    themeForestDesc: 'Natureza com imagem de fundo',
    reload: 'Recarregar',
};
const message_en = {
    todo: 'To do',
    inProgress: 'In progress',
    paused: 'Paused',
    done: 'Done',
    failed: 'Failed',
    emptyColumn: 'Nothing here yet.',
    boardEmptyTitle: 'No workflow tasks yet.',
    boardEmptySubtitle: 'Create one with /createNewChat kai: <title> from any thread.',
    loadError: 'Could not load tasks.',
    retry: 'Retry',
    board: 'Board',
    allProcesses: 'all processes',
    appearance: 'Appearance',
    themes: 'Board theme',
    themeClean: 'Clean',
    themeAmber: 'Amber',
    themeForest: 'Forest',
    themeCleanDesc: 'Neutral and minimal',
    themeAmberDesc: 'Warm and cozy tones',
    themeForestDesc: 'Nature background image',
    reload: 'Reload',
};
/// **collab_i18n_end**
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { msgListTasks, msgGetOrgPreferences } from '/_102025_/l2/shared/api.js';
import '/_102025_/l2/collabTasksCard.js';
import '/_102025_/l2/collabTasksEmptyState.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
// ── Module-level tag vocabulary cache ─────────────────────────────────────
let _tagCache = null;
async function loadTagVocabulary(organizationId, userId) {
    if (_tagCache)
        return _tagCache;
    const result = await msgGetOrgPreferences({ organizationId, userId });
    if (result.success && result.response) {
        _tagCache = result.response.tagVocabulary ?? [];
    }
    else {
        _tagCache = [];
    }
    return _tagCache;
}
const THEME_KEY = 'collab-board-theme';
const VALID_THEMES = ['clean', 'amber', 'forest'];
function loadTheme() {
    const saved = localStorage.getItem(THEME_KEY);
    return saved && VALID_THEMES.includes(saved) ? saved : 'clean';
}
const ALWAYS_COLUMNS = ['todo', 'in progress', 'paused', 'done'];
const STAGGER_CAP = 8;
let CollabTasksBoard = class CollabTasksBoard extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-tasks-board-102025 {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  --status-todo-accent: #185fa5;
  --status-todo-soft-bg: #e6f1fb;
  --status-todo-text: #185fa5;
  --status-in-progress-accent: #854f0b;
  --status-in-progress-soft-bg: #faeeda;
  --status-in-progress-text: #854f0b;
  --status-paused-accent: #6b7280;
  --status-paused-soft-bg: #f3f4f6;
  --status-paused-text: #6b7280;
  --status-done-accent: #3b6d11;
  --status-done-soft-bg: #eaf3de;
  --status-done-text: #3b6d11;
  --status-failed-accent: #a32d2d;
  --status-failed-soft-bg: #fcebeb;
  --status-failed-text: #a32d2d;
  --board-bg: transparent;
  --board-col-bg: var(--color-background-secondary, #f5f4f0);
  --board-col-border: var(--color-border-tertiary, rgba(0, 0, 0, 0.08));
  --board-col-text: var(--color-text-secondary, #5f5e5a);
  --board-header-bg: var(--color-background-primary, #ffffff);
  --board-header-border: var(--color-border-tertiary, rgba(0, 0, 0, 0.08));
  --board-card-bg: var(--color-background-primary, #ffffff);
  --board-card-border: var(--color-border-tertiary, rgba(0, 0, 0, 0.08));
}
@media (prefers-color-scheme: dark) {
  collab-tasks-board-102025 {
    --status-todo-soft-bg: rgba(12, 68, 124, 0.13);
    --status-todo-text: #85b7eb;
    --status-in-progress-soft-bg: rgba(99, 56, 6, 0.13);
    --status-in-progress-text: #fac775;
    --status-paused-soft-bg: rgba(255, 255, 255, 0.06);
    --status-paused-text: #9c9a92;
    --status-done-soft-bg: rgba(39, 80, 10, 0.13);
    --status-done-text: #97c459;
    --status-failed-soft-bg: rgba(121, 31, 31, 0.13);
    --status-failed-text: #f09595;
  }
}
collab-tasks-board-102025 .board-header {
  display: flex;
  align-items: center;
  height: 44px;
  padding: 0 16px;
  gap: 8px;
  flex-shrink: 0;
  background: var(--board-header-bg);
  border-bottom: 0.5px solid var(--board-header-border);
  z-index: 10;
}
collab-tasks-board-102025 .board-header-left {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: 1;
  min-width: 0;
}
collab-tasks-board-102025 .board-header-title {
  font-size: 14px;
  font-weight: 500;
  color: var(--color-text-primary, #1a1a18);
  white-space: nowrap;
}
collab-tasks-board-102025 .board-header-sep {
  font-size: 13px;
  color: var(--color-text-tertiary, #888780);
}
collab-tasks-board-102025 .board-header-sub {
  font-size: 12px;
  color: var(--color-text-tertiary, #888780);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
collab-tasks-board-102025 .board-header-right {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
}
collab-tasks-board-102025 .board-icon-btn {
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: none;
  border: 0.5px solid transparent;
  border-radius: 7px;
  cursor: pointer;
  color: var(--color-text-tertiary, #888780);
  transition: background 0.12s, border-color 0.12s, color 0.12s;
}
collab-tasks-board-102025 .board-icon-btn:hover {
  background: var(--color-background-secondary, #f5f4f0);
  border-color: var(--board-col-border);
  color: var(--color-text-secondary, #5f5e5a);
}
collab-tasks-board-102025 .board-icon-btn.active {
  background: var(--color-background-secondary, #f5f4f0);
  border-color: var(--board-col-border);
  color: var(--color-text-primary, #1a1a18);
}
collab-tasks-board-102025 .settings-panel {
  padding: 12px 16px;
  border-bottom: 0.5px solid var(--board-header-border);
  background: var(--board-header-bg);
  flex-shrink: 0;
  animation: panel-slide-down 140ms ease-out both;
}
@keyframes panel-slide-down {
  from {
    opacity: 0;
    transform: translateY(-6px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
collab-tasks-board-102025 .settings-panel-title {
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--color-text-tertiary, #888780);
  margin-bottom: 10px;
}
collab-tasks-board-102025 .settings-theme-grid {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}
collab-tasks-board-102025 .settings-theme-card {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 6px;
  width: 140px;
  padding: 8px 10px;
  border: 0.5px solid var(--board-col-border);
  border-radius: 10px;
  cursor: pointer;
  background: var(--board-col-bg);
  transition: border-color 0.12s, box-shadow 0.12s;
}
collab-tasks-board-102025 .settings-theme-card:hover {
  border-color: var(--color-border-secondary, rgba(0, 0, 0, 0.18));
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}
collab-tasks-board-102025 .settings-theme-card.selected {
  border-color: var(--status-todo-accent, #185fa5);
  box-shadow: 0 0 0 1.5px var(--status-todo-accent, #185fa5) inset;
}
collab-tasks-board-102025 .theme-preview {
  border-radius: 4px;
  overflow: hidden;
}
collab-tasks-board-102025 .theme-info {
  display: flex;
  flex-direction: column;
  gap: 1px;
}
collab-tasks-board-102025 .theme-name {
  font-size: 12px;
  font-weight: 500;
  color: var(--color-text-primary, #1a1a18);
}
collab-tasks-board-102025 .theme-desc {
  font-size: 10px;
  color: var(--color-text-tertiary, #888780);
  line-height: 1.3;
}
collab-tasks-board-102025 .theme-check {
  position: absolute;
  top: 6px;
  right: 6px;
  color: var(--status-todo-accent, #185fa5);
  display: flex;
  align-items: center;
  justify-content: center;
}
collab-tasks-board-102025 .board-error {
  background: var(--color-background-danger, #fcebeb);
  color: var(--color-text-danger, #a32d2d);
  border-radius: 8px;
  padding: 10px 14px;
  margin: 12px 16px 0;
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 13px;
  flex-shrink: 0;
}
collab-tasks-board-102025 .board-error-retry {
  background: none;
  border: none;
  cursor: pointer;
  color: inherit;
  text-decoration: underline;
  font-size: 13px;
  padding: 0;
  flex-shrink: 0;
}
collab-tasks-board-102025 .board-columns {
  display: flex;
  flex-direction: row;
  gap: 10px;
  padding: 14px 16px;
  flex: 1;
  box-sizing: border-box;
  overflow-x: auto;
  overflow-y: hidden;
  background: var(--board-bg);
}
collab-tasks-board-102025 .board-column {
  flex: 1 1 0;
  min-width: 220px;
  max-width: 320px;
  background: var(--board-col-bg);
  border: 0.5px solid var(--board-col-border);
  border-radius: 10px;
  padding: 10px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
collab-tasks-board-102025 h2.col-header {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 34px;
  padding: 0 6px 6px;
  flex-shrink: 0;
  margin: 0;
  font-size: inherit;
  font-weight: inherit;
  border-bottom: 0.5px solid var(--board-col-border);
  margin-bottom: 2px;
}
collab-tasks-board-102025 .col-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  flex-shrink: 0;
}
collab-tasks-board-102025 .col-label {
  flex: 1;
  font-size: 11px;
  font-weight: 500;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--board-col-text);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
collab-tasks-board-102025 .col-count {
  font-size: 10px;
  font-weight: 500;
  padding: 1px 6px;
  border-radius: 8px;
  flex-shrink: 0;
}
collab-tasks-board-102025 .status-todo .col-dot {
  background: var(--status-todo-accent);
}
collab-tasks-board-102025 .status-todo .col-count {
  background: var(--status-todo-soft-bg);
  color: var(--status-todo-text);
}
collab-tasks-board-102025 .status-in-progress .col-dot {
  background: var(--status-in-progress-accent);
}
collab-tasks-board-102025 .status-in-progress .col-count {
  background: var(--status-in-progress-soft-bg);
  color: var(--status-in-progress-text);
}
collab-tasks-board-102025 .status-paused .col-dot {
  background: var(--status-paused-accent);
}
collab-tasks-board-102025 .status-paused .col-count {
  background: var(--status-paused-soft-bg);
  color: var(--status-paused-text);
}
collab-tasks-board-102025 .status-done .col-dot {
  background: var(--status-done-accent);
}
collab-tasks-board-102025 .status-done .col-count {
  background: var(--status-done-soft-bg);
  color: var(--status-done-text);
}
collab-tasks-board-102025 .status-failed .col-dot {
  background: var(--status-failed-accent);
}
collab-tasks-board-102025 .status-failed .col-count {
  background: var(--status-failed-soft-bg);
  color: var(--status-failed-text);
}
collab-tasks-board-102025 .col-stack {
  display: flex;
  flex-direction: column;
  gap: 6px;
  overflow-y: auto;
  flex: 1;
  padding-top: 8px;
  padding-bottom: 4px;
}
collab-tasks-board-102025 .col-empty {
  border: 0.5px dashed var(--board-col-border);
  border-radius: 7px;
  padding: 14px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--color-text-tertiary, #9ca3af);
  font-size: 11px;
  text-align: center;
}
@keyframes shimmer {
  0% {
    background-position: -200% 0;
  }
  100% {
    background-position: 200% 0;
  }
}
collab-tasks-board-102025 .skeleton-card {
  background: var(--board-card-bg);
  border: 0.5px solid var(--board-col-border);
  border-radius: 8px;
  padding: 10px 12px;
}
collab-tasks-board-102025 .skeleton-card .skeleton-line {
  border-radius: 4px;
  background: linear-gradient(90deg, var(--color-background-secondary, #eceae3) 0%, rgba(255, 255, 255, 0.18) 50%, var(--color-background-secondary, #eceae3) 100%);
  background-size: 200% 100%;
  animation: shimmer 1.4s ease-in-out infinite;
}
collab-tasks-board-102025 .skeleton-card .skeleton-title {
  width: 70%;
  height: 11px;
  margin-bottom: 8px;
}
collab-tasks-board-102025 .skeleton-card .skeleton-meta {
  width: 45%;
  height: 9px;
}
@keyframes card-enter {
  from {
    opacity: 0;
    transform: translateY(4px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
collab-tasks-board-102025 .card-animate {
  animation: card-enter 200ms ease-out both;
}
@media (prefers-reduced-motion: reduce) {
  collab-tasks-board-102025 .skeleton-card .skeleton-line {
    animation: none;
  }
  collab-tasks-board-102025 .card-animate {
    animation: none;
    opacity: 1;
  }
  collab-tasks-board-102025 .settings-panel {
    animation: none;
  }
}
collab-tasks-board-102025.theme-amber {
  --board-bg: #f5e8cc;
  --board-col-bg: #fdf4e3;
  --board-col-border: rgba(120, 68, 8, 0.22);
  --board-col-text: #4a2f07;
  --board-header-bg: #f0ddb5;
  --board-header-border: rgba(120, 68, 8, 0.22);
  --board-card-bg: #fffcf5;
}
collab-tasks-board-102025.theme-amber .board-header-title {
  color: #2e1a02;
}
collab-tasks-board-102025.theme-amber .board-header-sep {
  color: #8a5a1c;
}
collab-tasks-board-102025.theme-amber .board-header-sub {
  color: #7a4f18;
}
collab-tasks-board-102025.theme-amber .board-icon-btn {
  color: #7a4f18;
}
collab-tasks-board-102025.theme-amber .board-icon-btn:hover,
collab-tasks-board-102025.theme-amber .board-icon-btn.active {
  background: rgba(120, 68, 8, 0.1);
  border-color: rgba(120, 68, 8, 0.28);
  color: #2e1a02;
}
collab-tasks-board-102025.theme-amber .col-label {
  color: #4a2f07;
}
collab-tasks-board-102025.theme-amber .col-empty {
  border-color: rgba(120, 68, 8, 0.22);
  color: #7a5a2e;
}
collab-tasks-board-102025.theme-amber .settings-panel {
  background: #f0ddb5;
  border-color: rgba(120, 68, 8, 0.22);
}
collab-tasks-board-102025.theme-amber .settings-panel-title {
  color: #7a4f18;
}
collab-tasks-board-102025.theme-amber .settings-theme-card {
  background: #fdf4e3;
  border-color: rgba(120, 68, 8, 0.2);
}
collab-tasks-board-102025.theme-amber .settings-theme-card .theme-name {
  color: #2e1a02;
}
collab-tasks-board-102025.theme-amber .settings-theme-card .theme-desc {
  color: #7a5a2e;
}
collab-tasks-board-102025.theme-amber .settings-theme-card:hover {
  border-color: rgba(120, 68, 8, 0.38);
}
@media (prefers-color-scheme: dark) {
  collab-tasks-board-102025.theme-amber {
    --board-bg: #1e1508;
    --board-col-bg: rgba(133, 79, 11, 0.18);
    --board-col-border: rgba(240, 163, 50, 0.16);
    --board-col-text: #f5c97a;
    --board-header-bg: #160f04;
    --board-header-border: rgba(240, 163, 50, 0.14);
    --board-card-bg: rgba(133, 79, 11, 0.12);
  }
}
collab-tasks-board-102025.theme-forest {
  --board-bg: radial-gradient(ellipse at 10% 80%, rgba(34, 197, 94, 0.08) 0%, transparent 55%), radial-gradient(ellipse at 90% 20%, rgba(16, 185, 129, 0.06) 0%, transparent 45%), linear-gradient(160deg, #0f2316 0%, #162b1b 50%, #0d1f12 100%);
  --board-col-bg: rgba(255, 255, 255, 0.07);
  --board-col-border: rgba(255, 255, 255, 0.09);
  --board-col-text: rgba(200, 240, 210, 0.7);
  --board-header-bg: rgba(15, 35, 22, 0.96);
  --board-header-border: rgba(255, 255, 255, 0.08);
  --board-card-bg: rgba(255, 255, 255, 0.08);
  --status-todo-accent: #58a5e0;
  --status-todo-soft-bg: rgba(88, 165, 224, 0.15);
  --status-todo-text: #85c4f5;
  --status-in-progress-accent: #f0a83a;
  --status-in-progress-soft-bg: rgba(240, 168, 58, 0.15);
  --status-in-progress-text: #fac775;
  --status-paused-accent: #9ca3af;
  --status-paused-soft-bg: rgba(255, 255, 255, 0.07);
  --status-paused-text: #9c9a92;
  --status-done-accent: #4ade80;
  --status-done-soft-bg: rgba(74, 222, 128, 0.15);
  --status-done-text: #86efac;
  --status-failed-accent: #f87171;
  --status-failed-soft-bg: rgba(248, 113, 113, 0.15);
  --status-failed-text: #fca5a5;
}
collab-tasks-board-102025.theme-forest .board-header-title {
  color: rgba(220, 255, 230, 0.92);
}
collab-tasks-board-102025.theme-forest .board-header-sep,
collab-tasks-board-102025.theme-forest .board-header-sub {
  color: rgba(180, 220, 195, 0.5);
}
collab-tasks-board-102025.theme-forest .board-icon-btn {
  color: rgba(180, 220, 195, 0.55);
}
collab-tasks-board-102025.theme-forest .board-icon-btn:hover,
collab-tasks-board-102025.theme-forest .board-icon-btn.active {
  background: rgba(255, 255, 255, 0.08);
  border-color: rgba(255, 255, 255, 0.12);
  color: rgba(220, 255, 230, 0.9);
}
collab-tasks-board-102025.theme-forest .col-label {
  color: rgba(200, 240, 210, 0.65);
}
collab-tasks-board-102025.theme-forest .col-empty {
  border-color: rgba(255, 255, 255, 0.08);
  color: rgba(180, 220, 195, 0.4);
}
collab-tasks-board-102025.theme-forest .board-columns {
  background: var(--board-bg);
  background-attachment: local;
}
collab-tasks-board-102025.theme-forest .settings-panel {
  background: rgba(15, 35, 22, 0.96);
  border-color: rgba(255, 255, 255, 0.08);
}
collab-tasks-board-102025.theme-forest .settings-panel-title {
  color: rgba(180, 220, 195, 0.5);
}
collab-tasks-board-102025.theme-forest .settings-theme-card {
  background: rgba(255, 255, 255, 0.06);
  border-color: rgba(255, 255, 255, 0.1);
}
collab-tasks-board-102025.theme-forest .settings-theme-card .theme-name {
  color: rgba(220, 255, 230, 0.9);
}
collab-tasks-board-102025.theme-forest .settings-theme-card .theme-desc {
  color: rgba(180, 220, 195, 0.5);
}
collab-tasks-board-102025.theme-forest .settings-theme-card:hover {
  border-color: rgba(255, 255, 255, 0.2);
}
collab-tasks-board-102025.theme-forest .skeleton-card {
  background: rgba(255, 255, 255, 0.05);
}
collab-tasks-board-102025.theme-forest .skeleton-card .skeleton-line {
  background: linear-gradient(90deg, rgba(255, 255, 255, 0.06) 0%, rgba(255, 255, 255, 0.12) 50%, rgba(255, 255, 255, 0.06) 100%);
  background-size: 200% 100%;
}
`);
        this.reloadKey = 0;
        this.userId = '';
        this.organizationId = 'collabcodes';
        this.activeTasks = [];
        this.closedTasks = [];
        this.tagVocabulary = [];
        this.loadingActive = true;
        this.loadingClosed = true;
        this.error = null;
        this._theme = 'clean';
        this._showSettings = false;
        this._initialFetchDone = false;
        this._refetchTimer = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this._theme = loadTheme();
        this._applyThemeClass();
        this._onTaskChange = (e) => this._handleTaskChange(e);
        this._onThreadChange = (e) => this._handleThreadChange(e);
        this._onTaskMetaChanged = (e) => this._handleTaskMetaChanged(e);
        const w = window?.top ?? window;
        w.addEventListener('task-change', this._onTaskChange);
        w.addEventListener('thread-change', this._onThreadChange);
        w.addEventListener('task-meta-changed', this._onTaskMetaChanged);
        this._fetchAll();
        this._initialFetchDone = true;
    }
    _applyThemeClass() {
        VALID_THEMES.forEach(t => this.classList.remove(`theme-${t}`));
        this.classList.add(`theme-${this._theme}`);
    }
    _setTheme(theme) {
        this._theme = theme;
        localStorage.setItem(THEME_KEY, theme);
        this._applyThemeClass();
        this._showSettings = false;
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        const w = window?.top ?? window;
        w.removeEventListener('task-change', this._onTaskChange);
        w.removeEventListener('thread-change', this._onThreadChange);
        w.removeEventListener('task-meta-changed', this._onTaskMetaChanged);
        if (this._refetchTimer)
            clearTimeout(this._refetchTimer);
    }
    updated(changed) {
        super.updated(changed);
        if (this._initialFetchDone && changed.has('reloadKey')) {
            this._fetchAll();
        }
    }
    async _fetchAll() {
        this.loadingActive = true;
        this.loadingClosed = true;
        this.error = null;
        try {
            const [vocab, activeResult] = await Promise.all([
                loadTagVocabulary(this.organizationId, this.userId),
                msgListTasks({ userId: this.userId, view: 'active', pageSize: 200 }),
            ]);
            this.tagVocabulary = vocab;
            if (!activeResult.success) {
                this.error = activeResult.error ?? 'error';
                this.loadingActive = false;
                this.loadingClosed = false;
                return;
            }
            this.activeTasks = this._filterWorkflow(activeResult.response?.tasks ?? []);
            this.loadingActive = false;
            // Lazy: closed view
            this._fetchClosed();
        }
        catch (err) {
            this.error = err?.message ?? 'error';
            this.loadingActive = false;
            this.loadingClosed = false;
        }
    }
    async _fetchClosed() {
        this.loadingClosed = true;
        try {
            const result = await msgListTasks({ userId: this.userId, view: 'closed', pageSize: 100 });
            if (result.success) {
                this.closedTasks = this._filterWorkflow(result.response?.tasks ?? []);
            }
        }
        catch {
            // closed fetch errors are silent; keep what we had
        }
        this.loadingClosed = false;
    }
    _filterWorkflow(tasks) {
        return tasks.filter(t => {
            if (!t.taskRoom?.pmaId) {
                console.warn('[Board] non-workflow task slipped through:', t.PK);
                return false;
            }
            return true;
        });
    }
    _scheduleRefetch() {
        if (this._refetchTimer)
            clearTimeout(this._refetchTimer);
        this._refetchTimer = setTimeout(() => this._fetchAll(), 300);
    }
    _handleTaskChange(e) {
        const task = e.detail?.context?.task;
        if (!task) {
            this._scheduleRefetch();
            return;
        }
        if (!task.taskRoom?.pmaId)
            return;
        const isClosed = task.status === 'done' || task.status === 'failed';
        const activeIdx = this.activeTasks.findIndex(t => t.PK === task.PK);
        const closedIdx = this.closedTasks.findIndex(t => t.PK === task.PK);
        if (activeIdx >= 0) {
            if (isClosed) {
                this.activeTasks = this.activeTasks.filter(t => t.PK !== task.PK);
                this.closedTasks = [task, ...this.closedTasks];
            }
            else {
                const updated = [...this.activeTasks];
                updated[activeIdx] = task;
                this.activeTasks = updated;
            }
        }
        else if (closedIdx >= 0) {
            const updated = [...this.closedTasks];
            updated[closedIdx] = task;
            this.closedTasks = updated;
        }
        else {
            this._scheduleRefetch();
        }
    }
    _handleThreadChange(e) {
        const thread = e.detail;
        if (!thread?.threadId) {
            this._scheduleRefetch();
            return;
        }
        const threadId = thread.threadId;
        const activeIdx = this.activeTasks.findIndex(t => t.taskRoom?.threadId === threadId);
        const closedIdx = this.closedTasks.findIndex(t => t.taskRoom?.threadId === threadId);
        if (activeIdx < 0 && closedIdx < 0)
            return; // not our task
        this._scheduleRefetch();
    }
    _handleTaskMetaChanged(e) {
        const { taskId, taskTitle } = e.detail;
        const pk = `task/#${taskId}`;
        const activeIdx = this.activeTasks.findIndex(t => t.PK === pk);
        if (activeIdx >= 0) {
            const updated = [...this.activeTasks];
            updated[activeIdx] = { ...updated[activeIdx], title: taskTitle };
            this.activeTasks = updated;
            return;
        }
        const closedIdx = this.closedTasks.findIndex(t => t.PK === pk);
        if (closedIdx >= 0) {
            const updated = [...this.closedTasks];
            updated[closedIdx] = { ...updated[closedIdx], title: taskTitle };
            this.closedTasks = updated;
        }
    }
    _bucket() {
        const buckets = {
            'todo': [], 'in progress': [], 'paused': [], 'done': [], 'failed': [],
        };
        for (const t of this.activeTasks) {
            if (t.status in buckets)
                buckets[t.status].push(t);
        }
        for (const t of this.closedTasks) {
            if (t.status === 'done')
                buckets.done.push(t);
            else if (t.status === 'failed')
                buckets.failed.push(t);
        }
        return buckets;
    }
    render() {
        const m = getMsg();
        const header = html `
      <div class="board-header">
        <div class="board-header-left">
          <span class="board-header-title">${m.board}</span>
          <span class="board-header-sep">·</span>
          <span class="board-header-sub">${m.allProcesses}</span>
        </div>
        <div class="board-header-right">
          <button
            class="board-icon-btn ${this._showSettings ? 'active' : ''}"
            title="${m.appearance}"
            @click=${() => { this._showSettings = !this._showSettings; }}
          >
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="12" r="3"></circle>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
            </svg>
          </button>
          <button
            class="board-icon-btn"
            title="${m.reload}"
            @click=${() => this._fetchAll()}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="23 4 23 10 17 10"></polyline>
              <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
            </svg>
          </button>
        </div>
      </div>
    `;
        if (this.error && this.activeTasks.length === 0 && this.closedTasks.length === 0) {
            return html `
        ${header}
        <div class="board-error">
          <span>${m.loadError}</span>
          <button class="board-error-retry" @click=${() => this._fetchAll()}>${m.retry}</button>
        </div>
      `;
        }
        const buckets = this._bucket();
        const totalActive = ALWAYS_COLUMNS.reduce((s, k) => s + buckets[k].length, 0);
        const hasFailed = buckets.failed.length > 0;
        const totalAll = totalActive + buckets.done.length + buckets.failed.length;
        const isLoading = this.loadingActive;
        if (!isLoading && !this.loadingClosed && totalAll === 0) {
            return html `
        ${header}
        ${this._showSettings ? this._renderSettings(m) : nothing}
        <collab-tasks-empty-state-102025
          title=${m.boardEmptyTitle}
          subtitle=${m.boardEmptySubtitle}
        ></collab-tasks-empty-state-102025>
      `;
        }
        const columns = hasFailed ? [...ALWAYS_COLUMNS, 'failed'] : [...ALWAYS_COLUMNS];
        return html `
      ${header}
      ${this._showSettings ? this._renderSettings(m) : nothing}
      ${this.error ? html `
        <div class="board-error">
          <span>${m.loadError}</span>
          <button class="board-error-retry" @click=${() => this._fetchAll()}>${m.retry}</button>
        </div>
      ` : nothing}
      <div class="board-columns">
        ${columns.map(status => this._renderColumn(status, buckets, m, isLoading, totalAll))}
      </div>
    `;
    }
    _renderSettings(m) {
        const themes = [
            {
                id: 'clean',
                label: m.themeClean,
                desc: m.themeCleanDesc,
                preview: `
          <div style="display:flex;gap:3px;height:28px">
            <div style="flex:1;background:#f5f4f0;border-radius:3px"></div>
            <div style="flex:1;background:#eceae3;border-radius:3px"></div>
            <div style="flex:1;background:#f5f4f0;border-radius:3px"></div>
          </div>
        `,
            },
            {
                id: 'amber',
                label: m.themeAmber,
                desc: m.themeAmberDesc,
                preview: `
          <div style="display:flex;gap:3px;height:28px">
            <div style="flex:1;background:#faeeda;border-radius:3px"></div>
            <div style="flex:1;background:#f5e4c3;border-radius:3px"></div>
            <div style="flex:1;background:#faeeda;border-radius:3px"></div>
          </div>
        `,
            },
            {
                id: 'forest',
                label: m.themeForest,
                desc: m.themeForestDesc,
                preview: `
          <div style="display:flex;gap:3px;height:28px;background:linear-gradient(135deg,#0f2316 0%,#1a3a1f 100%);border-radius:3px;padding:3px">
            <div style="flex:1;background:rgba(255,255,255,0.10);border-radius:2px"></div>
            <div style="flex:1;background:rgba(255,255,255,0.07);border-radius:2px"></div>
            <div style="flex:1;background:rgba(255,255,255,0.10);border-radius:2px"></div>
          </div>
        `,
            },
        ];
        return html `
      <div class="settings-panel">
        <div class="settings-panel-title">${m.themes}</div>
        <div class="settings-theme-grid">
          ${themes.map(t => html `
            <div
              class="settings-theme-card ${this._theme === t.id ? 'selected' : ''}"
              @click=${() => this._setTheme(t.id)}
            >
              <div class="theme-preview" .innerHTML=${t.preview}></div>
              <div class="theme-info">
                <span class="theme-name">${t.label}</span>
                <span class="theme-desc">${t.desc}</span>
              </div>
              ${this._theme === t.id ? html `
                <span class="theme-check">
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                    <circle cx="6" cy="6" r="6" fill="currentColor"/>
                    <path d="M3.5 6l1.8 1.8 3-3" stroke="white" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </span>
              ` : nothing}
            </div>
          `)}
        </div>
      </div>
    `;
    }
    _renderColumn(status, buckets, m, boardLoading, totalAll) {
        const tasks = buckets[status];
        const isClosedCol = status === 'done' || status === 'failed';
        const loading = isClosedCol ? this.loadingClosed : boardLoading;
        const skeletonCount = status === 'done' ? 1 : 3;
        const label = status === 'in progress' ? m.inProgress : m[status];
        const cssStatus = status.replace(' ', '-');
        return html `
      <div class="board-column status-${cssStatus}" aria-busy=${loading ? 'true' : 'false'}>
        <h2 class="col-header">
          <span class="col-dot"></span>
          <span class="col-label">${label}</span>
          <span class="col-count">${loading ? '…' : tasks.length}</span>
        </h2>
        <div class="col-stack">
          ${loading
            ? this._renderSkeletons(skeletonCount)
            : tasks.length === 0
                ? (totalAll > 0
                    ? html `<div class="col-empty">${m.emptyColumn}</div>`
                    : nothing)
                : tasks.map((task, i) => this._renderCard(task, status, i))}
        </div>
      </div>
    `;
    }
    _renderCard(task, status, index) {
        const delay = Math.min(index, STAGGER_CAP) * 30;
        return html `
      <collab-tasks-card-102025
        class="card-animate"
        style="animation-delay: ${delay}ms"
        .task=${task}
        .tagVocabulary=${this.tagVocabulary}
        .boardStatus=${status}
      ></collab-tasks-card-102025>
    `;
    }
    _renderSkeletons(count) {
        return Array.from({ length: count }, () => html `
      <div class="skeleton-card" aria-hidden="true">
        <div class="skeleton-line skeleton-title"></div>
        <div class="skeleton-line skeleton-meta"></div>
      </div>
    `);
    }
};
__decorate([
    property({ type: Number })
], CollabTasksBoard.prototype, "reloadKey", void 0);
__decorate([
    property({ type: String })
], CollabTasksBoard.prototype, "userId", void 0);
__decorate([
    property({ type: String })
], CollabTasksBoard.prototype, "organizationId", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "activeTasks", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "closedTasks", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "tagVocabulary", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "loadingActive", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "loadingClosed", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "error", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "_theme", void 0);
__decorate([
    state()
], CollabTasksBoard.prototype, "_showSettings", void 0);
CollabTasksBoard = __decorate([
    customElement('collab-tasks-board-102025')
], CollabTasksBoard);
export { CollabTasksBoard };
