/// <mls fileReference="_102025_/l2/collabMessagesUserModal.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { createThreadDM, getDmThreadByUsers } from '/_102025_/l2/collabMessagesHelper.js';
import { dispatchThreadOpen } from '/_102025_/l2/collabMessagesEvents.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    messageDirect: 'Ir para direct message',
};
const message_en = {
    loading: 'Loading...',
    messageDirect: 'Go to direct message',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesUserModal = class CollabMessagesUserModal extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-user-modal-102025 {
  z-index: 9999;
  position: absolute;
}
collab-messages-user-modal-102025 .collab-messages-user-modal-box {
  background: var(--surface-alt-bg);
  color: var(--text-default);
  border-radius: 8px;
  padding: 16px;
  width: 280px;
  font-family: sans-serif;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
}
collab-messages-user-modal-102025 .collab-messages-user-modal-header {
  display: flex;
  align-items: center;
  margin-bottom: 12px;
}
collab-messages-user-modal-102025 .collab-messages-user-modal-avatar {
  width: 48px;
  height: 48px;
  border-radius: 4px;
  margin-right: 12px;
}
collab-messages-user-modal-102025 .collab-messages-user-modal-userName {
  font-weight: bold;
  font-size: var(--font-size-16);
}
collab-messages-user-modal-102025 .collab-messages-user-modal-userId {
  font-size: var(--font-size-12);
  color: var(--text-muted);
}
collab-messages-user-modal-102025 .collab-messages-user-modal-userStatus {
  margin-top: 0.5rem;
  font-size: var(--font-size-12);
  color: var(--text-muted);
}
collab-messages-user-modal-102025 .collab-messages-user-modal-userStatus.active {
  color: var(--status-success-text);
}
collab-messages-user-modal-102025 .user-message-error {
  color: var(--status-error-text);
  font-size: var(--font-size-12);
  display: flex;
  align-items: center;
}
collab-messages-user-modal-102025 .user-message-error svg {
  margin-right: 0.3rem;
  width: 12px;
  fill: var(--status-error-text);
}
collab-messages-user-modal-102025 .collab-messages-user-modal-actions {
  display: flex;
  gap: 8px;
}
collab-messages-user-modal-102025 .collab-messages-user-modal-actions .loader {
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid #ccc;
  border-top: 2px solid #333;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
collab-messages-user-modal-102025 .collab-messages-user-modal-actions a {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  padding: 6px 8px;
  cursor: pointer;
  font-size: 14px;
  text-decoration: underline;
}
collab-messages-user-modal-102025 .collab-messages-user-modal-actions a svg {
  fill: currentColor;
}
collab-messages-user-modal-102025 .collab-messages-user-modal-actions a[aria-disabled='true'] {
  cursor: wait;
  opacity: 0.7;
  pointer-events: none;
}
collab-messages-user-modal-102025 .collab-messages-user-modal-message-btn {
  color: var(--selected-text);
}
`);
        this.msg = messages['en'];
        this.open = true;
        this.isDirectMessage = false;
        this.isLoading = false;
        this.errorMessage = '';
        this.handleGlobalClick = (e) => {
            if (!this.contains(e.target)) {
                this.destroy();
            }
        };
    }
    close() {
        this.open = false;
    }
    firstUpdated() {
        document.addEventListener('click', this.handleGlobalClick);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        document.removeEventListener('click', this.handleGlobalClick);
    }
    destroy() {
        this.remove();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.open)
            return null;
        return html `
        <div class="collab-messages-user-modal-box"
            @mouseover=${(e) => e.stopPropagation()}
            @mouseleave=${(e) => { e.stopPropagation(); this.destroy(); }}
            @click=${(e) => e.stopPropagation()}
        >
            <div class="collab-messages-user-modal-header">
            <img class="collab-messages-user-modal-avatar" src=${this.user?.avatar_url} alt=${this.user?.name} />
                <div>
                    <div class="collab-messages-user-modal-userName">${this.user?.name}<span class="collab-messages-user-modal-userId"> (${this.user?.userId})</span></div>
                    <div class="collab-messages-user-modal-userStatus ${this.user?.status}"> ● ${this.user?.status}</div>
                </div>
            </div>

            ${this.errorMessage ? html `<small class="user-message-error">${this.errorMessage}<small>` : ''}

            ${this.actualUserId !== this.user?.userId && !this.isDirectMessage ?
            html `    
                <div class="collab-messages-user-modal-actions">
                    <a
                        href="#"
                        @click=${this.onClickUserAction} 
                        class="collab-messages-user-modal-message-btn"
                        aria-disabled=${this.isLoading ? 'true' : 'false'}
                    >
                        ${this.isLoading ? html `<span class="loader"></span>` : this.msg.messageDirect}
                    </a>
                </div>` : ''}
        
        </div>
    
    `;
    }
    async onClickUserAction(e) {
        e.preventDefault();
        if (this.isLoading)
            return;
        if (!this.actualUserId || !this.user)
            return;
        this.isLoading = true;
        try {
            let thread = await getDmThreadByUsers(this.actualUserId, this.user.userId);
            if (!thread) {
                const threadName = `@${this.user.name}`;
                thread = await createThreadDM(threadName, this.user.userId, 'CONNECT');
            }
            this.destroy();
            if (thread)
                dispatchThreadOpen(thread?.threadId);
        }
        catch (err) {
            this.errorMessage = err.message;
        }
        finally {
            this.isLoading = false;
        }
        ;
    }
};
__decorate([
    property({ type: Boolean })
], CollabMessagesUserModal.prototype, "open", void 0);
__decorate([
    property()
], CollabMessagesUserModal.prototype, "user", void 0);
__decorate([
    property()
], CollabMessagesUserModal.prototype, "actualUserId", void 0);
__decorate([
    property({ type: Boolean })
], CollabMessagesUserModal.prototype, "isDirectMessage", void 0);
__decorate([
    state()
], CollabMessagesUserModal.prototype, "isLoading", void 0);
__decorate([
    state()
], CollabMessagesUserModal.prototype, "errorMessage", void 0);
CollabMessagesUserModal = __decorate([
    customElement('collab-messages-user-modal-102025')
], CollabMessagesUserModal);
export { CollabMessagesUserModal };
