/// <mls fileReference="_102025_/l2/collabMessagesHumanDmApi.ts" enhancement="_blank" />
import { post } from '/_102036_/l2/shared/api.js';
const ERROR_CODES = new Set([
    'not_found',
    'self',
    'schema',
    'not_human',
    'legacy_ambiguous',
    'archived',
    'pair_corrupt',
    'storage_unavailable',
    'contention_exhausted',
    'unknown_outcome',
    'incompatible',
]);
function isRecord(value) {
    return typeof value === 'object' && value !== null;
}
function textOf(reply) {
    const msg = typeof reply.msg === 'string' ? reply.msg : '';
    const message = typeof reply.message === 'string' ? reply.message : '';
    return msg || message;
}
function isUnknownAction(text) {
    return /unknown action|invalid action/i.test(text);
}
function asErrorCode(value) {
    return typeof value === 'string' && ERROR_CODES.has(value)
        ? value
        : undefined;
}
function fail(code, message) {
    return { ok: false, code, message: message || code };
}
function pairMatches(users, userId, recipientUserId) {
    if (!Array.isArray(users) || users.length !== 2)
        return false;
    const ids = users.map((user) => (isRecord(user) && typeof user.userId === 'string' ? user.userId : ''));
    if (ids.some((id) => id === ''))
        return false;
    const expected = new Set([userId, recipientUserId]);
    return new Set(ids).size === 2 && ids.every((id) => expected.has(id));
}
/**
 * Aceita a resposta só com HTTP 200, outcome created|existing e thread privada,
 * ativa, com exatamente os dois participantes. O resto é falha, inclusive 200
 * com erro de domínio e action desconhecida no backend antigo.
 */
export function validateHumanDmReply(reply, userId, recipientUserId) {
    if (!isRecord(reply)) {
        return fail('schema', 'invalid ensureHumanDm reply');
    }
    const text = textOf(reply);
    if (isUnknownAction(text)) {
        return fail('incompatible', text);
    }
    const statusCode = typeof reply.statusCode === 'number' ? reply.statusCode : undefined;
    const known = asErrorCode(reply.code);
    if (statusCode !== 200) {
        return fail(known && known !== 'incompatible' ? known : 'unknown_outcome', text);
    }
    const outcome = reply.outcome;
    if (outcome !== 'created' && outcome !== 'existing') {
        return fail(known ?? 'schema', text);
    }
    const thread = reply.thread;
    if (!isRecord(thread) || typeof thread.threadId !== 'string' || thread.threadId === '') {
        return fail('schema', text || 'thread missing');
    }
    if (thread.status !== 'active' || thread.visibility !== 'private' || !pairMatches(thread.users, userId, recipientUserId)) {
        return fail(known ?? 'schema', text || 'thread is not an active private pair');
    }
    return {
        ok: true,
        outcome,
        thread: thread,
    };
}
export async function msgEnsureHumanDm(args) {
    try {
        const reply = await post({
            action: 'ensureHumanDm',
            userId: args.userId,
            recipientUserId: args.recipientUserId,
            group: args.group,
        });
        return validateHumanDmReply(reply, args.userId, args.recipientUserId);
    }
    catch (error) {
        console.error('msgEnsureHumanDm', error);
        const message = error instanceof Error ? error.message : String(error);
        const statusCode = isRecord(error) && typeof error.statusCode === 'number' ? error.statusCode : undefined;
        return validateHumanDmReply({ statusCode, msg: message }, args.userId, args.recipientUserId);
    }
}
