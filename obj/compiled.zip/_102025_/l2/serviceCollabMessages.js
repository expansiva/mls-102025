/// <mls shortName="serviceCollabMessages" project="102025" enhancement="_100554_enhancementLitService" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, ifDefined } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { addCoachMark } from '/_100554_/l2/coachMarks';
import { listThreads, addThread, listUsers, updateUsers, getThread, cleanupThreads, listPoolings, getTask, getMessage } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { saveLastTab, loadLastTab, saveUserId, saveLastAlertTime, loadLastAlertTime } from "/_102025_/l2/collabMessagesHelper.js";
import { openService, changeFavIcon } from "/_100554_/l2/libCommom.js";
import { continuePoolingTask } from "/_100554_/l2/aiAgentOrchestration.js";
import { checkIfNotificationUnread } from '/_102025_/l2/collabMessagesSyncNotifications.js';
import { ServiceBase } from '/_100554_/l2/serviceBase.js';
import { collab_bell_slash, collab_xmark } from '/_102025_/l2/collabMessagesIcons.js';
import '/_102025_/l2/collabMessagesAdd.js';
import '/_102025_/l2/collabMessagesChat.js';
import '/_102025_/l2/collabMessagesTasks.js';
import '/_102025_/l2/collabMessagesApps.js';
import '/_102025_/l2/collabMessagesMoments.js';
import '/_102025_/l2/collabMessagesSettings.js';
import '/_102025_/l2/collabMessagesFindtask.js';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    crm: 'CRM',
    tasks: 'Tasks',
    docs: 'Docs',
    connect: 'Conectar',
    alertMsgTitle: 'Ative as notificações',
    alertMsgBody: 'Para não perder mensagens importantes, permita notificações no navegador.',
    moments: 'Moments',
    apps: 'Apps'
};
const message_en = {
    loading: 'Loading...',
    crm: 'CRM',
    tasks: 'Tasks',
    docs: 'Docs',
    connect: 'Connect',
    alertMsgTitle: 'Enable notifications',
    alertMsgBody: 'To avoid missing important messages, allow notifications in your browser.',
    moments: 'Moments',
    apps: 'Apps'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceCollabMessages = class ServiceCollabMessages extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-nav-3-service[data-service="_102025_serviceCollabMessages"] .tools collab-nav-3-menu-tools-link[key="toolAdd"] .icon-link{display:none}service-collab-messages-102025{display:block;position:relative;overflow-x:hidden !important}service-collab-messages-102025 .section-add{padding:1rem}service-collab-messages-102025 .alert-notification{position:relative;width:calc(100% - 2rem - 2px);z-index:999999;background:#e8f9e8;color:#111;border:1px solid #b4e2b4;padding:1rem;display:flex;align-items:center;gap:2rem}service-collab-messages-102025 .alert-notification>div{font-size:14px;display:flex;justify-content:space-between;flex-direction:column}service-collab-messages-102025 .alert-notification>svg{width:50px;height:50px;fill:currentColor}service-collab-messages-102025 .alert-notification button{position:absolute;top:10px;right:10px;background:none;border:none;font-size:18px;cursor:pointer}`);
        this.msg = messages['en'];
        this.dataLocal = { lastTab: 'CRM' };
        this.activeTab = 'CRM';
        this.activeScenerie = 'tabs';
        this.isLoadingThread = false;
        this.userThreads = {};
        this.showNotificationAlert = false;
        this.threadToOpen = '';
        this.taskToOpen = '';
        this.lastLevel = -1;
        this.groupSelected = 'CRM';
        this.details = {
            icon: '&#xf086',
            state: 'background',
            position: 'right',
            tooltip: 'Messages',
            visible: true,
            widget: '_102025_serviceCollabMessages',
            level: [0, 2, 3, 5]
        };
        this.menu = {
            title: '',
            main: {
                opReset: { text: 'Reset onboarding', icon: 'f2ea' },
                opSettings: { text: 'Settings', icon: 'f085' },
                opFindTask: { text: 'Find Task', icon: 'f002' },
                opAboutThis: 'About this content',
            },
            tools: {},
            tabs: {
                group: 'Mode',
                type: 'onlyicon',
                selected: ETabs.Loading,
                options: [
                    { text: this.msg.crm, icon: 'f095' },
                    { text: this.msg.tasks, icon: 'f0ae' },
                    { text: this.msg.connect, icon: 'f0c1' },
                    { text: this.msg.moments, icon: 'f1ea' },
                    { text: this.msg.apps, icon: 'f58d' },
                ]
            },
            onClickMain: this.onClickMain.bind(this),
            onClickTabs: this.onClickTabs.bind(this),
        };
        this.isFirstEnter = true;
        this.onThreadChange = async (e) => {
            const customEvent = e;
            const thread = customEvent.detail;
            this.userThreads[thread.threadId].thread = thread;
            if (this.groupSelected !== 'CONNECT') {
                this.checkNotificationPending();
            }
        };
        this.onThreadCreate = async (e) => {
            const customEvent = e;
            const thread = customEvent.detail;
            if (!thread)
                return;
            this.userThreads[thread.threadId] = {
                thread: thread,
                users: []
            };
            this.requestUpdate();
        };
    }
    onClickTabs(index) {
        this.threadToOpen = '';
        this.taskToOpen = '';
        if (this.activeTab === ETabs[index]) {
            this.activeTab = 'Loading';
            setTimeout(() => {
                this.activeTab = ETabs[index];
            }, 0);
            return;
        }
        ;
        this.activeTab = ETabs[index];
        if (this.level === 7 && this.activeTab === 'APPS')
            return;
        saveLastTab(this.activeTab);
    }
    onClickMain(op) {
        if (op === 'opAboutThis')
            this.showAboutThis();
        if (op === 'opReset')
            this.resetOnBoarding();
        if (op === 'opSettings')
            this.openSettings();
        if (op === 'opFindTask')
            this.openFindTask();
    }
    onServiceClick(visible, reinit, el) {
        if (visible) {
            this.checkNotificationPermission();
            this.configureByLevel();
        }
    }
    async connectedCallback() {
        super.connectedCallback();
        if (this.level === 7) {
            this.dataLocal.lastTab = 'APPS';
        }
        else
            this.dataLocal.lastTab = loadLastTab();
        this.setEvents();
    }
    disconnectedCallback() {
        this.removeEvents();
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        window.addEventListener('thread-change', this.onThreadChange.bind(this));
        this.startPendentsPoolingsIfNeeded();
        this.checkNotificationPending();
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('activeTab') && ['CRM', 'TASK', 'DOCS', 'CONNECT', 'APPS'].includes(this.activeTab)) {
            if (!this.userPerfil) {
                this.userPerfil = await this.getUser();
                saveUserId(this.userPerfil.userId);
                await cleanupThreads(this.userPerfil.threads);
            }
            await this.getThreadFromLocalDB();
            this.updateThreads();
        }
        if (changedProperties.has('dataLocal')) {
            if (this.menu.setTabActive && this.activeTab !== 'Loading')
                this.menu.setTabActive(ETabs[this.dataLocal.lastTab]);
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return this.renderTabs();
    }
    changeDisplayMenu(show) {
        if (!this.nav3Menu)
            return;
        const item = this.nav3Menu?.querySelector('li[data-key="4"]');
        if (!item)
            return;
        if (show)
            item.style.display = 'inline-flex';
        else
            item.style.display = 'none';
    }
    configureByLevel() {
        if (!this.menu || !this.menu.tabs)
            return;
        if (this.level === 7 && this.lastLevel !== 7) {
            this.changeDisplayMenu(true);
        }
        if (this.lastLevel === 7 && this.level !== 7 && this.menu.setTabActive) {
            this.changeDisplayMenu(false);
            if (this.isFirstEnter) {
                this.isFirstEnter = false;
                this.menu.setTabActive(ETabs[loadLastTab()]);
            }
            else if (this.activeTab === 'APPS')
                this.menu.setTabActive(ETabs[loadLastTab()]);
            else
                this.menu.setTabActive(ETabs[this.activeTab]);
        }
        this.lastLevel = this.level;
    }
    checkNotificationPermission() {
        if (typeof Notification === "undefined" || Notification.permission !== "denied") {
            return;
        }
        const lastShown = Number(loadLastAlertTime() || 0);
        const now = Date.now();
        const oneWeek = 7 * 24 * 60 * 60 * 1000;
        if (!lastShown || (now - lastShown) > oneWeek) {
            this.showNotificationAlert = true;
            saveLastAlertTime(now);
        }
    }
    async startPendentsPoolingsIfNeeded() {
        const pendingsTasks = await listPoolings();
        if (!pendingsTasks || pendingsTasks.length === 0)
            return;
        for (let taskPending of pendingsTasks) {
            const task = await getTask(taskPending.taskId);
            if (!task || !task.messageid_created)
                continue;
            const message = await getMessage(task.messageid_created);
            if (!message)
                continue;
            const context = { message, task, isTest: false };
            await continuePoolingTask(context);
        }
    }
    showAboutThis() {
        const div = document.createElement('div');
        div.style.padding = '1rem';
        let name = 'nothing selected';
        switch (this.activeTab) {
            case 'CRM':
                name = 'collab-messages-chat-102025';
                break;
            case 'TASK':
                name = 'collab-messages-tasks-102025';
                break;
            case 'APPS':
                name = 'collab-messages-apps-102025';
                break;
            case 'MOMENTS':
                name = 'collab-messages-moments-102025';
                break;
            case 'CONNECT':
                name = 'collab-messages-chat-102025';
                break;
            default:
                name = 'nothing selected';
        }
        div.innerHTML = `
        
            <h3>About this content</h3>
            <ul>
                <li>Reference: ${name}</li>
                <li>Level: ${this.level}</li>
                <li>Position: ${this.position}</li>
            </ul>
        `;
        if (this.menu.setMode)
            this.menu.setMode('page', div);
        return true;
    }
    setEvents() {
        mls.events.addEventListener([0, 1, 2, 3, 4, 5, 6, 7], ['collabMessages'], this.onCollabEventsCollabMessages.bind(this));
        window.addEventListener('thread-create', this.onThreadCreate);
    }
    removeEvents() {
        window.removeEventListener('thread-create', this.onThreadCreate);
        window.removeEventListener('thread-change', this.onThreadChange.bind(this));
        mls.events.removeEventListener([0, 1, 2, 3, 4, 5, 6, 7], ['collabMessages'], this.onCollabEventsCollabMessages.bind(this));
    }
    renderTabs() {
        switch (this.activeTab) {
            case 'CRM':
                return this.renderCRM();
            case 'TASK':
                return this.renderTasks();
            case 'MOMENTS':
                return this.renderMoments();
            case 'APPS':
                return this.renderApps();
            case 'CONNECT':
                return this.renderConnect();
            case 'Loading':
                return html `${this.msg.loading}`;
            default:
                return html ``;
        }
    }
    renderAlert() {
        if (!this.showNotificationAlert)
            return html ``;
        return html `  
            <div class="alert-notification">
                ${collab_bell_slash}
                <div>
                    <strong>${this.msg.alertMsgTitle}</strong><br>
                    ${this.msg.alertMsgBody}
                <div>
                
                <button @click=${this.onAlertClose}>${collab_xmark}</button>
            </div>
        `;
    }
    onAlertClose() {
        this.showNotificationAlert = false;
    }
    renderCRM() {
        this.groupSelected = 'CRM';
        // this.execCoachMarks('CRM');
        return html `
        ${this.renderAlert()}
        <collab-messages-chat-102025 
            .isLoadingThread= ${this.isLoadingThread}
            group="CRM"
            .userThreads=${{
            CRM: Object.keys(this.userThreads)
                .filter((key) => this.userThreads[key].thread.group === 'CRM')
                .map((key) => this.userThreads[key])
        }} 
            .allThreads=${Object.keys(this.userThreads).map((key) => this.userThreads[key].thread)}
            
            userId=${this.userPerfil?.userId} 
        ></collab-messages-chat-102025>`;
    }
    renderTasks() {
        this.groupSelected = 'TASK';
        // this.execCoachMarks('Tasks');
        return html `<collab-messages-tasks-102025></collab-messages-tasks-102025>`;
    }
    renderMoments() {
        this.groupSelected = 'MOMENTS';
        // this.execCoachMarks('Moments');
        return html `<collab-messages-moments-102025 ></collab-messages-moments-102025>`;
    }
    renderApps() {
        this.groupSelected = 'APPS';
        // this.execCoachMarks('Apps');
        return html `<collab-messages-apps-102025 ></collab-messages-apps-102025>`;
    }
    renderConnect() {
        this.groupSelected = 'CONNECT';
        // this.execCoachMarks('Connect');
        return html `
        ${this.renderAlert()}
        <collab-messages-chat-102025 
            
            .isLoadingThread= ${this.isLoadingThread}
            group="CONNECT"
            .userThreads=${{
            CONNECT: Object.keys(this.userThreads)
                .filter((key) => this.userThreads[key].thread.group === 'CONNECT')
                .map((key) => this.userThreads[key])
        }}
            .allThreads=${Object.keys(this.userThreads).map((key) => this.userThreads[key].thread)}
            threadToOpen=${ifDefined(this.threadToOpen || undefined)}
            taskToOpen=${ifDefined(this.taskToOpen || undefined)}

            userId=${this.userPerfil?.userId} 
        ></collab-messages-chat-102025>`;
    }
    async getUser() {
        try {
            const response = await mls.api.msgGetUserUpdate({ userId: "" });
            return response.user;
        }
        catch (err) {
            this.setError(err.message);
            throw new Error(err.message);
        }
    }
    async updateThreads() {
        if (!this.userPerfil?.userId) {
            this.setError('Invalid userId');
            return;
        }
        this.isLoadingThread = true;
        const userId = this.userPerfil.userId;
        const userThreads = this.userPerfil.threads;
        for await (let threadId of userThreads) {
            if (this.userThreads[threadId]) {
                continue;
            }
            const threadInfo = await this.getThreadInfo(threadId, userId);
            this.userThreads[threadId] = threadInfo;
            addThread(threadInfo.thread);
            updateUsers(threadInfo.users);
        }
        this.isLoadingThread = false;
        this.requestUpdate();
    }
    async getThreadFromLocalDB() {
        const threads = await listThreads();
        const users = await listUsers();
        for (let thread of threads) {
            if (this.userThreads[thread.threadId]) {
                return;
            }
            const threadUsers = [];
            thread.users.forEach((user) => {
                const userDB = users.find((us) => us.userId === user.userId);
                if (userDB)
                    threadUsers.push(userDB);
            });
            this.userThreads[thread.threadId] = {
                thread: thread,
                users: threadUsers
            };
        }
    }
    async getThreadInfo(threadId, userId) {
        try {
            const response = await mls.api.msgGetThreadUpdate({
                threadId,
                userId
            });
            return response;
        }
        catch (err) {
            this.setError('Erro ao buscar threads: ' + err);
            throw new Error(err.message);
        }
    }
    execCoachMarks(name) {
        if (this.visible === 'false')
            return;
        const infoMark = {
            key: `serviceCollabMessage${name}`,
            transparency: "normal",
            fontSize: "1.1em",
            timeClose: 15,
            steps: [
                {
                    elementRef: `collab-nav-3-menu li[data-tooltip="${name}"]`,
                    text: `<div style="padding:1rem;"><img src="/100554/l3/assets/coachMarkCollabMessages${name}.png"  style="display: block; max-width: 100%; height: auto;"></img></div>`,
                    position: "bottom",
                    marginV: 25,
                    marginH: 25,
                    arrow: "up",
                    duration: 15,
                    autoClose: true,
                },
            ]
        };
        addCoachMark(infoMark);
    }
    resetOnBoarding() {
        const ls = localStorage.getItem('coach-marks-100554');
        if (!ls)
            return;
        const data = JSON.parse(ls);
        ['CRM', 'Tasks', 'Docs', 'Connect', 'Apps'].forEach((tab) => {
            const indexToRemove = data.findIndex((item) => item === `serviceCollabMessage${tab}`);
            if (indexToRemove !== -1) {
                data.splice(indexToRemove, 1);
            }
        });
        localStorage.setItem('coach-marks-100554', JSON.stringify(data));
        if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    openSettings() {
        if (this.menu.setTabActive)
            this.menu.setTabActive(-1);
        if (this.menu.setMode) {
            const settings = document.createElement('collab-messages-settings-102025');
            settings['serviceBase'] = this;
            this.menu.setMode('page', settings);
        }
        return true;
    }
    openFindTask() {
        if (this.menu.setTabActive)
            this.menu.setTabActive(-1);
        if (this.menu.setMode) {
            const settings = document.createElement('collab-messages-findtask-102025');
            settings['serviceBase'] = this;
            this.menu.setMode('page', settings);
        }
        return true;
    }
    async onCollabEventsCollabMessages(ev) {
        if (!ev.desc)
            return;
        this.threadToOpen = '';
        this.taskToOpen = '';
        try {
            const data = JSON.parse(ev.desc);
            if (data.type === 'thread-open') {
                if (!data.threadId)
                    return;
                const thread = await getThread(data.threadId);
                if (!thread)
                    return;
                if (data.taskId)
                    this.taskToOpen = data.taskId;
                openService('_102025_serviceCollabMessages', 'left', ev.level);
                const group = thread.group;
                this.threadToOpen = thread.threadId;
                if (group !== this.activeTab)
                    this.activeTab = group;
            }
        }
        catch (err) {
            console.error(err.message);
        }
    }
    async checkNotificationPending() {
        const hasPendingMessages = await checkIfNotificationUnread();
        if (hasPendingMessages) {
            changeFavIcon(true);
            this.toogleBadge(true, '_102025_serviceCollabMessages');
        }
    }
};
__decorate([
    property()
], ServiceCollabMessages.prototype, "dataLocal", void 0);
__decorate([
    property()
], ServiceCollabMessages.prototype, "activeTab", void 0);
__decorate([
    property()
], ServiceCollabMessages.prototype, "activeScenerie", void 0);
__decorate([
    state()
], ServiceCollabMessages.prototype, "isLoadingThread", void 0);
__decorate([
    state()
], ServiceCollabMessages.prototype, "userPerfil", void 0);
__decorate([
    state()
], ServiceCollabMessages.prototype, "userThreads", void 0);
__decorate([
    state()
], ServiceCollabMessages.prototype, "showNotificationAlert", void 0);
__decorate([
    state()
], ServiceCollabMessages.prototype, "threadToOpen", void 0);
__decorate([
    state()
], ServiceCollabMessages.prototype, "taskToOpen", void 0);
__decorate([
    state()
], ServiceCollabMessages.prototype, "lastLevel", void 0);
ServiceCollabMessages = __decorate([
    customElement('service-collab-messages-102025')
], ServiceCollabMessages);
export { ServiceCollabMessages };
var ETabs;
(function (ETabs) {
    ETabs[ETabs["CRM"] = 0] = "CRM";
    ETabs[ETabs["TASK"] = 1] = "TASK";
    ETabs[ETabs["CONNECT"] = 2] = "CONNECT";
    ETabs[ETabs["MOMENTS"] = 3] = "MOMENTS";
    ETabs[ETabs["APPS"] = 4] = "APPS";
    ETabs[ETabs["Add"] = 5] = "Add";
    ETabs[ETabs["Loading"] = 6] = "Loading";
})(ETabs || (ETabs = {}));
