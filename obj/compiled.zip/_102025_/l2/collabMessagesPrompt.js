/// <mls fileReference="_102025_/l2/collabMessagesPrompt.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, ifDefined } from 'lit';
import { customElement, property, state, query, } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { collab_arrow_up_long } from '/_102025_/l2/collabMessagesIcons.js';
import { getThread, listUsers } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { emojiList } from '/_102025_/l2/collabMessagesEmojis.js';
import '/_102025_/l2/collabMessagesAvatar.js';
let CollabMessagesPrompt = class CollabMessagesPrompt extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-prompt-102025{display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5}collab-messages-prompt-102025 .wrapper{display:flex;align-items:center;background-color:var(--grey-color-light);padding:8px 4px;box-shadow:0 2px 4px rgba(0,0,0,0.1);border-top-left-radius:12px;border-top-right-radius:12px}collab-messages-prompt-102025 .wrapper textarea{padding:4px 4px;border:1px solid #d1d1d1;background-color:#fff;color:#000;font-size:14px;transition:border-color .3s ease;width:100%;border-radius:8px;outline:none;overflow-y:auto;resize:none;max-height:200px;min-height:40px;line-height:1.2}collab-messages-prompt-102025 .wrapper button{margin-left:8px;padding:10px 12px;border:none;border-radius:9999px;background-color:#ddd;color:#fff;font-size:16px;cursor:pointer;transition:background-color .3s ease}collab-messages-prompt-102025 .wrapper button:disabled{background-color:#e0e0e0;cursor:not-allowed}collab-messages-prompt-102025 .mention-suggestions{position:absolute;left:5%;right:0;background-color:#fff;border:1px solid #ccc;z-index:10;display:block;width:200px;border-radius:10px;padding:0;margin:0;list-style:none;font-size:var(--font-size-12);max-height:150px;overflow:auto}collab-messages-prompt-102025 .mention-suggestions li{color:#000000;display:flex;padding:5px 10px;cursor:pointer}collab-messages-prompt-102025 .mention-suggestions li collab-messages-avatar-102025{width:30px}collab-messages-prompt-102025 .mention-suggestions li:first-child{border-top-left-radius:10px;border-top-right-radius:10px}collab-messages-prompt-102025 .mention-suggestions li:last-child{border-bottom-left-radius:10px;border-bottom-right-radius:10px}collab-messages-prompt-102025 .mention-suggestions li.active{background-color:#eee}collab-messages-prompt-102025 .mention{color:var(--active-color);font-weight:bold}collab-messages-prompt-102025 .special-mention{color:var(--info-color);font-weight:bold}collab-messages-prompt-102025 .emoji-suggestion{font-size:20px;line-height:1}collab-messages-prompt-102025 .emoji-code{color:#888;font-size:12px}collab-messages-prompt-102025 .agent-suggestion{font-weight:600;color:var(--active-color)}collab-messages-prompt-102025 .user-suggestion{font-weight:500;color:#333}collab-messages-prompt-102025 .formatted-text{white-space:pre-wrap;position:absolute;top:0;left:0;pointer-events:none;z-index:-1;font-family:'Arial',sans-serif;padding:8px;min-height:40px;width:100%}`);
        this.text = '';
        this.mentionActive = false;
        this.mentionQuery = '';
        this.mentionSuggestions = [];
        this.mentionIndex = 0;
        this.allUsers = [];
        this.allAgents = [];
        this.alreadyLoadingAgents = false;
        this.acceptAutoCompleteUser = false;
        this.acceptAutoCompleteAgents = false;
    }
    connectedCallback() {
        super.connectedCallback();
        window.visualViewport?.addEventListener("resize", () => {
            this.calculatePosition();
        });
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        this.adjustTextAreaHeight();
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('threadId')
            && this.threadId !== ''
            && this.threadId !== changedProperties.get('threadId')
            && this.acceptAutoCompleteUser) {
            this.getUsers();
        }
    }
    async getUsers() {
        if (!this.threadId)
            return;
        const thread = await getThread(this.threadId.trim());
        if (!thread)
            return;
        const users = await listUsers();
        this.allUsers = users;
    }
    async getAgents() {
        const agentsFiles = await this.getAgentsFiles();
        const agentsPublic = agentsFiles.map((agent) => {
            const { visibility, agentName, avatar_url, agentDescription, scope } = agent;
            if (visibility === 'public') {
                let inScope = this.scope ? false : true;
                if (this.scope && scope) {
                    inScope = scope.includes(this.scope);
                }
                if (!this.scope && scope)
                    inScope = false;
                if (inScope) {
                    return {
                        name: agentName,
                        description: agentDescription,
                        avatar_url,
                        alias: agentName.replace('agent', '')
                    };
                }
            }
        }).filter((item) => !!item);
        this.allAgents = agentsPublic;
    }
    getCaretCoordinates() {
        if (!this.textArea)
            return null;
        const div = document.createElement("div");
        const style = getComputedStyle(this.textArea);
        for (const prop of style) {
            div.style.setProperty(prop, style.getPropertyValue(prop));
        }
        div.style.position = "absolute";
        div.style.visibility = "hidden";
        div.style.whiteSpace = "pre-wrap";
        div.style.wordWrap = "break-word";
        div.style.overflow = "hidden";
        const text = this.textArea.value.substring(0, this.textArea.selectionStart);
        const span = document.createElement("span");
        span.textContent = "\u200b";
        div.textContent = text;
        div.appendChild(span);
        this.appendChild(div);
        const rect = span.getBoundingClientRect();
        const coords = { x: rect.left, y: rect.bottom };
        this.removeChild(div);
        return coords;
    }
    calculatePosition() {
        if (!this.mentionSuggestionsElement || !this.wrapper)
            return;
        const coords = this.getCaretCoordinates();
        const bound1 = this.wrapper.getBoundingClientRect();
        const bound2 = this.mentionSuggestionsElement.getBoundingClientRect();
        if (!coords)
            return;
        const viewport = window.visualViewport;
        let x = coords.x;
        let y = coords.y;
        if (viewport) {
            x = coords.x - viewport.offsetLeft;
            y = coords.y - viewport.offsetTop;
        }
        this.mentionSuggestionsElement.style.position = "fixed";
        this.mentionSuggestionsElement.style.left = `${x}px`;
        this.mentionSuggestionsElement.style.top = `${y - bound1.height - bound2.height - 4}px`;
    }
    adjustTextAreaHeight() {
        const maxHeight = 200;
        const minHeight = 40;
        if (this.textArea) {
            const prevHeight = this.textArea.offsetHeight;
            if (this.text === '') {
                this.textArea.style.height = `${minHeight}px`;
            }
            else {
                this.textArea.style.height = 'auto';
                this.textArea.style.height = Math.min(this.textArea.scrollHeight, maxHeight) + 'px';
            }
            const newHeight = this.textArea.offsetHeight;
            if (newHeight !== prevHeight) {
                this.dispatchEvent(new CustomEvent('textarea-resize', {
                    detail: {
                        height: newHeight
                    },
                    bubbles: true,
                    composed: true
                }));
            }
            this.calculatePosition();
        }
    }
    async getAgentsFiles() {
        const keys = Object.keys(mls.stor.files);
        const ret = [];
        for await (const k of keys) {
            if (k.indexOf('agent') < 0)
                continue;
            const file = mls.stor.files[k];
            const path = `/_${file.project}_${file.folder ? file.folder + '/' : ''}${file.shortName}`;
            if (file.extension !== '.ts' || !file.shortName.startsWith('agent'))
                continue;
            try {
                const mdl = await import(path);
                if (!mdl.createAgent)
                    continue;
                const agent = mdl.createAgent();
                ret.push(agent);
            }
            catch (err) {
                console.info(err);
                continue;
            }
        }
        return ret;
    }
    render() {
        return html `
            </div>
                <div class="wrapper">
                    <textarea
                        .value=${this.text}
                        @input=${this.handleInput}
                        @focus=${this.handleFocus}
                        @keydown=${this.handleKeyDown}
                        id="prompt_input"
                        placeholder="${ifDefined(this.placeholder)}">
                    </textarea>
                    <button @click=${this.handleSend}>${collab_arrow_up_long}</button>
                    ${this.mentionActive && this.mentionSuggestions.length > 0 ? html `
                        <ul class="mention-suggestions">
                            ${this.mentionSuggestions.map((s, i) => html `
                                <li
                                    class="${i === this.mentionIndex ? 'active' : ''}"
                                    title=${s.description}
                                    @click=${() => this.selectMention(s)}
                                >
                                    ${s.type === 'emoji' ? html `
                                    <span class="emoji-suggestion">${s.text}</span>
                                    <span class="emoji-code">:${s.value}:</span>
                                    ` : s.type === 'agent' ? html `
                                    ${s.avatar_url
            ? html `<collab-messages-avatar-102025 width="20px" height="20px" avatar=${s.avatar_url}></collab-messages-avatar-102025>`
            : ''}
                                    <span class="agent-suggestion">${s.text}</span>
                                    ` : s.type === 'user' ? html `
                                    ${s.avatar_url
            ? html `<collab-messages-avatar-102025 width="20px" height="20px" avatar=${s.avatar_url}></collab-messages-avatar-102025>`
            : ''}
                                    <span class="user-suggestion">${s.text}</span>
                                    ` : ''}
                                </li>
                                `)}
                        </ul>
                ` : ''}
        </div>`;
    }
    async handleFocus() {
        if (this.acceptAutoCompleteAgents &&
            (!this.alreadyLoadingAgents || this.scope !== this.lastScopeLoaded)) {
            this.lastScopeLoaded = this.scope;
            this.alreadyLoadingAgents = true;
            this.getAgents();
        }
    }
    async handleInput(e) {
        if (!e.target)
            return;
        const target = e.target;
        this.text = target.value;
        this.adjustTextAreaHeight();
        const cursorPos = target.selectionStart;
        const beforeCursor = this.text.slice(0, cursorPos);
        let suggestions = [];
        let query = '';
        const matchUser = beforeCursor.match(/(?:^|\s)@([a-zA-Z]*)$/);
        if (matchUser && this.acceptAutoCompleteUser) {
            query = matchUser[1];
            suggestions = this.getUserSuggestions(query);
        }
        const matchAgent = beforeCursor.match(/(?:^|\s)@@([a-zA-Z]*)$/);
        if (matchAgent && this.acceptAutoCompleteAgents) {
            query = matchAgent[1];
            suggestions = this.getAgentSuggestions(query);
        }
        const matchEmoji = beforeCursor.match(/::(\w+)$/);
        if (matchEmoji) {
            query = matchEmoji[1];
            suggestions = this.getEmojiSuggestions(query).slice(0, 10);
        }
        if (suggestions.length > 0) {
            this.mentionActive = true;
            this.mentionQuery = query;
            this.mentionSuggestions = suggestions;
            await this.updateComplete;
            this.calculatePosition();
        }
        else {
            this.mentionActive = false;
            this.mentionSuggestions = [];
            this.mentionQuery = '';
        }
    }
    getUserSuggestions(query) {
        return this.allUsers
            .filter(user => user.name.toLowerCase().startsWith(query.toLowerCase()))
            .map(user => ({
            avatar_url: user.avatar_url,
            text: user.name,
            value: user.name,
            description: user.name,
            type: 'user'
        }));
    }
    getAgentSuggestions(query) {
        return this.allAgents
            .filter(agent => agent.name.toLowerCase().startsWith(query.toLowerCase()) ||
            agent.alias.toLowerCase().startsWith(query.toLowerCase()))
            .map(agent => ({
            text: agent.alias,
            value: agent.name,
            description: agent.description,
            avatar_url: agent.avatar_url,
            type: 'agent'
        }));
    }
    getEmojiSuggestions(query) {
        // Remove :: caso o usuário tenha digitado junto e converte para lowercase
        const q = query.replace(/^::/, '').toLowerCase().trim();
        if (!q)
            return []; // se estiver vazio, retorna nada
        return emojiList
            .filter(e => e.value.toLowerCase().startsWith(q) || // busca pelo value
            (Array.isArray(e.alias) && e.alias.some(a => a.toLowerCase().includes(q))) // busca pelos aliases
        )
            .map(e => ({
            text: e.text,
            value: e.value,
            description: e.description,
            type: 'emoji'
        }));
    }
    async handleKeyDown(e) {
        if (e.key === "Enter" && e.ctrlKey && !e.shiftKey) {
            e.preventDefault();
            await this.handleSend();
            return;
        }
        if (this.mentionActive) {
            const mention = this.mentionSuggestions[this.mentionIndex];
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                this.mentionIndex = (this.mentionIndex + 1) % this.mentionSuggestions.length;
                this.scrollToActiveMention();
            }
            else if (e.key === 'ArrowUp') {
                e.preventDefault();
                this.mentionIndex =
                    (this.mentionIndex - 1 + this.mentionSuggestions.length) % this.mentionSuggestions.length;
                this.scrollToActiveMention();
            }
            else if (e.key === 'Tab') {
                e.preventDefault();
                this.selectMention(mention);
            }
            else if (e.key === 'Enter') {
                if (this.mentionSuggestions.length > 0) {
                    e.preventDefault();
                    this.selectMention(mention);
                }
            }
        }
    }
    async scrollToActiveMention() {
        if (!this.mentionSuggestionsElement)
            return;
        await this.updateComplete;
        const activeItem = this.mentionSuggestionsElement.querySelector('li.active');
        if (!activeItem)
            return;
        const containerTop = this.mentionSuggestionsElement.scrollTop;
        const containerBottom = containerTop + this.mentionSuggestionsElement.clientHeight;
        const itemTop = activeItem.offsetTop;
        const itemBottom = itemTop + activeItem.offsetHeight;
        if (itemBottom > containerBottom) {
            this.mentionSuggestionsElement.scrollTop += itemBottom - containerBottom;
        }
        else if (itemTop < containerTop) {
            this.mentionSuggestionsElement.scrollTop -= containerTop - itemTop;
        }
    }
    selectMention(suggestion) {
        if (!this.textArea || !suggestion)
            return;
        const cursorPos = this.textArea.selectionStart;
        const beforeCursor = this.text.slice(0, cursorPos);
        const afterCursor = this.text.slice(cursorPos);
        let newText = '';
        switch (suggestion.type) {
            case 'emoji':
                newText = beforeCursor.replace(/::\w*$/, `${suggestion.text} `) + afterCursor;
                break;
            case 'agent':
                newText = beforeCursor.replace(/@{2}[a-zA-Z]*$/, `@@${suggestion.text} `) + afterCursor;
                break;
            case 'user':
                newText = beforeCursor.replace(/@{1}[a-zA-Z]*$/, `@${suggestion.text} `) + afterCursor;
                break;
        }
        this.text = newText;
        this.mentionActive = false;
        this.mentionSuggestions = [];
        this.mentionQuery = '';
        this.mentionIndex = 0;
        this.actualMention = suggestion;
        setTimeout(() => {
            if (!this.textArea)
                return;
            const newCursorPos = newText.length - afterCursor.length;
            this.textArea.selectionStart = this.textArea.selectionEnd = newCursorPos;
            this.textArea.focus();
        });
    }
    extractAgentName(text) {
        const match = text.match(/^@@(\w+)/);
        if (!match)
            return undefined;
        let value = match[1];
        if (!value.startsWith('agent')) {
            const capitalized = value.charAt(0).toUpperCase() + value.slice(1);
            value = 'agent' + capitalized;
        }
        return value;
    }
    async handleSend() {
        if (!this.text)
            return;
        let finalText = this.text.trim();
        let isSpecialMention = false;
        let agentName;
        if (this.allUsers.length > 0) {
            const sortedUsers = [...this.allUsers].sort((a, b) => b.name.length - a.name.length);
            sortedUsers.forEach(user => {
                const escapedName = user.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                const regex = new RegExp(`(^|\\s)@${escapedName}(?=$|\\s|[.,!?])`, 'g');
                finalText = finalText.replace(regex, `$1[@${user.name}](${user.userId})`);
            });
        }
        if (finalText.startsWith('@@')) {
            isSpecialMention = true;
            agentName = this.extractAgentName(finalText.trim());
        }
        if (this.onSend && typeof this.onSend === 'function') {
            this.onSend(finalText, { isSpecialMention, agentName });
        }
        this.text = '';
        this.adjustTextAreaHeight();
    }
};
__decorate([
    query('textarea')
], CollabMessagesPrompt.prototype, "textArea", void 0);
__decorate([
    query('.mention-suggestions')
], CollabMessagesPrompt.prototype, "mentionSuggestionsElement", void 0);
__decorate([
    query('.wrapper')
], CollabMessagesPrompt.prototype, "wrapper", void 0);
__decorate([
    property()
], CollabMessagesPrompt.prototype, "text", void 0);
__decorate([
    state()
], CollabMessagesPrompt.prototype, "actualMention", void 0);
__decorate([
    state()
], CollabMessagesPrompt.prototype, "mentionActive", void 0);
__decorate([
    state()
], CollabMessagesPrompt.prototype, "mentionQuery", void 0);
__decorate([
    state()
], CollabMessagesPrompt.prototype, "mentionSuggestions", void 0);
__decorate([
    state()
], CollabMessagesPrompt.prototype, "mentionIndex", void 0);
__decorate([
    state()
], CollabMessagesPrompt.prototype, "allUsers", void 0);
__decorate([
    state()
], CollabMessagesPrompt.prototype, "allAgents", void 0);
__decorate([
    state()
], CollabMessagesPrompt.prototype, "alreadyLoadingAgents", void 0);
__decorate([
    state()
], CollabMessagesPrompt.prototype, "lastScopeLoaded", void 0);
__decorate([
    property({ type: Function })
], CollabMessagesPrompt.prototype, "onSend", void 0);
__decorate([
    property()
], CollabMessagesPrompt.prototype, "threadId", void 0);
__decorate([
    property()
], CollabMessagesPrompt.prototype, "placeholder", void 0);
__decorate([
    property()
], CollabMessagesPrompt.prototype, "scope", void 0);
__decorate([
    property({
        type: Boolean,
        converter: (value) => value === 'true'
    })
], CollabMessagesPrompt.prototype, "acceptAutoCompleteUser", void 0);
__decorate([
    property({
        type: Boolean,
        converter: (value) => value === 'true'
    })
], CollabMessagesPrompt.prototype, "acceptAutoCompleteAgents", void 0);
CollabMessagesPrompt = __decorate([
    customElement('collab-messages-prompt-102025')
], CollabMessagesPrompt);
export { CollabMessagesPrompt };
