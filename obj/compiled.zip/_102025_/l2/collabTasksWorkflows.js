/// <mls fileReference="_102025_/l2/collabTasksWorkflows.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    title: 'Workflows',
    subtitle: 'processos em uso',
    reload: 'Recarregar',
    loadError: 'Não consegui carregar.',
    retry: 'Tentar de novo',
    emptyTitle: 'Nenhum workflow ativo.',
    emptySub: 'Tasks com workflow aparecerão aqui quando criadas.',
    active: 'ativo',
    activeP: 'ativos',
    done: 'concluído',
    doneP: 'concluídos',
    failed: 'falhou',
    failedP: 'falharam',
    staticWf: 'Workflow estático',
    dynamicWf: 'Workflow dinâmico',
    noType: 'Workflow',
    openBoard: 'Ver no board',
};
const message_en = {
    title: 'Workflows',
    subtitle: 'processes in use',
    reload: 'Reload',
    loadError: 'Could not load.',
    retry: 'Retry',
    emptyTitle: 'No active workflows.',
    emptySub: 'Tasks with a workflow will appear here.',
    active: 'active',
    activeP: 'active',
    done: 'done',
    doneP: 'done',
    failed: 'failed',
    failedP: 'failed',
    staticWf: 'Static workflow',
    dynamicWf: 'Dynamic workflow',
    noType: 'Workflow',
    openBoard: 'View in board',
};
/// **collab_i18n_end**
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { msgListTasks } from '/_102025_/l2/shared/api.js';
import { getUserId } from '/_102025_/l2/collabMessagesHelper.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
let CollabTasksWorkflows = class CollabTasksWorkflows extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-tasks-workflows-102025 {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  --wf-text-primary: var(--color-text-primary, #1a1a18);
  --wf-text-secondary: var(--color-text-secondary, #5f5e5a);
  --wf-text-tertiary: var(--color-text-tertiary, #888780);
  --wf-bg: var(--color-background-primary, #ffffff);
  --wf-row-hover: var(--color-background-secondary, #f5f4f0);
  --wf-border: var(--color-border-tertiary, rgba(0, 0, 0, 0.08));
  --wf-progress-bg: var(--color-background-secondary, #eceae3);
}
@media (prefers-color-scheme: dark) {
  collab-tasks-workflows-102025 {
    --wf-text-primary: #e8e6dc;
    --wf-text-secondary: #b8b5ac;
    --wf-text-tertiary: #8a8880;
    --wf-bg: #1e1e1c;
    --wf-row-hover: #28281f;
    --wf-border: rgba(255, 255, 255, 0.08);
    --wf-progress-bg: #303028;
  }
}
collab-tasks-workflows-102025 .wf-header {
  display: flex;
  align-items: center;
  height: 44px;
  padding: 0 16px;
  gap: 8px;
  flex-shrink: 0;
  background: var(--wf-bg);
  border-bottom: 0.5px solid var(--wf-border);
}
collab-tasks-workflows-102025 .wf-header-left {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: 1;
  min-width: 0;
}
collab-tasks-workflows-102025 .wf-title {
  font-size: 14px;
  font-weight: 500;
  color: var(--wf-text-primary);
  white-space: nowrap;
}
collab-tasks-workflows-102025 .wf-sep {
  font-size: 13px;
  color: var(--wf-text-tertiary);
}
collab-tasks-workflows-102025 .wf-sub {
  font-size: 12px;
  color: var(--wf-text-tertiary);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
collab-tasks-workflows-102025 .wf-icon-btn {
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: none;
  border: 0.5px solid transparent;
  border-radius: 7px;
  cursor: pointer;
  color: var(--wf-text-tertiary);
  transition: background 0.12s, border-color 0.12s;
}
collab-tasks-workflows-102025 .wf-icon-btn:hover {
  background: var(--wf-row-hover);
  border-color: var(--wf-border);
}
collab-tasks-workflows-102025 .wf-body {
  flex: 1;
  overflow-y: auto;
  padding: 14px 16px;
  background: var(--wf-bg);
}
collab-tasks-workflows-102025 .wf-error {
  background: var(--color-background-danger, #fcebeb);
  color: var(--color-text-danger, #a32d2d);
  border-radius: 8px;
  padding: 10px 14px;
  font-size: 13px;
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 12px;
}
collab-tasks-workflows-102025 .wf-error button {
  background: none;
  border: none;
  cursor: pointer;
  color: inherit;
  text-decoration: underline;
  font-size: 13px;
  padding: 0;
}
collab-tasks-workflows-102025 .wf-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 48px 24px;
  text-align: center;
}
collab-tasks-workflows-102025 .wf-empty .empty-icon {
  color: var(--wf-text-tertiary);
  margin-bottom: 4px;
}
collab-tasks-workflows-102025 .wf-empty .empty-title {
  font-size: 14px;
  font-weight: 500;
  color: var(--wf-text-secondary);
}
collab-tasks-workflows-102025 .wf-empty .empty-sub {
  font-size: 12px;
  color: var(--wf-text-tertiary);
  max-width: 280px;
  line-height: 1.5;
}
collab-tasks-workflows-102025 .wf-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
collab-tasks-workflows-102025 .wf-row {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 11px 12px;
  border: 0.5px solid var(--wf-border);
  border-radius: 10px;
  background: var(--wf-bg);
  cursor: pointer;
  outline: none;
  transition: border-color 0.12s, box-shadow 0.12s;
}
collab-tasks-workflows-102025 .wf-row:hover {
  border-color: var(--color-border-secondary, rgba(0, 0, 0, 0.18));
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
}
collab-tasks-workflows-102025 .wf-row:focus-visible {
  outline: 2px solid #185fa5;
  outline-offset: 2px;
}
collab-tasks-workflows-102025 .wf-icon-cell {
  flex-shrink: 0;
}
collab-tasks-workflows-102025 .wf-badge {
  width: 34px;
  height: 34px;
  border-radius: 8px;
  background: var(--color-background-info, #e6f1fb);
  color: var(--color-text-info, #185fa5);
  font-size: 10px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  letter-spacing: 0.04em;
}
@media (prefers-color-scheme: dark) {
  collab-tasks-workflows-102025 .wf-badge {
    background: rgba(24, 95, 165, 0.15);
    color: #85b7eb;
  }
}
collab-tasks-workflows-102025 .wf-info {
  flex: 1;
  min-width: 0;
}
collab-tasks-workflows-102025 .wf-name {
  font-size: 13px;
  font-weight: 500;
  color: var(--wf-text-primary);
  margin-bottom: 2px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
collab-tasks-workflows-102025 .wf-type {
  font-size: 10px;
  color: var(--wf-text-tertiary);
}
collab-tasks-workflows-102025 .wf-stats {
  display: flex;
  gap: 4px;
  flex-wrap: wrap;
  justify-content: flex-end;
  min-width: 90px;
}
collab-tasks-workflows-102025 .stat-pill {
  font-size: 9px;
  font-weight: 500;
  padding: 2px 6px;
  border-radius: 8px;
  white-space: nowrap;
}
collab-tasks-workflows-102025 .stat-pill.stat-active {
  background: var(--color-background-info, #e6f1fb);
  color: var(--color-text-info, #185fa5);
}
collab-tasks-workflows-102025 .stat-pill.stat-done {
  background: var(--color-background-success, #eaf3de);
  color: var(--color-text-success, #3b6d11);
}
collab-tasks-workflows-102025 .stat-pill.stat-failed {
  background: var(--color-background-danger, #fcebeb);
  color: var(--color-text-danger, #a32d2d);
}
@media (prefers-color-scheme: dark) {
  collab-tasks-workflows-102025 .stat-pill.stat-active {
    background: rgba(24, 95, 165, 0.15);
    color: #85b7eb;
  }
  collab-tasks-workflows-102025 .stat-pill.stat-done {
    background: rgba(74, 222, 128, 0.15);
    color: #86efac;
  }
  collab-tasks-workflows-102025 .stat-pill.stat-failed {
    background: rgba(248, 113, 113, 0.15);
    color: #fca5a5;
  }
}
collab-tasks-workflows-102025 .wf-progress-wrap {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
  width: 88px;
}
collab-tasks-workflows-102025 .wf-progress-bar {
  flex: 1;
  height: 5px;
  border-radius: 3px;
  background: var(--wf-progress-bg);
  overflow: hidden;
  display: flex;
}
collab-tasks-workflows-102025 .bar-done {
  height: 100%;
  background: #3b6d11;
  transition: width 0.4s ease;
}
collab-tasks-workflows-102025 .bar-failed {
  height: 100%;
  background: #a32d2d;
  transition: width 0.4s ease;
}
@media (prefers-color-scheme: dark) {
  collab-tasks-workflows-102025 .bar-done {
    background: #4ade80;
  }
  collab-tasks-workflows-102025 .bar-failed {
    background: #f87171;
  }
}
collab-tasks-workflows-102025 .wf-pct {
  font-size: 10px;
  color: var(--wf-text-tertiary);
  font-variant-numeric: tabular-nums;
  flex-shrink: 0;
  min-width: 26px;
  text-align: right;
}
@keyframes shimmer {
  0% {
    background-position: -200% 0;
  }
  100% {
    background-position: 200% 0;
  }
}
collab-tasks-workflows-102025 .skel {
  border-radius: 4px;
  background: linear-gradient(90deg, var(--wf-row-hover) 0%, rgba(128, 128, 128, 0.1) 50%, var(--wf-row-hover) 100%);
  background-size: 200% 100%;
  animation: shimmer 1.4s ease-in-out infinite;
}
collab-tasks-workflows-102025 .wf-row-skeleton {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 11px 12px;
  border-radius: 10px;
}
collab-tasks-workflows-102025 .skel-badge {
  width: 34px;
  height: 34px;
  border-radius: 8px;
  flex-shrink: 0;
}
collab-tasks-workflows-102025 .skel-body {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 5px;
}
collab-tasks-workflows-102025 .skel-name {
  height: 13px;
}
collab-tasks-workflows-102025 .skel-type {
  height: 10px;
  width: 80px;
}
collab-tasks-workflows-102025 .skel-progress {
  width: 88px;
  height: 5px;
  border-radius: 3px;
  flex-shrink: 0;
}
@media (prefers-reduced-motion: reduce) {
  collab-tasks-workflows-102025 .skel {
    animation: none;
  }
}
`);
        this.userId = '';
        this.groups = [];
        this.loading = true;
        this.error = null;
    }
    connectedCallback() {
        super.connectedCallback();
        if (!this.userId)
            this.userId = getUserId() || '';
        this._fetchAll();
    }
    async _fetchAll() {
        this.loading = true;
        this.error = null;
        try {
            const [activeRes, closedRes] = await Promise.all([
                msgListTasks({ userId: this.userId, view: 'active', pageSize: 200 }),
                msgListTasks({ userId: this.userId, view: 'closed', pageSize: 200 }),
            ]);
            if (!activeRes.success) {
                this.error = activeRes.error ?? 'error';
                this.loading = false;
                return;
            }
            const all = [
                ...(activeRes.response?.tasks ?? []),
                ...(closedRes.response?.tasks ?? []),
            ].filter(t => t.taskRoom?.pmaId);
            const map = new Map();
            for (const t of all) {
                const pmaId = t.taskRoom.pmaId;
                if (!map.has(pmaId)) {
                    map.set(pmaId, {
                        pmaId,
                        workflowType: t.taskRoom?.workflowType,
                        active: [], done: [], failed: [],
                    });
                }
                const g = map.get(pmaId);
                if (!g.workflowType && t.taskRoom?.workflowType)
                    g.workflowType = t.taskRoom.workflowType;
                if (t.status === 'done')
                    g.done.push(t);
                else if (t.status === 'failed')
                    g.failed.push(t);
                else
                    g.active.push(t);
            }
            // Sort: most active tasks first
            this.groups = [...map.values()].sort((a, b) => (b.active.length + b.done.length + b.failed.length) -
                (a.active.length + a.done.length + a.failed.length));
        }
        catch (err) {
            this.error = err?.message ?? 'error';
        }
        this.loading = false;
    }
    render() {
        const m = getMsg();
        return html `
      <div class="wf-header">
        <div class="wf-header-left">
          <span class="wf-title">${m.title}</span>
          <span class="wf-sep">·</span>
          <span class="wf-sub">${this.loading ? '…' : `${this.groups.length} ${m.subtitle}`}</span>
        </div>
        <button class="wf-icon-btn" title="${m.reload}" @click=${() => this._fetchAll()}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="23 4 23 10 17 10"></polyline>
            <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
          </svg>
        </button>
      </div>

      <div class="wf-body">
        ${this.error ? html `
          <div class="wf-error">
            <span>${m.loadError}</span>
            <button @click=${() => this._fetchAll()}>${m.retry}</button>
          </div>
        ` : nothing}

        ${this.loading
            ? this._renderSkeletons()
            : this.groups.length === 0
                ? html `
              <div class="wf-empty">
                <div class="empty-icon">
                  <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                    <path d="M4 8h24M4 16h16M4 24h20" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" opacity=".35"/>
                    <circle cx="24" cy="22" r="5" stroke="currentColor" stroke-width="1.2" opacity=".35"/>
                  </svg>
                </div>
                <div class="empty-title">${m.emptyTitle}</div>
                <div class="empty-sub">${m.emptySub}</div>
              </div>
            `
                : html `
              <div class="wf-list">
                ${this.groups.map(g => this._renderGroup(g, m))}
              </div>
            `}
      </div>
    `;
    }
    _openInBoard(pmaId) {
        const w = window?.top ?? window;
        w.dispatchEvent(new CustomEvent('tasks-open-board-filter', {
            detail: { pmaId },
            bubbles: true,
            composed: true,
        }));
    }
    _renderGroup(g, m) {
        const total = g.active.length + g.done.length + g.failed.length;
        const donePct = total > 0 ? Math.round((g.done.length / total) * 100) : 0;
        const failPct = total > 0 ? Math.round((g.failed.length / total) * 100) : 0;
        const typeLabel = g.workflowType === 'staticWorkflow' ? m.staticWf
            : g.workflowType === 'dynamicWorkflow' ? m.dynamicWf
                : m.noType;
        const activeLabel = g.active.length === 1 ? m.active : m.activeP;
        const doneLabel = g.done.length === 1 ? m.done : m.doneP;
        const failLabel = g.failed.length === 1 ? m.failed : m.failedP;
        return html `
      <div
        class="wf-row"
        role="button"
        tabindex="0"
        title="${m.openBoard}"
        @click=${() => this._openInBoard(g.pmaId)}
        @keydown=${(e) => { if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this._openInBoard(g.pmaId);
        } }}
      >
        <div class="wf-icon-cell">
          <div class="wf-badge">${g.pmaId.slice(0, 3).toUpperCase()}</div>
        </div>
        <div class="wf-info">
          <div class="wf-name">${g.pmaId}</div>
          <div class="wf-type">${typeLabel}</div>
        </div>
        <div class="wf-stats">
          ${g.active.length > 0 ? html `
            <span class="stat-pill stat-active">${g.active.length} ${activeLabel}</span>
          ` : nothing}
          ${g.done.length > 0 ? html `
            <span class="stat-pill stat-done">${g.done.length} ${doneLabel}</span>
          ` : nothing}
          ${g.failed.length > 0 ? html `
            <span class="stat-pill stat-failed">${g.failed.length} ${failLabel}</span>
          ` : nothing}
        </div>
        <div class="wf-progress-wrap">
          <div class="wf-progress-bar">
            ${donePct > 0 ? html `<div class="bar-done" style="width:${donePct}%"></div>` : nothing}
            ${failPct > 0 ? html `<div class="bar-failed" style="width:${failPct}%"></div>` : nothing}
          </div>
          <span class="wf-pct">${donePct}%</span>
        </div>
      </div>
    `;
    }
    _renderSkeletons() {
        return html `
      <div class="wf-list">
        ${[70, 55, 85].map(w => html `
          <div class="wf-row-skeleton">
            <div class="skel skel-badge"></div>
            <div class="skel-body">
              <div class="skel skel-name" style="width:${w}px"></div>
              <div class="skel skel-type"></div>
            </div>
            <div class="skel skel-progress"></div>
          </div>
        `)}
      </div>
    `;
    }
};
__decorate([
    property({ type: String })
], CollabTasksWorkflows.prototype, "userId", void 0);
__decorate([
    state()
], CollabTasksWorkflows.prototype, "groups", void 0);
__decorate([
    state()
], CollabTasksWorkflows.prototype, "loading", void 0);
__decorate([
    state()
], CollabTasksWorkflows.prototype, "error", void 0);
CollabTasksWorkflows = __decorate([
    customElement('collab-tasks-workflows-102025')
], CollabTasksWorkflows);
export { CollabTasksWorkflows };
