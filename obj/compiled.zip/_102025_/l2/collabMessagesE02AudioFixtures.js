/// <mls fileReference="_102025_/l2/collabMessagesE02AudioFixtures.ts" enhancement="_blank" />
const receipt = { localRequests: 1, providerAttempts: 1, costChargedUsd: 0.0042, resolvedModel: 'audio-fixture', reconciliationPending: false };
const base = {
    contractVersion: 'john-audio.v1', processingId: 'audio-fixture-p1', sourceAvailable: true,
    transcription: { state: 'completed', receipt, result: { status: 'speech', text: 'Schedule the review for Tuesday.', uncertainties: [] } },
    review: { state: 'awaiting_review', selectedVersion: 1, versions: [{ version: 1, origin: 'model', text: 'Schedule the review for Tuesday.', createdAt: '2026-09-23T12:00:00Z', status: 'speech', uncertainties: [] }] },
    interpretation: { state: 'not_requested', transcriptVersion: null, contextVersion: null, contextSourceIds: [], receipt: null }, error: null,
};
/** Visual-proof fixtures only. Nothing imports or activates these in the normal product path. */
export const E02_AUDIO_VISUAL_FIXTURES = Object.freeze({
    pending: { ...base, transcription: { state: 'sent', receipt: null }, review: { state: 'not_available', selectedVersion: null, versions: [] } },
    transcript: base,
    corrected: { ...base, review: { state: 'reviewed', selectedVersion: 2, versions: [...base.review.versions, { version: 2, origin: 'human', text: 'Schedule the review for next Tuesday.', createdAt: '2026-09-23T12:03:00Z', status: 'speech' }] } },
    noSpeech: { ...base, transcription: { state: 'completed', receipt, result: { status: 'no_speech', text: '', uncertainties: [] } }, review: { state: 'awaiting_review', selectedVersion: 1, versions: [{ version: 1, origin: 'model', text: '', createdAt: '2026-09-23T12:00:00Z', status: 'no_speech' }] } },
    unintelligible: { ...base, transcription: { state: 'completed', receipt, result: { status: 'unintelligible', text: '', uncertainties: [{ excerpt: 'inaudible speech', reason: 'background_noise' }] } }, review: { state: 'awaiting_review', selectedVersion: 1, versions: [{ version: 1, origin: 'model', text: '', createdAt: '2026-09-23T12:00:00Z', status: 'unintelligible', uncertainties: [{ excerpt: 'inaudible speech', reason: 'background_noise' }] }] } },
    failed: { ...base, transcription: { state: 'failed', receipt }, review: { state: 'not_available', selectedVersion: null, versions: [] }, error: { code: 'structured_output_rejected', phase: 'transcription', retryable: false } },
    costUncertain: { ...base, transcription: { state: 'uncertain', receipt: { localRequests: 1, providerAttempts: null, costChargedUsd: null, resolvedModel: null, reconciliationPending: true } } },
    interpreted: { ...base, interpretation: { state: 'completed', transcriptVersion: 1, contextVersion: 'memory-v3', contextSourceIds: ['message/source-1'], request: 'Explain using my context.', receipt, result: { answer: 'This is a request to schedule a review.', inferences: [{ statement: 'Tuesday is the requested day.', basis: 'transcript' }] } } },
    obsolete: { ...base, interpretation: { state: 'obsolete', transcriptVersion: 1, contextVersion: 'memory-v2', contextSourceIds: ['message/source-old'], receipt }, error: { code: 'source_changed', phase: 'interpretation', retryable: false } },
    unavailable: { ...base, sourceAvailable: false },
    xssLiteral: { ...base, review: { state: 'awaiting_review', selectedVersion: 1, versions: [{ version: 1, origin: 'model', text: '<img src=x onerror=alert(1)>', createdAt: '2026-09-23T12:00:00Z', status: 'speech' }] } },
});
