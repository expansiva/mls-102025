/// <mls fileReference="_102025_/l2/collabTasksApprovals.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    title: 'Aprovações',
    reload: 'Recarregar',
    loadError: 'Não consegui carregar.',
    retry: 'Tentar de novo',
    emptyTitle: 'Nenhuma pendência.',
    emptySub: 'Tasks de workflow atribuídas a você aparecerão aqui.',
    pending: 'pendente',
    pendingP: 'pendentes',
    paused: 'pausado',
    pausedP: 'pausados',
    todo: 'A fazer',
    inProgress: 'Em andamento',
    pausedLabel: 'Pausado',
    priorityUrgent: 'urgente',
    priorityHigh: 'alta',
    priorityNormal: 'normal',
    priorityLow: 'baixa',
    today: 'hoje',
    tomorrow: 'amanhã',
    overdue: 'atrasado',
    openTask: 'Abrir task',
    waitingSince: 'há',
    day: 'dia',
    days: 'dias',
};
const message_en = {
    title: 'Approvals',
    reload: 'Reload',
    loadError: 'Could not load.',
    retry: 'Retry',
    emptyTitle: 'Nothing pending.',
    emptySub: 'Workflow tasks assigned to you will appear here.',
    pending: 'pending',
    pendingP: 'pending',
    paused: 'paused',
    pausedP: 'paused',
    todo: 'To do',
    inProgress: 'In progress',
    pausedLabel: 'Paused',
    priorityUrgent: 'urgent',
    priorityHigh: 'high',
    priorityNormal: 'normal',
    priorityLow: 'low',
    today: 'today',
    tomorrow: 'tomorrow',
    overdue: 'overdue',
    openTask: 'Open task',
    waitingSince: 'for',
    day: 'day',
    days: 'days',
};
/// **collab_i18n_end**
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { msgListTasks } from '/_102025_/l2/shared/api.js';
import { openElementInServiceDetails } from '/_102027_/l2/libCommom.js';
import { getUserId } from '/_102025_/l2/collabMessagesHelper.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
const PRIORITY_ORDER = { urgent: 0, high: 1, normal: 2, low: 3 };
function waitingDays(lastUpdated) {
    return Math.floor((Date.now() - lastUpdated) / 86400000);
}
function dueDateLabel(dueDate, m) {
    if (!dueDate)
        return '';
    const today = new Date().toISOString().slice(0, 10);
    const tomorrow = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
    if (dueDate === today)
        return m.today;
    if (dueDate === tomorrow)
        return m.tomorrow;
    if (new Date(dueDate + 'T23:59:59') < new Date())
        return m.overdue;
    return dueDate;
}
let CollabTasksApprovals = class CollabTasksApprovals extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-tasks-approvals-102025 {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  --ap-text-primary: var(--color-text-primary, #1a1a18);
  --ap-text-secondary: var(--color-text-secondary, #5f5e5a);
  --ap-text-tertiary: var(--color-text-tertiary, #888780);
  --ap-bg: var(--color-background-primary, #ffffff);
  --ap-row-hover: var(--color-background-secondary, #f5f4f0);
  --ap-border: var(--color-border-tertiary, rgba(0, 0, 0, 0.08));
  --ap-sep: rgba(0, 0, 0, 0.06);
}
@media (prefers-color-scheme: dark) {
  collab-tasks-approvals-102025 {
    --ap-text-primary: #e8e6dc;
    --ap-text-secondary: #b8b5ac;
    --ap-text-tertiary: #8a8880;
    --ap-bg: #1e1e1c;
    --ap-row-hover: #28281f;
    --ap-border: rgba(255, 255, 255, 0.08);
    --ap-sep: rgba(255, 255, 255, 0.06);
  }
}
collab-tasks-approvals-102025 .ap-header {
  display: flex;
  align-items: center;
  height: 44px;
  padding: 0 16px;
  gap: 8px;
  flex-shrink: 0;
  background: var(--ap-bg);
  border-bottom: 0.5px solid var(--ap-border);
}
collab-tasks-approvals-102025 .ap-header-left {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: 1;
  min-width: 0;
}
collab-tasks-approvals-102025 .ap-title {
  font-size: 14px;
  font-weight: 500;
  color: var(--ap-text-primary);
  white-space: nowrap;
}
collab-tasks-approvals-102025 .ap-sep {
  font-size: 13px;
  color: var(--ap-text-tertiary);
}
collab-tasks-approvals-102025 .ap-sub {
  font-size: 12px;
  color: var(--ap-text-tertiary);
  white-space: nowrap;
}
collab-tasks-approvals-102025 .ap-icon-btn {
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: none;
  border: 0.5px solid transparent;
  border-radius: 7px;
  cursor: pointer;
  color: var(--ap-text-tertiary);
  transition: background 0.12s, border-color 0.12s;
}
collab-tasks-approvals-102025 .ap-icon-btn:hover {
  background: var(--ap-row-hover);
  border-color: var(--ap-border);
}
collab-tasks-approvals-102025 .ap-body {
  flex: 1;
  overflow-y: auto;
  padding: 12px 16px 16px;
  background: var(--ap-bg);
}
collab-tasks-approvals-102025 .ap-error {
  background: var(--color-background-danger, #fcebeb);
  color: var(--color-text-danger, #a32d2d);
  border-radius: 8px;
  padding: 10px 14px;
  font-size: 13px;
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 12px;
}
collab-tasks-approvals-102025 .ap-error button {
  background: none;
  border: none;
  cursor: pointer;
  color: inherit;
  text-decoration: underline;
  font-size: 13px;
  padding: 0;
}
collab-tasks-approvals-102025 .ap-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 48px 24px;
  text-align: center;
}
collab-tasks-approvals-102025 .ap-empty .empty-icon {
  color: var(--ap-text-tertiary);
  margin-bottom: 4px;
}
collab-tasks-approvals-102025 .ap-empty .empty-title {
  font-size: 14px;
  font-weight: 500;
  color: var(--ap-text-secondary);
}
collab-tasks-approvals-102025 .ap-empty .empty-sub {
  font-size: 12px;
  color: var(--ap-text-tertiary);
  max-width: 280px;
  line-height: 1.5;
}
collab-tasks-approvals-102025 .ap-section-label {
  font-size: 10px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--ap-text-tertiary);
  padding: 0 2px 8px;
  display: flex;
  align-items: center;
  gap: 6px;
}
collab-tasks-approvals-102025 .ap-section-label.mt {
  padding-top: 16px;
}
collab-tasks-approvals-102025 .ap-count {
  font-size: 10px;
  font-weight: 500;
  padding: 1px 5px;
  border-radius: 8px;
  background: var(--ap-row-hover);
  color: var(--ap-text-tertiary);
  text-transform: none;
  letter-spacing: 0;
}
collab-tasks-approvals-102025 .ap-list {
  display: flex;
  flex-direction: column;
}
collab-tasks-approvals-102025 .ap-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 8px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.1s;
  outline: none;
  position: relative;
}
collab-tasks-approvals-102025 .ap-row + .ap-row::before {
  content: '';
  position: absolute;
  top: 0;
  left: 8px;
  right: 8px;
  height: 0.5px;
  background: var(--ap-sep);
}
collab-tasks-approvals-102025 .ap-row:hover {
  background: var(--ap-row-hover);
}
collab-tasks-approvals-102025 .ap-row:focus-visible {
  outline: 2px solid #185fa5;
  outline-offset: -2px;
}
collab-tasks-approvals-102025 .ap-left {
  flex: 1;
  min-width: 0;
}
collab-tasks-approvals-102025 .ap-task-title {
  font-size: 13px;
  font-weight: 500;
  color: var(--ap-text-primary);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  margin-bottom: 3px;
  line-height: 1.35;
}
collab-tasks-approvals-102025 .ap-task-meta {
  display: flex;
  align-items: center;
  gap: 5px;
  flex-wrap: nowrap;
  overflow: hidden;
}
collab-tasks-approvals-102025 .ap-pma {
  font-size: 10px;
  padding: 1px 5px;
  border-radius: 6px;
  background: rgba(88, 28, 135, 0.07);
  color: #5b21b6;
  white-space: nowrap;
}
@media (prefers-color-scheme: dark) {
  collab-tasks-approvals-102025 .ap-pma {
    background: rgba(167, 139, 250, 0.12);
    color: #a78bfa;
  }
}
collab-tasks-approvals-102025 .ap-tag {
  font-size: 10px;
  padding: 1px 5px;
  border-radius: 6px;
  background: var(--ap-row-hover);
  color: var(--ap-text-tertiary);
  white-space: nowrap;
}
collab-tasks-approvals-102025 .ap-wait {
  font-size: 10px;
  color: var(--ap-text-tertiary);
  white-space: nowrap;
}
collab-tasks-approvals-102025 .ap-wait.old {
  color: var(--color-text-warning, #854f0b);
  font-weight: 500;
}
@media (prefers-color-scheme: dark) {
  collab-tasks-approvals-102025 .ap-wait.old {
    color: #fac775;
  }
}
collab-tasks-approvals-102025 .ap-right {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 3px;
  flex-shrink: 0;
}
collab-tasks-approvals-102025 .ap-pri-badge {
  font-size: 9px;
  font-weight: 500;
  padding: 2px 6px;
  border-radius: 7px;
  white-space: nowrap;
}
collab-tasks-approvals-102025 .ap-pri-badge.priority-urgent {
  background: #fcebeb;
  color: #a32d2d;
}
collab-tasks-approvals-102025 .ap-pri-badge.priority-high {
  background: #faeeda;
  color: #854f0b;
}
collab-tasks-approvals-102025 .ap-pri-badge.priority-normal,
collab-tasks-approvals-102025 .ap-pri-badge.priority-low {
  background: var(--ap-row-hover);
  color: var(--ap-text-tertiary);
}
@media (prefers-color-scheme: dark) {
  collab-tasks-approvals-102025 .ap-pri-badge.priority-urgent {
    background: rgba(248, 113, 113, 0.15);
    color: #fca5a5;
  }
  collab-tasks-approvals-102025 .ap-pri-badge.priority-high {
    background: rgba(240, 168, 58, 0.15);
    color: #fac775;
  }
}
collab-tasks-approvals-102025 .ap-status-badge {
  font-size: 9px;
  font-weight: 500;
  padding: 2px 6px;
  border-radius: 7px;
  white-space: nowrap;
}
collab-tasks-approvals-102025 .ap-status-badge.paused {
  background: var(--color-background-secondary, #f3f4f6);
  color: #6b7280;
}
@media (prefers-color-scheme: dark) {
  collab-tasks-approvals-102025 .ap-status-badge.paused {
    background: rgba(107, 114, 128, 0.15);
    color: #9ca3af;
  }
}
collab-tasks-approvals-102025 .ap-due {
  font-size: 10px;
  color: var(--ap-text-tertiary);
  white-space: nowrap;
}
collab-tasks-approvals-102025 .ap-due.overdue {
  color: #a32d2d;
  font-weight: 500;
}
@media (prefers-color-scheme: dark) {
  collab-tasks-approvals-102025 .ap-due.overdue {
    color: #fca5a5;
  }
}
@keyframes shimmer {
  0% {
    background-position: -200% 0;
  }
  100% {
    background-position: 200% 0;
  }
}
@keyframes sfade {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
collab-tasks-approvals-102025 .skel {
  border-radius: 4px;
  background: linear-gradient(90deg, var(--ap-row-hover) 0%, rgba(128, 128, 128, 0.1) 50%, var(--ap-row-hover) 100%);
  background-size: 200% 100%;
  animation: shimmer 1.4s ease-in-out infinite;
}
collab-tasks-approvals-102025 .ap-row-skeleton {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 8px;
  animation: sfade 200ms ease-out both;
}
collab-tasks-approvals-102025 .skel-body {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 5px;
}
collab-tasks-approvals-102025 .skel-title {
  height: 12px;
}
collab-tasks-approvals-102025 .skel-meta {
  height: 9px;
}
collab-tasks-approvals-102025 .skel-badge {
  width: 42px;
  height: 18px;
  border-radius: 7px;
  flex-shrink: 0;
}
@media (prefers-reduced-motion: reduce) {
  collab-tasks-approvals-102025 .skel {
    animation: none;
  }
}
`);
        this.userId = '';
        this.pending = [];
        this.paused = [];
        this.loading = true;
        this.error = null;
    }
    connectedCallback() {
        super.connectedCallback();
        if (!this.userId)
            this.userId = getUserId() || '';
        this._fetchAll();
    }
    async _fetchAll() {
        this.loading = true;
        this.error = null;
        try {
            const res = await msgListTasks({ userId: this.userId, view: 'active', pageSize: 200 });
            if (!res.success) {
                this.error = res.error ?? 'error';
                this.loading = false;
                return;
            }
            const tasks = res.response?.tasks ?? [];
            // Pending: assigned to me, todo, has workflow
            const pendingTasks = tasks
                .filter(t => t.taskRoom?.pmaId &&
                t.status === 'todo' &&
                (t.assignees?.includes(this.userId) || t.owner === this.userId))
                .sort((a, b) => {
                const pa = PRIORITY_ORDER[a.priority ?? 'normal'] ?? 2;
                const pb = PRIORITY_ORDER[b.priority ?? 'normal'] ?? 2;
                if (pa !== pb)
                    return pa - pb;
                return (b.last_updated ?? 0) - (a.last_updated ?? 0);
            });
            // Paused: workflow paused waiting for action
            const pausedTasks = tasks
                .filter(t => t.taskRoom?.pmaId &&
                t.status === 'paused' &&
                (t.assignees?.includes(this.userId) || t.owner === this.userId))
                .sort((a, b) => (b.last_updated ?? 0) - (a.last_updated ?? 0));
            this.pending = pendingTasks;
            this.paused = pausedTasks;
        }
        catch (err) {
            this.error = err?.message ?? 'error';
        }
        this.loading = false;
    }
    async _openTask(task) {
        await import('/_102025_/l2/collabMessagesTaskRoom.js');
        const room = document.createElement('collab-messages-task-room-102025');
        room.task = task;
        room.userId = this.userId;
        openElementInServiceDetails(room);
    }
    render() {
        const m = getMsg();
        const total = this.pending.length + this.paused.length;
        const subLabel = this.loading ? '…'
            : total === 0 ? '0'
                : `${total} ${total === 1 ? m.pending : m.pendingP}`;
        return html `
      <div class="ap-header">
        <div class="ap-header-left">
          <span class="ap-title">${m.title}</span>
          <span class="ap-sep">·</span>
          <span class="ap-sub">${subLabel}</span>
        </div>
        <button class="ap-icon-btn" title="${m.reload}" @click=${() => this._fetchAll()}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="23 4 23 10 17 10"></polyline>
            <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
          </svg>
        </button>
      </div>

      <div class="ap-body">
        ${this.error ? html `
          <div class="ap-error">
            <span>${m.loadError}</span>
            <button @click=${() => this._fetchAll()}>${m.retry}</button>
          </div>
        ` : nothing}

        ${this.loading
            ? this._renderSkeletons(3)
            : total === 0
                ? html `
              <div class="ap-empty">
                <div class="empty-icon">
                  <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
                    <rect x="3" y="5" width="30" height="26" rx="3" stroke="currentColor" stroke-width="1.2" opacity=".3"/>
                    <path d="M10 14h16M10 20h10" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" opacity=".35"/>
                    <path d="M22 20l4 4-4 4" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" opacity=".35"/>
                  </svg>
                </div>
                <div class="empty-title">${m.emptyTitle}</div>
                <div class="empty-sub">${m.emptySub}</div>
              </div>
            `
                : html `
              ${this.pending.length > 0 ? html `
                <div class="ap-section-label">
                  ${m.pending} <span class="ap-count">${this.pending.length}</span>
                </div>
                <div class="ap-list">
                  ${this.pending.map(t => this._renderRow(t, m, false))}
                </div>
              ` : nothing}

              ${this.paused.length > 0 ? html `
                <div class="ap-section-label ${this.pending.length > 0 ? 'mt' : ''}">
                  ${m.paused} <span class="ap-count">${this.paused.length}</span>
                </div>
                <div class="ap-list">
                  ${this.paused.map(t => this._renderRow(t, m, true))}
                </div>
              ` : nothing}
            `}
      </div>
    `;
    }
    _renderRow(task, m, isPaused) {
        const days = task.last_updated ? waitingDays(task.last_updated) : 0;
        const waitLabel = days === 0 ? m.today
            : days === 1 ? `${m.waitingSince} 1 ${m.day}`
                : `${m.waitingSince} ${days} ${m.days}`;
        const dueLabel = dueDateLabel(task.dueDate, m);
        const isOverdue = !!task.dueDate && new Date(task.dueDate + 'T23:59:59') < new Date();
        const priLabel = task.priority
            ? m[`priority${task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}`] ?? task.priority
            : null;
        return html `
      <div
        class="ap-row"
        role="button"
        tabindex="0"
        title="${m.openTask}"
        @click=${() => this._openTask(task)}
        @keydown=${(e) => { if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this._openTask(task);
        } }}
      >
        <div class="ap-left">
          <div class="ap-task-title">${task.title}</div>
          <div class="ap-task-meta">
            ${task.taskRoom?.pmaId ? html `<span class="ap-pma">${task.taskRoom.pmaId}</span>` : nothing}
            ${task.tags?.[0] ? html `<span class="ap-tag">${task.tags[0]}</span>` : nothing}
            <span class="ap-wait ${days >= 3 ? 'old' : ''}">${waitLabel}</span>
          </div>
        </div>
        <div class="ap-right">
          ${isPaused ? html `
            <span class="ap-status-badge paused">${m.pausedLabel}</span>
          ` : priLabel ? html `
            <span class="ap-pri-badge priority-${task.priority}">${priLabel}</span>
          ` : nothing}
          ${dueLabel ? html `
            <span class="ap-due ${isOverdue ? 'overdue' : ''}">${dueLabel}</span>
          ` : nothing}
        </div>
      </div>
    `;
    }
    _renderSkeletons(count) {
        return html `
      <div class="ap-list">
        ${Array.from({ length: count }, (_, i) => html `
          <div class="ap-row-skeleton" style="animation-delay:${i * 60}ms">
            <div class="skel-body">
              <div class="skel skel-title" style="width:${50 + (i % 3) * 15}%"></div>
              <div class="skel skel-meta"  style="width:${30 + (i % 2) * 10}%"></div>
            </div>
            <div class="skel skel-badge"></div>
          </div>
        `)}
      </div>
    `;
    }
};
__decorate([
    property({ type: String })
], CollabTasksApprovals.prototype, "userId", void 0);
__decorate([
    state()
], CollabTasksApprovals.prototype, "pending", void 0);
__decorate([
    state()
], CollabTasksApprovals.prototype, "paused", void 0);
__decorate([
    state()
], CollabTasksApprovals.prototype, "loading", void 0);
__decorate([
    state()
], CollabTasksApprovals.prototype, "error", void 0);
CollabTasksApprovals = __decorate([
    customElement('collab-tasks-approvals-102025')
], CollabTasksApprovals);
export { CollabTasksApprovals };
