/// <mls fileReference="_102025_/l2/collabTasksSettings.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    title: 'Configurações',
    subtitle: 'Tasks',
    tags: 'Vocabulário de tags',
    tagsDesc: 'Tags configuradas para esta organização.',
    tagsEmpty: 'Nenhuma tag configurada.',
    future: 'Em breve',
    settingNotif: 'Notificações',
    settingNotifD: 'Quando e como notificar aprovadores e responsáveis.',
    settingExport: 'Exportação e auditoria',
    settingExportD: 'CSV, PDF e trilha completa de instâncias de processo.',
    settingPerms: 'Perfis e permissões',
    settingPermsD: 'Quem pode criar, editar e aprovar workflows.',
    themesHint: 'O tema do board pode ser alterado pelo ícone ⚙ no Board ou em Minhas tasks.',
    reload: 'Recarregar',
    loadError: 'Não consegui carregar.',
    retry: 'Tentar de novo',
};
const message_en = {
    title: 'Settings',
    subtitle: 'Tasks',
    tags: 'Tag vocabulary',
    tagsDesc: 'Tags configured for this organization.',
    tagsEmpty: 'No tags configured.',
    future: 'Coming soon',
    settingNotif: 'Notifications',
    settingNotifD: 'When and how to notify approvers and owners.',
    settingExport: 'Export & audit',
    settingExportD: 'CSV, PDF and full process instance trail.',
    settingPerms: 'Profiles & permissions',
    settingPermsD: 'Who can create, edit and approve workflows.',
    themesHint: 'The board theme can be changed from the ⚙ icon in Board or My tasks.',
    reload: 'Reload',
    loadError: 'Could not load.',
    retry: 'Retry',
};
/// **collab_i18n_end**
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { msgGetOrgPreferences } from '/_102025_/l2/shared/api.js';
import { getUserId } from '/_102025_/l2/collabMessagesHelper.js';
import { loadTasksTheme, applyThemeToHost, } from '/_102025_/l2/collabTasksTheme.js';
import '/_102025_/l2/collabTasksDesignTokens.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
const TAG_COLOR_LABEL = {
    bug: { bg: '#fcebeb', text: '#a32d2d' },
    feature: { bg: '#e6f1fb', text: '#185fa5' },
    business: { bg: '#faeeda', text: '#854f0b' },
    process: { bg: '#e1f5ee', text: '#085041' },
    neutral: { bg: '#f5f4f0', text: '#5f5e5a' },
};
let CollabTasksSettings = class CollabTasksSettings extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-tasks-settings-102025 {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  --st-text-primary: var(--color-text-primary, #1a1a18);
  --st-text-secondary: var(--color-text-secondary, #5f5e5a);
  --st-text-tertiary: var(--ct-text-tertiary, #6e6d68);
  --st-bg: var(--color-background-primary, #ffffff);
  --st-section-bg: var(--color-background-secondary, #f5f4f0);
  --st-border: var(--color-border-tertiary, rgba(0, 0, 0, 0.08));
  --st-row-hover: var(--color-background-secondary, #f5f4f0);
}
@media (prefers-color-scheme: dark) {
  collab-tasks-settings-102025 {
    --st-text-primary: #e8e6dc;
    --st-text-secondary: #b8b5ac;
    --st-text-tertiary: #8a8880;
    --st-bg: #1e1e1c;
    --st-section-bg: #28281f;
    --st-border: rgba(255, 255, 255, 0.08);
    --st-row-hover: #28281f;
  }
}
collab-tasks-settings-102025 .st-header {
  display: flex;
  align-items: center;
  height: 44px;
  padding: 0 16px;
  gap: 8px;
  flex-shrink: 0;
  background: var(--st-bg);
  border-bottom: 0.5px solid var(--st-border);
}
collab-tasks-settings-102025 .st-header-left {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: 1;
  min-width: 0;
}
collab-tasks-settings-102025 .st-title {
  font-size: 14px;
  font-weight: 500;
  color: var(--st-text-primary);
  white-space: nowrap;
}
collab-tasks-settings-102025 .st-sep {
  font-size: 13px;
  color: var(--st-text-tertiary);
}
collab-tasks-settings-102025 .st-sub {
  font-size: 12px;
  color: var(--st-text-tertiary);
}
collab-tasks-settings-102025 .st-icon-btn {
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: none;
  border: 0.5px solid transparent;
  border-radius: 7px;
  cursor: pointer;
  color: var(--st-text-tertiary);
  transition: background 0.12s, border-color 0.12s;
}
collab-tasks-settings-102025 .st-icon-btn:hover {
  background: var(--st-row-hover);
  border-color: var(--st-border);
}
collab-tasks-settings-102025 .st-body {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  background: var(--st-bg);
  display: flex;
  flex-direction: column;
  gap: 20px;
}
collab-tasks-settings-102025 .st-section {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
collab-tasks-settings-102025 .st-section-header {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
collab-tasks-settings-102025 .st-section-title {
  font-size: 12px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--st-text-tertiary);
}
collab-tasks-settings-102025 .st-section-desc {
  font-size: 12px;
  color: var(--st-text-secondary);
}
collab-tasks-settings-102025 .st-error {
  background: var(--color-background-danger, #fcebeb);
  color: var(--color-text-danger, #a32d2d);
  border-radius: 8px;
  padding: 10px 14px;
  font-size: 13px;
  display: flex;
  align-items: center;
  gap: 10px;
}
collab-tasks-settings-102025 .st-error button {
  background: none;
  border: none;
  cursor: pointer;
  color: inherit;
  text-decoration: underline;
  font-size: 13px;
  padding: 0;
}
collab-tasks-settings-102025 .st-empty {
  font-size: 12px;
  color: var(--st-text-tertiary);
  padding: 4px 0;
}
collab-tasks-settings-102025 .st-theme-hint {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 10px 12px;
  border-radius: 10px;
  background: var(--st-section-bg);
  color: var(--st-text-secondary);
  font-size: 12px;
  line-height: 1.45;
}
collab-tasks-settings-102025 .st-theme-hint svg {
  flex-shrink: 0;
  margin-top: 1px;
  color: var(--st-text-tertiary);
}
collab-tasks-settings-102025 .tag-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
collab-tasks-settings-102025 .tag-chip {
  font-size: 11px;
  font-weight: 500;
  padding: 3px 9px;
  border-radius: 12px;
}
collab-tasks-settings-102025 .st-future-list {
  display: flex;
  flex-direction: column;
  gap: 1px;
  border: 0.5px solid var(--st-border);
  border-radius: 10px;
  overflow: hidden;
}
collab-tasks-settings-102025 .st-future-row {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 11px 14px;
  background: var(--st-bg);
  transition: background 0.1s;
}
collab-tasks-settings-102025 .st-future-row + .st-future-row {
  border-top: 0.5px solid var(--st-border);
}
collab-tasks-settings-102025 .st-future-icon {
  width: 30px;
  height: 30px;
  border-radius: 8px;
  background: var(--st-section-bg);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 14px;
  flex-shrink: 0;
}
collab-tasks-settings-102025 .st-future-info {
  flex: 1;
  min-width: 0;
}
collab-tasks-settings-102025 .st-future-name {
  font-size: 13px;
  font-weight: 500;
  color: var(--st-text-primary);
  margin-bottom: 1px;
}
collab-tasks-settings-102025 .st-future-desc {
  font-size: 11px;
  color: var(--st-text-tertiary);
  line-height: 1.3;
}
collab-tasks-settings-102025 .st-soon-badge {
  font-size: 9px;
  font-weight: 600;
  padding: 2px 7px;
  border-radius: 8px;
  background: var(--st-section-bg);
  color: var(--st-text-tertiary);
  text-transform: uppercase;
  letter-spacing: 0.04em;
  flex-shrink: 0;
}
@keyframes shimmer {
  0% {
    background-position: -200% 0;
  }
  100% {
    background-position: 200% 0;
  }
}
collab-tasks-settings-102025 .skel {
  border-radius: 4px;
  background: linear-gradient(90deg, var(--st-section-bg) 0%, rgba(128, 128, 128, 0.1) 50%, var(--st-section-bg) 100%);
  background-size: 200% 100%;
  animation: shimmer 1.4s ease-in-out infinite;
}
@media (prefers-reduced-motion: reduce) {
  collab-tasks-settings-102025 .skel {
    animation: none;
  }
}
`);
        this.userId = '';
        this.organizationId = 'collabcodes';
        this.tagVocabulary = [];
        this.loadingTags = true;
        this.errorTags = null;
    }
    connectedCallback() {
        super.connectedCallback();
        if (!this.userId)
            this.userId = getUserId() || '';
        // Apply the currently saved theme to this host so this screen visually
        // matches the rest of the tasks tab (header tone, etc.). Listen for
        // changes so it follows along if the user switches theme in Board.
        applyThemeToHost(loadTasksTheme(), this);
        this._onThemeChanged = () => applyThemeToHost(loadTasksTheme(), this);
        const w = window?.top ?? window;
        w.addEventListener('tasks-theme-changed', this._onThemeChanged);
        w.addEventListener('tasks-bg-changed', this._onThemeChanged);
        this._loadTags();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        const w = window?.top ?? window;
        w.removeEventListener('tasks-theme-changed', this._onThemeChanged);
        w.removeEventListener('tasks-bg-changed', this._onThemeChanged);
    }
    async _loadTags() {
        this.loadingTags = true;
        this.errorTags = null;
        try {
            const res = await msgGetOrgPreferences({ organizationId: this.organizationId, userId: this.userId });
            if (res.success)
                this.tagVocabulary = res.response?.tagVocabulary ?? [];
            else
                this.errorTags = res.error ?? 'error';
        }
        catch (err) {
            this.errorTags = err?.message ?? 'error';
        }
        this.loadingTags = false;
    }
    render() {
        const m = getMsg();
        const lang = document.documentElement.lang ?? 'en';
        return html `
      <div class="st-header">
        <div class="st-header-left">
          <span class="st-title">${m.title}</span>
          <span class="st-sep">·</span>
          <span class="st-sub">${m.subtitle}</span>
        </div>
        <button class="st-icon-btn" title="${m.reload}" @click=${() => this._loadTags()}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="23 4 23 10 17 10"></polyline>
            <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
          </svg>
        </button>
      </div>

      <div class="st-body">

        <!-- ── Theme hint (themes themselves now live in Board / My tasks gear) ── -->
        <div class="st-theme-hint" role="note">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
            <circle cx="7" cy="7" r="5.5" stroke="currentColor" stroke-width="1.1"/>
            <path d="M7 6.2v3.4M7 4.4v.05" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/>
          </svg>
          <span>${m.themesHint}</span>
        </div>

        <!-- ── Tag vocabulary ── -->
        <section class="st-section">
          <div class="st-section-header">
            <div class="st-section-title">${m.tags}</div>
            <div class="st-section-desc">${m.tagsDesc}</div>
          </div>

          ${this.errorTags ? html `
            <div class="st-error">
              <span>${m.loadError}</span>
              <button @click=${() => this._loadTags()}>${m.retry}</button>
            </div>
          ` : this.loadingTags ? html `
            <div class="tag-chips">
              ${[60, 80, 55, 70, 45].map(w => html `
                <div class="skel" style="width:${w}px;height:22px;border-radius:12px"></div>
              `)}
            </div>
          ` : this.tagVocabulary.length === 0 ? html `
            <div class="st-empty">${m.tagsEmpty}</div>
          ` : html `
            <div class="tag-chips">
              ${this.tagVocabulary.map(entry => {
            const colors = TAG_COLOR_LABEL[entry.color] ?? TAG_COLOR_LABEL.neutral;
            const label = entry.label
                ? (lang === 'pt' ? entry.label.pt : entry.label.en) || entry.tag
                : entry.tag;
            return html `
                  <span class="tag-chip" style="background:${colors.bg};color:${colors.text}">
                    ${label}
                  </span>
                `;
        })}
            </div>
          `}
        </section>

        <!-- ── Coming soon ── -->
        <section class="st-section">
          <div class="st-section-header">
            <div class="st-section-title">${m.future}</div>
          </div>
          <div class="st-future-list">
            ${([
            { name: m.settingNotif, desc: m.settingNotifD, icon: '🔔' },
            { name: m.settingPerms, desc: m.settingPermsD, icon: '👥' },
            { name: m.settingExport, desc: m.settingExportD, icon: '📦' },
        ]).map(item => html `
              <div class="st-future-row">
                <div class="st-future-icon">${item.icon}</div>
                <div class="st-future-info">
                  <div class="st-future-name">${item.name}</div>
                  <div class="st-future-desc">${item.desc}</div>
                </div>
                <span class="st-soon-badge">soon</span>
              </div>
            `)}
          </div>
        </section>

      </div>
    `;
    }
};
__decorate([
    property({ type: String })
], CollabTasksSettings.prototype, "userId", void 0);
__decorate([
    property({ type: String })
], CollabTasksSettings.prototype, "organizationId", void 0);
__decorate([
    state()
], CollabTasksSettings.prototype, "tagVocabulary", void 0);
__decorate([
    state()
], CollabTasksSettings.prototype, "loadingTags", void 0);
__decorate([
    state()
], CollabTasksSettings.prototype, "errorTags", void 0);
CollabTasksSettings = __decorate([
    customElement('collab-tasks-settings-102025')
], CollabTasksSettings);
export { CollabTasksSettings };
