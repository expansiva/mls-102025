/// <mls fileReference="_102025_/l2/collabTasksCard.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    open: 'Abrir sala da task',
    todo: 'A fazer',
    inProgress: 'Em andamento',
    paused: 'Pausado',
    done: 'Concluído',
    failed: 'Falhou',
};
const message_en = {
    open: 'Open task room',
    todo: 'To do',
    inProgress: 'In progress',
    paused: 'Paused',
    done: 'Done',
    failed: 'Failed',
};
/// **collab_i18n_end**
import { html, nothing } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { dispatchThreadOpen } from '/_102025_/l2/collabMessagesEvents.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
const TAG_COLOR_MAP = {
    bug: 'bug',
    feature: 'feature',
    business: 'business',
    process: 'process',
    empresa: 'business',
    processo: 'process',
};
function tagColor(tag, vocab) {
    if (vocab) {
        const entry = vocab.find(e => e.tag === tag);
        if (entry)
            return entry.color;
    }
    return TAG_COLOR_MAP[tag.toLowerCase()] || 'neutral';
}
function assigneeColorIndex(userId) {
    let hash = 0;
    for (let i = 0; i < userId.length; i++)
        hash = (hash + userId.charCodeAt(i)) & 0xff;
    return hash % 5;
}
function assigneeInitials(userId) {
    const parts = userId.split(/[\s._-]/);
    if (parts.length >= 2)
        return (parts[0][0] + parts[1][0]).toUpperCase();
    return userId.slice(0, 2).toUpperCase();
}
const STATUS_EMOJI = {
    'todo': '⬜',
    'in progress': '▶️',
    'paused': '⏸️',
    'done': '✅',
    'failed': '❌',
};
const STATUS_CLASS = {
    'todo': 'board-status-todo',
    'in progress': 'board-status-in-progress',
    'paused': 'board-status-paused',
    'done': 'board-status-done',
    'failed': 'board-status-failed',
};
let CollabTasksCard = class CollabTasksCard extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-tasks-card-102025 {
  display: block;
  position: relative;
  background: var(--color-background-primary, #ffffff);
  border: 1px solid var(--color-border, #e5e7eb);
  border-radius: 8px;
  padding: 10px 12px;
  cursor: pointer;
  transition: box-shadow 0.12s ease-out, border-color 0.12s ease-out, transform 0.12s ease-out;
  outline: none;
}
collab-tasks-card-102025:hover {
  border-color: var(--color-accent, #6366f1);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
  transform: translateY(-1px);
}
collab-tasks-card-102025:focus-visible {
  outline: 2px solid var(--color-accent, #6366f1);
  outline-offset: 2px;
}
collab-tasks-card-102025.has-board-status::before {
  content: '';
  position: absolute;
  top: -1px;
  left: -1px;
  right: -1px;
  height: 2px;
  border-radius: 8px 8px 0 0;
  background: var(--card-status-accent, var(--color-accent, #6366f1));
}
collab-tasks-card-102025.board-status-todo {
  --card-status-accent: #185fa5;
}
collab-tasks-card-102025.board-status-in-progress {
  --card-status-accent: #854f0b;
}
collab-tasks-card-102025.board-status-paused {
  --card-status-accent: #6b7280;
}
collab-tasks-card-102025.board-status-done {
  --card-status-accent: #3b6d11;
}
collab-tasks-card-102025.board-status-failed {
  --card-status-accent: #a32d2d;
}
collab-tasks-card-102025 .card-title {
  font-size: 13px;
  font-weight: 500;
  color: var(--color-text-primary, #111111);
  margin-bottom: 4px;
  line-height: 1.4;
}
collab-tasks-card-102025 .card-description {
  font-size: 12px;
  color: var(--color-text-secondary, #6b7280);
  margin-bottom: 6px;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
collab-tasks-card-102025 .card-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  align-items: center;
  margin-bottom: 4px;
}
collab-tasks-card-102025 .card-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 6px;
  gap: 6px;
}
collab-tasks-card-102025 .assignee-row {
  display: flex;
  align-items: center;
  gap: 3px;
}
collab-tasks-card-102025 .assignee-chip {
  width: 20px;
  height: 20px;
  border-radius: 50%;
  font-size: 9px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  position: relative;
}
collab-tasks-card-102025 .assignee-chip[title]:hover::after {
  content: attr(title);
  position: absolute;
  bottom: calc(100% + 4px);
  left: 50%;
  transform: translateX(-50%);
  background: rgba(0, 0, 0, 0.75);
  color: #fff;
  font-size: 11px;
  font-weight: 400;
  padding: 2px 6px;
  border-radius: 4px;
  white-space: nowrap;
  pointer-events: none;
  z-index: 10;
}
collab-tasks-card-102025 .assignee-0 {
  background: #dbeafe;
  color: #1e40af;
}
collab-tasks-card-102025 .assignee-1 {
  background: #d1fae5;
  color: #065f46;
}
collab-tasks-card-102025 .assignee-2 {
  background: #fef3c7;
  color: #92400e;
}
collab-tasks-card-102025 .assignee-3 {
  background: #ede9fe;
  color: #5b21b6;
}
collab-tasks-card-102025 .assignee-4 {
  background: #fee2e2;
  color: #991b1b;
}
collab-tasks-card-102025 .assignee-overflow {
  background: var(--color-background-secondary, #f3f4f6);
  color: var(--color-text-secondary, #6b7280);
}
collab-tasks-card-102025 .status-emoji {
  font-size: 13px;
  line-height: 1;
  cursor: default;
  position: relative;
  flex-shrink: 0;
}
collab-tasks-card-102025 .status-emoji[title]:hover::after {
  content: attr(title);
  position: absolute;
  bottom: calc(100% + 4px);
  right: 0;
  background: rgba(0, 0, 0, 0.75);
  color: #fff;
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 4px;
  white-space: nowrap;
  pointer-events: none;
  z-index: 10;
}
collab-tasks-card-102025 .badge {
  font-size: 10px;
  font-weight: 600;
  padding: 2px 7px;
  border-radius: 9999px;
  letter-spacing: 0.02em;
}
collab-tasks-card-102025 .b-bug {
  background: #fee2e2;
  color: #991b1b;
}
collab-tasks-card-102025 .b-feature {
  background: #dbeafe;
  color: #1e40af;
}
collab-tasks-card-102025 .b-business {
  background: #fef3c7;
  color: #92400e;
}
collab-tasks-card-102025 .b-process {
  background: #d1fae5;
  color: #065f46;
}
collab-tasks-card-102025 .b-neutral {
  background: var(--color-background-secondary, #f3f4f6);
  color: var(--color-text-secondary, #6b7280);
}
collab-tasks-card-102025 .priority-pill {
  font-size: 10px;
  padding: 1px 6px;
  border-radius: 4px;
  background: var(--color-background-secondary, #f3f4f6);
  color: var(--color-text-secondary, #6b7280);
}
collab-tasks-card-102025 .priority-high,
collab-tasks-card-102025 .priority-urgent {
  background: #fef3c7;
  color: #b45309;
}
collab-tasks-card-102025 .due-pill {
  font-size: 10px;
  padding: 1px 6px;
  border-radius: 4px;
  background: var(--color-background-secondary, #f3f4f6);
  color: var(--color-text-secondary, #6b7280);
}
collab-tasks-card-102025 .pma-badge {
  font-size: 10px;
  padding: 1px 6px;
  border-radius: 4px;
  background: #ede9fe;
  color: var(--color-accent, #6366f1);
}
@media (max-width: 279px) {
  collab-tasks-card-102025 .card-description {
    display: none;
  }
}
@media (prefers-color-scheme: dark) {
  collab-tasks-card-102025:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.32);
  }
}
@media (prefers-reduced-motion: reduce) {
  collab-tasks-card-102025 {
    transition: none;
  }
  collab-tasks-card-102025:hover {
    transform: none;
  }
}
`);
        this.tagVocabulary = [];
        this.boardStatus = '';
    }
    connectedCallback() {
        super.connectedCallback();
        this.setAttribute('tabindex', '0');
        this.setAttribute('role', 'button');
        this.addEventListener('click', this._onClick.bind(this));
        this.addEventListener('keydown', this._onKeyDown.bind(this));
    }
    updated(changed) {
        super.updated(changed);
        if (changed.has('boardStatus'))
            this._applyStatusClass();
    }
    _applyStatusClass() {
        // Remove any previous status class
        Object.values(STATUS_CLASS).forEach(c => this.classList.remove(c));
        if (this.boardStatus) {
            const cls = STATUS_CLASS[this.boardStatus];
            if (cls) {
                this.classList.add(cls);
                this.classList.add('has-board-status');
            }
        }
        else {
            this.classList.remove('has-board-status');
        }
    }
    render() {
        const task = this.task;
        if (!task)
            return nothing;
        const m = getMsg();
        const firstTag = task.tags?.[0];
        const tc = firstTag ? tagColor(firstTag, this.tagVocabulary) : null;
        const pmaId = task.taskRoom?.pmaId;
        const assignees = task.assignees ?? [];
        const visibleAssignees = assignees.slice(0, 3);
        const overflowCount = assignees.length - visibleAssignees.length;
        const statusEmoji = STATUS_EMOJI[task.status] ?? '';
        const statusLabel = m[task.status === 'in progress' ? 'inProgress' : task.status] ?? task.status;
        return html `
      <div class="card-title">${task.title}</div>
      ${task.description ? html `<div class="card-description">${task.description}</div>` : nothing}
      <div class="card-meta">
        ${firstTag && tc ? html `<span class="badge b-${tc}">${firstTag}</span>` : nothing}
        ${task.priority ? html `<span class="priority-pill priority-${task.priority}">${task.priority}</span>` : nothing}
        ${pmaId ? html `<span class="pma-badge">${pmaId}</span>` : nothing}
      </div>
      <div class="card-footer">
        <div class="assignee-row">
          ${visibleAssignees.map(uid => html `
            <span
              class="assignee-chip assignee-${assigneeColorIndex(uid)}"
              title=${uid}
            >${assigneeInitials(uid)}</span>
          `)}
          ${overflowCount > 0 ? html `<span class="assignee-chip assignee-overflow">+${overflowCount}</span>` : nothing}
        </div>
        <div style="display:flex;align-items:center;gap:6px;">
          ${task.dueDate ? html `<span class="due-pill">📅 ${task.dueDate}</span>` : nothing}
          ${statusEmoji ? html `<span class="status-emoji" title=${statusLabel}>${statusEmoji}</span>` : nothing}
        </div>
      </div>
    `;
    }
    _onClick() {
        const task = this.task;
        if (!task?.taskRoom?.threadId)
            return;
        dispatchThreadOpen(task.taskRoom.threadId, task.PK);
    }
    _onKeyDown(e) {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this._onClick();
        }
    }
};
__decorate([
    property({ type: Object })
], CollabTasksCard.prototype, "task", void 0);
__decorate([
    property({ type: Array })
], CollabTasksCard.prototype, "tagVocabulary", void 0);
__decorate([
    property({ type: String })
], CollabTasksCard.prototype, "boardStatus", void 0);
CollabTasksCard = __decorate([
    customElement('collab-tasks-card-102025')
], CollabTasksCard);
export { CollabTasksCard };
