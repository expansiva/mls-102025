/// <mls fileReference="_102025_/l2/collabTasksCard.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    open: 'Abrir sala da task',
    todo: 'A fazer',
    inProgress: 'Em andamento',
    paused: 'Pausado',
    done: 'Concluído',
    failed: 'Falhou',
};
const message_en = {
    open: 'Open task room',
    todo: 'To do',
    inProgress: 'In progress',
    paused: 'Paused',
    done: 'Done',
    failed: 'Failed',
};
/// **collab_i18n_end**
import { html, nothing } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { openElementInServiceDetails } from '/_102027_/l2/libCommom.js';
import { getUserId } from '/_102025_/l2/collabMessagesHelper.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
const TAG_COLOR_MAP = {
    bug: 'bug',
    feature: 'feature',
    business: 'business',
    process: 'process',
    empresa: 'business',
    processo: 'process',
};
function tagColor(tag, vocab) {
    if (vocab) {
        const entry = vocab.find(e => e.tag === tag);
        if (entry)
            return entry.color;
    }
    return TAG_COLOR_MAP[tag.toLowerCase()] || 'neutral';
}
function assigneeColorIndex(userId) {
    let hash = 0;
    for (let i = 0; i < userId.length; i++)
        hash = (hash + userId.charCodeAt(i)) & 0xff;
    return hash % 5;
}
function assigneeInitials(userId) {
    const parts = userId.split(/[\s._-]/);
    if (parts.length >= 2)
        return (parts[0][0] + parts[1][0]).toUpperCase();
    return userId.slice(0, 2).toUpperCase();
}
const STATUS_EMOJI = {
    'todo': '⬜',
    'in progress': '▶️',
    'paused': '⏸️',
    'done': '✅',
    'failed': '❌',
};
const STATUS_CLASS = {
    'todo': 'board-status-todo',
    'in progress': 'board-status-in-progress',
    'paused': 'board-status-paused',
    'done': 'board-status-done',
    'failed': 'board-status-failed',
};
let CollabTasksCard = class CollabTasksCard extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-tasks-card-102025 {
  display: block;
  position: relative;
  background: var(--board-card-bg, var(--color-background-primary, #ffffff));
  border: 0.5px solid var(--board-col-border, var(--color-border-tertiary, rgba(0, 0, 0, 0.08)));
  border-radius: 10px;
  padding: 9px 11px 8px;
  cursor: pointer;
  transition: border-color 0.12s ease-out, box-shadow 0.12s ease-out, transform 0.1s ease-out;
  outline: none;
  overflow: hidden;
}
collab-tasks-card-102025:hover {
  border-color: var(--color-border-secondary, rgba(0, 0, 0, 0.18));
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.06);
  transform: translateY(-1px);
}
collab-tasks-card-102025:focus-visible {
  outline: 2px solid var(--status-todo-accent, #185fa5);
  outline-offset: 2px;
}
collab-tasks-card-102025:active {
  transform: translateY(0);
  box-shadow: none;
}
collab-tasks-card-102025.has-board-status::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  width: 3px;
  border-radius: 10px 0 0 10px;
  background: var(--card-status-accent, var(--color-border-secondary, rgba(0, 0, 0, 0.18)));
}
collab-tasks-card-102025.has-board-status {
  padding-left: 13px;
}
collab-tasks-card-102025.board-status-todo {
  --card-status-accent: var(--status-todo-accent, #185fa5);
}
collab-tasks-card-102025.board-status-in-progress {
  --card-status-accent: var(--status-in-progress-accent, #854f0b);
}
collab-tasks-card-102025.board-status-paused {
  --card-status-accent: var(--status-paused-accent, #6b7280);
}
collab-tasks-card-102025.board-status-done {
  --card-status-accent: var(--status-done-accent, #3b6d11);
}
collab-tasks-card-102025.board-status-failed {
  --card-status-accent: var(--status-failed-accent, #a32d2d);
}
collab-tasks-card-102025 .card-title {
  font-size: 12px;
  font-weight: 500;
  color: var(--color-text-primary, #1a1a18);
  margin-bottom: 5px;
  line-height: 1.35;
}
collab-tasks-card-102025 .card-description {
  font-size: 11px;
  color: var(--color-text-secondary, #5f5e5a);
  margin-bottom: 6px;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}
collab-tasks-card-102025 .card-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  align-items: center;
  margin-bottom: 7px;
}
collab-tasks-card-102025 .card-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 6px;
  border-top: 0.5px solid var(--board-col-border, rgba(0, 0, 0, 0.06));
  padding-top: 6px;
  margin-top: 2px;
}
collab-tasks-card-102025 .assignee-row {
  display: flex;
  align-items: center;
  gap: 2px;
}
collab-tasks-card-102025 .assignee-chip {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  font-size: 8px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  position: relative;
  border: 0.5px solid rgba(255, 255, 255, 0.5);
}
collab-tasks-card-102025 .assignee-chip[title]:hover::after {
  content: attr(title);
  position: absolute;
  bottom: calc(100% + 4px);
  left: 50%;
  transform: translateX(-50%);
  background: rgba(0, 0, 0, 0.78);
  color: #fff;
  font-size: 11px;
  font-weight: 400;
  padding: 2px 6px;
  border-radius: 4px;
  white-space: nowrap;
  pointer-events: none;
  z-index: 20;
}
collab-tasks-card-102025 .assignee-0 {
  background: #dbeafe;
  color: #1e40af;
}
collab-tasks-card-102025 .assignee-1 {
  background: #d1fae5;
  color: #065f46;
}
collab-tasks-card-102025 .assignee-2 {
  background: #fef3c7;
  color: #92400e;
}
collab-tasks-card-102025 .assignee-3 {
  background: #ede9fe;
  color: #5b21b6;
}
collab-tasks-card-102025 .assignee-4 {
  background: #fee2e2;
  color: #991b1b;
}
collab-tasks-card-102025 .assignee-overflow {
  background: var(--color-background-secondary, #f5f4f0);
  color: var(--color-text-tertiary, #888780);
  font-size: 8px;
}
collab-tasks-card-102025 .status-emoji {
  font-size: 11px;
  line-height: 1;
  cursor: default;
  position: relative;
  flex-shrink: 0;
}
collab-tasks-card-102025 .status-emoji[title]:hover::after {
  content: attr(title);
  position: absolute;
  bottom: calc(100% + 4px);
  right: 0;
  background: rgba(0, 0, 0, 0.78);
  color: #fff;
  font-size: 11px;
  padding: 2px 6px;
  border-radius: 4px;
  white-space: nowrap;
  pointer-events: none;
  z-index: 20;
}
collab-tasks-card-102025 .badge {
  font-size: 9px;
  font-weight: 500;
  padding: 2px 6px;
  border-radius: 8px;
  letter-spacing: 0.02em;
}
collab-tasks-card-102025 .b-bug {
  background: #fcebeb;
  color: #a32d2d;
}
collab-tasks-card-102025 .b-feature {
  background: #e6f1fb;
  color: #185fa5;
}
collab-tasks-card-102025 .b-business {
  background: #faeeda;
  color: #633806;
}
collab-tasks-card-102025 .b-process {
  background: #e1f5ee;
  color: #085041;
}
collab-tasks-card-102025 .b-neutral {
  background: var(--color-background-secondary, #f5f4f0);
  color: var(--color-text-tertiary, #888780);
}
collab-tasks-card-102025 .priority-pill {
  font-size: 9px;
  padding: 2px 6px;
  border-radius: 8px;
  background: var(--color-background-secondary, #f5f4f0);
  color: var(--color-text-tertiary, #888780);
}
collab-tasks-card-102025 .priority-high,
collab-tasks-card-102025 .priority-urgent {
  background: #faeeda;
  color: #854f0b;
}
collab-tasks-card-102025 .due-pill {
  font-size: 9px;
  padding: 2px 5px;
  border-radius: 6px;
  background: var(--color-background-secondary, #f5f4f0);
  color: var(--color-text-tertiary, #888780);
}
collab-tasks-card-102025 .pma-badge {
  font-size: 9px;
  padding: 2px 6px;
  border-radius: 8px;
  background: #ede9fe;
  color: #5b21b6;
}
@media (max-width: 259px) {
  collab-tasks-card-102025 .card-description {
    display: none;
  }
}
.theme-amber collab-tasks-card-102025 {
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.07);
}
.theme-amber collab-tasks-card-102025:hover {
  box-shadow: 0 4px 12px rgba(120, 68, 8, 0.14);
  border-color: rgba(100, 55, 5, 0.22);
}
.theme-amber collab-tasks-card-102025 .card-footer {
  border-color: rgba(100, 55, 5, 0.08);
}
.theme-forest collab-tasks-card-102025 {
  border-color: rgba(0, 0, 0, 0.1);
}
.theme-forest collab-tasks-card-102025 .card-title {
  color: #1a1a18;
}
.theme-forest collab-tasks-card-102025 .card-description {
  color: #5f5e5a;
}
.theme-forest collab-tasks-card-102025 .card-footer {
  border-color: rgba(0, 0, 0, 0.08);
}
.theme-trello collab-tasks-card-102025 .card-title {
  color: #172b4d;
}
.theme-trello collab-tasks-card-102025 .card-description {
  color: #5e6c84;
}
.theme-trello collab-tasks-card-102025 .card-footer {
  border-color: rgba(9, 30, 66, 0.08);
}
.theme-trello collab-tasks-card-102025 .badge.b-bug {
  background: #ffebe6;
  color: #bf2600;
}
.theme-trello collab-tasks-card-102025 .badge.b-feature {
  background: #deebff;
  color: #0052cc;
}
.theme-trello collab-tasks-card-102025 .badge.b-business {
  background: #fff0b3;
  color: #974f0c;
}
.theme-trello collab-tasks-card-102025 .badge.b-process {
  background: #e3fcef;
  color: #006644;
}
.theme-trello collab-tasks-card-102025.has-board-status::before {
  display: none;
}
.theme-trello collab-tasks-card-102025.has-board-status {
  padding-left: 11px;
}
.theme-clickup collab-tasks-card-102025 .card-title {
  color: rgba(235, 225, 255, 0.94);
}
.theme-clickup collab-tasks-card-102025 .card-description {
  color: rgba(190, 175, 240, 0.7);
}
.theme-clickup collab-tasks-card-102025 .card-footer {
  border-color: rgba(147, 51, 234, 0.18);
}
.theme-clickup collab-tasks-card-102025 .badge.b-bug {
  background: rgba(248, 113, 113, 0.18);
  color: #fca5a5;
}
.theme-clickup collab-tasks-card-102025 .badge.b-feature {
  background: rgba(129, 140, 248, 0.18);
  color: #a5b4fc;
}
.theme-clickup collab-tasks-card-102025 .badge.b-business {
  background: rgba(251, 146, 60, 0.18);
  color: #fdba74;
}
.theme-clickup collab-tasks-card-102025 .badge.b-process {
  background: rgba(52, 211, 153, 0.18);
  color: #6ee7b7;
}
.theme-clickup collab-tasks-card-102025 .badge.b-neutral {
  background: rgba(255, 255, 255, 0.08);
  color: rgba(200, 185, 255, 0.65);
}
.theme-clickup collab-tasks-card-102025 .priority-pill,
.theme-clickup collab-tasks-card-102025 .due-pill {
  background: rgba(255, 255, 255, 0.08);
  color: rgba(200, 185, 255, 0.75);
}
.theme-clickup collab-tasks-card-102025 .pma-badge {
  background: rgba(167, 139, 250, 0.18);
  color: #c4b5fd;
}
.theme-clickup collab-tasks-card-102025 .assignee-chip {
  border-color: rgba(147, 51, 234, 0.3);
}
@media (prefers-color-scheme: dark) {
  collab-tasks-card-102025:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.32);
  }
}
@media (prefers-reduced-motion: reduce) {
  collab-tasks-card-102025 {
    transition: none;
  }
  collab-tasks-card-102025:hover {
    transform: none;
  }
}
`);
        this.tagVocabulary = [];
        this.boardStatus = '';
    }
    connectedCallback() {
        super.connectedCallback();
        this.setAttribute('tabindex', '0');
        this.setAttribute('role', 'button');
        this.addEventListener('click', this._onClick.bind(this));
        this.addEventListener('keydown', this._onKeyDown.bind(this));
    }
    updated(changed) {
        super.updated(changed);
        if (changed.has('boardStatus'))
            this._applyStatusClass();
    }
    _applyStatusClass() {
        // Remove any previous status class
        Object.values(STATUS_CLASS).forEach(c => this.classList.remove(c));
        if (this.boardStatus) {
            const cls = STATUS_CLASS[this.boardStatus];
            if (cls) {
                this.classList.add(cls);
                this.classList.add('has-board-status');
            }
        }
        else {
            this.classList.remove('has-board-status');
        }
    }
    render() {
        const task = this.task;
        if (!task)
            return nothing;
        const m = getMsg();
        const firstTag = task.tags?.[0];
        const tc = firstTag ? tagColor(firstTag, this.tagVocabulary) : null;
        const pmaId = task.taskRoom?.pmaId;
        const assignees = task.assignees ?? [];
        const visibleAssignees = assignees.slice(0, 3);
        const overflowCount = assignees.length - visibleAssignees.length;
        const statusEmoji = STATUS_EMOJI[task.status] ?? '';
        const statusLabel = m[task.status === 'in progress' ? 'inProgress' : task.status] ?? task.status;
        return html `
      <div class="card-title">${task.title}</div>
      ${task.description ? html `<div class="card-description">${task.description}</div>` : nothing}
      <div class="card-meta">
        ${firstTag && tc ? html `<span class="badge b-${tc}">${firstTag}</span>` : nothing}
        ${task.priority ? html `<span class="priority-pill priority-${task.priority}">${task.priority}</span>` : nothing}
        ${pmaId ? html `<span class="pma-badge">${pmaId}</span>` : nothing}
      </div>
      <div class="card-footer">
        <div class="assignee-row">
          ${visibleAssignees.map(uid => html `
            <span
              class="assignee-chip assignee-${assigneeColorIndex(uid)}"
              title=${uid}
            >${assigneeInitials(uid)}</span>
          `)}
          ${overflowCount > 0 ? html `<span class="assignee-chip assignee-overflow">+${overflowCount}</span>` : nothing}
        </div>
        <div style="display:flex;align-items:center;gap:6px;">
          ${task.dueDate ? html `<span class="due-pill">📅 ${task.dueDate}</span>` : nothing}
          ${statusEmoji ? html `<span class="status-emoji" title=${statusLabel}>${statusEmoji}</span>` : nothing}
        </div>
      </div>
    `;
    }
    async _onClick() {
        const task = this.task;
        if (!task)
            return;
        await import('/_102025_/l2/collabMessagesTaskRoom.js');
        const room = document.createElement('collab-messages-task-room-102025');
        room.task = task;
        room.userId = getUserId() || '';
        openElementInServiceDetails(room);
    }
    _onKeyDown(e) {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this._onClick();
        }
    }
};
__decorate([
    property({ type: Object })
], CollabTasksCard.prototype, "task", void 0);
__decorate([
    property({ type: Array })
], CollabTasksCard.prototype, "tagVocabulary", void 0);
__decorate([
    property({ type: String })
], CollabTasksCard.prototype, "boardStatus", void 0);
CollabTasksCard = __decorate([
    customElement('collab-tasks-card-102025')
], CollabTasksCard);
export { CollabTasksCard };
