/// <mls fileReference="_102025_/l2/collabMessagesTaskPreviewFlexible.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { CollabLitElement } from '/_102027_/l2/collabLitElement.js';
let CollabMessagesTaskPreviewFlexible = class CollabMessagesTaskPreviewFlexible extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-task-preview-flexible-102025 {
  display: block;
  background: #ffffff;
  position: relative;
  height: 100%;
  color: #3c3c3c;
}
collab-messages-task-preview-flexible-102025 .tab-header {
  display: flex;
  justify-content: space-between;
  border-bottom: 1px solid #ccc;
  background-color: #f0f0f0;
  overflow: hidden;
  flex-shrink: 0;
}
collab-messages-task-preview-flexible-102025 .tab-group-left {
  display: flex;
  overflow-x: auto;
  flex: 1;
  min-width: 0;
  scrollbar-width: thin;
}
collab-messages-task-preview-flexible-102025 .tab-group-left::-webkit-scrollbar {
  height: 6px;
}
collab-messages-task-preview-flexible-102025 .tab-group-left::-webkit-scrollbar-thumb {
  background-color: var(--grey-color-darker);
  border-radius: 4px;
}
collab-messages-task-preview-flexible-102025 .tab-group-right {
  display: flex;
  flex-shrink: 0;
}
collab-messages-task-preview-flexible-102025 .tab-button {
  padding: 10px 16px;
  cursor: pointer;
  background: none;
  border: none;
  border-right: 1px solid #ddd;
  font-size: 14px;
  transition: background-color 0.2s ease;
  display: flex;
  flex-direction: column;
}
collab-messages-task-preview-flexible-102025 .tab-button:hover {
  background-color: #e0e0e0;
}
collab-messages-task-preview-flexible-102025 .tab-button.active {
  background-color: #ffffff;
  font-weight: bold;
  border-bottom: 2px solid #007bff;
}
collab-messages-task-preview-flexible-102025 .tab-content {
  position: relative;
  padding: 0;
  margin: 0;
  background-color: #ffffff;
  display: flex;
  height: 100%;
  flex-direction: column;
  font-size: 14px;
  overflow-y: auto;
}
collab-messages-task-preview-flexible-102025 .containerinputs {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  align-items: center;
  padding: 1rem;
}
collab-messages-task-preview-flexible-102025 .containerinputs details {
  width: 100%;
  max-width: 900px;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  background-color: #fafafa;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  font-family: 'Inter', sans-serif;
  transition: all 0.3s ease;
}
collab-messages-task-preview-flexible-102025 .containerinputs details[open] .title {
  display: none;
}
collab-messages-task-preview-flexible-102025 .containerinputs details .chevron {
  transition: transform 0.3s;
}
collab-messages-task-preview-flexible-102025 .containerinputs details[open] .chevron {
  transform: rotate(90deg);
}
collab-messages-task-preview-flexible-102025 .containerinputs details[open] .moveelement {
  display: none !important;
}
collab-messages-task-preview-flexible-102025 .containerinputs details summary {
  position: relative;
  cursor: pointer;
  padding: 1rem;
  border-bottom: 1px solid #e0e0e0;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
collab-messages-task-preview-flexible-102025 .containerinputs details summary:hover .moveelement {
  display: flex;
}
collab-messages-task-preview-flexible-102025 .containerinputs details summary .trash {
  z-index: 9999;
}
collab-messages-task-preview-flexible-102025 .containerinputs details summary .pheader {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
collab-messages-task-preview-flexible-102025 .containerinputs details summary .pheader .title {
  margin-left: 1rem;
}
collab-messages-task-preview-flexible-102025 .containerinputs details summary .pheader .type .typeMode {
  appearance: none;
  padding: 0.4rem 1rem;
  font-size: 0.95rem;
  border: 1px solid #ccc;
  border-radius: 6px;
  background-color: white;
  transition: border 0.3s ease;
}
collab-messages-task-preview-flexible-102025 .containerinputs details > div {
  padding: 1rem;
}
collab-messages-task-preview-flexible-102025 .containerinputs details > div pre.content {
  width: calc(100% - 2rem);
  border: none;
  resize: vertical;
  padding: 1rem;
  font-size: 0.95rem;
  font-family: 'Fira Code', monospace;
  background-color: #fff;
  border-radius: 6px;
  color: #333;
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.05);
  line-height: 1.5;
  word-break: break-word;
  white-space: pre-wrap;
}
collab-messages-task-preview-flexible-102025 ul {
  list-style: none;
  padding: 1rem;
  margin: 1rem 0;
  border-radius: 12px;
  color: #333;
}
collab-messages-task-preview-flexible-102025 ul li {
  margin-bottom: 0.75rem;
  padding: 0.5rem 0.75rem;
  background: white;
  border-radius: 8px;
  transition: background 0.3s;
}
collab-messages-task-preview-flexible-102025 ul li code {
  font-family: 'Courier New', monospace;
  background-color: #eee;
  padding: 2px 6px;
  border-radius: 4px;
}
`);
        this.mode = 'flexible';
        this.message = null;
        this.task = null;
        this.step = null;
        this.msize = '';
        // ── Editor config ─────────────────────────────────────────────────────────
        this.editorConf = {
            contextmenu: true,
            autoIndent: 'full',
            wordWrap: 'on',
            wrappingIndent: 'indent',
            tabCompletion: 'on',
            renderControlCharacters: false,
            showUnused: true,
            glyphMargin: true,
            minimap: { enabled: false },
            useTabStops: true,
            scrollBeyondLastColumn: 2,
            scrollBeyondLastLine: false,
            formatOnType: true,
            fixedOverflowWidgets: true,
            codeLens: true,
            showFoldingControls: 'mouseover',
            suggestSelection: 'first',
            stickyScroll: { enabled: false, maxLineCount: 3 },
            stickyTabStops: true,
            fontSize: 14,
            automaticLayout: true,
        };
    }
    get sharedEditor() {
        return window.elEditorTaskView;
    }
    get sharedMonaco() {
        return window.editorTaskView;
    }
    async firstUpdated() {
        if (this.mode === 'flexible') {
            this.mountEditor();
        }
    }
    updated(changedProps) {
        if (this.mode === 'flexible') {
            // Re-mount the shared editor whenever it isn't inside our host
            // (re-render recreated #elEditor, or another instance grabbed it).
            const detached = !!this.elEditor && (!this.sharedEditor || this.sharedEditor.parentElement !== this.elEditor);
            if (detached || changedProps.has('mode')) {
                this.mountEditor();
                this.updateEditorContent();
            }
            else if (changedProps.has('step')) {
                this.updateEditorContent();
            }
        }
        if (changedProps.has('msize')) {
            this.sharedEditor?.setAttribute('msize', this.msize);
        }
    }
    // ── Editor lifecycle ──────────────────────────────────────────────────────
    ensureEditorCreated() {
        if (this.sharedMonaco)
            return;
        const editorEl = document.createElement('mls-editor-100529');
        editorEl.style.cssText = 'width:100%; height:100%';
        const model = this.createModel();
        const ed1 = monaco.editor.create(editorEl, this.editorConf);
        monaco.languages.typescript.javascriptDefaults.setCompilerOptions({ noImplicitAny: true });
        ed1.updateOptions({ readOnly: true });
        ed1.setModel(model);
        editorEl.mlsEditor = ed1;
        window.elEditorTaskView = editorEl;
        window.editorTaskView = ed1;
    }
    /**
     * Called every time the flexible tab becomes visible.
     * Creates the shared editor once, then re-appends it to the fresh #elEditor node.
     */
    mountEditor() {
        if (!this.elEditor)
            return;
        this.ensureEditorCreated();
        this.elEditor.appendChild(this.sharedEditor);
    }
    createModel() {
        const uri = monaco.Uri.parse('file://server/taskViewModel.ts');
        return monaco.editor.getModel(uri)
            ?? monaco.editor.createModel('', 'javascript', uri);
    }
    updateEditorContent() {
        const ed1 = this.sharedMonaco;
        if (!ed1 || !this.step)
            return;
        const value = JSON.stringify(this.step.result, null, 2);
        ed1.getModel()?.setValue(value);
    }
    // ── Render ────────────────────────────────────────────────────────────────
    render() {
        if (!this.step)
            return html `<p>Step not Found.</p>`;
        return html `
            <div style="height: calc(100% - 41px);">
                <div class="tab-header">
                    <div class="tab-group-left">
                        <button class="tab-button ${this.mode === 'info' ? 'active' : ''}"
                            @click=${() => this.setMode('info')}>Info</button>
                        <button class="tab-button ${this.mode === 'flexible' ? 'active' : ''}"
                            @click=${() => this.setMode('flexible')}>Flexible</button>
                    </div>
                </div>
                <div class="tab-content">
                    ${this.renderMode()}
                </div>
            </div>
        `;
    }
    setMode(mode) {
        this.mode = mode;
    }
    renderMode() {
        switch (this.mode) {
            case 'flexible': return this.renderFlexible();
            case 'info': return this.renderInfo();
            case 'result': return this.renderResults();
            default: return this.renderInfo();
        }
    }
    renderInfo() {
        if (!this.task || !this.step)
            return html `Not found!`;
        const progressLabel = this.step.status === 'in_progress' ? '(in progress)' : '';
        const lastUpdated = new Date(this.task.last_updated).toLocaleString();
        const cost = this.step.interaction?.cost ?? '0';
        return html `
            <div class="containerinputs">
                <details open>
                    <summary>${this.renderSummary(`Flexible ${progressLabel}`)}</summary>
                    <ul>
                        <li>#${this.step.stepId} - ${this.step.type} - ${this.step.status} - $${cost}</li>
                    </ul>
                </details>
                <details>
                    <summary>${this.renderSummary('Task details')}</summary>
                    <ul>
                        <li>
                            <header>
                                <h2>${this.task.PK}</h2>
                                <small>Status: ${this.task.status} | Última atualização: ${lastUpdated}</small>
                                <br/><small>${this.task.title}</small>
                            </header>
                        </li>
                    </ul>
                </details>
                <details>
                    <summary>${this.renderSummary('Message details')}</summary>
                    <ul>
                        <li><pre>${JSON.stringify(this.message, null, 2)}</pre></li>
                    </ul>
                </details>
            </div>
        `;
    }
    renderSummary(title) {
        return html `
            <div class="pheader">
                <div style="display:flex; align-items:center; gap:.5rem">
                    <span>${title}</span>
                </div>
                <div style="display:flex; gap:.5rem">
                    <div class="chevron">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" style="width:10px">
                            <path d="M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"/>
                        </svg>
                    </div>
                </div>
            </div>
        `;
    }
    renderFlexible() {
        if (!this.step)
            return html `
            <div class="containerinputs"><h3>No input found!</h3></div>
        `;
        if (this.step.result?.dataUrl) {
            return html `
                <div style="max-width:520px; margin:0 auto; text-align:center;">
                    <figure style="margin:0;">
                        <img
                            src="${this.step.result.dataUrl}"
                            alt="${this.step.result.dataUrl}"
                            style="width:100%; height:auto; display:block; border-radius:12px; box-shadow:0 6px 18px rgba(0,0,0,0.12);"
                        />
                        <figcaption style="margin-top:10px; font-size:14px; color:#555; line-height:1.4;">
                            ${this.step.result.dataUrl}
                        </figcaption>
                    </figure>
                </div>
            `;
        }
        return html `<div id="elEditor" style="width:100%; height:100%"></div>`;
    }
    renderResults() {
        if (!this.step)
            return html `Not found step`;
        const nextOptions = [
            ...(this.step.interaction?.payload ?? []),
            ...(this.step.nextSteps ?? []),
        ];
        return html `
            <ul>
                ${nextOptions.length === 0
            ? html `<li><em>Not next step</em></li>`
            : nextOptions.map((ns) => html `<li>[${ns.stepId}] ${ns.type} - ${ns.agentName}</li>`)}
            </ul>
        `;
    }
};
__decorate([
    state()
], CollabMessagesTaskPreviewFlexible.prototype, "mode", void 0);
__decorate([
    property({ type: Object })
], CollabMessagesTaskPreviewFlexible.prototype, "message", void 0);
__decorate([
    property({ type: Object })
], CollabMessagesTaskPreviewFlexible.prototype, "task", void 0);
__decorate([
    property({ type: Object })
], CollabMessagesTaskPreviewFlexible.prototype, "step", void 0);
__decorate([
    property({ type: String })
], CollabMessagesTaskPreviewFlexible.prototype, "msize", void 0);
__decorate([
    query('#elEditor')
], CollabMessagesTaskPreviewFlexible.prototype, "elEditor", void 0);
CollabMessagesTaskPreviewFlexible = __decorate([
    customElement('collab-messages-task-preview-flexible-102025')
], CollabMessagesTaskPreviewFlexible);
export { CollabMessagesTaskPreviewFlexible };
