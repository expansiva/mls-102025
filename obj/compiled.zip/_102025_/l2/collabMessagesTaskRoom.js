/// <mls fileReference="_102025_/l2/collabMessagesTaskRoom.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { msgAddMessage, msgEnsureTaskRoom, msgGetThreadUpdates } from '/_102025_/l2/shared/api.js';
import '/_102025_/l2/collabMessagesChatMessage.js';
import '/_102025_/l2/collabMessagesPrompt.js';
let CollabMessagesTaskRoom = class CollabMessagesTaskRoom extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-task-room-102025 {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
  flex: 1;
}
collab-messages-task-room-102025 .task-room {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  flex: 1;
  height: 100%;
  min-height: 0;
}
collab-messages-task-room-102025 .task-room-messages {
  display: flex;
  flex-direction: column;
  align-items: stretch;
  flex: 1;
  min-height: 0;
  overflow: auto;
  overflow-x: hidden;
  padding-right: 0.25rem;
}
collab-messages-task-room-102025 collab-messages-prompt-102025 {
  flex-shrink: 0;
}
collab-messages-task-room-102025 collab-messages-chat-message-102025 {
  display: flex;
  width: 100%;
}
collab-messages-task-room-102025 .task-room-empty,
collab-messages-task-room-102025 .task-room-loading,
collab-messages-task-room-102025 .task-room-error {
  color: var(--text-primary-color-disabled);
  padding: 0.75rem 0;
}
collab-messages-task-room-102025 .task-room-error {
  color: var(--error-color);
}
`);
        this.roomUsers = [];
        this.messages = [];
        this.loading = false;
        this.error = '';
        this.ensuredKey = '';
    }
    async updated(changedProperties) {
        if (changedProperties.has('task') || changedProperties.has('message') || changedProperties.has('userId')) {
            await this.ensureRoom();
        }
    }
    render() {
        if (!this.task)
            return html `<div class="task-room-empty">No task.</div>`;
        if (this.error)
            return html `<div class="task-room-error">${this.error}</div>`;
        if (this.loading && !this.roomThread)
            return html `<div class="task-room-loading">Loading...</div>`;
        if (!this.roomThread)
            return nothing;
        const userId = this.getUserId();
        const displayMessages = this.messages.map((item, index) => this.toMessageView(item, index));
        const actualThread = {
            thread: this.roomThread,
            users: this.roomUsers,
            messages: displayMessages
        };
        return html `
            <div class="task-room">
                <div class="task-room-messages">
                    ${displayMessages.map((item) => html `
                        <collab-messages-chat-message-102025
                            .message=${item}
                            .actualThread=${actualThread}
                            .usersAvaliables=${this.roomUsers}
                            .userId=${userId}
                        ></collab-messages-chat-message-102025>
                    `)}
                </div>
                <collab-messages-prompt-102025
                    .threadId=${this.roomThread.threadId}
                    .userId=${userId}
                    placeholder="Message task room"
                    .onSend=${(content, options) => this.sendMessage(content, options)}
                    acceptAutoCompleteUser="true"
                    enableRichPreview="true"
                ></collab-messages-prompt-102025>
            </div>
        `;
    }
    async ensureRoom() {
        if (!this.task)
            return;
        const userId = this.getUserId();
        const parentThreadId = this.getParentThreadId();
        if (!userId || !parentThreadId) {
            this.error = 'Missing parent thread or user for task room.';
            return;
        }
        const key = this.getEnsureKey(userId, parentThreadId, this.task);
        if (this.roomThread && this.ensuredKey === key)
            return;
        if (this.loading && this.ensuredKey === key)
            return;
        this.ensuredKey = key;
        this.loading = true;
        this.error = '';
        const result = await msgEnsureTaskRoom({
            userId,
            taskId: this.task.PK,
            parentThreadId
        });
        this.loading = false;
        if (!result.success || !result.response) {
            this.error = result.error || 'Could not open task room.';
            return;
        }
        this.task = result.response.task;
        this.roomThread = result.response.thread;
        this.ensuredKey = this.getEnsureKey(userId, parentThreadId, result.response.task);
        await this.loadMessages();
    }
    async loadMessages() {
        const userId = this.getUserId();
        if (!this.roomThread || !userId)
            return;
        const result = await msgGetThreadUpdates({
            threadId: this.roomThread.threadId,
            userId,
            lastOrderAt: '20000101000000.0000'
        });
        if (!result.success || !result.response) {
            this.error = result.error || 'Could not load task room messages.';
            return;
        }
        this.roomThread = result.response.thread || this.roomThread;
        this.roomUsers = result.response.users || [];
        this.messages = result.response.messages || [];
    }
    async sendMessage(content, options) {
        const userId = this.getUserId();
        if (!this.roomThread || !userId || !content.trim())
            return;
        const result = await msgAddMessage({
            userId,
            threadId: this.roomThread.threadId,
            content,
            replyTo: options.replyTo
        });
        if (!result.success || !result.response) {
            this.error = result.error || 'Could not send task room message.';
            return;
        }
        this.messages = [...this.messages, result.response.message];
    }
    getUserId() {
        return this.userId || this.message?.senderId || '';
    }
    getParentThreadId() {
        return this.task?.taskRoom?.parentThreadId || this.message?.threadId || '';
    }
    getEnsureKey(userId, parentThreadId, task) {
        return `${task.PK}|${userId}|${parentThreadId}|${task.taskRoom?.threadId || ''}`;
    }
    toMessageView(message, index) {
        const previous = this.messages[index - 1];
        const { taskId, taskTitle, taskStatus, taskResults, taskResultsTranslated, taskTitleTranslated, ...messageWithoutTaskCard } = message;
        return {
            ...messageWithoutTaskCard,
            isSame: !!previous && previous.senderId === message.senderId,
            footers: []
        };
    }
};
__decorate([
    property()
], CollabMessagesTaskRoom.prototype, "task", void 0);
__decorate([
    property()
], CollabMessagesTaskRoom.prototype, "message", void 0);
__decorate([
    property()
], CollabMessagesTaskRoom.prototype, "userId", void 0);
__decorate([
    state()
], CollabMessagesTaskRoom.prototype, "roomThread", void 0);
__decorate([
    state()
], CollabMessagesTaskRoom.prototype, "roomUsers", void 0);
__decorate([
    state()
], CollabMessagesTaskRoom.prototype, "messages", void 0);
__decorate([
    state()
], CollabMessagesTaskRoom.prototype, "loading", void 0);
__decorate([
    state()
], CollabMessagesTaskRoom.prototype, "error", void 0);
CollabMessagesTaskRoom = __decorate([
    customElement('collab-messages-task-room-102025')
], CollabMessagesTaskRoom);
export { CollabMessagesTaskRoom };
