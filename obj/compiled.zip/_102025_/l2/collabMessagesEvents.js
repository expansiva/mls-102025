/// <mls fileReference="_102025_/l2/collabMessagesEvents.ts" enhancement="_blank"/>
export function notifyMessageSendChange(context) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('message-send', {
        detail: { context },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyTaskChange(context, oldContextCreateAt) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('task-change', {
        detail: { context, oldContextCreateAt },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
/** Ephemeral step title on the client. No server, store, or intents. */
export const STEP_TITLE_LOCAL_EVENT = 'step-title-local';
export const LOCAL_STEP_TITLE_MIN_MS = 500;
const localStepTitleLastEmit = new Map();
/** Pure tick decision: at most one event per step per ~500ms, drop a repeated same title. */
export function shouldEmitLocalStepTitle(last, now, title, minIntervalMs = LOCAL_STEP_TITLE_MIN_MS) {
    if (!title)
        return false;
    if (!last)
        return true;
    if (last.title === title)
        return false;
    if (now - last.at < minIntervalMs)
        return false;
    return true;
}
export function getLocalStepTitleEventScope() {
    try {
        if (typeof window === 'undefined')
            return undefined;
        return window.top ?? window;
    }
    catch {
        return undefined;
    }
}
/**
 * Paint a step title in the open task UI. Fail-soft: no window (headless/CLI) is a silent no-op;
 * any throw is swallowed — an ornament must never kill a run.
 */
export function changeLocalStepTitle(taskPK, stepId, title) {
    try {
        if (!taskPK || !title)
            return;
        const scopeWindow = getLocalStepTitleEventScope();
        if (!scopeWindow)
            return;
        const key = `${taskPK}:${stepId}`;
        const now = Date.now();
        const last = localStepTitleLastEmit.get(key);
        if (!shouldEmitLocalStepTitle(last, now, title))
            return;
        localStepTitleLastEmit.set(key, { at: now, title });
        scopeWindow.dispatchEvent(new CustomEvent(STEP_TITLE_LOCAL_EVENT, {
            detail: { taskPK, stepId, title },
            bubbles: true,
            composed: true,
        }));
    }
    catch {
        /* fail-soft */
    }
}
/** Main-thread tick while a worker/await holds. No-op (and no timer) without window. */
export function startLocalStepTitleTick(taskPK, stepId, makeTitle, intervalMs = LOCAL_STEP_TITLE_MIN_MS) {
    try {
        if (!getLocalStepTitleEventScope())
            return () => { };
        const startedAt = Date.now();
        const tick = () => {
            changeLocalStepTitle(taskPK, stepId, makeTitle(Math.floor((Date.now() - startedAt) / 1000)));
        };
        tick();
        const id = setInterval(tick, intervalMs);
        let stopped = false;
        return () => {
            if (stopped)
                return;
            stopped = true;
            try {
                clearInterval(id);
            }
            catch { /* fail-soft */ }
        };
    }
    catch {
        return () => { };
    }
}
export function notifyTaskCompleted(context, result) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('task-completed', {
        detail: { context, result },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyThreadChange(thread) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('thread-change', {
        detail: thread,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyMessageChange(message) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('message-change', {
        detail: message,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyThreadNotification(show) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('thread-notification', {
        detail: show,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyThreadCreate(thread) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('thread-create', {
        detail: thread,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function dispatchDetailsTaskClose(taskId) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('task-details-close', {
        detail: taskId,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function dispatchDetailsTaskClick(messageId, taskId, task, message) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('task-details-click', {
        detail: { messageId, taskId, task, message },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function dispatchThreadOpen(threadId, taskId) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('thread-open', {
        detail: { taskId, threadId },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
/** Existing share-link format from createMessageLink: `#message/{threadId}` or `#message/{threadId}/{messageId}`. */
export function threadOpenFromHash(hash) {
    const raw = hash.startsWith('#') ? hash.slice(1) : hash;
    const match = raw.match(/^message\/([^/]+)(?:\/([^/]+))?$/);
    if (!match || !match[1])
        return undefined;
    const threadId = decodeURIComponent(match[1]);
    if (!threadId)
        return undefined;
    const messageId = match[2] ? decodeURIComponent(match[2]) : undefined;
    return messageId ? { threadId, messageId } : { threadId };
}
export function notifyTaskMetaChanged(payload) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('task-meta-changed', {
        detail: payload,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
