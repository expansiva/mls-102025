/// <mls fileReference="_102025_/l2/collabMessagesE01Context.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { post } from '/_102025_/l2/shared/api.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
const text = {
    en: { open: 'Context sent', close: 'Hide context', openExecution: 'Execution status', closeExecution: 'Hide execution', loading: 'Loading execution context…', unavailable: 'Context is unavailable.', sourceUnavailable: 'That source is no longer available.', refresh: 'Refresh', cancel: 'Cancel execution', status: 'Status', reason: 'Interruption reason', cost: 'Observed cost', pendingCost: 'to be determined', memory: 'Memory', version: 'version', promptVersion: 'Prompt version', templateVersion: 'Context template', none: 'none', sections: 'Sections', history: 'History window', omissions: 'Omissions', sources: 'Sources', limits: 'Limits', bytes: 'Envelope bytes', disclosure: 'This shows the context sent to the model, not its internal reasoning.', pilot: 'Supervised pilot', requests: 'Local requests / provider attempts' },
    pt: { open: 'Contexto enviado', close: 'Ocultar contexto', openExecution: 'Status da execução', closeExecution: 'Ocultar execução', loading: 'Carregando contexto da execução…', unavailable: 'O contexto não está disponível.', sourceUnavailable: 'Essa fonte não está mais disponível.', refresh: 'Atualizar', cancel: 'Cancelar execução', status: 'Status', reason: 'Motivo da interrupção', cost: 'Custo observado', pendingCost: 'a apurar', memory: 'Memória', version: 'versão', promptVersion: 'Versão do prompt', templateVersion: 'Template de contexto', none: 'nenhuma', sections: 'Seções', history: 'Janela de histórico', omissions: 'Omissões', sources: 'Fontes', limits: 'Limites', bytes: 'Bytes do envelope', disclosure: 'Isto mostra o contexto enviado ao modelo, não seu raciocínio interno.', pilot: 'Piloto supervisionado', requests: 'Requisições locais / tentativas do provider' },
};
let CollabMessagesE01Context = class CollabMessagesE01Context extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-e01-context-102025 {
  display: block;
  margin-top: 0.35rem;
}
collab-messages-e01-context-102025 button {
  min-height: 30px;
  border: 1px solid var(--cm-border, #d1d5db);
  border-radius: 6px;
  padding: 0.25rem 0.5rem;
  color: inherit;
  background: var(--cm-panel-bg, #fff);
  cursor: pointer;
}
collab-messages-e01-context-102025 button:focus-visible,
collab-messages-e01-context-102025 summary:focus-visible {
  outline: 3px solid var(--focus-ring, #2563eb);
  outline-offset: 2px;
}
collab-messages-e01-context-102025 .e01-context-toggle {
  color: var(--cm-green-dark, #007a3d);
  font-weight: 700;
}
collab-messages-e01-context-102025 .e01-context-panel {
  box-sizing: border-box;
  width: min(320px, 75vw);
  margin-top: 0.4rem;
  padding: 0.65rem;
  border: 1px solid var(--cm-border, #e2e7e3);
  border-radius: 8px;
  background: var(--cm-panel-bg, #fff);
  color: var(--cm-text, #111827);
  overflow-wrap: anywhere;
}
collab-messages-e01-context-102025 .e01-context-panel.error {
  color: var(--cm-danger, #b91c1c);
}
collab-messages-e01-context-102025 .e01-context-disclosure {
  margin: 0 0 0.5rem;
  color: var(--cm-text-muted, #5b635f);
  font-size: 11px;
}
collab-messages-e01-context-102025 .e01-context-feedback {
  color: var(--cm-danger, #b91c1c);
  font-size: 12px;
}
collab-messages-e01-context-102025 dl {
  display: grid;
  grid-template-columns: minmax(70px, auto) 1fr;
  gap: 0.25rem 0.5rem;
  margin: 0.45rem 0;
}
collab-messages-e01-context-102025 dt {
  font-weight: 700;
}
collab-messages-e01-context-102025 dd {
  margin: 0;
}
collab-messages-e01-context-102025 .status.cancelled,
collab-messages-e01-context-102025 .status.failed {
  color: var(--cm-danger, #b91c1c);
}
collab-messages-e01-context-102025 .status.completed {
  color: var(--cm-green-dark, #007a3d);
}
collab-messages-e01-context-102025 .e01-context-sources,
collab-messages-e01-context-102025 .e01-context-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 0.35rem;
  align-items: center;
  margin-top: 0.5rem;
}
collab-messages-e01-context-102025 .e01-context-sources strong {
  flex-basis: 100%;
}
collab-messages-e01-context-102025 .danger {
  color: var(--cm-danger, #b91c1c);
  border-color: var(--cm-danger, #b91c1c);
}
collab-messages-e01-context-102025 summary {
  cursor: pointer;
  margin-top: 0.5rem;
}
collab-messages-e01-context-102025 ul {
  margin: 0.35rem 0;
  padding-left: 1.1rem;
}
@media (max-width: 420px) {
  collab-messages-e01-context-102025 .e01-context-panel {
    width: min(270px, 76vw);
  }
  collab-messages-e01-context-102025 dl {
    grid-template-columns: 1fr;
  }
}
`);
        this.userId = '';
        this.threadId = '';
        this.sourceMessageId = '';
        this.sessionKey = '';
        this.variant = 'response';
        this.open = false;
        this.phase = 'idle';
        this.error = '';
        this.feedback = '';
        this.identity = '';
        this.toggle = () => { this.open = !this.open; if (this.open && this.phase === 'idle')
            void this.load(); };
        this.load = async () => {
            const identity = this.identityToken();
            if (!this.userId || !this.threadId || !this.sourceMessageId)
                return;
            this.phase = 'loading';
            this.error = '';
            this.feedback = '';
            try {
                const response = await post({ action: 'getE01Execution', userId: this.userId, threadId: this.threadId, sourceMessageId: this.sourceMessageId });
                if (identity !== this.identityToken())
                    return;
                this.execution = response.execution;
                this.phase = 'ready';
            }
            catch (error) {
                if (identity === this.identityToken()) {
                    this.phase = 'error';
                    this.error = error.message || this.copy().unavailable;
                }
            }
        };
    }
    updated(changed) {
        super.updated(changed);
        if (changed.has('userId') || changed.has('threadId') || changed.has('sourceMessageId') || changed.has('sessionKey') || changed.has('variant')) {
            const next = this.identityToken();
            if (this.identity && next !== this.identity)
                this.clearPrivateState();
            this.identity = next;
        }
    }
    render() {
        const t = this.copy();
        const openLabel = this.variant === 'source' ? t.openExecution : t.open;
        const closeLabel = this.variant === 'source' ? t.closeExecution : t.close;
        return html `<div class="e01-context-control">
      <button class="e01-context-toggle" aria-expanded=${this.open ? 'true' : 'false'} @click=${this.toggle}>${this.open ? closeLabel : openLabel}</button>
      ${this.open ? this.renderPanel(t) : nothing}
    </div>`;
    }
    renderPanel(t) {
        if (this.phase === 'loading')
            return html `<div class="e01-context-panel" role="status">${t.loading}</div>`;
        if (this.phase === 'error' || !this.execution)
            return html `<div class="e01-context-panel error" role="alert">${this.error || t.unavailable}<button @click=${this.load}>${t.refresh}</button></div>`;
        const e = this.execution;
        const c = e.context;
        const active = ['admitted', 'queued', 'running'].includes(e.status);
        const pilotCost = e.pilot
            ? `${e.pilot.observedSpendUsd === null ? t.pendingCost : `${e.pilot.observedSpendUsd} USD`}${e.pilot.reconciliationPending && e.pilot.observedSpendUsd !== null ? ` + ${t.pendingCost}` : ''}`
            : null;
        return html `<section class="e01-context-panel" aria-label=${this.variant === 'source' ? t.openExecution : t.open}>
      ${this.variant === 'response' ? html `<p class="e01-context-disclosure">${t.disclosure}</p>` : nothing}
      ${this.feedback ? html `<p class="e01-context-feedback" role="status">${this.feedback}</p>` : nothing}
      <dl><dt>${t.status}</dt><dd class="status ${e.status}">${this.statusLabel(e.status)}</dd>
        ${e.terminalReason ? html `<dt>${t.reason}</dt><dd>${this.reasonLabel(e.terminalReason)}</dd>` : nothing}
        <dt>${t.cost}</dt><dd>${pilotCost ?? (e.cost.amount === null ? t.pendingCost : `${e.cost.amount} ${e.cost.currency}`)}</dd>
        ${e.pilot ? html `<dt>${t.pilot}</dt><dd>${e.pilot.pilotId} · ${e.pilot.operationalBudgetUsd} USD</dd><dt>${t.requests}</dt><dd>${e.pilot.localRequests}/${e.pilot.localRequestLimit} · ${e.pilot.providerAttempts ?? t.pendingCost}</dd>` : nothing}
        <dt>${t.limits}</dt><dd>${e.limits.maxOutputTokens} tokens · ${Math.round(e.limits.deadlineMs / 1000)}s${e.limits.maxCost ? ` · ${e.limits.maxCost.amount} ${e.limits.maxCost.currency}` : ''}</dd>
      </dl>
      ${this.variant === 'response' && c ? html `
        <dl><dt>${t.promptVersion}</dt><dd>${c.promptVersion}</dd><dt>${t.templateVersion}</dt><dd>${c.templateVersion}</dd><dt>${t.memory}</dt><dd>${c.memory.status === 'included' ? `${t.version} ${c.memory.version}` : t.none}</dd><dt>${t.sections}</dt><dd>${c.memory.sectionsIncluded.join(', ') || t.none}</dd><dt>${t.history}</dt><dd>${c.historyIds.length}</dd><dt>${t.bytes}</dt><dd>${c.bytes.envelope}</dd></dl>
        ${this.renderSources(c.sources, t)}
        ${c.omissions.length ? html `<details><summary>${t.omissions} (${c.omissions.length})</summary><ul>${c.omissions.map(item => html `<li>${item.kind}: ${item.id} — ${item.reason}</li>`)}</ul></details>` : nothing}
      ` : nothing}
      <div class="e01-context-actions"><button @click=${this.load}>${t.refresh}</button>${active ? html `<button class="danger" @click=${this.cancel}>${t.cancel}</button>` : nothing}</div>
    </section>`;
    }
    renderSources(sources, t) {
        if (!sources.length)
            return nothing;
        return html `<div class="e01-context-sources"><strong>${t.sources}</strong>${sources.map(source => source.kind === 'message'
            ? html `<button @click=${() => this.openSource(source.ref)}>${source.ref.split('/').pop()}</button>`
            : html `<span>${source.kind}: ${source.ref}</span>`)}</div>`;
    }
    async cancel() {
        if (!this.execution || ['completed', 'failed', 'cancelled'].includes(this.execution.status))
            return;
        const identity = this.identityToken();
        const executionId = this.execution.executionId;
        try {
            const response = await post({ action: 'cancelE01Execution', userId: this.userId, threadId: this.threadId, executionId });
            if (identity !== this.identityToken())
                return;
            this.execution = { ...response.execution, context: this.execution.context };
            this.phase = 'ready';
        }
        catch (error) {
            if (identity === this.identityToken()) {
                this.phase = 'error';
                this.error = error.message || this.copy().unavailable;
            }
        }
    }
    async openSource(ref) {
        const identity = this.identityToken();
        try {
            await post({ action: 'getE01Execution', userId: this.userId, threadId: this.threadId, sourceMessageId: this.sourceMessageId, openSourceMessageId: ref });
            if (identity !== this.identityToken())
                return;
            this.dispatchEvent(new CustomEvent('e01-open-source', { detail: { messageId: ref }, bubbles: true, composed: true }));
        }
        catch {
            if (identity === this.identityToken())
                this.feedback = this.copy().sourceUnavailable;
        }
    }
    statusLabel(status) {
        const pt = (document.documentElement.lang || 'en').toLowerCase().startsWith('pt');
        const labels = { admitted: ['admitted', 'admitida'], queued: ['queued', 'na fila'], running: ['running', 'em execução'], completed: ['completed', 'concluída'], failed: ['failed', 'falhou'], cancelled: ['cancelled', 'cancelada'] };
        return labels[status]?.[pt ? 1 : 0] || status;
    }
    reasonLabel(reason) {
        const pt = (document.documentElement.lang || 'en').toLowerCase().startsWith('pt');
        const labels = { cancelled: ['cancelled', 'cancelada'], timeout: ['time limit reached', 'tempo limite atingido'], budget_exceeded: ['limit unavailable or exceeded', 'limite indisponível ou excedido'], provider_error: ['provider error', 'erro do provedor'], context_changed: ['context changed', 'contexto alterado'], context_missing: ['context unavailable', 'contexto indisponível'], outcome_unknown: ['outcome unknown', 'resultado desconhecido'] };
        return labels[reason]?.[pt ? 1 : 0] || reason;
    }
    clearPrivateState() { this.open = false; this.phase = 'idle'; this.execution = undefined; this.error = ''; this.feedback = ''; }
    identityToken() { return `${this.sessionKey}|${this.userId}|${this.threadId}|${this.sourceMessageId}|${this.variant}`; }
    copy() { return (document.documentElement.lang || 'en').toLowerCase().startsWith('pt') ? text.pt : text.en; }
};
__decorate([
    property()
], CollabMessagesE01Context.prototype, "userId", void 0);
__decorate([
    property()
], CollabMessagesE01Context.prototype, "threadId", void 0);
__decorate([
    property()
], CollabMessagesE01Context.prototype, "sourceMessageId", void 0);
__decorate([
    property()
], CollabMessagesE01Context.prototype, "sessionKey", void 0);
__decorate([
    property()
], CollabMessagesE01Context.prototype, "variant", void 0);
__decorate([
    state()
], CollabMessagesE01Context.prototype, "open", void 0);
__decorate([
    state()
], CollabMessagesE01Context.prototype, "phase", void 0);
__decorate([
    state()
], CollabMessagesE01Context.prototype, "execution", void 0);
__decorate([
    state()
], CollabMessagesE01Context.prototype, "error", void 0);
__decorate([
    state()
], CollabMessagesE01Context.prototype, "feedback", void 0);
CollabMessagesE01Context = __decorate([
    customElement('collab-messages-e01-context-102025')
], CollabMessagesE01Context);
export { CollabMessagesE01Context };
