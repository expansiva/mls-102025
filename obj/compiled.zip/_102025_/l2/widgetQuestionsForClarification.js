/// <mls fileReference="_102025_/l2/widgetQuestionsForClarification.ts" enhancement="_102027_/l2/enhancementLit" /> 
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
export class WidgetQuestionsForClarification102025 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-questions-for-clarification-102025 {
  background: var(--bg-primary-color);
  color: var(--text-primary-color);
  font-size: var(--font-size-16);
  border-radius: var(--space-16);
  box-shadow: 0 2px 12px 0 rgba(192, 192, 192, 0.18);
  padding: var(--space-32);
  max-width: 880px;
  margin: var(--space-40) auto;
  display: block;
}
widget-questions-for-clarification-102025 .title {
  font-size: var(--font-size-24);
  font-weight: 500;
  color: var(--text-primary-color-darker);
  letter-spacing: 0.5px;
  margin-bottom: 1.6em;
  margin-top: 0.2em;
  line-height: 1.2;
}
widget-questions-for-clarification-102025 .clarification-form {
  display: flex;
  flex-direction: column;
  gap: var(--space-24);
}
widget-questions-for-clarification-102025 .clarification-question {
  display: flex;
  flex-direction: column;
  gap: var(--space-8);
}
widget-questions-for-clarification-102025 .clarification-question[data-type="MoSCoW"] {
  flex-direction: row;
  align-items: center;
  gap: var(--space-16);
}
widget-questions-for-clarification-102025 .clarification-question[data-type="MoSCoW"] select {
  min-width: 110px;
  max-width: 140px;
  padding: var(--space-8) var(--space-8);
  font-size: var(--font-size-16);
  border-radius: var(--space-8);
  border: 1.2px solid var(--grey-color);
  background: var(--bg-primary-color-lighter);
  color: var(--text-primary-color);
  margin-right: var(--space-16);
  font-weight: 500;
}
widget-questions-for-clarification-102025 .clarification-question[data-type="MoSCoW"] select:focus {
  border: 1.2px solid var(--active-color);
  background: var(--bg-primary-color-lighter);
}
widget-questions-for-clarification-102025 .clarification-question[data-type="MoSCoW"] .moscow-label {
  font-size: var(--font-size-16);
  color: var(--text-primary-color);
  font-weight: 400;
  line-height: 1.4;
  margin: 0;
}
widget-questions-for-clarification-102025 .clarification-question label,
widget-questions-for-clarification-102025 .clarification-question .moscow-label {
  font-size: var(--font-size-16);
  color: var(--text-primary-color-lighter);
  font-weight: 400;
  margin: 0 0 0.2em 0;
  line-height: 1.5;
}
widget-questions-for-clarification-102025 .clarification-question textarea,
widget-questions-for-clarification-102025 .clarification-question select {
  color: var(--text-primary-color);
  background: var(--bg-primary-color);
  font-family: var(--font-family-primary);
}
widget-questions-for-clarification-102025 .clarification-question textarea,
widget-questions-for-clarification-102025 .clarification-question select:not([data-moscow]) {
  font-size: var(--font-size-16);
  padding: var(--space-8) var(--space-16);
  border-radius: var(--space-8);
  border: 1.2px solid var(--grey-color);
  background: var(--bg-secondary-color-lighter);
  transition: border var(--transition-slow);
  margin-top: 0.25em;
}
widget-questions-for-clarification-102025 .clarification-question textarea:focus,
widget-questions-for-clarification-102025 .clarification-question select:not([data-moscow]):focus {
  border: 1.2px solid var(--active-color);
  background: var(--bg-primary-color-lighter);
}
widget-questions-for-clarification-102025 .clarification-question textarea {
  min-height: 48px;
  resize: vertical;
}
widget-questions-for-clarification-102025 .clarification-question input[type="checkbox"] {
  accent-color: var(--active-color);
  transform: scale(1.1);
  margin: 0 var(--space-8) 0 0;
  vertical-align: middle;
}
widget-questions-for-clarification-102025 .clarification-actions {
  display: flex;
  justify-content: flex-end;
  gap: var(--space-16);
  margin-top: var(--space-32);
}
widget-questions-for-clarification-102025 .clarification-actions .action-btn {
  min-width: 120px;
  font-size: var(--font-size-16);
  font-weight: 500;
  border-radius: var(--space-8);
  padding: var(--space-8) var(--space-16);
  border: none;
  cursor: pointer;
  transition: background var(--transition-slow), color var(--transition-slow);
  outline: none;
}
widget-questions-for-clarification-102025 .clarification-actions .action-btn.cancel {
  background: var(--bg-secondary-color);
  color: var(--text-primary-color);
}
widget-questions-for-clarification-102025 .clarification-actions .action-btn.cancel:hover {
  background: var(--bg-secondary-color-hover);
}
widget-questions-for-clarification-102025 .clarification-actions .action-btn.continue {
  background: var(--active-color);
  color: #fff;
}
widget-questions-for-clarification-102025 .clarification-actions .action-btn.continue:hover {
  background: var(--active-color-hover);
}
widget-questions-for-clarification-102025 .clarification-actions .action-btn:disabled {
  background: var(--bg-secondary-color-disabled);
  color: var(--text-primary-color-disabled);
  cursor: not-allowed;
  opacity: 0.7;
}
widget-questions-for-clarification-102025 .clarification-legends {
  font-size: var(--font-size-12);
  color: var(--text-primary-color-lighter);
  margin-top: 1.8em;
  opacity: 0.7;
}
@media (max-width: 544px) {
  widget-questions-for-clarification-102025 {
    padding: var(--space-16);
  }
  widget-questions-for-clarification-102025 .clarification-actions {
    flex-direction: column;
    gap: var(--space-8);
  }
  widget-questions-for-clarification-102025 .clarification-actions .action-btn {
    width: 100%;
  }
  widget-questions-for-clarification-102025 .title {
    font-size: var(--font-size-20);
  }
}
`);
        this.value = null;
        this.readonly = false;
        this.mode = 'old';
        // Local state for editing answers
        this.localAnswers = {};
    }
    attributeChangedCallback(name, oldVal, newVal) {
        if (name === 'value') {
            try {
                this.value = JSON.parse(newVal);
            }
            catch (e) {
                console.log("error on widgetQuestionsForClarification.attributeChangedCallback", e);
                this.value = null;
            }
        }
        super.attributeChangedCallback?.(name, oldVal, newVal);
    }
    updated(changedProps) {
        // Initialize answers when value changes
        if (changedProps.has('value') && this.value) {
            const initialAnswers = {};
            Object.entries(this.value.questions).forEach(([key, q]) => {
                initialAnswers[key] = q.answer ?? (q.type === 'boolean' ? false : '');
            });
            this.localAnswers = initialAnswers;
        }
    }
    // Input change handler for all field types
    onInputChange(questionId, value) {
        this.localAnswers = {
            ...this.localAnswers,
            [questionId]: value,
        };
        // Keep 'value' in sync with localAnswers (two-way)
        if (this.value) {
            this.value = {
                ...this.value,
                questions: Object.fromEntries(Object.entries(this.value.questions).map(([key, q]) => [
                    key,
                    { ...q, answer: this.localAnswers[key] ?? q.answer }
                ]))
            };
        }
    }
    onCancel() {
        if (this.value && !this.readonly) {
            this.dispatchEvent(new CustomEvent('clarification-finish', {
                detail: {
                    value: this.value,
                    action: 'cancel'
                },
                bubbles: true,
                composed: true
            }));
            return;
        }
    }
    onContinue() {
        // Update answers into 'value'
        if (this.value && !this.readonly) {
            this.value = {
                ...this.value,
                questions: Object.fromEntries(Object.entries(this.value.questions).map(([key, q]) => [
                    key,
                    { ...q, answer: this.localAnswers[key] }
                ]))
            };
            this.dispatchEvent(new CustomEvent('clarification-finish', {
                detail: {
                    value: this.value,
                    action: 'continue'
                },
                bubbles: true,
                composed: true
            }));
            return;
        }
    }
    render() {
        if (!this.value || !this.value.questions || !this.value.legends)
            return html `<div>No questions available. value is ${typeof this.value}</div>`;
        const isDisabled = this.readonly === true;
        return html `
    <h2 class='title'>${this.value.title}</h2>
    <form class="clarification-form" @submit=${(e) => e.preventDefault()}>
      ${Object.entries(this.value.questions).map(([key, q]) => html `
        <div
          class="clarification-question"
          data-type=${q.type}
        >
          ${q.type === 'boolean' ? html `
            <label style="display: flex; align-items: center; gap: 0.6em;">
              <input
                type="checkbox"
                .checked=${!!this.localAnswers[key]}
                @change=${(e) => this.onInputChange(key, e.target.checked)}
                style="margin: 0;"
              />
              <span>${q.question}</span>
            </label>
          ` : q.type === 'MoSCoW' ? html `
            <div style="display: flex; align-items: center; gap: 1em;">
              <select
                style="min-width: 110px;"
                .value=${String(this.localAnswers[key] ?? '')}
                @change=${(e) => this.onInputChange(key, e.target.value)}
              >
                <option value="">Select...</option>
                <option value="must">Must</option>
                <option value="should">Should</option>
                <option value="could">Could</option>
                <option value="wont">Won't</option>
              </select>
              <span class="moscow-label">${q.question}</span>
            </div>
          ` : q.type === 'range' ? html `
            <label style="display: flex; align-items: center; gap: 1em;">
              <input
                type="range"
                min="0"
                max="100"
                step="1"
                .value=${String(this.localAnswers[key] ?? q.answer ?? 50)}
                @input=${(e) => this.onInputChange(key, e.target.value)}
                style="width: 180px;"
              />
              <span style="min-width: 34px; text-align: right;">
                ${this.localAnswers[key] ?? q.answer ?? 50}
              </span>
              <span style="flex:1;">${q.question}</span>
            </label>
          ` : html `
            <label>${q.question}</label>
            ${q.type === 'open' ? html `
              <textarea
                .value=${String(this.localAnswers[key] ?? '')}
                @input=${(e) => this.onInputChange(key, e.target.value)}
                rows="2"
              ></textarea>
            ` : q.type === 'select' && q.options ? html `
              <select
                @change=${(e) => this.onInputChange(key, e.target.value)}
              >
                <option value="" ?selected=${!this.localAnswers[key]}>Select...</option>
                ${q.options.map(option => html `
                  <option value=${option.id} ?selected=${String(this.localAnswers[key] ?? '') === option.id}>${option.label}</option>
                `)}
              </select>
            ` : null}
          `}
        </div>
      `)} 
      <div class="clarification-actions">
        <button type="button" class="action-btn cancel" @click=${this.onCancel} ?disabled=${isDisabled}>Cancel</button>
        <button type="button" class="action-btn continue" @click=${this.onContinue} ?disabled=${isDisabled}>Continue</button>
      </div>
      ${this.value.legends?.length ? html `
        <div class="clarification-legends" style="margin-top:2em;">
          ${this.value.legends.map(line => html `<div>${line}</div>`)}
        </div>
      ` : ''}
    </form>
  `;
    }
}
__decorate([
    property({ type: Object })
], WidgetQuestionsForClarification102025.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], WidgetQuestionsForClarification102025.prototype, "readonly", void 0);
__decorate([
    property()
], WidgetQuestionsForClarification102025.prototype, "mode", void 0);
__decorate([
    state()
], WidgetQuestionsForClarification102025.prototype, "localAnswers", void 0);
if (!customElements.get('widget-questions-for-clarification-102025')) {
    customElements.define('widget-questions-for-clarification-102025', WidgetQuestionsForClarification102025);
}
