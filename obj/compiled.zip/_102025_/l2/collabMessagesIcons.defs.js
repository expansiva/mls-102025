"use strict";
/// <mls shortName="collabMessagesIcons" project="102025" enhancement="_blank" folder="" />
