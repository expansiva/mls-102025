/// <mls fileReference="_102025_/l2/e02AudioPolling.ts" enhancement="_blank" />
const browserScheduler = {
    schedule: (callback, delayMs) => setTimeout(callback, delayMs),
    cancel: token => clearTimeout(token),
};
/** One bounded polling chain. Calling start twice never replenishes its budget. */
export class E02AudioPollingSession {
    constructor(maxPolls, delayMs, poll, scheduler = browserScheduler) {
        this.delayMs = delayMs;
        this.poll = poll;
        this.scheduler = scheduler;
        this.running = false;
        this.generation = 0;
        this.remaining = Math.max(0, Math.floor(maxPolls));
    }
    get active() { return this.running; }
    get pollsRemaining() { return this.remaining; }
    start() {
        if (this.running || this.remaining <= 0)
            return;
        this.running = true;
        this.scheduleNext();
    }
    stop() {
        this.running = false;
        this.generation++;
        if (this.timer !== undefined)
            this.scheduler.cancel(this.timer);
        this.timer = undefined;
    }
    scheduleNext() {
        if (!this.running || this.remaining <= 0) {
            this.stop();
            return;
        }
        const generation = this.generation;
        this.timer = this.scheduler.schedule(() => void this.tick(generation), this.delayMs);
    }
    async tick(generation) {
        this.timer = undefined;
        if (!this.running || generation !== this.generation || this.remaining <= 0)
            return;
        this.remaining--;
        const continuePolling = await this.poll();
        if (!this.running || generation !== this.generation || !continuePolling || this.remaining <= 0) {
            this.stop();
            return;
        }
        this.scheduleNext();
    }
}
