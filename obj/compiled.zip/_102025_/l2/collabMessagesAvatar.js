/// <mls fileReference="_102025_/l2/collabMessagesAvatar.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { collab_user } from '/_102025_/l2/collabMessagesIcons.js';
import { generateAgentAvatar } from '/_102025_/l2/collabMessagesHelper.js';
let CollabMessagesAvatar = class CollabMessagesAvatar extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-avatar-102025 {
  display: inline-block;
  position: relative;
  width: var(--avatar-width, 30px);
  height: var(--avatar-height, 30px);
  flex: 0 0 var(--avatar-width, 30px);
}
collab-messages-avatar-102025 .avatar {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
  align-items: center;
  justify-content: center;
  width: var(--avatar-width, 30px);
  height: var(--avatar-height, 30px);
}
collab-messages-avatar-102025 .avatar img {
  width: var(--avatar-width, 30px);
  height: var(--avatar-height, 30px);
  border-radius: 50%;
  object-fit: cover;
  box-shadow: var(--cm-shadow-sm, 0 1px 3px rgba(0, 0, 0, 0.14));
}
collab-messages-avatar-102025 .avatar svg {
  width: var(--avatar-width, 30px);
  height: var(--avatar-height, 30px);
  border-radius: 50%;
  background: var(--cm-green-avatar, #cfe9d8);
  color: var(--cm-green, #008f4c);
  box-shadow: var(--cm-shadow-sm, 0 1px 3px rgba(0, 0, 0, 0.14));
}
collab-messages-avatar-102025 .avatar .avatar-placeholder {
  width: var(--avatar-width, 30px);
  height: var(--avatar-height, 30px);
  border-radius: 50%;
  background-color: var(--cm-green-avatar, #cfe9d8);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  color: var(--cm-green, #008f4c);
  cursor: pointer;
  box-shadow: var(--cm-shadow-sm, 0 1px 3px rgba(0, 0, 0, 0.14));
}
collab-messages-avatar-102025 .avatar .avatar-placeholder svg {
  width: 12px;
  height: 12px;
  box-shadow: none;
}
`);
        this.avatar = '';
        this.alt = '';
        this.width = '30px';
        this.height = '30px';
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('width') || changedProperties.has('height')) {
            this.style.setProperty('--avatar-width', this.width);
            this.style.setProperty('--avatar-height', this.height);
        }
    }
    render() {
        const isSvg = this.avatar.trim().startsWith('<svg');
        const avatar = this.avatar ? this.avatar : generateAgentAvatar(this.alt || '.');
        return html `
        <div class="avatar">
            ${avatar
            ? isSvg ? html `${unsafeHTML(avatar)}` : html `<img src="${avatar}" alt="${this.alt || 'Avatar'}" />`
            : html `<div class="avatar-placeholder">${collab_user}</div>`}
        </div>`;
    }
};
__decorate([
    property()
], CollabMessagesAvatar.prototype, "avatar", void 0);
__decorate([
    property()
], CollabMessagesAvatar.prototype, "alt", void 0);
__decorate([
    property({ type: String })
], CollabMessagesAvatar.prototype, "width", void 0);
__decorate([
    property({ type: String })
], CollabMessagesAvatar.prototype, "height", void 0);
CollabMessagesAvatar = __decorate([
    customElement('collab-messages-avatar-102025')
], CollabMessagesAvatar);
export { CollabMessagesAvatar };
