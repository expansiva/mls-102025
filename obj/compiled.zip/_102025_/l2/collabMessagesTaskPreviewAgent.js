/// <mls fileReference="_102025_/l2/collabMessagesTaskPreviewAgent.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, property, state, query } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { loadAgent, restartStep } from '/_102027_/l2/aiAgentOrchestration.js';
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { requestMonacoLoad } from '/_102025_/l2/requestMonacoLoad.js';
let CollabMessagesTaskPreviewAgent = class CollabMessagesTaskPreviewAgent extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-task-preview-agent-102025 {
  display: block;
  background: #ffffff;
  position: relative;
  height: 100%;
  color: #3c3c3c;
}
collab-messages-task-preview-agent-102025 .tab-header {
  display: flex;
  justify-content: space-between;
  border-bottom: 1px solid #ccc;
  background-color: #f0f0f0;
  overflow: hidden;
  flex-shrink: 0;
}
collab-messages-task-preview-agent-102025 .tab-group-left {
  display: flex;
  overflow-x: auto;
  flex: 1;
  min-width: 0;
  scrollbar-width: thin;
}
collab-messages-task-preview-agent-102025 .tab-group-left::-webkit-scrollbar {
  height: 6px;
}
collab-messages-task-preview-agent-102025 .tab-group-left::-webkit-scrollbar-thumb {
  background-color: var(--border-default-focus);
  border-radius: 4px;
}
collab-messages-task-preview-agent-102025 .tab-group-right {
  display: flex;
  flex-shrink: 0;
}
collab-messages-task-preview-agent-102025 .tab-button {
  padding: 10px 16px;
  cursor: pointer;
  background: none;
  border: none;
  border-right: 1px solid #ddd;
  font-size: 14px;
  transition: background-color 0.2s ease;
  display: flex;
  flex-direction: column;
}
collab-messages-task-preview-agent-102025 .tab-button:hover {
  background-color: #e0e0e0;
}
collab-messages-task-preview-agent-102025 .tab-button.active {
  background-color: #ffffff;
  font-weight: bold;
  border-bottom: 2px solid #007bff;
}
collab-messages-task-preview-agent-102025 .tab-content {
  position: relative;
  padding: 0;
  margin: 0;
  background-color: #ffffff;
  display: flex;
  height: 100%;
  flex-direction: column;
  font-size: 14px;
  overflow-y: auto;
}
collab-messages-task-preview-agent-102025 .header {
  display: flex;
  align-items: center;
}
collab-messages-task-preview-agent-102025 button.action-btn:hover {
  opacity: 0.8;
}
collab-messages-task-preview-agent-102025 .containerinputs {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  align-items: center;
  padding: 1rem;
}
collab-messages-task-preview-agent-102025 details {
  width: 100%;
  max-width: 900px;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  background-color: #fafafa;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  font-family: 'Inter', sans-serif;
  transition: all 0.3s ease;
}
collab-messages-task-preview-agent-102025 details[open] .title {
  display: none;
}
collab-messages-task-preview-agent-102025 details .chevron {
  transition: transform 0.3s;
}
collab-messages-task-preview-agent-102025 details[open] .chevron {
  transform: rotate(90deg);
}
collab-messages-task-preview-agent-102025 details[open] .moveelement {
  display: none !important;
}
collab-messages-task-preview-agent-102025 details summary {
  position: relative;
  cursor: pointer;
  padding: 1rem;
  border-bottom: 1px solid #e0e0e0;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
collab-messages-task-preview-agent-102025 details summary:hover .moveelement {
  display: flex;
}
collab-messages-task-preview-agent-102025 details summary .trash {
  z-index: 9999;
}
collab-messages-task-preview-agent-102025 details summary .pheader {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
collab-messages-task-preview-agent-102025 details summary .pheader .title {
  margin-left: 1rem;
}
collab-messages-task-preview-agent-102025 details summary .pheader .type .typeMode {
  appearance: none;
  padding: 0.4rem 1rem;
  font-size: 0.95rem;
  border: 1px solid #ccc;
  border-radius: 6px;
  background-color: white;
  transition: border 0.3s ease;
}
collab-messages-task-preview-agent-102025 details > div {
  padding: 1rem;
}
collab-messages-task-preview-agent-102025 details > div pre.content {
  width: calc(100% - 2rem);
  border: none;
  resize: vertical;
  padding: 1rem;
  font-size: 0.95rem;
  font-family: 'Fira Code', monospace;
  background-color: #fff;
  border-radius: 6px;
  color: #333;
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.05);
  line-height: 1.5;
  word-break: break-word;
  white-space: pre-wrap;
}
collab-messages-task-preview-agent-102025 ul {
  list-style: none;
  padding: 1rem;
  margin: 1rem 0;
  border-radius: 12px;
  color: #333;
}
collab-messages-task-preview-agent-102025 ul li {
  margin-bottom: 0.75rem;
  padding: 0.5rem 0.75rem;
  background: white;
  border-radius: 8px;
  transition: background 0.3s;
}
collab-messages-task-preview-agent-102025 ul li code {
  font-family: 'Courier New', monospace;
  background-color: #eee;
  padding: 2px 6px;
  border-radius: 4px;
}
`);
        this.message = null;
        this.task = null;
        this.step = null;
        this.agentDescription = '';
        this.prompts = [];
        this.mode = 'info';
        this.monacoLoadError = null;
        this.lastKey = -1;
        this.editorConf = {
            contextmenu: true,
            autoIndent: 'full',
            wordWrap: 'on',
            wrappingIndent: 'indent',
            tabCompletion: 'on',
            renderControlCharacters: false,
            showUnused: true,
            glyphMargin: true,
            minimap: { enabled: false },
            useTabStops: true,
            scrollBeyondLastColumn: 2,
            scrollBeyondLastLine: false,
            formatOnType: true,
            fixedOverflowWidgets: true,
            codeLens: true,
            showFoldingControls: 'mouseover',
            suggestSelection: 'first',
            stickyScroll: { enabled: false, maxLineCount: 3 },
            stickyTabStops: true,
            fontSize: 14,
            automaticLayout: true,
        };
    }
    // Dedicated monaco instance for the Payload tab. It must NOT share the
    // singleton used by the Raw/Flexible previews (window.editorTaskView),
    // otherwise they overwrite each other's content (the Raw step-0 view would
    // show a payload, and the payload would show the last set value).
    get sharedEditor() {
        return window.elEditorAgentPayload;
    }
    get sharedMonaco() {
        return window.editorAgentPayload;
    }
    firstUpdated() {
        this.init();
        if (this.mode === 'payload') {
            this.mountEditor();
            this.updateEditorContent();
        }
    }
    update(changedProperties) {
        super.update(changedProperties);
        this.init();
    }
    updated(changedProperties) {
        if ((changedProperties.has('mode') || changedProperties.has('step') || changedProperties.has('task')) && this.mode === 'payload') {
            this.mountEditor();
            this.updateEditorContent();
        }
    }
    render() {
        if (!this.step) {
            return html `<p>Step not Found.</p>`;
        }
        return html `
            <div style="height: calc(100% - 41px);">
                <div class="tab-header">
                    <div class="tab-group-left">
                        <button
                            class="tab-button ${this.mode === 'info' ? 'active' : ''}" @click=${() => this.selectTabInfo()} >
                            Info                            
                        </button>
                        <button
                            class="tab-button ${this.mode === 'input' ? 'active' : ''}" @click=${() => this.selectTabInput()} >
                            Inputs
                        </button>
                        <button
                            class="tab-button ${this.mode === 'payload' ? 'active' : ''}" @click=${() => this.selectTabPayload()} >
                            Payload
                        </button>

                    </div>
                </div>
                <div class="tab-content">
                    ${this.renderMode()}
                    
                </div>
            </div>
        `;
    }
    renderMode() {
        switch (this.mode) {
            case 'input': return this.renderInputs();
            case 'payload': return this.renderPayload();
            case 'info': return this.renderInfo();
            case 'result': return this.renderResults();
            default: return this.renderInputs();
        }
    }
    renderInfo() {
        if (!this.task || !this.step)
            return html `Not found!`;
        let trace = '';
        if (this.step.interaction && Array.isArray(this.step.interaction.trace)) {
            this.step.interaction.trace.forEach((i) => trace += `<p>${i}<p>`);
        }
        else if (this.step.interaction) {
            trace = this.step.interaction.trace;
        }
        const aux = this.step.status === 'in_progress' ? '(in progress)' : '';
        return html `
        <div class="containerinputs">
            <details open>
                <summary> ${this.renderSummary('Agent ' + aux)} </summary>
                <ul>
                    <li>
                        #${this.step.stepId} - ${this.step.agentName} - ${this.step.status} - $${this.step.interaction?.cost}
                    </li>
                    <li>
                        <b>Trace: </b>${unsafeHTML(trace)}
                    </li>
                    <li>
                        <b>${this.step.agentName}: </b>${this.agentDescription}
                    </li>
                </ul>
            </details>
            <details>
                <summary> ${this.renderSummary('Task details')}</summary>
                <ul>
                    <li>
                        <header>
                                <h2>${this.task.PK}</h2>
                                <small>Status: ${this.task.status} | Última atualização: ${new Date(this.task.last_updated).toLocaleString()}</small>
                        <br/><small>${this.task.title}</small>
                        </header>
                    </li>
                </ul>
            </details>
            <details>
                <summary> ${this.renderSummary('Message details')}</summary>
                <ul>
                    <li>
                        <pre>
                            ${JSON.stringify(this.message, null, 2)}
                        </pre>
                    </li>
                </ul>
            </details>
            <details>
                <summary>${this.renderSummary('Advanced details')} </summary>
                <ul>
                    <li>
                        <span>Execute</span>
                        <div style="float: right;">
                            ${this.canRestartStep()
            ? html `
                            <span>(run again - restart step)</span>
                            <svg xmlns="http://www.w3.org/2000/svg" style="transform: rotateY(174deg); z-index:9999;width:15px; cursor:pointer" @click=${(e) => { e.stopPropagation(); e.preventDefault(); this.restartStep(e.currentTarget, this.step.stepId); }} viewBox="0 0 576 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M209.4 39.5c-9.1-9.6-24.3-10-33.9-.9L33.8 173.2c-19.9 18.9-19.9 50.7 0 69.6L175.5 377.4c9.6 9.1 24.8 8.7 33.9-.9s8.7-24.8-.9-33.9L66.8 208 208.5 73.4c9.6-9.1 10-24.3 .9-33.9zM352 64c0-12.6-7.4-24.1-19-29.2s-25-3-34.4 5.4l-160 144c-6.7 6.1-10.6 14.7-10.6 23.8s3.9 17.7 10.6 23.8l160 144c9.4 8.5 22.9 10.6 34.4 5.4s19-16.6 19-29.2l0-64 32 0c53 0 96 43 96 96c0 30.4-12.8 47.9-22.2 56.7c-5.5 5.1-9.8 12-9.8 19.5c0 10.9 8.8 19.7 19.7 19.7c2.8 0 5.6-.6 8.1-1.9C494.5 467.9 576 417.3 576 304c0-97.2-78.8-176-176-176l-48 0 0-64z"/></svg>
                            <span class="result"></span>`
            : html `<span style="opacity:.6">(restart available only for failed steps with planning)</span>`}
                        </div>
                    </li>
                </ul>
            </details>
        </div>
        `;
    }
    renderSummary(title) {
        return html `
            <div class="pheader">
                <div style="display:flex; align-items: center;gap:.5rem">
                    <span>
                        ${title}
                    </span>
                </div>
                <div style="display:flex; gap:.5rem">
                    <div class="chevron">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" style="width:10px"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"/></svg>
                    </div>
                </div>
            </div>
        `;
    }
    renderInputs() {
        const hasPrompts = this.prompts && this.prompts.length > 0;
        const tools = this.step?.interaction?.tools;
        const hasTools = Array.isArray(tools) && tools.length > 0;
        const toolChoice = this.step?.interaction?.toolChoice;
        if (!hasPrompts && !hasTools)
            return html `
            <div class="containerinputs">
                <h3>No input found!</h3>
            </div>
        `;
        return html `
        <div class="containerinputs containerdraganddrop">
            ${hasPrompts
            ? repeat(this.prompts, ((key) => key.type + Date.now()), ((p, idx) => { return this.renderPrompt(p, idx); }))
            : ''}
            ${hasTools ? this.renderTools(tools, toolChoice) : ''}
        </div>
        `;
    }
    renderTools(tools, toolChoice) {
        return html `
            ${toolChoice ? this.renderJsonCard('toolChoice', this.toolName(toolChoice) || 'toolChoice', toolChoice) : ''}
            ${tools.map((tool) => this.renderJsonCard('tool', this.toolName(tool) || 'tool', tool))}
        `;
    }
    toolName(tool) {
        return tool?.function?.name ?? tool?.name ?? '';
    }
    renderJsonCard(typeMode, title, value) {
        const content = JSON.stringify(value, null, 2);
        return html `
            <details class="prompt ${typeMode}">
                <summary>
                    <div class="pheader">
                        <div class="type" style="display:flex; align-items: center;gap:.5rem">
                            <span class="typeMode">${typeMode}</span>
                            <span class="title">${title}</span>
                        </div>
                        <div style="display:flex; gap:.5rem">
                            <div class="chevron">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" style="width:10px"><path d="M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"/></svg>
                            </div>
                        </div>
                    </div>
                </summary>
                <div>
                    <pre class="content">${content}</pre>
                </div>
            </details>
        `;
    }
    renderPayload() {
        const payload = this.getPayloadTabValue();
        if (!this.hasPayloadTabValue(payload)) {
            return html `
            <div class="containerinputs">
                <h3>No payload found!</h3>
            </div>
        `;
        }
        if (this.monacoLoadError) {
            return html `
            <div class="containerinputs">
                <h3>${this.monacoLoadError}</h3>
            </div>
        `;
        }
        requestAnimationFrame(() => this.updateEditorContent());
        return html `<div id="elEditor" style="width:100%; height:100%"></div>`;
    }
    renderPrompt(prompt, idx) {
        let pp = prompt.content.trim();
        return html `
            <details class="prompt ${prompt.type}" >
                <summary>
                    <div class="pheader">
                        <div class="type" style="display:flex; align-items: center;gap:.5rem">
                            <span class="typeMode">${prompt.type}</span>
                            <span class="title">
                                ${pp.substring(0, 50)}...
                            </span>
                        </div>
                        <div style="display:flex; gap:.5rem">
                            <div class="chevron">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" style="width:10px"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"/></svg>
                            </div>
                        </div>
                    </div>
                </summary>
                <div>
                    <pre class="content">${pp}</pre>
                </div>
            </details>
        `;
    }
    renderResults() {
        if (!this.step)
            return html `Not found step`;
        const nextOptions = [];
        if (this.step.interaction?.payload) {
            nextOptions.push(...this.step.interaction.payload);
        }
        if (this.step.nextSteps) {
            nextOptions.push(...this.step.nextSteps);
        }
        return html `
        <ul>
            ${nextOptions.length === 0 ? html `<li><em>Not next step</em></li>`
            : nextOptions.map((ns) => html ` <li> [${ns.stepId}] ${ns.type} - ${ns.agentName} </li> `)}
        </ul>
        `;
    } //<li @click=${() => this.navigateToStep(ns.stepId)}> [${ns.stepId}] ${ns.type} - ${ns.agentName} </li>
    //------IMPLEMENTATION----------
    async init() {
        if (this.step && this.step.stepId === this.lastKey)
            return;
        this.lastKey = this.step?.stepId || -1;
        this.getPrompts();
        await this.getDescription();
    }
    async getDescription() {
        if (!this.step || !this.step.agentName)
            return;
        try {
            const agent = await loadAgent(this.step.agentName);
            if (!agent)
                return;
            if (!agent || !agent.agentDescription)
                return;
            this.agentDescription = agent.agentDescription;
        }
        catch (e) {
        }
    }
    getPrompts() {
        if (this.step && this.step.interaction && this.step.interaction.input) {
            this.prompts = this.step.interaction.input;
        }
        else {
            this.prompts = [];
        }
    }
    selectTabInput() {
        this.mode = 'input';
    }
    selectTabInfo() {
        this.mode = 'info';
    }
    selectTabResult() {
        this.mode = 'result';
    }
    selectTabPayload() {
        this.mode = 'payload';
    }
    // ── Monaco editor (dedicated instance for the Payload tab) ────
    ensureEditorCreated() {
        if (this.sharedMonaco)
            return;
        const editorEl = document.createElement('mls-editor-100529');
        editorEl.style.cssText = 'width:100%; height:100%';
        const model = this.createModel();
        const ed1 = monaco.editor.create(editorEl, this.editorConf);
        monaco.languages.typescript.javascriptDefaults.setCompilerOptions({ noImplicitAny: true });
        ed1.updateOptions({ readOnly: true });
        ed1.setModel(model);
        editorEl.mlsEditor = ed1;
        window.elEditorAgentPayload = editorEl;
        window.editorAgentPayload = ed1;
    }
    mountEditor() {
        if (!this.elEditor)
            return;
        if (typeof monaco === 'undefined') {
            void this.loadMonacoThenMount();
            return;
        }
        this.ensureEditorCreated();
        this.elEditor.appendChild(this.sharedEditor);
    }
    /**
     * Monaco is no longer guaranteed to be loaded outside the Studio dev environment
     * (Ctrl+Alt+S) — this preview (the Payload tab) is a normal end-user feature, so it asks
     * the host via LoadMonaco instead of importing the shell that hosts it.
     */
    async loadMonacoThenMount() {
        const mls = window.mls;
        if (!mls)
            return;
        try {
            await requestMonacoLoad(mls);
        }
        catch (e) {
            console.warn('collabMessagesTaskPreviewAgent: monaco could not be loaded', e);
            this.monacoLoadError = 'Monaco could not be loaded.';
            return;
        }
        this.monacoLoadError = null;
        this.mountEditor();
    }
    createModel() {
        const uri = monaco.Uri.parse('file://server/agentPayloadModel.ts');
        return monaco.editor.getModel(uri)
            ?? monaco.editor.createModel('', 'javascript', uri);
    }
    updateEditorContent() {
        const ed1 = this.sharedMonaco;
        if (!ed1 || !this.step)
            return;
        const value = JSON.stringify(this.getPayloadTabValue(), null, 2);
        ed1.getModel()?.setValue(value);
    }
    getPayloadTabValue() {
        const payload = this.step?.interaction?.payload;
        if (this.hasPayloadTabValue(payload))
            return payload;
        const tracePayload = this.getTracePayload();
        if (tracePayload.length > 0)
            return tracePayload;
        return null;
    }
    hasPayloadTabValue(payload) {
        return payload !== null && payload !== undefined && (!Array.isArray(payload) || payload.length > 0);
    }
    getTracePayload() {
        const result = [];
        const trace = this.step?.interaction?.trace;
        if (!Array.isArray(trace))
            return result;
        for (const item of trace) {
            const parsed = this.parseTracePayloadItem(item);
            if (parsed !== null)
                result.push(parsed);
        }
        return result;
    }
    parseTracePayloadItem(item) {
        if (this.isTracePayloadItem(item))
            return item;
        if (typeof item !== 'string')
            return null;
        const value = item.trim();
        if (!value.startsWith('{'))
            return null;
        try {
            const parsed = JSON.parse(value);
            return this.isTracePayloadItem(parsed) ? parsed : null;
        }
        catch {
            return null;
        }
    }
    isTracePayloadItem(value) {
        if (!value || typeof value !== 'object' || Array.isArray(value))
            return false;
        const record = value;
        return 'title' in record && ('trace' in record || 'ok' in record || 'stage' in record || 'restart' in record);
    }
    canRestartStep() {
        if (!this.step || this.step.status !== 'failed')
            return false;
        if (this.step.planning)
            return true;
        // parallel_dynamic children have no planning but are restartable (re-run with their args).
        return this.isParallelChild();
    }
    isParallelChild() {
        if (!this.task || !this.step)
            return false;
        const stepId = this.step.stepId;
        return getAllSteps(this.task.iaCompressed?.nextSteps).some(s => !!s.progress && (s.nextSteps || []).some(ns => ns.stepId === stepId));
    }
    async restartStep(el, stepId) {
        const sum = el?.closest('div');
        let result;
        if (sum)
            result = sum.querySelector('.result');
        if (result)
            result.innerText = '';
        if (!this.task || !this.message) {
            if (result)
                result.innerText = 'result: no task/message';
            return;
        }
        const cleaner = window.confirm('Clear inputs and outputs of this step?') ? 'input_output' : undefined;
        el.classList.add('rotate');
        try {
            const context = {
                task: this.task,
                message: this.message,
                isTest: false,
            };
            await restartStep(context, stepId, cleaner);
            if (result)
                result.innerText = 'result: Ok';
        }
        catch (e) {
            console.info(e);
            if (result)
                result.innerText = e && e.message ? 'result: ' + e.message : 'result: Erro';
        }
        finally {
            el.classList.remove('rotate');
        }
    }
};
__decorate([
    property({ type: Object })
], CollabMessagesTaskPreviewAgent.prototype, "message", void 0);
__decorate([
    property({ type: Object })
], CollabMessagesTaskPreviewAgent.prototype, "task", void 0);
__decorate([
    property({ type: Object })
], CollabMessagesTaskPreviewAgent.prototype, "step", void 0);
__decorate([
    property({ type: String })
], CollabMessagesTaskPreviewAgent.prototype, "agentDescription", void 0);
__decorate([
    state()
], CollabMessagesTaskPreviewAgent.prototype, "prompts", void 0);
__decorate([
    state()
], CollabMessagesTaskPreviewAgent.prototype, "mode", void 0);
__decorate([
    state()
], CollabMessagesTaskPreviewAgent.prototype, "monacoLoadError", void 0);
__decorate([
    query('#elEditor')
], CollabMessagesTaskPreviewAgent.prototype, "elEditor", void 0);
CollabMessagesTaskPreviewAgent = __decorate([
    customElement('collab-messages-task-preview-agent-102025')
], CollabMessagesTaskPreviewAgent);
export { CollabMessagesTaskPreviewAgent };
