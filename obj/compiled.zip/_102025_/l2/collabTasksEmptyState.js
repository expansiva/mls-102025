/// <mls fileReference="_102025_/l2/collabTasksEmptyState.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let CollabTasksEmptyState = class CollabTasksEmptyState extends StateLitElement {
    constructor() {
        super(...arguments);
        this.title = '';
        this.subtitle = '';
    }
    render() {
        return html `
      <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="3" width="7" height="7" rx="1"></rect>
        <rect x="14" y="3" width="7" height="7" rx="1"></rect>
        <rect x="3" y="14" width="7" height="7" rx="1"></rect>
        <rect x="14" y="14" width="7" height="7" rx="1"></rect>
      </svg>
      ${this.title ? html `<div class="title">${this.title}</div>` : ''}
      ${this.subtitle ? html `<div class="subtitle">${this.subtitle}</div>` : ''}
      <slot></slot>
    `;
    }
};
CollabTasksEmptyState.styles = css `
    :host {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100%;
      min-height: 200px;
      padding: 40px 20px;
      text-align: center;
      color: var(--color-text-secondary, #9ca3af);
    }
    .icon {
      width: 48px;
      height: 48px;
      margin-bottom: 16px;
      opacity: 0.4;
    }
    .title {
      font-size: 16px;
      font-weight: 600;
      color: var(--color-text-primary, #374151);
      margin-bottom: 6px;
    }
    .subtitle {
      font-size: 13px;
      color: var(--color-text-secondary, #9ca3af);
      max-width: 300px;
    }
    ::slotted(*) { margin-top: 16px; }
  `;
__decorate([
    property({ type: String })
], CollabTasksEmptyState.prototype, "title", void 0);
__decorate([
    property({ type: String })
], CollabTasksEmptyState.prototype, "subtitle", void 0);
CollabTasksEmptyState = __decorate([
    customElement('collab-tasks-empty-state-102025')
], CollabTasksEmptyState);
export { CollabTasksEmptyState };
