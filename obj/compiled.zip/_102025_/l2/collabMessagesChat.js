/// <mls fileReference="_102025_/l2/collabMessagesChat.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML, nothing } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { collab_chevron_left, collab_gear, collab_translate, collab_circle_exclamation, collab_plus, collab_folder_tree } from '/_102025_/l2/collabMessagesIcons.js';
import { removeThreadFromSync, getThreadUpdateInBackground, checkIfNotificationUnread } from '/_102025_/l2/collabMessagesSyncNotifications.js';
import { openElementInServiceDetails, clearServiceDetails, changeFavIcon } from '/_100554_/l2/libCommom.js';
import { getTemporaryContext, formatTimestamp, notifyThreadChange } from '/_100554_/l2/aiAgentHelper.js';
import { loadAgent, executeBeforePrompt } from '/_100554_/l2/aiAgentOrchestration.js';
import { addOrUpdateTask, addMessages, addMessage, updateThread, updateUsers, getMessage, getMessagesByThreadId, deleteAllMessagesFromThread, listUsers, getThread, updateLastMessageReadTime } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { loadChatPreferences, getBotsContext, registerToken, loadNotificationPreferences, loadNotificationDeviceId, defaultThreadImage } from '/_102025_/l2/collabMessagesHelper.js';
import '/_102025_/l2/collabMessagesTaskInfo.js';
import '/_102025_/l2/collabMessagesTask.js';
import '/_102025_/l2/collabMessagesTopics.js';
import '/_102025_/l2/collabMessagesPrompt.js';
import '/_102025_/l2/collabMessagesAvatar.js';
import '/_102025_/l2/collabMessagesThreadDetails.js';
import '/_102025_/l2/collabMessagesRichPreview.js';
import '/_102025_/l2/collabMessagesUserModal.js';
import '/_102025_/l2/collabMessagesThreadModal.js';
import '/_102025_/l2/collabMessagesFilter.js';
import '/_102025_/l2/collabMessagesAdd.js';
import { AGENTDEFAULT } from '/_102025_/l2/collabMessagesHelper.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    btnAddParticipant: 'Adicionar participante',
    threadDetails: 'Detalhes da sala',
    threadAdd: 'Adicionar sala',
    msgNotSend: 'Mensagem não enviada*',
    noThreads: 'Nenhuma sala disponível no momento.',
    placeholderSearch: 'Digite para filtrar',
    threadArchived: 'A thread foi arquivada por [user] em [date]',
    threadDeleting: 'A thread foi deletada em [date]',
    archived: 'Arquivado',
    deleting: 'Deletando',
    deleted: 'Deletada',
    btnNext: 'Continuar',
    promptPlaceholder: 'Digite aqui... (@ para menções) (@@ para agentes)',
    today: 'Hoje',
    yesterday: 'Ontem',
    newMessages: 'Novas mensagens',
    lastMessagePrefix: 'Você'
};
const message_en = {
    loading: 'Loading...',
    btnAddParticipant: 'Add Participant',
    threadDetails: 'Thread details',
    threadAdd: 'Add thread',
    msgNotSend: 'Message not sent*',
    noThreads: 'No threads available at the moment.',
    placeholderSearch: 'Type to filter',
    threadArchived: 'Thread is archived by [user] in [date]',
    threadDeleting: 'Thread was deleted in [date]',
    archived: 'Archived',
    deleting: 'Deleting',
    deleted: 'Deleted',
    btnNext: 'Next',
    promptPlaceholder: 'Type here... (@ for mentions) (@@ for agents)',
    today: 'Today',
    yesterday: 'Yesterday',
    newMessages: 'New messages',
    lastMessagePrefix: 'You'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesChat = class CollabMessagesChat extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-chat-102025{position:relative;display:flex;flex-direction:column;height:100%;width:375px;background:var(--bg-primary-color-darker)}collab-messages-chat-102025 .loader{display:inline-block;width:10px;height:10px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}collab-messages-chat-102025 .header{padding:.1rem;height:50px;min-height:50px;color:var(--text-primary-color);cursor:pointer;display:flex;align-items:center;justify-content:center;font-weight:bold;font-size:var(--font-size-12);text-transform:uppercase;border-bottom:1px solid var(--grey-color-dark)}collab-messages-chat-102025 .header svg{fill:currentColor}collab-messages-chat-102025 .header collab-messages-filter-102025{width:calc(100% - 50px)}collab-messages-chat-102025 .header .header-title{max-width:300px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}collab-messages-chat-102025 .header .header-actions{margin-left:auto;margin-right:1rem;display:flex;gap:.5rem}collab-messages-chat-102025 .header .header-actions span{cursor:pointer}collab-messages-chat-102025 .header>span{display:flex;align-items:center;gap:.5rem;flex:1;justify-content:center}collab-messages-chat-102025 .welcome-message{padding:1rem}collab-messages-chat-102025 .welcome-message button{background-color:var(--info-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer;width:100%}collab-messages-chat-102025 .welcome-message button:hover{background-color:var(--info-color-hover)}collab-messages-chat-102025 .thread-search{width:100%;padding:0 .3rem}collab-messages-chat-102025 .thread-search input[type="search"]{width:100%;padding:.4rem 1rem;font-size:1rem;border:1px solid #ccc;border-radius:15px;outline:none;transition:border-color .2s,box-shadow .2s;box-shadow:0 0 0 2px transparent}collab-messages-chat-102025 .thread-list{list-style:none;margin:0;padding:0;overflow-y:auto;overflow-x:hidden;width:375px}collab-messages-chat-102025 .thread-list .archived-title{background:var(--grey-color-lighter);text-align:center;text-transform:uppercase;font-size:var(--font-size-16)}collab-messages-chat-102025 .thread-list .unread-count{background-color:var(--success-color);color:#fff;font-size:.75rem;font-weight:bold;padding:.25rem .5rem;border-radius:12px;margin-left:1rem;white-space:nowrap}collab-messages-chat-102025 .thread-list .thread-group details:not([open]){background:var(--grey-color-light)}collab-messages-chat-102025 .thread-list .thread-group summary{cursor:pointer;list-style:none;height:70px;transition:background-color .5s;display:flex;align-items:center;padding:.1rem .3rem;position:relative;width:100%;border-bottom:1px solid var(--grey-color)}collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-item-header{display:flex;justify-content:space-between}collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-item-header .thread-group-name{font-size:1rem;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text-primary-color)}collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-item-header .last-group-update{font-size:.875rem;color:var(--grey-color-dark);white-space:nowrap}collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-content{flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;padding:.9rem}collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-avatar{width:50px;height:50px}collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-avatar svg{fill:currentColor;width:40px;height:50px}collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-avatar img{border-radius:15px;width:100%;height:100%}collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-summary{display:flex;justify-content:space-between;align-items:center}collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-summary .last-group-message{font-size:.875rem;color:var(--grey-color-darker);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}collab-messages-chat-102025 .thread-list .thread-group summary::-webkit-details-marker{display:none}collab-messages-chat-102025 .thread-item:hover{background-color:var(--bg-primary-color-focus)}collab-messages-chat-102025 .thread-item{cursor:pointer;height:70px;transition:background-color .5s;display:flex;align-items:center;padding:.1rem .3rem;position:relative;width:100%;border-bottom:1px solid var(--grey-color)}collab-messages-chat-102025 .thread-item .back-button{cursor:pointer}collab-messages-chat-102025 .thread-item .avatar{flex:0 0 auto;width:48px;height:48px;border-radius:50%;margin-right:1rem}collab-messages-chat-102025 .thread-item .thread-content{flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;padding:.9rem}collab-messages-chat-102025 .thread-item .thread-item-avatar{width:40px;height:40px;border-radius:15px;border:1px solid var(--grey-color-light)}collab-messages-chat-102025 .thread-item .thread-item-avatar img,collab-messages-chat-102025 .thread-item .thread-item-avatar svg{border-radius:15px;width:100%;height:100%}collab-messages-chat-102025 .thread-item .thread-item-header{display:flex;justify-content:space-between}collab-messages-chat-102025 .thread-item .thread-item-header .thread-name{font-size:1rem;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--text-primary-color)}collab-messages-chat-102025 .thread-item .thread-item-header .last-update,collab-messages-chat-102025 .thread-item .thread-item-header .archived-at{font-size:.875rem;color:var(--grey-color-dark);white-space:nowrap}collab-messages-chat-102025 .thread-item .thread-summary{display:flex;justify-content:space-between;align-items:center}collab-messages-chat-102025 .thread-item .thread-summary .last-message{font-size:.875rem;color:var(--grey-color-darker);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}collab-messages-chat-102025 .unread-messages{background:radial-gradient(circle at center, #868686 0%, rgba(255,255,255,0.6) 70%, rgba(255,255,255,0) 100%);position:absolute;width:100%;top:50px;right:0;color:#FFFFFF;text-align:center;text-transform:uppercase;font-size:16px;animation:pulseLoading 1.5s infinite ease-in-out}collab-messages-chat-102025 .new-messages-label{display:flex;justify-content:center;background:#ebebeb;text-transform:uppercase;font-size:12px;font-weight:bold}collab-messages-chat-102025 .error-messages{position:absolute;top:50px;left:0;padding-left:1rem;background:var(--grey-color-light);color:var(--error-color);font-size:var(--font-size-16)}@keyframes pulseLoading{0%{opacity:.6}50%{opacity:1}100%{opacity:.6}}collab-messages-chat-102025 .chat-container{display:flex;flex:1;flex-direction:column;padding:6px;width:calc(100% - 12px);overflow-y:auto;max-height:100%}collab-messages-chat-102025 .chat-container .message-time{text-align:center;font-size:.85rem;color:gray;margin-bottom:5px}collab-messages-chat-102025 .chat-container .message{display:flex;flex-direction:column;align-items:flex-start;width:100%;margin-top:10px}collab-messages-chat-102025 .chat-container .message.user{align-items:flex-end}collab-messages-chat-102025 .chat-container .message.same{margin-top:0}collab-messages-chat-102025 .chat-container .message .message-row{max-width:80%;margin-bottom:3px;margin-left:50px;position:relative}collab-messages-chat-102025 .chat-container .message .message-row .message-card{display:flex;flex-direction:column;background-color:#f5f5f5;border-radius:8px;padding:.5rem;position:relative;font-size:14px}collab-messages-chat-102025 .chat-container .message .message-row .message-card.system:not(.same){border-top-left-radius:0px}collab-messages-chat-102025 .chat-container .message .message-row .message-card.system:not(.same):before{content:'';position:absolute;top:0px;left:-15px;width:6px;height:0;border-top:0px solid transparent;border-right:10px solid #f5f5f5;border-bottom:12px solid transparent}collab-messages-chat-102025 .chat-container .message .message-row .message-card.user{background-color:#daf8cb;align-self:flex-end}collab-messages-chat-102025 .chat-container .message .message-row .message-card .message-title{color:#be069c}collab-messages-chat-102025 .chat-container .message .message-row .message-card .message-ai{margin-top:.3rem;display:flex;margin-left:auto;width:100%}collab-messages-chat-102025 .chat-container .message .message-row .message-card .failed{margin-top:.2rem}collab-messages-chat-102025 .chat-container .message .message-row .message-card .failed>div{display:flex;gap:.3rem}collab-messages-chat-102025 .chat-container .message .message-row .message-card .failed svg{fill:var(--error-color);width:14px;height:14px}collab-messages-chat-102025 .chat-container .message .message-row .message-card .failed small{color:#000000;font-style:italic;font-size:var(--font-size-12)}collab-messages-chat-102025 .chat-container .message .message-row .message-card .message-content{margin-top:.4rem;color:#000;display:flex;align-items:center;gap:.4rem;word-break:break-word}collab-messages-chat-102025 .chat-container .message .message-row .message-card .message-content svg{width:12px;fill:var(--active-color)}collab-messages-chat-102025 .chat-container .message .message-row .message-card .message-result .message-result-text{border-top:1px solid var(--grey-color-dark);margin-top:.5rem;white-space:pre-line;color:#000;word-break:break-word}collab-messages-chat-102025 .chat-container .message .message-row .message-card .message-result .message-result-text widget-text2-collab-messages-m-d-102025 .collab-md-message{font-family:inherit;font-size:inherit;color:inherit;line-height:inherit;background:inherit;padding:inherit}collab-messages-chat-102025 .chat-container .message .message-row .message-card .message-result .message-result-text widget-text2-collab-messages-m-d-102025 .collab-md-message .mention-agent{color:var(--active-color);background-color:transparent}collab-messages-chat-102025 .chat-container .message .message-row .message-card .message-result .message-result-text widget-text2-collab-messages-m-d-102025 .collab-md-message .mention-agent:hover{color:var(--active-color-hover)}collab-messages-chat-102025 .chat-container .message .message-row .message-card .message-content.trace{display:flex;flex-direction:column;align-items:flex-start}collab-messages-chat-102025 .chat-container .message .message-row .message-card .message-content.translate{padding:0;margin:0;font-size:11px;font-style:italic;color:#717070;padding-inline-start:6px;border-left:2px solid #717070}collab-messages-chat-102025 .chat-container .message .message-row .message-card .message-footer{font-size:.75rem;color:gray;text-align:right}collab-messages-chat-102025 .chat-container .message .message-row collab-messages-avatar-102025{position:absolute;top:-3px;left:-40px}collab-messages-chat-102025 .chat-container .message .message-group{display:contents}`);
        this.msg = messages['en'];
        this.isLoadingThread = false;
        this.filteredThreads = { active: [], archived: [], deleted: [], deleting: [] };
        this.isThreadError = false;
        this.threadErrorMsg = '';
        this.lastTopicFilter = '';
        this.welcomeMessage = '';
        this.usersAvaliables = [];
        this.group = 'CONNECT';
        this.activeScenerie = 'list';
        this.actualMessages = [];
        this.actualMessagesParsed = {};
        this.isLoadingMessages = false;
        this.searchTerm = '';
        this.userThreads = {};
        this.allThreads = [];
        this.lastMessageReaded = '';
        this.unreadCountInSelectedThread = 0;
        this.isSystemChangeScroll = false;
        this.savedScrollTop = 0;
        this.hasMoreMessagesLocalDB = true;
        this.hasMoreMessagesBefore = false;
        this.messagesLimit = 10;
        this.messagesOffset = 0;
        this.isLoadingMoreMessages = false;
        this.isChangeTopics = false;
        this.wasMessagesAtBottom = true;
        this.alreadyCheckForRegisterToken = false;
        this.onTaskChange = async (e) => {
            const customEvent = e;
            const message = customEvent.detail.context.message;
            const task = customEvent.detail.context.task;
            const thId = message?.threadId;
            if (!this.actualThread || !thId || thId !== this.actualThread.thread.threadId)
                return;
            await this.updateMessageAI(customEvent.detail.context, false, customEvent.detail.oldContextCreateAt);
            if (task)
                await addOrUpdateTask(customEvent.detail.context.task);
        };
        this.onTaskDetailsClose = async (_e) => {
            const taskId = _e.detail;
            clearServiceDetails();
            if (taskId) {
                this.taskToOpen = taskId;
                this.openTask();
            }
        };
        this.onThreadChange = async (e) => {
            const customEvent = e;
            await this.updateMessageAI(customEvent.detail, false);
            const thread = customEvent.detail;
            const threadUpdated = this.userThreads[this.group].find((th) => th.thread.threadId === thread.threadId);
            if (['deleted'].includes(thread.status)) {
                await deleteAllMessagesFromThread(thread.threadId);
            }
            if (threadUpdated)
                threadUpdated.thread = { ...threadUpdated.thread, ...thread };
            else if (thread.group === this.group) {
                this.userThreads[this.group] = [...this.userThreads[this.group], { thread, hasMore: false, users: [] }];
            }
            if (threadUpdated?.thread.threadId === this.actualThread?.thread.threadId) {
                this.actualThread = threadUpdated;
                if (this.actualThread && this.actualThread.thread.unreadCount && this.actualThread.thread.unreadCount > 0) {
                    const chatEl = this.querySelector('.chat-container');
                    if (chatEl) {
                        const isScrolledToBottom = chatEl.scrollTop + chatEl.clientHeight >= chatEl.scrollHeight - 1;
                        if (isScrolledToBottom)
                            this.isSystemChangeScroll = true;
                    }
                    const messagesInDb = await getMessagesByThreadId(this.actualThread.thread.threadId, this.messagesLimit, 0);
                    this.actualMessages = messagesInDb;
                    this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
                    await this.updateLastMessage(this.actualThread);
                }
            }
            if (this.activeScenerie === 'threadDetails' && (thread.status === 'deleted' ||
                thread.status === 'deleting' ||
                thread.status === 'archived')) {
                this.activeScenerie = 'list';
            }
            this.requestUpdate();
        };
        this.onMessageSend = async (e) => {
            const customEvent = e;
            const message = customEvent.detail.context.message;
            const outputs = customEvent.detail.context.botOutput;
            const thId = message?.threadId;
            if (!this.actualThread || !thId || thId !== this.actualThread.thread.threadId)
                return;
            this.updateMessage2(false, true, { ...message, footers: [] }, message, outputs);
        };
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('activeScenerie') && (this.activeScenerie === 'list')) {
            this.usersAvaliables = await listUsers();
        }
        if (changedProperties.has('threadToOpen')) {
            if (this.threadToOpen) {
                if (this.activeScenerie !== 'list') {
                    this.activeScenerie = 'list';
                    await this.updateComplete;
                }
                const threadElement = this.querySelector(`[threadId="${this.threadToOpen}"]`);
                if (!threadElement)
                    return;
                const detailsParent = threadElement.closest('details');
                if (detailsParent && !detailsParent.open) {
                    detailsParent.open = true;
                    await this.updateComplete;
                }
                this.onThreadClick(threadElement.item);
            }
        }
        if (changedProperties.has('activeScenerie')
            && (changedProperties.get('activeScenerie') === 'task'
                || changedProperties.get('activeScenerie') === 'addParticipant'
                || changedProperties.get('activeScenerie') === 'threadDetails')
            && this.activeScenerie === 'details') {
            this.restoreScrollPosition();
        }
        if (changedProperties.has('actualMessagesParsed') && this.actualMessagesParsed !== undefined) {
            if (this.messageContainer && (this.isSystemChangeScroll)) {
                await this.updateComplete;
                const target = this.unreadEl;
                let offset = this.messageContainer.scrollHeight;
                if (target)
                    target.scrollIntoView({ block: 'center' });
                else
                    this.messageContainer.scrollTop = offset;
                this.isSystemChangeScroll = false;
            }
        }
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        window.removeEventListener('task-change', this.onTaskChange);
        window.removeEventListener('task-details-close', this.onTaskDetailsClose);
        window.removeEventListener('thread-change', this.onThreadChange.bind(this));
        window.removeEventListener('message-send', this.onMessageSend);
        document.removeEventListener("visibilitychange", this.onVisibilityChange.bind(this));
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        window.addEventListener('task-change', this.onTaskChange);
        window.addEventListener('task-details-close', this.onTaskDetailsClose);
        window.addEventListener('thread-change', this.onThreadChange.bind(this));
        window.addEventListener('message-send', this.onMessageSend);
        document.addEventListener("visibilitychange", this.onVisibilityChange.bind(this));
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.activeScenerie === 'loading') {
            return html `<div class="loading">${this.msg.loading}</div>`;
        }
        return html `
            ${this.renderHeader()}
            ${this.renderContent()}`;
    }
    renderHeader() {
        switch (this.activeScenerie) {
            case 'task':
                return html `
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} <span class="header-title">Task: ${this.actualTask?.PK || ''}</span></span>
                    </div>`;
            case 'details':
                return html `
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} <span class="header-title">Thread: ${this.getThreadName(this.actualThread)}</span></span>
                        ${this.actualThread?.thread.status !== 'deleted' ? html `
                            <div class="header-actions">
                                <span @click=${this.onThreadDetailsClick}>${collab_gear}</span>
                            </div>
                        ` : ''}                        
                    </div>`;
            case 'list':
                return html `<div class="header">
                    ${this.renderThreadSearch()}
                    <div class="header-actions">
                            <span @click=${this.onThreadAddClick}>${collab_plus}</span>
                    </div>
                </div>`;
            case 'threadDetails':
                return html `
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} ${this.msg.threadDetails}</span>
                    </div>`;
            case 'threadAdd':
                return html `
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} ${this.msg.threadAdd}</span>
                    </div>`;
            default:
                return null;
        }
    }
    renderContent() {
        switch (this.activeScenerie) {
            case 'list':
                return this.renderListThreads();
            case 'details':
                return this.renderChatMessages();
            case 'task':
                return this.renderTaskDetails();
            case 'threadDetails':
                return this.renderThreadDetails();
            case 'threadAdd':
                return this.renderThreadAdd();
            default:
                return null;
        }
    }
    renderChatMessages() {
        if (!this.actualThread)
            return html ``;
        if (this.welcomeMessage && !['deleting', 'deleted', 'archived'].includes(this.actualThread?.thread.status)) {
            return this.renderWelcomeMessage();
        }
        if (this.actualThread.thread.status === 'deleting' || this.actualThread.thread.status === 'deleted') {
            const formatedTimestamp = formatTimestamp(this.actualThread.thread.deletedAt || '');
            const deletedAt = this.parseLocalDate(formatedTimestamp?.dateFull || '');
            return html `
                <div>${this.msg.threadDeleting.replace('[date]', deletedAt.datafull)}</div>
            `;
        }
        if (this.actualThread.thread.status === 'archived') {
            const formatedTimestamp = formatTimestamp(this.actualThread.thread.archivedAt || '');
            const archivedAt = this.parseLocalDate(formatedTimestamp?.dateFull || '');
            const archivedBy = this.actualThread.users.find((user) => user.userId === this.actualThread?.thread.archivedBy);
            return html `
                <div>${this.msg.threadArchived.replace('[user]', archivedBy?.name || '').replace('[date]', archivedAt.datafull)}</div>
            `;
        }
        this.userPreferenceChat = loadChatPreferences();
        const sortedEntries = Object.entries(this.actualMessagesParsed)
            .map(([date, value]) => [date.trim(), value])
            .sort(([a], [b]) => new Date(a).getTime() - new Date(b).getTime());
        const sortedObj = Object.fromEntries(sortedEntries);
        let nextNeedShowLabel = false;
        return html `
            ${this.renderTopics()}
            <div
                @scroll=${this.onChatScroll} class="chat-container"
                @copy=${this.onCopyChat}
            >
            ${Object.keys(sortedObj).map((key, index) => {
            const threadMessages = sortedObj[key];
            const messageTime = this.parseLocalDate(key);
            const displayDate = this.formatMessageDate(messageTime.dateObject);
            return html `
                <div class="message-time">${displayDate}</div>
                    ${threadMessages.map((message) => {
                const dateFormated = formatTimestamp(message.createAt);
                const userToFind = [
                    ...this.usersAvaliables,
                    ...(this.actualThread?.users || [])
                ].filter((user, index, self) => index === self.findIndex(u => u.userId === user.userId));
                const userName = userToFind.find((user) => user.userId === message.senderId)?.name || message.senderId;
                const userAvatar = userToFind.find((user) => user.userId === message.senderId)?.avatar_url || '';
                const cls = message.senderId === this.userId ? 'user' : 'system';
                const isSame = message.isSame;
                if (this.lastMessageReaded === message.createAt && this.unreadCountInSelectedThread)
                    nextNeedShowLabel = true;
                else
                    nextNeedShowLabel = false;
                const titleTranslated = this.getTitleMessageTranslated(message);
                return html `
                            <div class="message ${cls} ${isSame ? 'same' : ''}">
                                <div class="message-group">
                                    <div class="message-row">
                                        <div class="message-card ${cls} ${isSame ? 'same' : ''}">
                                            ${!isSame ? html `<div class="message-title">@${userName}</div>` : ``}
                                            ${this.renderMessageByLanguage(message)}
                                            ${message.isLoading ? html `<span class="loader"></span>` : ''}
                                            ${message.isFailed ? html `<div class="failed">
                                                <div>
                                                    <span>${collab_circle_exclamation}</span>
                                                    <small>${this.msg.msgNotSend}</small>
                                                </div>
                                                <small>${message.isFailedError}</small>
                                            </div>` : ''}
                                            ${message.taskId ? html `
                                                <div class="message-ai">
                                                    <collab-messages-task-102025
                                                        messageId=${message.createAt}
                                                        .context= ${message.context}
                                                        lastChanged= ${message.lastChanged}
                                                        taskId=${message.taskId}
                                                        threadId=${this.actualThread?.thread.threadId}
                                                        userId=${this.userId}
                                                        title=${titleTranslated}
                                                        status=${message.taskStatus}
                                                        @taskclick=${() => this.onTaskClick(message?.taskId || '', message.createAt, message.threadId, message)}
                                                    >
                                                    </collab-messages-task-102025>
                                                </div> ` : html ``}
                                            ${this.renderMessageResultByLanguage(message)}
                                            ${this.renderMessageFooterResult(message)}
                                            <div class="message-footer">${dateFormated?.timeShort}</div>
                                        </div>
                                        ${cls === 'system' && !isSame ? html `<collab-messages-avatar-102025 avatar=${userAvatar}></collab-messages-avatar-102025>` : ''}
                                    </div>
                                </div>
                            </div>
                            ${nextNeedShowLabel ? html `<div class="new-messages-label">${this.msg.newMessages}</div>` : ''}
                            `;
            })}`;
        })}
                ${this.isLoadingMessages ? html `<div class="unread-messages">Loading messages...</div>` : html ``}
                ${this.isThreadError ? html `<div class="error-messages">${this.threadErrorMsg}</div>` : html ``}

            </div>
        ${this.renderPrompt()}`;
    }
    renderWelcomeMessage() {
        return html `
            <div class="welcome-message">
                <p>${this.welcomeMessage}</p>
                <button @click=${() => { this.welcomeMessage = ''; }}>${this.msg.btnNext}</button>       
            </div>`;
    }
    renderMessageFooterResult(message) {
        if (!message.footers || message.footers.length === 0)
            return html ``;
        return html `<div class="message-result">
            ${message.footers?.map((footer) => {
            const content = footer.lines.join('\n').trim();
            if (!content)
                return html ``;
            return html `
                <div class="message-result-text">
                    <b>${footer.title?.trim()}</b>
                    <div>
                        ${this.renderCollabMessagesRichPreview(footer.lines.join('\n').trim())}                    
                    </div>
                </div>`;
        })}
        </div>`;
    }
    renderCollabMessagesRichPreview(text) {
        return html `
        <collab-messages-rich-preview-102025 
            @mention-hover=${this.onMentionHover}
            @channel-hover=${this.onChannelHover}
            .allUsers=${this.usersAvaliables} 
            .allThreads=${this.allThreads}
            text="${text}"
        ></collab-messages-rich-preview-102025>`;
    }
    renderTopics() {
        return html `
            <collab-messages-topics-102025
                .selectedTopic=${this.lastTopicFilter === '' ? 'all' : this.lastTopicFilter}
                .messages=${this.actualMessages}
                .threadTopics=${this.actualThread?.thread.defaultTopics || []}
                @topic-selected=${(e) => this.onTopicClick(e)}
            ></collab-messages-topics-102025>
        `;
    }
    async onTopicClick(e) {
        this.lastTopicFilter = e.detail.topic === 'all' ? '' : e.detail.topic;
        this.isChangeTopics = true;
        if (e.detail.topic === 'all')
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        else
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        await this.updateComplete;
        if (this.messageContainer) {
            const newHeight = this.messageContainer.scrollHeight;
            this.messageContainer.scrollTop = newHeight;
        }
    }
    async onMentionHover(ev) {
        this.removeAllUserModal();
        if (!ev.detail || !ev.detail.value || !ev.detail.element)
            return;
        const actualUserModal = this.usersAvaliables.find((user) => user.name === ev.detail.value);
        const rects = ev.detail.element.getBoundingClientRect();
        const modal = document.createElement('collab-messages-user-modal-102025');
        modal.user = actualUserModal;
        modal.setAttribute('actualUserId', this.userId);
        this.appendChild(modal);
        await modal.updateComplete;
        const rectsModal = modal.getBoundingClientRect();
        modal.style.top = (rects.top - rectsModal.height - rects.height - 70) + 'px';
        modal.style.left = '20px';
    }
    async onChannelHover(ev) {
        this.removeAllUserModal();
        if (!ev.detail || !ev.detail.value || !ev.detail.element)
            return;
        const actualThreadModal = this.allThreads.find((thread) => thread.name === `#${ev.detail.value}`);
        const rects = ev.detail.element.getBoundingClientRect();
        const modal = document.createElement('collab-messages-thread-modal-102025');
        modal.thread = actualThreadModal;
        this.appendChild(modal);
        await modal.updateComplete;
        const rectsModal = modal.getBoundingClientRect();
        modal.style.top = (rects.top - rectsModal.height - rects.height - 70) + 'px';
        modal.style.left = '20px';
    }
    removeAllUserModal() {
        const all = this.querySelectorAll('collab-messages-user-modal-102025');
        all.forEach((item) => item.remove());
    }
    removeAllChannelModal() {
        const all = this.querySelectorAll('collab-messages-thread-modal-102025');
        all.forEach((item) => item.remove());
    }
    renderMessageResultByLanguage(message) {
        if (!message.taskResults || message.taskResults.length === 0 || message.taskStatus !== 'done')
            return html ``;
        const mode = this.userPreferenceChat?.translationMode || 'icon';
        if (!this.userPreferenceChat || mode === 'none') {
            return html `<div class="message-content">${message.taskResults[0]}</div>`;
        }
        const response = message.taskResults[0];
        const { language } = this.userPreferenceChat;
        const messageByLanguagePref = message.taskResultsTranslated ? message.taskResultsTranslated[language] : '';
        const isSameLanguege = language === message.taskResultsTranslated?.language_detected;
        switch (mode) {
            case 'icon':
                return html `<div class="message-content">${messageByLanguagePref || response} ${!isSameLanguege ? collab_translate : ''}</div>`;
            case 'text':
                return html `
                <div class="message-content">${messageByLanguagePref || response}</div>
                ${!isSameLanguege ? html `<small class="message-content translate">${response}</small>` : ''}`;
            case 'iconText':
                return html `<div class="message-content">${messageByLanguagePref || response} ${!isSameLanguege ? collab_translate : ''}</div>
                ${!isSameLanguege ? html `<small class="message-content translate">${response}</small>` : ''}`;
            case 'trace':
                return html `<div class="message-content trace">
                <div><b>[LanguageDetected: ${message.language_detected}]</b> ${response}</div>
                ${Object.keys(message.taskResultsTranslated || {}).map((key) => {
                    if (key === 'language_detected')
                        return '';
                    if (key === message.taskResultsTranslated?.language_detected)
                        return '';
                    return html `<div><b>[${key}]</b> ${message.taskResultsTranslated ? message.taskResultsTranslated[key] : ''}</div>`;
                })}
                </div>`;
            default:
                return null;
        }
    }
    getTitleMessageTranslated(message) {
        const mode = this.userPreferenceChat?.translationMode || 'icon';
        if (!this.userPreferenceChat || mode === 'none' || !message.taskTitleTranslated) {
            return message.taskTitle;
        }
        const { language } = this.userPreferenceChat;
        const titleByLanguagePref = message.taskTitleTranslated ? (message.taskTitleTranslated[language] ? message.taskTitleTranslated[language] : message.taskTitle) : message.taskTitle;
        return titleByLanguagePref;
    }
    renderMessageByLanguage(message) {
        const mode = this.userPreferenceChat?.translationMode || 'icon';
        if (!this.userPreferenceChat || mode === 'none' || !message.translations) {
            return html `
            <div class="message-content">
                ${this.renderCollabMessagesRichPreview(message.content)} 
            </div>`;
        }
        const { language } = this.userPreferenceChat;
        const messageByLanguagePref = message.translations ? message.translations[language] : '';
        const isSameLanguege = language === message.language_detected;
        switch (mode) {
            case 'icon':
                return html `
                <div class="message-content">
                    ${this.renderCollabMessagesRichPreview(messageByLanguagePref || message.content)} 
                     ${!isSameLanguege ? collab_translate : ''}
                </div>`;
            case 'text':
                return html `
                <div class="message-content">
                    ${this.renderCollabMessagesRichPreview(messageByLanguagePref || message.content)}   
                </div>
                ${!isSameLanguege ?
                    html `<small class="message-content translate">
                            ${this.renderCollabMessagesRichPreview(message.content)}   
                        </small>`
                    : ''}`;
            case 'iconText':
                return html `
                    <div class="message-content">
                        ${this.renderCollabMessagesRichPreview(messageByLanguagePref || message.content)}   
                        ${!isSameLanguege ? collab_translate : ''}
                    </div>
                ${!isSameLanguege ?
                    html `<small class="message-content translate">
                        ${this.renderCollabMessagesRichPreview(message.content)}    
                    </small>`
                    : ''}`;
            case 'trace':
                return html `
                <div class="message-content trace">
                    <div>
                        <b>[LanguageDetected: ${message.language_detected}]</b>
                        ${this.renderCollabMessagesRichPreview(message.content)}   
                    </div>
                    ${Object.keys(message.translations).map((key) => {
                    if (key === 'language_detected')
                        return '';
                    if (key === message.language_detected)
                        return '';
                    return html `
                            <div>
                                <b>[${key}]</b>
                                ${this.renderCollabMessagesRichPreview(message.translations ? message.translations[key] : '')}                        
                            </div>`;
                })}
                </div>`;
            default:
                return null;
        }
    }
    renderPrompt() {
        return html `
            <collab-messages-prompt-102025
                acceptAutoCompleteAgents="true"
                acceptAutoCompleteUser="true"
                threadId=${this.actualThread?.thread.threadId}
                .onSend=${this.handleSend.bind(this)}
                placeholder=${this.msg.promptPlaceholder}
                @textarea-resize=${this.handlePromptResize}
            ></collab-messages-prompt-102025>
        `;
    }
    renderListThreads() {
        if (!this.userThreads[this.group] || (this.userThreads[this.group].length === 0 && !this.isLoadingThread)) {
            return html `<div style="padding:1rem;">${this.msg.noThreads}</div>`;
        }
        const ordenedThreads = this.getOrdenedThreadsByStatus();
        this.filteredThreads = this.getFilteredThreads(ordenedThreads);
        return html `
            ${this.renderThreadsByStatus2()}
            ${this.isLoadingThread ? html `<div>${this.msg.loading}</div>` : ''}
        `;
    }
    getThreadAvatar(item) {
        let threadAvatar = defaultThreadImage;
        if (item.thread.name.startsWith('@') && item.thread.users.length === 2) {
            const user = item.users.find((user) => user.userId !== this.userId);
            if (user && user.avatar_url)
                threadAvatar = user.avatar_url;
        }
        else if (item.thread.avatar_url) {
            threadAvatar = item.thread.avatar_url;
        }
        return threadAvatar;
    }
    getThreadName(item) {
        if (!item)
            return '';
        if (this.isDirectMessage(item)) {
            const user = item.users.find((user) => user.userId !== this.userId);
            if (user)
                return '@' + user.name;
        }
        return item.thread.name || item.thread.threadId;
    }
    isDirectMessage(item) {
        return item.thread.name.startsWith('@') && item.thread.users.length === 2;
    }
    renderThreadsByStatus2() {
        const groups = this.groupThreadsByPrefix(this.filteredThreads.active);
        return html `
        <ul class="thread-list">
            ${Object.entries(groups).map(([prefix, items]) => {
            if (items.length === 1) {
                return this.renderThreadItemLi(items[0]);
            }
            else {
                const lastItem = items[0];
                const unreadCount = items.reduce((total, item) => total + (item.thread?.unreadCount || 0), 0);
                const now = new Date();
                const isToday = lastItem._lastMessageDate.dateObject.getFullYear() === now.getFullYear() &&
                    lastItem._lastMessageDate.dateObject.getMonth() === now.getMonth() &&
                    lastItem._lastMessageDate.dateObject.getDate() === now.getDate();
                const displayDate = isToday
                    ? lastItem._lastMessageDate.time
                    : this.formatMessageDate(lastItem._lastMessageDate.dateObject);
                return html `
                        <li class="thread-group">
                            <details>
                                <summary class="group-title">
                                    <div class="thread-group-avatar">
                                        ${collab_folder_tree}
                                    </div>
                                    <div class="thread-group-content">
                                        <div class="thread-group-item-header">
                                            <span class="thread-group-name">${prefix}</span>
                                            <span class="last-group-update">${displayDate}</span>
                                        </div>
                                        <div class="thread-group-summary">
                                            <span class="last-group-message">${items.length} Threads </span>
                                            ${unreadCount > 0 ? html `<span class="unread-count">${unreadCount}</span>` : nothing}
                                        </div>
                                    </div>                                
                                </summary>
                                <ul class="group-items">
                                    ${items.map(item => this.renderThreadItemLi(item, prefix))}
                                </ul>
                            </details>
                        </li>
                    `;
            }
        })}
        
            ${this.renderArchivedThreads()}
            ${this.renderDeletingThreads()}
            ${this.renderDeletedThreads()}

        </ul>
    `;
    }
    renderThreadItemLi(item, prefix) {
        let threadAvatar = this.getThreadAvatar(item);
        let threadName = this.getThreadName(item);
        if (prefix)
            threadName = threadName.replace(prefix + '/', '');
        const isDirectMessage = this.isDirectMessage(item);
        let lastMessage = item.thread.lastMessage || '';
        const firstColonIndex = lastMessage.indexOf(':');
        let userMessageId = lastMessage.slice(0, firstColonIndex);
        let userMessage = lastMessage.slice(firstColonIndex + 1);
        const unreadCount = item.thread.unreadCount || 0;
        const now = new Date();
        const isToday = item._lastMessageDate.dateObject.getFullYear() === now.getFullYear() &&
            item._lastMessageDate.dateObject.getMonth() === now.getMonth() &&
            item._lastMessageDate.dateObject.getDate() === now.getDate();
        const displayDate = isToday
            ? item._lastMessageDate.time
            : this.formatMessageDate(item._lastMessageDate.dateObject);
        if (item.users.length > 0) {
            const sortedUsers = [...item.users].sort((a, b) => b.name.length - a.name.length);
            if (userMessageId === this.userId)
                userMessageId = this.msg.lastMessagePrefix;
            else
                userMessageId = sortedUsers.find(u => u.userId === userMessageId)?.name || '';
            userMessage = userMessage.replace(/\[@([^\]]+)\]\(([^)]+)\)/g, (_m, name, userId) => {
                const user = sortedUsers.find(u => u.userId === userId);
                if (!user)
                    return `@${name}`;
                return `@${user.name}`;
            });
        }
        return html `
        <li .item=${item} threadId=${item.thread.threadId} 
            @click=${() => this.onThreadClick(item)} 
            class="thread-item">
            <div class="thread-item-avatar">
                ${threadAvatar.startsWith('<') && threadAvatar.endsWith('>') ?
            html `${unsafeHTML(threadAvatar)}` :
            html `<img src="${threadAvatar}"></img>`}
            </div>
            <div class="thread-content">
                <div class="thread-item-header">
                    <span class="thread-name">${threadName}</span>
                    <span class="last-update">${displayDate}</span>
                </div>
                <div class="thread-summary">
                    ${userMessage ? html `
                            <span class="last-message">${userMessageId && !isDirectMessage ? html `<span>${userMessageId}:</span>` : nothing}${userMessage || ''}</span>
                        ` : nothing}
                    
                    ${unreadCount > 0 ? html `<span class="unread-count">${unreadCount}</span>` : nothing}
                </div>
            </div>
        </li>
    `;
    }
    formatMessageDate(input) {
        const date = typeof input === 'string' ? new Date(input) : input;
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const target = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        const diffTime = today.getTime() - target.getTime();
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        if (diffDays === 0)
            return this.msg.today;
        if (diffDays === 1)
            return this.msg.yesterday;
        const lang = document.querySelector('html')?.lang || 'pt-BR';
        if (diffDays > 1 && diffDays < 7) {
            return target.toLocaleDateString(lang, {
                weekday: 'short',
            });
        }
        return target.toLocaleDateString(lang);
    }
    renderArchivedThreads() {
        if (this.filteredThreads.archived.length === 0)
            return html `${nothing}`;
        return html `        
            ${this.filteredThreads.archived.map((item) => {
            let threadAvatar = this.getThreadAvatar(item);
            const unreadCount = item.thread.unreadCount || 0;
            function isWithinLastWeek(date) {
                const now = new Date();
                const oneWeekAgo = new Date();
                oneWeekAgo.setDate(now.getDate() - 7);
                return date >= oneWeekAgo;
            }
            if (!item._lastMessageDateArchived)
                return html ``;
            return html `
                ${!isWithinLastWeek(item._lastMessageDateArchived.dateObject)
                ? html `${nothing}`
                : html `
                        <li @click=${() => this.onThreadClick(item)} class="thread-item">
                            <div class="thread-item-avatar">
                                    ${threadAvatar.startsWith('<') && threadAvatar.endsWith('>') ?
                    html `${unsafeHTML(threadAvatar)}` :
                    html `<img src="${threadAvatar}"></img>`}
                            </div>
                            <div class="thread-content">
                                <div class="thread-item-header">
                                    <span class="thread-name">(${this.msg.archived}) ${item.thread.name || item.thread.threadId}</span>
                                    ${unreadCount > 0 ? html `<span class="unread-count">*</span>` : nothing}
                                </div>
                            </div>
                        </li>`}`;
        })}
        `;
    }
    renderDeletingThreads() {
        if (this.filteredThreads.deleting.length === 0)
            return html ``;
        return html `        
            ${this.filteredThreads.deleting.map((item) => {
            let threadAvatar = this.getThreadAvatar(item);
            const unreadCount = item.thread.unreadCount || 0;
            function isWithinLastWeek(date) {
                const now = new Date();
                const oneWeekAgo = new Date();
                oneWeekAgo.setDate(now.getDate() - 7);
                return date >= oneWeekAgo;
            }
            if (!item.lastMessageDateDeleting)
                return html ``;
            return html `
                ${!isWithinLastWeek(item.lastMessageDateDeleting.dateObject)
                ? html ``
                : html `
                        <li @click=${() => this.onThreadClick(item)} class="thread-item">
                            <div class="thread-item-avatar">
                                    ${threadAvatar.startsWith('<') && threadAvatar.endsWith('>') ?
                    html `${unsafeHTML(threadAvatar)}` :
                    html `<img src="${threadAvatar}"></img>`}
                            </div>
                            <div class="thread-content">
                                <div class="thread-item-header">
                                    <span class="thread-name">(${this.msg.deleting}) ${item.thread.name || item.thread.threadId}</span>
                                    ${unreadCount > 0 ? html `<span class="unread-count">*</span>` : nothing}

                                </div>
                            </div>
                        </li>`}`;
        })}
        `;
    }
    renderDeletedThreads() {
        if (this.filteredThreads.deleted.length === 0)
            return html ``;
        return html `      
          
            ${this.filteredThreads.deleted.map((item) => {
            let threadAvatar = this.getThreadAvatar(item);
            if (!item.lastMessageDateDeleting)
                return html ``;
            const unreadCount = item.thread.unreadCount || 0;
            return html `
                <li @click=${() => this.onThreadClick(item)} class="thread-item">
                    <div class="thread-item-avatar">
                            ${threadAvatar.startsWith('<') && threadAvatar.endsWith('>') ?
                html `${unsafeHTML(threadAvatar)}` :
                html `<img src="${threadAvatar}"></img>`}
                    </div>
                    <div class="thread-content">
                        <div class="thread-item-header">
                            <span class="thread-name" style="text-decoration: line-through;">(${this.msg.deleted}) ${item.thread.name || item.thread.threadId}</span>
                            ${unreadCount > 0 ? html `<span class="unread-count">*</span>` : nothing}
                        </div>
                    </div>
                </li>`;
        })}
        `;
    }
    renderThreadSearch() {
        return html `
		<collab-messages-filter-102025
			@search-change=${this.onSearchInput}
            .expanded=${this.searchTerm !== ''}
            .query=${this.searchTerm}
			placeholder=${this.msg.placeholderSearch}>
		</collab-messages-filter-102025>
	`;
    }
    renderTaskDetails() {
        const messageId = `${this.actualThread?.thread.threadId}/${this.actualMessage?.createAt}`;
        return html `<collab-messages-task-info-102025 messageId=${messageId} .task=${this.actualTask} .message=${this.actualMessage} taskId=${this.actualTask?.PK}></collab-messages-task-info-102025>`;
    }
    renderThreadDetails() {
        return html `<collab-messages-thread-details-102025 userId=${this.userId} .threadDetails=${{ ...this.actualThread }}></collab-messages-thread-details-102025>`;
    }
    renderThreadAdd() {
        return html `
            <collab-messages-add-102025 
                .onAddSuccess = ${() => { this.activeScenerie = 'list'; }}
                .group=${this.group}
                userId=${this.userId} 
            ></collab-messages-add-102025>`;
    }
    onSearchInput(e) {
        this.searchTerm = e.detail.toLowerCase();
        const ordenedThreads = this.getOrdenedThreadsByStatus();
        this.filteredThreads = this.getFilteredThreads(ordenedThreads);
    }
    async updateMessagesAfterScrollMore(newMessages, container, previousHeight) {
        this.actualMessages = [...this.actualMessages, ...newMessages];
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        await this.updateComplete;
        const newHeight = container.scrollHeight;
        container.scrollTop = newHeight - previousHeight;
    }
    async getBeforeMessagesInServer(thread) {
        const firstItem = [...this.actualMessages].sort((a, b) => a.orderAt.localeCompare(b.orderAt))[0];
        const response = await this.getMessagesBefore(thread, firstItem.orderAt);
        const newMessages = response?.data;
        this.hasMoreMessagesBefore = response?.hasMore || false;
        return newMessages;
    }
    onCopyChat(ev) {
        ev.preventDefault();
        const selection = window.getSelection();
        if (!selection)
            return;
        let container = document.createElement("div");
        for (let i = 0; i < selection.rangeCount; i++) {
            container.appendChild(selection.getRangeAt(i).cloneContents());
        }
        const extractMessage = (el) => {
            const titleEl = el.querySelector(".message-title");
            const timeEl = el.querySelector(".message-footer");
            const contentEl = el.querySelector(".collab-md-message");
            const taskEl = el.querySelector('collab-messages-task-102025');
            let author = titleEl?.textContent?.trim();
            const content = contentEl?.innerText?.trim() || "";
            const time = timeEl?.textContent?.trim() || "";
            const task = taskEl?.getAttribute('taskid');
            return {
                author,
                content,
                time,
                task
            };
        };
        const items = container.querySelectorAll(".message-time, .message-card");
        if (items.length === 0) {
            const { author, content, task, time } = extractMessage(container);
            if (content) {
                const msg = `${time ? time : ''} ${author ? author : ''} ${content} ${task ? `(Task:${task})` : ''}`;
                return ev.clipboardData?.setData("text/plain", msg);
            }
            ev.clipboardData?.setData("text/plain", selection.toString());
            return;
        }
        let result = [];
        let lastAuthor = "";
        let currentDate = "";
        items.forEach(el => {
            if (el.classList.contains("message-time")) {
                currentDate = el.textContent?.trim() || '';
                result.push(`--- ${currentDate} ---`);
            }
            else {
                let { author, content, task, time } = extractMessage(el);
                if (!author)
                    author = lastAuthor;
                else
                    lastAuthor = author;
                if (content) {
                    result.push(`${time ? time : ''} ${author ? author : ''} ${content} ${task ? `(Task:${task})` : ''}`);
                }
            }
        });
        if (result.length > 0) {
            ev.clipboardData?.setData("text/plain", result.join("\n"));
        }
    }
    async onChatScroll(e) {
        this.removeAllUserModal();
        if (this.isChangeTopics) {
            this.isChangeTopics = false;
            return;
        }
        if (this.isSystemChangeScroll) {
            this.isSystemChangeScroll = false;
            return;
        }
        const container = e.target;
        this.savedScrollTop = container.scrollTop;
        const threshold = 5;
        this.wasMessagesAtBottom = container.scrollTop + container.clientHeight >= container.scrollHeight - threshold;
        const previousHeight = container.scrollHeight;
        if (container.scrollTop === 0 &&
            !this.isLoadingMoreMessages &&
            this.actualThread &&
            !this.hasMoreMessagesLocalDB &&
            this.hasMoreMessagesBefore) {
            this.isLoadingMoreMessages = true;
            const newMessages = await this.getBeforeMessagesInServer(this.actualThread.thread);
            if (newMessages)
                this.updateMessagesAfterScrollMore(newMessages.map(item => ({ ...item, footers: [], })), container, previousHeight);
            this.isLoadingMoreMessages = false;
            return;
        }
        if (container.scrollTop === 0 &&
            !this.isLoadingMoreMessages &&
            this.actualThread &&
            this.hasMoreMessagesLocalDB) {
            this.isLoadingMoreMessages = true;
            const newOffset = this.messagesOffset + this.messagesLimit;
            const newMessages = await getMessagesByThreadId(this.actualThread.thread.threadId, this.messagesLimit, newOffset);
            if (newMessages.length > 0) {
                this.messagesOffset = newOffset;
                this.updateMessagesAfterScrollMore(newMessages, container, previousHeight);
            }
            else {
                const newMessages = await this.getBeforeMessagesInServer(this.actualThread.thread);
                if (newMessages)
                    this.updateMessagesAfterScrollMore(newMessages.map(item => ({ ...item, footers: [], })), container, previousHeight);
                this.hasMoreMessagesLocalDB = false;
            }
            this.isLoadingMoreMessages = false;
        }
    }
    groupThreadsByPrefix(threads) {
        const groups = {};
        for (const t of threads) {
            const name = this.getThreadName(t);
            if (name.startsWith('_') && name.includes('/')) {
                const [prefix] = name.split('/');
                if (!groups[prefix])
                    groups[prefix] = [];
                groups[prefix].push(t);
            }
            else {
                groups[name] = [t];
            }
        }
        return groups;
    }
    getOrdenedThreadsByStatus() {
        const threads = this.userThreads[this.group]
            .map((item) => {
            const lastTimestamp = item.thread.lastMessageTime
                ? item.thread.lastMessageTime
                : item.thread.history[0].timestamp;
            const formatedTimestamp = formatTimestamp(lastTimestamp)?.dateFull;
            const lastMessageDate = this.parseLocalDate(formatedTimestamp || '');
            let lastMessageDateArchived;
            let lastMessageDateDeleting;
            if (item.thread.status === 'archived' && item.thread.archivedAt) {
                const formatedTimestampArchived = formatTimestamp(item.thread.archivedAt)?.dateFull;
                lastMessageDateArchived = this.parseLocalDate(formatedTimestampArchived || '');
            }
            if ((item.thread.status === 'deleting' || item.thread.status === 'deleted') && item.thread.deletedAt) {
                const formatedTimestampArchived = formatTimestamp(item.thread.deletedAt)?.dateFull;
                lastMessageDateDeleting = this.parseLocalDate(formatedTimestampArchived || '');
            }
            return {
                ...item,
                _lastMessageDate: lastMessageDate,
                _lastMessageDateArchived: lastMessageDateArchived,
                lastMessageDateDeleting: lastMessageDateDeleting,
            };
        })
            .sort((a, b) => b._lastMessageDate.dateObject.getTime() -
            a._lastMessageDate.dateObject.getTime());
        const result = {
            archived: [],
            deleted: [],
            deleting: [],
            active: [],
        };
        for (const threadInfo of threads) {
            if (threadInfo.thread.status === 'archived') {
                result.archived.push(threadInfo);
            }
            else if (threadInfo.thread.status === 'deleted') {
                result.deleted.push(threadInfo);
            }
            else if (threadInfo.thread.status === 'deleting') {
                result.deleting.push(threadInfo);
            }
            else {
                result.active.push(threadInfo);
            }
        }
        return result;
    }
    getFilteredThreads(ordened) {
        if (!this.searchTerm)
            return ordened;
        const term = this.searchTerm.toLowerCase();
        Object.keys(ordened).forEach((key) => {
            const key2 = key;
            ordened[key2] = ordened[key2].filter(item => {
                const threadName = item.thread.name?.toLowerCase() ?? '';
                if (threadName.startsWith('@')) {
                    const users = item.thread.users
                        .map(u => this.usersAvaliables.find(au => au.userId === u.userId));
                    return users.some(user => (`@${user?.name.toLowerCase()}`).includes(term));
                }
                return threadName.includes(term);
            });
        });
        return ordened;
    }
    async getMessagesAfter(thread, lastOrderAt = '') {
        if (!this.userId) {
            return undefined;
        }
        const response = await mls.api.msgGetMessagesAfter({
            lastOrderAt,
            threadId: thread.threadId,
            userId: this.userId
        });
        return response;
    }
    async getMessagesBefore(thread, orderAt = '') {
        if (!this.userId) {
            return undefined;
        }
        const response = await mls.api.msgGetMessagesBefore({
            orderAt,
            threadId: thread.threadId,
            userId: this.userId
        });
        return response;
    }
    parseMessages(rawData, topic) {
        const groupedByDay = {};
        [...rawData].forEach(msg => {
            if (topic &&
                msg.content &&
                !(msg.content.startsWith(`${topic} `) ||
                    msg.content.endsWith(` ${topic}`) ||
                    msg.content.includes(` ${topic} `))) {
                return;
            }
            const formatted = formatTimestamp(msg.createAt);
            const dateKey = formatted?.date ||
                msg.createAt
                    .slice(0, 8)
                    .replace(/(\d{4})(\d{2})(\d{2})/, '$1-$2-$3');
            if (!groupedByDay[dateKey]) {
                groupedByDay[dateKey] = [];
            }
            groupedByDay[dateKey].push(msg);
        });
        for (const day in groupedByDay) {
            groupedByDay[day].sort((a, b) => a.orderAt.localeCompare(b.orderAt));
        }
        return this.groupMessages(groupedByDay);
    }
    groupMessages(groupedByDay) {
        const result = {};
        Object.keys(groupedByDay).forEach((key) => {
            let consecutiveCount = 0;
            let lastSenderId = null;
            result[key] = groupedByDay[key].map((msg, index, arr) => {
                let isSame = false;
                if (msg.senderId === lastSenderId) {
                    consecutiveCount++;
                    isSame = true;
                    if (consecutiveCount >= 3) {
                        consecutiveCount = 0;
                        isSame = false;
                    }
                }
                else {
                    consecutiveCount = 0;
                    isSame = false;
                    lastSenderId = msg.senderId;
                }
                return { ...msg, isSame };
            });
        });
        return result;
    }
    parseLocalDate(dateString) {
        const normalized = dateString.includes(' ')
            ? dateString.replace(' ', 'T')
            : `${dateString}T00:00:00`;
        const date = new Date(normalized);
        return {
            dateObject: date,
            datafull: date.toLocaleString(),
            date: date.toLocaleDateString(),
            time: date.toTimeString().split(' ')[0]
        };
    }
    mergeMessages(array1, array2) {
        const map = new Map();
        for (const item of array1) {
            map.set(`${item.threadId}/${item.createAt}`, item);
        }
        for (const item of array2) {
            map.set(`${item.threadId}/${item.createAt}`, { ...map.get(`${item.threadId}/${item.createAt}`), ...item });
        }
        return Array.from(map.values());
    }
    async onThreadClick(threadInfo) {
        this.welcomeMessage = '';
        this.activeScenerie = 'loading';
        this.lastTopicFilter = '';
        this.messagesOffset = 0;
        this.hasMoreMessagesLocalDB = true;
        this.hasMoreMessagesBefore = false;
        this.actualThread = threadInfo;
        const temp = await getThread(this.actualThread.thread.threadId);
        this.unreadCountInSelectedThread = temp?.unreadCount || 0;
        const messagesInDb = await getMessagesByThreadId(this.actualThread.thread.threadId, this.messagesLimit, 0);
        this.actualMessages = messagesInDb;
        this.isSystemChangeScroll = true;
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.activeScenerie = 'details';
        this.isLoadingMessages = true;
        this.isThreadError = false;
        this.threadErrorMsg = '';
        this.checkWelcomeMessage(this.actualThread.thread, messagesInDb);
        this.lastMessageReaded = threadInfo.thread.lastMessageReadTime;
        try {
            if (!this.userId)
                return;
            const threadByServer = await this.getThreadInfo(this.actualThread.thread.threadId, this.userId, threadInfo.thread.lastSync || new Date('2000-01-01').toISOString());
            await updateThread(threadByServer.thread.threadId, threadByServer.thread);
            threadInfo = await this.updateMessagesOnDb(threadByServer, threadByServer.messages);
            await updateUsers(threadByServer.users);
            this.actualThread = { ...threadByServer };
            if (threadByServer.hasMore)
                await this.loadAllMessages(threadInfo);
            this.checkForRegisterNotification();
            if (threadByServer.threadsPending) {
                for await (let threadsPending of threadByServer.threadsPending) {
                    if (threadsPending !== threadInfo.thread.threadId) {
                        removeThreadFromSync(threadsPending);
                        await getThreadUpdateInBackground(threadsPending);
                    }
                }
            }
            if (['deleted'].includes(threadByServer.thread.status)) {
                await deleteAllMessagesFromThread(threadByServer.thread.threadId);
                const threadUpdated = await this.clearUnreadMessageFromThread(threadByServer.thread);
                notifyThreadChange(threadUpdated);
            }
            this.checkNotificationsUnreadMessages();
            if (this.taskToOpen) {
                await this.updateComplete;
                this.openTask();
            }
        }
        catch (err) {
            this.isThreadError = true;
            this.threadErrorMsg = err.message || 'Error on read thread';
            throw new Error('Error on loading messages: ' + err.message);
        }
        finally {
            this.isLoadingMessages = false;
        }
    }
    openTask() {
        let taskEl = null;
        if (this.taskToOpen === 'last') {
            const tasks = this.querySelectorAll('collab-messages-task-102025');
            taskEl = tasks[tasks.length - 1] || null;
        }
        else {
            taskEl = this.querySelector(`collab-messages-task-102025[taskid="${this.taskToOpen}"]`);
        }
        if (taskEl) {
            taskEl.dispatchEvent(new CustomEvent('taskclick', {
                bubbles: true,
                composed: true
            }));
        }
        this.taskToOpen = '';
    }
    checkWelcomeMessage(thread, messagesInDb) {
        if (messagesInDb.length > 0)
            return;
        if (!thread.welcomeMessage)
            return;
        this.welcomeMessage = thread.welcomeMessage;
    }
    async checkNotificationsUnreadMessages() {
        const hasPendingMessages = await checkIfNotificationUnread();
        if (!hasPendingMessages) {
            changeFavIcon(false);
            mls.services['102025_serviceCollabMessages_left']?.toogleBadge(false, '_102025_serviceCollabMessages');
        }
    }
    async checkForRegisterNotification() {
        if (this.alreadyCheckForRegisterToken)
            return;
        this.alreadyCheckForRegisterToken = true;
        const notificationPreference = loadNotificationPreferences();
        if (notificationPreference === 'denied')
            return;
        await registerToken();
    }
    async loadAllMessages(threadInfo) {
        const response = await this.getMessagesAfter(threadInfo.thread, threadInfo.thread.lastSync || '');
        if (!response || !response.data || response.data.length === 0 || !this.actualThread || !this.userId) {
            return;
        }
        threadInfo = await this.updateMessagesOnDb(threadInfo, response.data);
        if (!response.hasMore)
            return;
        return this.loadAllMessages(threadInfo);
    }
    async updateMessagesOnDb(threadInfo, messages) {
        if (!messages)
            return threadInfo;
        const newMessages = [];
        for await (let mm of messages) {
            const messageId = `${mm.threadId}/${mm.createAt}`;
            const messageOld = await getMessage(messageId);
            const tempMessage = { ...mm, footers: messageOld?.footers || [] };
            newMessages.push(tempMessage);
        }
        const lastMessages = newMessages[newMessages.length - 1] || this.actualMessages[0];
        await addMessages(newMessages);
        if (lastMessages && this.actualThread)
            this.actualThread.thread = await updateLastMessageReadTime(threadInfo.thread.threadId, lastMessages.createAt);
        this.actualMessages = this.mergeMessages(this.actualMessages, newMessages);
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        await this.updateLastMessage(threadInfo);
        return threadInfo;
    }
    async clearUnreadMessageFromThread(thread) {
        const _thread = await updateThread(thread.threadId, thread, '', '', 0);
        if (this.actualThread)
            this.actualThread.thread = _thread;
        return _thread;
    }
    async updateLastMessage(threadInfo) {
        const keys = Object.keys(this.actualMessagesParsed).sort();
        const lastKey = keys.length > 0 ? keys[keys.length - 1] : null;
        const lastArray = lastKey ? this.actualMessagesParsed[lastKey] : [];
        const lastMessage = lastArray.length > 0 ? lastArray[lastArray.length - 1] : undefined;
        if (lastMessage) {
            const lastMessageText = `${lastMessage.senderId}:${lastMessage.content}`;
            const thread = await updateThread(threadInfo.thread.threadId, threadInfo.thread, lastMessageText, lastMessage.createAt, 0, lastMessage.createAt);
            threadInfo.thread = thread;
            notifyThreadChange(thread);
        }
    }
    async onTitleClick() {
        await this.updateComplete;
        if (this.activeScenerie === 'task') {
            this.activeScenerie = 'details';
            return;
        }
        if (this.activeScenerie === 'details' || this.activeScenerie === 'threadAdd') {
            this.actualThread = undefined;
            this.activeScenerie = 'list';
            return;
        }
        if (this.activeScenerie === 'threadDetails') {
            this.activeScenerie = 'details';
            return;
        }
    }
    onThreadDetailsClick() {
        this.saveScrollPosition();
        this.activeScenerie = 'threadDetails';
    }
    onThreadAddClick() {
        this.activeScenerie = 'threadAdd';
    }
    async handleSend(value, opt) {
        this.isSystemChangeScroll = true;
        this.lastTopicFilter = '';
        try {
            if (!opt.isSpecialMention) {
                await this.addMessage(value);
            }
            else {
                await this.addMessageIA(value, opt.agentName);
            }
        }
        catch (err) {
            throw new Error(err.message);
        }
    }
    handlePromptResize(e) {
        if (this.wasMessagesAtBottom) {
            const chatEl = this.querySelector('.chat-container');
            if (chatEl)
                chatEl.scrollTop = chatEl.scrollHeight;
        }
    }
    async addMessage(prompt) {
        if (!this.userId || !this.actualThread)
            return;
        this.unreadCountInSelectedThread = 0;
        const message = await this.createTempMessage(prompt, this.userId, this.actualThread.thread.threadId);
        try {
            const context = {
                message,
                task: undefined,
                isTest: false
            };
            const contextToBot = await getBotsContext(this.actualThread.thread, prompt, context);
            const params = {
                action: 'addMessage',
                content: prompt,
                threadId: this.actualThread.thread.threadId,
                userId: this.userId,
            };
            if (contextToBot)
                params.contextToBot = contextToBot;
            const response = await mls.api.msgAddMessage(params);
            message.isFailed = false;
            message.isFailedError = '';
            this.updateMessage2(false, true, message, response.message, response.botOutputs);
        }
        catch (err) {
            message.isFailed = true;
            message.isFailedError = err.message;
            message.isLoading = false;
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            console.error('Error on send message:' + err.message);
        }
    }
    async addMessageIA(prompt, agentName) {
        if (!this.userId || !this.actualThread)
            return;
        this.unreadCountInSelectedThread = 0;
        const context = getTemporaryContext(this.actualThread.thread.threadId, this.userId, prompt);
        let agentToCall = AGENTDEFAULT;
        if (agentName)
            agentToCall = agentName;
        const message = await this.createTempMessage(prompt, this.userId, this.actualThread.thread.threadId);
        try {
            const agent = await this.loadAgent(agentToCall);
            context.message = message;
            await executeBeforePrompt(agent, context);
        }
        catch (err) {
            console.error('Error on send message:' + err.message);
            if (message.isLoading) {
                message.isLoading = false;
                message.isFailed = true;
                message.isFailedError = err.message;
                this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            }
        }
    }
    async updateMessageAI(context, updateThreadDB, oldContextCreateAt) {
        if (this.activeScenerie !== 'details')
            return;
        if (!context.message)
            return;
        const { content, createAt, orderAt, senderId, threadId, taskId, status, taskTitle, taskTitleTranslated, taskStatus, taskResults, taskResultsTranslated } = context.message;
        const createAt2 = oldContextCreateAt ? oldContextCreateAt : createAt;
        let messageAdded = this.actualMessages.find((item) => item.content === content &&
            item.senderId === senderId &&
            item.createAt === createAt2 &&
            item.threadId === threadId);
        if (!messageAdded) {
            const newMessage = {
                content,
                createAt,
                orderAt,
                senderId,
                threadId,
                footers: []
            };
            if (updateThreadDB && this.actualThread) {
                const lastMessageText = `${senderId}:${content}`;
                const thread = await updateThread(threadId, this.actualThread.thread, lastMessageText, createAt, 0, createAt);
                if (this.actualThread)
                    this.actualThread.thread = thread;
            }
            if (taskId)
                newMessage.taskId = taskId;
            this.actualMessages.unshift({ context, lastChanged: new Date().getTime(), ...newMessage });
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            await addMessage(newMessage);
            this.requestUpdate();
        }
        else {
            messageAdded.content = content;
            messageAdded.senderId = senderId;
            messageAdded.createAt = createAt;
            messageAdded.threadId = threadId;
            messageAdded.orderAt = orderAt;
            if (status)
                messageAdded.status = status;
            if (taskTitle)
                messageAdded.taskTitle = taskTitle;
            if (taskTitleTranslated)
                messageAdded.taskTitleTranslated = taskTitleTranslated;
            if (taskStatus)
                messageAdded.taskStatus = taskStatus;
            if (taskResults)
                messageAdded.taskResults = taskResults;
            if (taskResultsTranslated)
                messageAdded.taskResultsTranslated = taskResultsTranslated;
            messageAdded.context = context;
            messageAdded.isLoading = false;
            messageAdded.lastChanged = new Date().getTime();
            if (taskId)
                messageAdded.taskId = taskId;
            const cloned = structuredClone(messageAdded);
            delete cloned.context;
            delete cloned.isLoading;
            delete cloned.lastChanged;
            if (oldContextCreateAt)
                this.isSystemChangeScroll = true;
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            await addMessage(cloned);
            if (this.actualThread)
                await this.updateLastMessage(this.actualThread);
            this.requestUpdate();
        }
    }
    async createTempMessage(content, senderId, threadId, taskId) {
        const now = new Date();
        const formattedDate = now.getFullYear().toString()
            + String(now.getMonth() + 1).padStart(2, '0')
            + String(now.getDate()).padStart(2, '0')
            + String(now.getHours() + 3).padStart(2, '0')
            + String(now.getMinutes()).padStart(2, '0')
            + String(now.getSeconds()).padStart(2, '0')
            + "." + Math.floor(1000 + Math.random() * 9000);
        const newMessage = {
            content,
            createAt: formattedDate,
            orderAt: formattedDate,
            senderId,
            threadId,
            isLoading: true,
            isFailed: false,
            isFailedError: '',
            footers: []
        };
        if (taskId)
            newMessage.taskId = taskId;
        this.actualMessages.unshift(newMessage);
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.requestUpdate();
        return newMessage;
    }
    async updateMessage2(updateLastSyncThreadDB, updateLastMessageThreadDB, oldMessage, newMessage, outputs) {
        if (this.actualThread && (updateLastSyncThreadDB || updateLastMessageThreadDB)) {
            const lastMessageText = `${newMessage.senderId}:${newMessage.content}`;
            let thread = await updateThread(newMessage.threadId, this.actualThread.thread, updateLastMessageThreadDB ? lastMessageText : undefined, updateLastMessageThreadDB ? newMessage.createAt : undefined, 0, updateLastSyncThreadDB ? newMessage.createAt : undefined);
            newMessage.createAt;
            thread = await updateLastMessageReadTime(newMessage.threadId, newMessage.createAt);
            if (this.actualThread)
                this.actualThread.thread = thread;
            notifyThreadChange(this.actualThread.thread);
        }
        const footerData = [];
        for await (let item of outputs || []) {
            const footerItem = {
                title: item.botId,
                lines: [item.output]
            };
            const module = await this.loadAgent(item.botId);
            if (module && module.afterBot && typeof module.afterBot === 'function') {
                const context = {
                    message: newMessage,
                    task: undefined,
                    isTest: false
                };
                try {
                    const response = await module.afterBot(context, item);
                    footerItem.lines = [response];
                }
                catch (err) {
                    footerItem.lines = [err.message];
                }
            }
            footerData.push(footerItem);
        }
        const alreadyExist = this.actualMessages.find(item => item.content === oldMessage.content &&
            item.senderId === oldMessage.senderId &&
            item.createAt === oldMessage.createAt &&
            item.threadId === oldMessage.threadId);
        if (alreadyExist) {
            this.actualMessages = this.actualMessages.map(item => {
                if (item.content === oldMessage.content &&
                    item.senderId === oldMessage.senderId &&
                    item.createAt === oldMessage.createAt &&
                    item.threadId === oldMessage.threadId) {
                    const { isLoading, isFailed, isFailedError, ...rest } = { ...newMessage, isSame: oldMessage.isSame, footers: footerData };
                    return rest;
                }
                return item;
            });
        }
        else
            this.actualMessages.unshift({ ...newMessage, footers: footerData });
        const m = newMessage;
        delete m.isLoading;
        delete m.isFailed;
        delete m.isFailedError;
        delete m.isSame;
        if (outputs)
            m.footers = footerData;
        await addMessage(m);
        const messagesInDb = await getMessagesByThreadId(m.threadId, this.messagesLimit, 0);
        this.actualMessages = messagesInDb;
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.requestUpdate();
    }
    async loadAgent(shortName) {
        try {
            const agent = await loadAgent(shortName);
            if (!agent)
                throw new Error(`(loadAgent) createAgent function not found in ${shortName}`);
            return agent;
        }
        catch (error) {
            throw new Error(`[loadAgent] ${error.message || error} `);
        }
    }
    async onTaskClick(taskId, messageId, threadId, message) {
        this.saveScrollPosition();
        const task = await this.getTaskUpdate(taskId, messageId, threadId);
        addOrUpdateTask(task);
        this.actualTask = task;
        this.actualMessage = message;
        const messageId2 = `${this.actualThread?.thread.threadId}/${this.actualMessage?.createAt}`;
        const el = document.createElement('collab-messages-task-info-102025');
        el.setAttribute('messageId', messageId2);
        if (this.actualTask && this.actualTask.PK)
            el.setAttribute('taskId', this.actualTask.PK);
        el['task'] = this.actualTask;
        el['message'] = this.actualMessage;
        openElementInServiceDetails(el);
    }
    async getTaskUpdate(taskId, createdAt, threadId) {
        if (!taskId || !createdAt || !threadId)
            throw new Error('Invalid args');
        if (!this.userId)
            throw new Error('Invalid userId');
        const taskData = await mls.api.msgGetTaskUpdate({
            taskId,
            messageId: `${threadId}/${createdAt}`,
            userId: this.userId
        });
        if (taskData.statusCode !== 200)
            throw new Error("error on AI get taskUpdate , stoped");
        return taskData.task;
    }
    async getThreadInfo(threadId, userId, lastOrderAt) {
        const deviceId = loadNotificationDeviceId();
        try {
            const response = await mls.api.msgGetThreadUpdate({
                threadId,
                userId,
                lastOrderAt,
                deviceId: deviceId || undefined
            });
            removeThreadFromSync(threadId);
            if (response.statusCode === 403) {
                throw new Error(response.msg);
            }
            return response;
        }
        catch (err) {
            throw new Error(err.message);
        }
    }
    saveScrollPosition() {
        if (this.messageContainer) {
            this.savedScrollTop = this.messageContainer.scrollTop;
        }
    }
    async restoreScrollPosition() {
        if (this.messageContainer) {
            await this.updateComplete;
            this.messageContainer.scrollTop = this.savedScrollTop;
        }
    }
    onVisibilityChange() {
        if (this.activeScenerie === 'details') {
            this.checkNotificationsUnreadMessages();
        }
    }
};
__decorate([
    query('collab-messages-prompt-102025')
], CollabMessagesChat.prototype, "collabMessagesPrompt", void 0);
__decorate([
    query('.new-messages-label')
], CollabMessagesChat.prototype, "unreadEl", void 0);
__decorate([
    query('.chat-container')
], CollabMessagesChat.prototype, "messageContainer", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "userPreferenceChat", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "isLoadingThread", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "filteredThreads", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "isThreadError", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "threadErrorMsg", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "lastTopicFilter", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "welcomeMessage", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "usersAvaliables", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "group", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "userId", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "threadToOpen", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "taskToOpen", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "userDeviceId", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "activeScenerie", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "actualThread", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "actualTask", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "actualMessage", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "actualMessages", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "actualMessagesParsed", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "isLoadingMessages", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "searchTerm", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesChat.prototype, "userThreads", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesChat.prototype, "allThreads", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "lastMessageReaded", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "unreadCountInSelectedThread", void 0);
CollabMessagesChat = __decorate([
    customElement('collab-messages-chat-102025')
], CollabMessagesChat);
export { CollabMessagesChat };
