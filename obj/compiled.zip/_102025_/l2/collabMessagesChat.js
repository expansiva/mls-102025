/// <mls fileReference="_102025_/l2/collabMessagesChat.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { repeat } from 'lit/directives/repeat.js';
import { customElement, property, state, query } from 'lit/decorators.js';
import { collab_chevron_left, collab_gear, collab_plus, collab_folder_tree, collab_bell } from '/_102025_/l2/collabMessagesIcons.js';
import { removeThreadFromSync, clearThreadNotification, clearTaskNotification, hasThreadNotificationPending, getPendingTaskNotificationsForThread, getThreadUpdateInBackground, checkIfNotificationUnread } from '/_102025_/l2/collabMessagesSyncNotifications.js';
import { notifyThreadChange, notifyThreadNotification } from '/_102025_/l2/collabMessagesEvents.js';
import { addOrUpdateTask, addMessages, addMessage, updateThread, updateUsers, getMessage, getMessagesByThreadId, deleteAllMessagesFromThread, listUsers, getThread, updateLastMessageReadTime } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { getBotsContext, registerToken, loadNotificationPreferences, loadNotificationDeviceId, generateAgentAvatar, getTemporaryContext, formatTimestamp, changeFavIcon } from '/_102025_/l2/collabMessagesHelper.js';
import { msgGetMessagesAfter, msgGetMessagesBefore, msgGetTaskUpdate, msgGetThreadUpdates, msgAddMessage } from '/_102025_/l2/shared/api.js';
import { environment } from '/_102036_/l2/environmentContract.js';
import '/_102025_/l2/collabMessagesTask.js';
import '/_102025_/l2/collabMessagesTaskInfo.js';
import '/_102025_/l2/collabMessagesTopics.js';
import '/_102025_/l2/collabMessagesPrompt.js';
import '/_102025_/l2/collabMessagesAvatar.js';
import '/_102025_/l2/collabMessagesThreadDetails.js';
import '/_102025_/l2/collabMessagesUserModal.js';
import '/_102025_/l2/collabMessagesThreadModal.js';
import '/_102025_/l2/collabMessagesFilter.js';
import '/_102025_/l2/collabMessagesAdd.js';
import '/_102025_/l2/collabMessagesChatMessage.js';
import '/_102025_/l2/collabMessagesRichPreviewText.js';
import { AGENTDEFAULT } from '/_102025_/l2/collabMessagesHelper.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    btnAddParticipant: 'Adicionar participante',
    threadDetails: 'Detalhes da sala',
    threadAdd: 'Adicionar sala',
    msgNotSend: 'Mensagem não enviada*',
    noThreads: 'Nenhuma sala disponível no momento.',
    placeholderSearch: 'Digite para filtrar',
    threadArchived: 'A thread foi arquivada por [user] em [date]',
    threadDeleting: 'A thread foi deletada em [date]',
    archived: 'Arquivado',
    deleting: 'Deletando',
    deleted: 'Deletada',
    btnNext: 'Continuar',
    promptPlaceholder: '(@ para menções) (@@ para agentes)',
    today: 'Hoje',
    yesterday: 'Ontem',
    newMessages: 'Novas mensagens',
    lastMessagePrefix: 'Você'
};
const message_en = {
    loading: 'Loading...',
    btnAddParticipant: 'Add Participant',
    threadDetails: 'Thread details',
    threadAdd: 'Add thread',
    msgNotSend: 'Message not sent*',
    noThreads: 'No threads available at the moment.',
    placeholderSearch: 'Type to filter',
    threadArchived: 'Thread is archived by [user] in [date]',
    threadDeleting: 'Thread was deleted in [date]',
    archived: 'Archived',
    deleting: 'Deleting',
    deleted: 'Deleted',
    btnNext: 'Next',
    promptPlaceholder: '(@ for mentions) (@@ for agents)',
    today: 'Today',
    yesterday: 'Yesterday',
    newMessages: 'New messages',
    lastMessagePrefix: 'You'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesChat = class CollabMessagesChat extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-chat-102025 {
  position: relative;
  display: flex;
  flex-direction: column;
  height: calc(100% - 41px);
  width: 375px;
  background: var(--bg-primary-color-darker);
}
collab-messages-chat-102025.custom {
  height: 100%;
}
collab-messages-chat-102025 .loader {
  display: inline-block;
  width: 10px;
  height: 10px;
  border: 2px solid #ccc;
  border-top: 2px solid #333;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
collab-messages-chat-102025 .header {
  padding: 0.1rem;
  height: 50px;
  min-height: 50px;
  color: var(--text-primary-color);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  font-size: var(--font-size-12);
  text-transform: uppercase;
  border-bottom: 1px solid var(--grey-color-dark);
}
collab-messages-chat-102025 .header svg {
  fill: currentColor;
}
collab-messages-chat-102025 .header collab-messages-filter-102025 {
  width: calc(100% - 50px);
}
collab-messages-chat-102025 .header .header-title {
  max-width: 300px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
collab-messages-chat-102025 .header .header-actions {
  margin-left: auto;
  margin-right: 1rem;
  display: flex;
  gap: 0.5rem;
}
collab-messages-chat-102025 .header .header-actions span {
  cursor: pointer;
}
collab-messages-chat-102025 .header > span {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex: 1;
  justify-content: center;
}
collab-messages-chat-102025 .welcome-message {
  padding: 1rem;
}
collab-messages-chat-102025 .welcome-message button {
  background-color: var(--info-color);
  border-radius: 8px;
  border: none;
  box-shadow: 0px 1px 3px 0px var(--grey-color);
  display: flex;
  flex-direction: row;
  justify-content: center;
  gap: 0.2rem;
  font-weight: 700;
  align-items: center;
  height: 40px;
  transition: height 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
  padding: 0.5rem;
  color: #ffffff;
  cursor: pointer;
  width: 100%;
}
collab-messages-chat-102025 .welcome-message button:hover {
  background-color: var(--info-color-hover);
}
collab-messages-chat-102025 .thread-search {
  width: 100%;
  padding: 0 0.3rem;
}
collab-messages-chat-102025 .thread-search input[type="search"] {
  width: 100%;
  padding: 0.4rem 1rem;
  font-size: 1rem;
  border: 1px solid #ccc;
  border-radius: 15px;
  outline: none;
  transition: border-color 0.2s, box-shadow 0.2s;
  box-shadow: 0 0 0 2px transparent;
}
collab-messages-chat-102025 .thread-list {
  list-style: none;
  margin: 0;
  padding: 0;
  overflow-y: auto;
  overflow-x: hidden;
  width: 375px;
}
collab-messages-chat-102025 .thread-list .archived-title {
  background: var(--grey-color-lighter);
  text-align: center;
  text-transform: uppercase;
  font-size: var(--font-size-16);
}
collab-messages-chat-102025 .thread-list .unread-count {
  background-color: var(--success-color);
  color: #fff;
  font-size: 0.75rem;
  font-weight: bold;
  padding: 0.25rem 0.5rem;
  border-radius: 12px;
  margin-left: 1rem;
  white-space: nowrap;
}
collab-messages-chat-102025 .thread-list .thread-group details:not([open]) {
  background: var(--grey-color-light);
}
collab-messages-chat-102025 .thread-list .thread-group.has-notification summary,
collab-messages-chat-102025 .thread-list .thread-item.has-notification {
  background-color: var(--bg-primary-color-focus);
}
collab-messages-chat-102025 .thread-list .thread-group.has-notification .thread-group-name,
collab-messages-chat-102025 .thread-list .thread-item.has-notification .thread-name {
  font-weight: 700;
}
collab-messages-chat-102025 .thread-list .thread-group.has-notification .last-group-message,
collab-messages-chat-102025 .thread-list .thread-item.has-notification .last-message {
  color: var(--text-primary-color);
}
collab-messages-chat-102025 .thread-list .tasks-pendings-count {
  position: relative;
  display: inline-block;
  font-size: 20px;
  fill: var(--warning-color);
  color: var(--warning-color);
  margin-right: 0.5rem;
}
collab-messages-chat-102025 .thread-list .tasks-pendings-count .notification-badge {
  position: absolute;
  top: -1px;
  right: -3px;
  background: red;
  color: white;
  border-radius: 50%;
  padding: 0.1em 0.1em;
  font-size: 0.49em;
  font-weight: bold;
  line-height: 1;
  min-width: 1em;
  text-align: center;
}
collab-messages-chat-102025 .thread-list .thread-group summary {
  cursor: pointer;
  list-style: none;
  height: 70px;
  transition: background-color 0.5s;
  display: flex;
  align-items: center;
  padding: 0.1rem 0.3rem;
  position: relative;
  width: 100%;
  border-bottom: 1px solid var(--grey-color);
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-item-header {
  display: flex;
  justify-content: space-between;
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-item-header .thread-group-name {
  font-size: 1rem;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--text-primary-color);
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-item-header .last-group-update {
  font-size: 0.875rem;
  color: var(--grey-color-dark);
  white-space: nowrap;
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-content {
  flex: 1;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  padding: 0.9rem;
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-avatar {
  width: 50px;
  height: 50px;
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-avatar svg {
  fill: currentColor;
  width: 40px;
  height: 50px;
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-avatar img {
  border-radius: 15px;
  width: 100%;
  height: 100%;
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-summary {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-summary .last-group-message {
  font-size: 0.875rem;
  color: var(--grey-color-darker);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  flex: 1;
}
collab-messages-chat-102025 .thread-list .thread-group summary::-webkit-details-marker {
  display: none;
}
collab-messages-chat-102025 .thread-item:hover {
  background-color: var(--bg-primary-color-focus);
}
collab-messages-chat-102025 .thread-item {
  cursor: pointer;
  height: 70px;
  transition: background-color 0.5s;
  display: flex;
  align-items: center;
  padding: 0.1rem 0.3rem;
  position: relative;
  width: 100%;
  border-bottom: 1px solid var(--grey-color);
}
collab-messages-chat-102025 .thread-item .back-button {
  cursor: pointer;
}
collab-messages-chat-102025 .thread-item .avatar {
  flex: 0 0 auto;
  width: 48px;
  height: 48px;
  border-radius: 50%;
  margin-right: 1rem;
}
collab-messages-chat-102025 .thread-item .thread-content {
  flex: 1;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  padding: 0.9rem;
}
collab-messages-chat-102025 .thread-item .thread-item-avatar {
  width: 40px;
  height: 40px;
  border-radius: 15px;
  border: 1px solid var(--grey-color-light);
}
collab-messages-chat-102025 .thread-item .thread-item-avatar img,
collab-messages-chat-102025 .thread-item .thread-item-avatar svg {
  border-radius: 15px;
  width: 100%;
  height: 100%;
}
collab-messages-chat-102025 .thread-item .thread-item-header {
  display: flex;
  justify-content: space-between;
}
collab-messages-chat-102025 .thread-item .thread-item-header .thread-name {
  font-size: 1rem;
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--text-primary-color);
}
collab-messages-chat-102025 .thread-item .thread-item-header .last-update,
collab-messages-chat-102025 .thread-item .thread-item-header .archived-at {
  font-size: 0.875rem;
  color: var(--grey-color-dark);
  white-space: nowrap;
}
collab-messages-chat-102025 .thread-item .thread-summary {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
collab-messages-chat-102025 .thread-item .thread-summary .last-message {
  font-size: 0.875rem;
  color: var(--grey-color-darker);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  flex: 1;
}
collab-messages-chat-102025 .unread-messages {
  background: radial-gradient(circle at center, #868686 0%, rgba(255, 255, 255, 0.6) 70%, rgba(255, 255, 255, 0) 100%);
  position: absolute;
  width: 100%;
  top: 50px;
  right: 0;
  color: #FFFFFF;
  text-align: center;
  text-transform: uppercase;
  font-size: 16px;
  animation: pulseLoading 1.5s infinite ease-in-out;
}
collab-messages-chat-102025 .new-messages-label {
  display: flex;
  justify-content: center;
  background: #ebebeb;
  color: #000000;
  text-transform: uppercase;
  font-size: 12px;
  font-weight: bold;
  margin: 5px 0;
}
collab-messages-chat-102025 .error-messages {
  position: absolute;
  top: 50px;
  left: 0;
  padding-left: 1rem;
  background: var(--grey-color-light);
  color: var(--error-color);
  font-size: var(--font-size-16);
}
@keyframes pulseLoading {
  0% {
    opacity: 0.6;
  }
  50% {
    opacity: 1;
  }
  100% {
    opacity: 0.6;
  }
}
collab-messages-chat-102025 .chat-container {
  display: flex;
  flex: 1;
  flex-direction: column;
  padding: 6px;
  width: calc(100% - 12px);
  overflow-y: auto;
  overflow-x: hidden;
  max-height: 100%;
}
collab-messages-chat-102025 .chat-container .message-time {
  text-align: center;
  font-size: 0.85rem;
  color: gray;
  margin-bottom: 5px;
}
collab-messages-chat-102025 .task-notification-nav {
  position: absolute;
  right: 18px;
  bottom: 86px;
  z-index: 5;
  width: 38px;
  height: 38px;
  border: 1px solid var(--grey-color-light);
  border-radius: 50%;
  background: var(--bg-primary-color);
  color: var(--success-color);
  box-shadow: rgba(0, 0, 0, 0.22) 0 2px 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: transform 0.15s ease, background-color 0.15s ease;
}
collab-messages-chat-102025 .task-notification-nav:hover {
  background: var(--bg-primary-color-focus);
  transform: translateY(-1px);
}
`);
        this.msg = messages['en'];
        this.isLoadingThread = false;
        this.filteredThreads = { active: [], archived: [], deleted: [], deleting: [] };
        this.isThreadError = false;
        this.threadErrorMsg = '';
        this.lastTopicFilter = '';
        this.welcomeMessage = '';
        this.usersAvaliables = [];
        this.taskNotificationNavDirection = '';
        this.group = 'CONNECT';
        this.activeScenerie = 'list';
        this.actualMessages = [];
        this.actualMessagesParsed = {};
        this.isLoadingMessages = false;
        this.searchTerm = '';
        this.userThreads = {};
        this.allThreads = [];
        this.lastMessageReaded = '';
        this.unreadCountInSelectedThread = 0;
        this.isSystemChangeScroll = false;
        this.savedScrollTop = 0;
        this.hasMoreMessagesLocalDB = true;
        this.hasMoreMessagesBefore = false;
        this.messagesLimit = 50;
        this.messagesOffset = 0;
        this.isLoadingMoreMessages = false;
        this.isChangeTopics = false;
        this.wasMessagesAtBottom = true;
        this.alreadyCheckForRegisterToken = false;
        this.onTaskChange = async (e) => {
            const customEvent = e;
            const message = customEvent.detail.context.message;
            const task = customEvent.detail.context.task;
            const thId = message?.threadId;
            if (!this.actualThread || !thId || thId !== this.actualThread.thread.threadId)
                return;
            await this.updateMessageAI(customEvent.detail.context, false, customEvent.detail.oldContextCreateAt);
            if (task)
                await addOrUpdateTask(customEvent.detail.context.task);
        };
        /*
        private onTaskDetailsClose = async (_e: Event) => {
            const taskId = (_e as CustomEvent).detail;
            clearServiceDetails();
            if (taskId) {
                this.taskToOpen = taskId;
                this.openTask();
            }
        };*/
        this.onThreadChange = async (e) => {
            const customEvent = e;
            await this.updateMessageAI(customEvent.detail, false);
            const thread = customEvent.detail;
            const threadUpdated = this.userThreads[this.group].find((th) => th.thread.threadId === thread.threadId);
            if (['deleted'].includes(thread.status)) {
                await deleteAllMessagesFromThread(thread.threadId);
            }
            if (threadUpdated)
                threadUpdated.thread = { ...threadUpdated.thread, ...thread };
            else if (thread.group === this.group) {
                this.userThreads[this.group] = [...this.userThreads[this.group], { thread, hasMore: false, users: [] }];
            }
            if (threadUpdated?.thread.threadId === this.actualThread?.thread.threadId) {
                this.actualThread = threadUpdated;
                if (this.actualThread) {
                    const hasUnreadMessages = !!(this.actualThread.thread.unreadCount && this.actualThread.thread.unreadCount > 0);
                    const chatEl = this.querySelector('.chat-container');
                    if (chatEl) {
                        const isScrolledToBottom = chatEl.scrollTop + chatEl.clientHeight >= chatEl.scrollHeight - 1;
                        if (isScrolledToBottom)
                            this.isSystemChangeScroll = true;
                    }
                    const messagesInDb = await getMessagesByThreadId(this.actualThread.thread.threadId, this.messagesLimit, 0);
                    this.actualMessages = messagesInDb;
                    this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
                    if (hasUnreadMessages)
                        await this.updateLastMessage(this.actualThread);
                }
            }
            if (this.activeScenerie === 'threadDetails' && (thread.status === 'deleted' ||
                thread.status === 'deleting' ||
                thread.status === 'archived')) {
                this.activeScenerie = 'list';
            }
            this.requestUpdate();
        };
        this.onMessageSend = async (e) => {
            const customEvent = e;
            const message = customEvent.detail.context.message;
            const outputs = customEvent.detail.context.botOutput;
            const thId = message?.threadId;
            if (!this.actualThread || !thId || thId !== this.actualThread.thread.threadId)
                return;
            this.updateMessage2(false, true, { ...message, footers: [] }, message, outputs);
        };
        this.onDocumentClick = () => {
            const all = Array.from(this.querySelectorAll('collab-messages-chat-message-102025'));
            all.forEach((item) => {
                item.openedReactionMessageId = undefined;
                item.reactionPickerTarget = undefined;
                item.openedMenuFor = undefined;
                item.messageMenuTarget = undefined;
                item.openedReactionListMessageId = undefined;
                item.reactionListTarget = undefined;
            });
        };
        this.scrollLock = false;
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('activeScenerie') && (this.activeScenerie === 'list')) {
            this.usersAvaliables = await listUsers();
        }
        if (changedProperties.has('threadToOpen')) {
            if (this.threadToOpen) {
                if (this.activeScenerie !== 'list') {
                    this.activeScenerie = 'list';
                    await this.updateComplete;
                }
                const threadElement = this.querySelector(`[threadId="${this.threadToOpen}"]`);
                if (!threadElement)
                    return;
                const detailsParent = threadElement.closest('details');
                if (detailsParent && !detailsParent.open) {
                    detailsParent.open = true;
                    await this.updateComplete;
                }
                this.onThreadClick(threadElement.item);
            }
        }
        if (changedProperties.has('activeScenerie')
            && (changedProperties.get('activeScenerie') === 'task'
                || changedProperties.get('activeScenerie') === 'addParticipant'
                || changedProperties.get('activeScenerie') === 'threadDetails')
            && this.activeScenerie === 'details') {
            this.restoreScrollPosition();
        }
        if (changedProperties.has('actualMessagesParsed') && this.actualMessagesParsed !== undefined) {
            await this.verifyChatScroll();
            await this.updateComplete;
            await this.nextFrame();
            this.updateTaskNotificationNavDirection();
        }
    }
    connectedCallback() {
        super.connectedCallback();
        document.addEventListener('click', this.onDocumentClick);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        window.removeEventListener('task-change', this.onTaskChange);
        // window.removeEventListener('task-details-close', this.onTaskDetailsClose);
        window.removeEventListener('thread-change', this.onThreadChange.bind(this));
        window.removeEventListener('message-change', this.onMessageChange.bind(this));
        window.removeEventListener('message-send', this.onMessageSend);
        document.removeEventListener("visibilitychange", this.onVisibilityChange.bind(this));
        document.removeEventListener('click', this.onDocumentClick);
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        window.addEventListener('task-change', this.onTaskChange);
        // window.addEventListener('task-details-close', this.onTaskDetailsClose);
        window.addEventListener('thread-change', this.onThreadChange.bind(this));
        window.addEventListener('message-change', this.onMessageChange.bind(this));
        window.addEventListener('message-send', this.onMessageSend);
        document.addEventListener("visibilitychange", this.onVisibilityChange.bind(this));
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.activeScenerie === 'loading') {
            return html `<div class="loading">${this.msg.loading}</div>`;
        }
        return html `
            ${this.renderHeader()}
            ${this.renderContent()}`;
    }
    renderHeader() {
        switch (this.activeScenerie) {
            case 'task':
                return html `
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} <span class="header-title">Task: ${this.actualTask?.PK || ''}</span></span>
                    </div>`;
            case 'details':
                return html `
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} <span class="header-title">Thread: ${this.getThreadName(this.actualThread)}</span></span>
                        ${this.actualThread?.thread.status !== 'deleted' ? html `
                            <div class="header-actions">
                                <span @click=${this.onThreadDetailsClick}>${collab_gear}</span>
                            </div>
                        ` : ''}                        
                    </div>`;
            case 'list':
                return html `<div class="header">
                    ${this.renderThreadSearch()}
                    <div class="header-actions">
                            <span @click=${this.onThreadAddClick}>${collab_plus}</span>
                    </div>
                </div>`;
            case 'threadDetails':
                return html `
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} ${this.msg.threadDetails}</span>
                    </div>`;
            case 'threadAdd':
                return html `
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} ${this.msg.threadAdd}</span>
                    </div>`;
            default:
                return null;
        }
    }
    renderContent() {
        switch (this.activeScenerie) {
            case 'list':
                return this.renderListThreads();
            case 'details':
                return this.renderChatMessages();
            case 'task':
                return this.renderTaskDetails();
            case 'threadDetails':
                return this.renderThreadDetails();
            case 'threadAdd':
                return this.renderThreadAdd();
            default:
                return null;
        }
    }
    renderChatMessages() {
        if (!this.actualThread)
            return html ``;
        if (this.welcomeMessage && !['deleting', 'deleted', 'archived'].includes(this.actualThread?.thread.status)) {
            return this.renderWelcomeMessage();
        }
        if (this.actualThread.thread.status === 'deleting' || this.actualThread.thread.status === 'deleted') {
            const formatedTimestamp = formatTimestamp(this.actualThread.thread.deletedAt || '');
            const deletedAt = this.parseLocalDate(formatedTimestamp?.dateFull || '');
            return html `
                <div>${this.msg.threadDeleting.replace('[date]', deletedAt.datafull)}</div>
            `;
        }
        if (this.actualThread.thread.status === 'archived') {
            const formatedTimestamp = formatTimestamp(this.actualThread.thread.archivedAt || '');
            const archivedAt = this.parseLocalDate(formatedTimestamp?.dateFull || '');
            const archivedBy = this.actualThread.users.find((user) => user.userId === this.actualThread?.thread.archivedBy);
            return html `
                <div>${this.msg.threadArchived.replace('[user]', archivedBy?.name || '').replace('[date]', archivedAt.datafull)}</div>
            `;
        }
        const sortedEntries = Object.entries(this.actualMessagesParsed)
            .map(([date, value]) => [date.trim(), value])
            .sort(([a], [b]) => new Date(a).getTime() - new Date(b).getTime());
        const sortedObj = Object.fromEntries(sortedEntries);
        let nextNeedShowLabel = false;
        return html `
            ${this.renderTopics()}
            <div
                @scroll=${this.onChatScroll} class="chat-container"
                @copy=${this.onCopyChat}
            >
                ${repeat(Object.keys(sortedObj), (key) => key, (key) => {
            const threadMessages = sortedObj[key];
            const messageTime = this.parseLocalDate(key);
            const displayDate = this.formatMessageDate(messageTime.dateObject);
            return html `
                    <div class="message-time">${displayDate}</div>
                        ${repeat(threadMessages, (message) => `${message.threadId}/${message.createAt}`, (message) => {
                if (this.lastMessageReaded === message.createAt && this.unreadCountInSelectedThread)
                    nextNeedShowLabel = true;
                else
                    nextNeedShowLabel = false;
                return html `
                                <collab-messages-chat-message-102025
                                    messageId=${message.createAt}
                                    .message=${message}
                                    .allThreads=${this.allThreads}
                                    .actualThread=${this.actualThread}
                                    .usersAvaliables=${this.usersAvaliables}
                                    .userId=${this.userId}
                                    .onTaskClick=${this.onTaskClick.bind(this)}
                                    @reply-preview-click=${this.onReplyPreviewClick}
                                    @reply-message=${this.onReplyMessageClick}
                                ></collab-messages-chat-message-102025>
                                ${nextNeedShowLabel ? html `<div class="new-messages-label">${this.msg.newMessages}</div>` : ''}`;
            })}`;
        })}
                        ${this.isLoadingMessages ? html `<div class="unread-messages">Loading messages...</div>` : html ``}
                        ${this.isThreadError ? html `<div class="error-messages">${this.threadErrorMsg}</div>` : html ``}
                    </div>
                ${this.renderTaskNotificationNav()}
                ${this.renderPrompt()}`;
    }
    renderTaskNotificationNav() {
        if (!this.actualThread)
            return nothing;
        const taskId = this.getFirstPendingTaskNotificationInView();
        if (!taskId)
            return nothing;
        const direction = this.taskNotificationNavDirection || 'up';
        if (!this.taskNotificationNavDirection)
            return nothing;
        return html `
            <button
                class="task-notification-nav ${direction}"
                @click=${() => this.scrollToTaskNotification(taskId)}
                title="Go to updated task"
            >
                ${this.renderTaskNotificationNavIcon(direction)}
            </button>
        `;
    }
    renderTaskNotificationNavIcon(direction) {
        const rotate = direction === 'down' ? 'rotate(180 12 12)' : '';
        return html `
            <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true">
                <g transform="${rotate}" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M7 14l5-5 5 5"></path>
                    <path d="M7 19l5-5 5 5"></path>
                </g>
            </svg>
        `;
    }
    renderWelcomeMessage() {
        return html `
            <div class="welcome-message">
                <p>${this.welcomeMessage}</p>
                <button @click=${() => { this.welcomeMessage = ''; }}>${this.msg.btnNext}</button>       
            </div>`;
    }
    renderTopics() {
        return html `
            <collab-messages-topics-102025
                .selectedTopic=${this.lastTopicFilter === '' ? 'all' : this.lastTopicFilter}
                .messages=${this.actualMessages}
                .threadTopics=${this.actualThread?.thread.defaultTopics || []}
                @topic-selected=${(e) => this.onTopicClick(e)}
            ></collab-messages-topics-102025>
        `;
    }
    async onTopicClick(e) {
        this.lastTopicFilter = e.detail.topic === 'all' ? '' : e.detail.topic;
        this.isChangeTopics = true;
        this.isSystemChangeScroll = true;
        if (e.detail.topic === 'all') {
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        }
        else
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        /*if (this.messageContainer) {
            const newHeight = this.messageContainer.scrollHeight;
            this.messageContainer.scrollTop = newHeight;
        }*/
    }
    removeAllModal() {
        const all = this.querySelectorAll('collab-messages-user-modal-102025');
        const all2 = this.querySelectorAll('collab-messages-thread-modal-102025');
        [...all, ...all2].forEach((item) => item.remove());
    }
    renderPrompt() {
        return html `
            <collab-messages-prompt-102025
                acceptAutoCompleteAgents="true"
                acceptAutoCompleteUser="true"
                enableRichPreview="true"
                threadId=${this.actualThread?.thread.threadId}
                .onSend=${this.handleSend.bind(this)}
                placeholder=${this.msg.promptPlaceholder}
                @textarea-resize=${this.handlePromptResize}
                scope="*"
            ></collab-messages-prompt-102025>
        `;
    }
    renderListThreads() {
        if (!this.userThreads[this.group] || (this.userThreads[this.group].length === 0 && !this.isLoadingThread)) {
            return html `<div style="padding:1rem;">${this.msg.noThreads}</div>`;
        }
        const ordenedThreads = this.getOrdenedThreadsByStatus();
        this.filteredThreads = this.getFilteredThreads(ordenedThreads);
        return html `
            ${this.renderThreadsByStatus2()}
            ${this.isLoadingThread ? html `<div>${this.msg.loading}</div>` : ''}
        `;
    }
    getThreadAvatar(item) {
        let threadAvatar = generateAgentAvatar(item.thread.name);
        if (item.thread.name.startsWith('@') && item.thread.users.length === 2) {
            const user = item.users.find((user) => user.userId !== this.userId);
            if (user && user.avatar_url)
                threadAvatar = user.avatar_url;
        }
        else if (item.thread.avatar_url) {
            threadAvatar = item.thread.avatar_url;
        }
        return threadAvatar;
    }
    getThreadName(item) {
        if (!item)
            return '';
        if (this.isDirectMessage(item)) {
            const user = item.users.find((user) => user.userId !== this.userId);
            if (user)
                return '@' + user.name;
        }
        return item.thread.name || item.thread.threadId;
    }
    isDirectMessage(item) {
        return item.thread.name.startsWith('@') && item.thread.users.length === 2;
    }
    renderThreadsByStatus2() {
        const groups = this.groupThreadsByPrefix(this.filteredThreads.active);
        return html `
        <ul class="thread-list">
            ${Object.entries(groups).map(([prefix, items]) => {
            if (items.length === 1) {
                return this.renderThreadItemLi(items[0]);
            }
            else {
                const lastItem = items[0];
                const unreadCount = items.reduce((total, item) => total + (item.thread?.unreadCount || 0), 0);
                const hasPendingNotification = items.some((item) => hasThreadNotificationPending(item.thread.threadId));
                const pendingTasksCount = items.reduce((total, item) => total + (item?.thread?.pendingTasks?.length || 0), 0);
                const now = new Date();
                const isToday = lastItem._lastMessageDate.dateObject.getFullYear() === now.getFullYear() &&
                    lastItem._lastMessageDate.dateObject.getMonth() === now.getMonth() &&
                    lastItem._lastMessageDate.dateObject.getDate() === now.getDate();
                const displayDate = isToday
                    ? lastItem._lastMessageDate.time
                    : this.formatMessageDate(lastItem._lastMessageDate.dateObject);
                return html `
                        <li class="thread-group ${hasPendingNotification ? 'has-notification' : ''}">
                            <details>
                                <summary class="group-title">
                                    <div class="thread-group-avatar">
                                        ${collab_folder_tree}
                                    </div>
                                    <div class="thread-group-content">
                                        <div class="thread-group-item-header">
                                            <span class="thread-group-name">${prefix}</span>
                                            <span class="last-group-update">
                                                ${this.renderTaskPendingsCount(pendingTasksCount)}
                                                ${displayDate}
                                            
                                            </span>
                                        </div>
                                        <div class="thread-group-summary">
                                            <span class="last-group-message">${items.length} Threads </span>
                                            ${unreadCount > 0 ? html `<span class="unread-count">${unreadCount}</span>` : hasPendingNotification ? html `<span class="unread-count">•</span>` : nothing}
                                        </div>
                                    </div>                                
                                </summary>
                                <ul class="group-items">
                                    ${items.map(item => this.renderThreadItemLi(item, prefix))}
                                </ul>
                            </details>
                        </li>
                    `;
            }
        })}
        
            ${this.renderArchivedThreads()}
            ${this.renderDeletingThreads()}
            ${this.renderDeletedThreads()}

        </ul>
    `;
    }
    renderThreadItemLi(item, prefix) {
        let threadAvatar = this.getThreadAvatar(item);
        let threadName = this.getThreadName(item);
        if (prefix)
            threadName = threadName.replace(prefix + '/', '');
        const isDirectMessage = this.isDirectMessage(item);
        let lastMessage = item.thread.lastMessage || '';
        const firstColonIndex = lastMessage.indexOf(':');
        let userMessageId = lastMessage.slice(0, firstColonIndex);
        let userMessage = lastMessage.slice(firstColonIndex + 1);
        const unreadCount = item.thread.unreadCount || 0;
        const hasPendingNotification = hasThreadNotificationPending(item.thread.threadId);
        const pendingTasksCount = item.thread.pendingTasks?.length || 0;
        const now = new Date();
        const isToday = item._lastMessageDate.dateObject.getFullYear() === now.getFullYear() &&
            item._lastMessageDate.dateObject.getMonth() === now.getMonth() &&
            item._lastMessageDate.dateObject.getDate() === now.getDate();
        const displayDate = isToday
            ? item._lastMessageDate.time
            : this.formatMessageDate(item._lastMessageDate.dateObject);
        if (item.users.length > 0) {
            const sortedUsers = [...item.users].sort((a, b) => b.name.length - a.name.length);
            if (userMessageId === this.userId)
                userMessageId = this.msg.lastMessagePrefix;
            else
                userMessageId = sortedUsers.find(u => u.userId === userMessageId)?.name || '';
            userMessage = userMessage.replace(/\[@([^\]]+)\]\(([^)]+)\)/g, (_m, name, userId) => {
                const user = sortedUsers.find(u => u.userId === userId);
                if (!user)
                    return `@${name}`;
                return `@${user.name}`;
            });
        }
        return html `
        <li .item=${item} threadId=${item.thread.threadId} 
            @click=${() => this.onThreadClick(item)} 
            class="thread-item ${hasPendingNotification ? 'has-notification' : ''}">
            <div class="thread-item-avatar">
                ${threadAvatar.startsWith('<') && threadAvatar.endsWith('>') ?
            html `${unsafeHTML(threadAvatar)}` :
            html `<img src="${threadAvatar}"></img>`}
            </div>
            <div class="thread-content">
                <div class="thread-item-header">
                    <span class="thread-name">${threadName}</span>
                    <span class="last-update">
                        ${this.renderTaskPendingsCount(pendingTasksCount)}
                        ${displayDate}
                    </span>
                </div>
                <div class="thread-summary">
                    ${userMessage ? html `
                            <span class="last-message">${userMessageId && !isDirectMessage ? html `<span>${userMessageId}:</span>` : nothing}${userMessage || ''}</span>
                        ` : nothing}
                    
                    ${unreadCount > 0 ? html `<span class="unread-count">${unreadCount}</span>` : hasPendingNotification ? html `<span class="unread-count">•</span>` : nothing}
                </div>
            </div>
        </li>
    `;
    }
    renderTaskPendingsCount(pendingTasksCount) {
        return html `
            ${pendingTasksCount > 0 ? html `
                <span class="tasks-pendings-count">
                    ${collab_bell}
                    <span class="notification-badge">${pendingTasksCount}</span>
                </span>` : nothing}
        `;
    }
    formatMessageDate(input) {
        const date = typeof input === 'string' ? new Date(input) : input;
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const target = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        const diffTime = today.getTime() - target.getTime();
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        if (diffDays === 0)
            return this.msg.today;
        if (diffDays === 1)
            return this.msg.yesterday;
        const lang = document.querySelector('html')?.lang || 'pt-BR';
        if (diffDays > 1 && diffDays < 7) {
            return target.toLocaleDateString(lang, {
                weekday: 'short',
            });
        }
        return target.toLocaleDateString(lang);
    }
    renderArchivedThreads() {
        if (this.filteredThreads.archived.length === 0)
            return html `${nothing}`;
        return html `        
            ${this.filteredThreads.archived.map((item) => {
            let threadAvatar = this.getThreadAvatar(item);
            const unreadCount = item.thread.unreadCount || 0;
            function isWithinLastWeek(date) {
                const now = new Date();
                const oneWeekAgo = new Date();
                oneWeekAgo.setDate(now.getDate() - 7);
                return date >= oneWeekAgo;
            }
            if (!item._lastMessageDateArchived)
                return html ``;
            return html `
                ${!isWithinLastWeek(item._lastMessageDateArchived.dateObject)
                ? html `${nothing}`
                : html `
                        <li @click=${() => this.onThreadClick(item)} class="thread-item">
                            <div class="thread-item-avatar">
                                    ${threadAvatar.startsWith('<') && threadAvatar.endsWith('>') ?
                    html `${unsafeHTML(threadAvatar)}` :
                    html `<img src="${threadAvatar}"></img>`}
                            </div>
                            <div class="thread-content">
                                <div class="thread-item-header">
                                    <span class="thread-name">(${this.msg.archived}) ${item.thread.name || item.thread.threadId}</span>
                                    ${unreadCount > 0 ? html `<span class="unread-count">*</span>` : nothing}
                                </div>
                            </div>
                        </li>`}`;
        })}
        `;
    }
    renderDeletingThreads() {
        if (this.filteredThreads.deleting.length === 0)
            return html ``;
        return html `        
            ${this.filteredThreads.deleting.map((item) => {
            let threadAvatar = this.getThreadAvatar(item);
            const unreadCount = item.thread.unreadCount || 0;
            function isWithinLastWeek(date) {
                const now = new Date();
                const oneWeekAgo = new Date();
                oneWeekAgo.setDate(now.getDate() - 7);
                return date >= oneWeekAgo;
            }
            if (!item.lastMessageDateDeleting)
                return html ``;
            return html `
                ${!isWithinLastWeek(item.lastMessageDateDeleting.dateObject)
                ? html ``
                : html `
                        <li @click=${() => this.onThreadClick(item)} class="thread-item">
                            <div class="thread-item-avatar">
                                    ${threadAvatar.startsWith('<') && threadAvatar.endsWith('>') ?
                    html `${unsafeHTML(threadAvatar)}` :
                    html `<img src="${threadAvatar}"></img>`}
                            </div>
                            <div class="thread-content">
                                <div class="thread-item-header">
                                    <span class="thread-name">(${this.msg.deleting}) ${item.thread.name || item.thread.threadId}</span>
                                    ${unreadCount > 0 ? html `<span class="unread-count">*</span>` : nothing}

                                </div>
                            </div>
                        </li>`}`;
        })}
        `;
    }
    renderDeletedThreads() {
        if (this.filteredThreads.deleted.length === 0)
            return html ``;
        return html `      
          
            ${this.filteredThreads.deleted.map((item) => {
            let threadAvatar = this.getThreadAvatar(item);
            if (!item.lastMessageDateDeleting)
                return html ``;
            const unreadCount = item.thread.unreadCount || 0;
            return html `
                <li @click=${() => this.onThreadClick(item)} class="thread-item">
                    <div class="thread-item-avatar">
                            ${threadAvatar.startsWith('<') && threadAvatar.endsWith('>') ?
                html `${unsafeHTML(threadAvatar)}` :
                html `<img src="${threadAvatar}"></img>`}
                    </div>
                    <div class="thread-content">
                        <div class="thread-item-header">
                            <span class="thread-name" style="text-decoration: line-through;">(${this.msg.deleted}) ${item.thread.name || item.thread.threadId}</span>
                            ${unreadCount > 0 ? html `<span class="unread-count">*</span>` : nothing}
                        </div>
                    </div>
                </li>`;
        })}
        `;
    }
    renderThreadSearch() {
        return html `
		<collab-messages-filter-102025
			@search-change=${this.onSearchInput}
            .expanded=${this.searchTerm !== ''}
            .query=${this.searchTerm}
			placeholder=${this.msg.placeholderSearch}>
		</collab-messages-filter-102025>
	`;
    }
    renderTaskDetails() {
        if (this.elementTaskDetails) {
            return html `${this.elementTaskDetails}`;
        }
        return html `<span> No find any widget to show task details <span>`;
    }
    renderThreadDetails() {
        return html `<collab-messages-thread-details-102025 userId=${this.userId} .threadDetails=${{ ...this.actualThread }}></collab-messages-thread-details-102025>`;
    }
    renderThreadAdd() {
        return html `
            <collab-messages-add-102025 
                .onAddSuccess = ${() => { this.activeScenerie = 'list'; }}
                .group=${this.group}
                userId=${this.userId} 
            ></collab-messages-add-102025>`;
    }
    onSearchInput(e) {
        this.searchTerm = e.detail.toLowerCase();
        const ordenedThreads = this.getOrdenedThreadsByStatus();
        this.filteredThreads = this.getFilteredThreads(ordenedThreads);
    }
    getScrollAnchor(container) {
        const containerRect = container.getBoundingClientRect();
        const messages = Array.from(container.querySelectorAll('collab-messages-chat-message-102025'));
        for (const message of messages) {
            const rect = message.getBoundingClientRect();
            if (rect.bottom >= containerRect.top) {
                const messageId = message.getAttribute('messageid');
                if (!messageId)
                    return;
                return {
                    messageId,
                    offsetTop: rect.top - containerRect.top
                };
            }
        }
    }
    restoreScrollAnchor(container, anchor) {
        if (!anchor)
            return;
        const target = container.querySelector(`collab-messages-chat-message-102025[messageid="${anchor.messageId}"]`);
        if (!target)
            return;
        const containerRect = container.getBoundingClientRect();
        const targetRect = target.getBoundingClientRect();
        container.scrollTop += targetRect.top - containerRect.top - anchor.offsetTop;
        this.savedScrollTop = container.scrollTop;
    }
    async updateMessagesAfterScrollMore(newMessages, container, anchor) {
        this.actualMessages = [...this.actualMessages, ...newMessages];
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        await this.updateComplete;
        await this.waitingForRenderCodesWebComponents();
        await this.nextFrame();
        await this.nextFrame();
        this.restoreScrollAnchor(container, anchor);
    }
    async getBeforeMessagesInServer(thread) {
        const firstItem = [...this.actualMessages].sort((a, b) => a.orderAt.localeCompare(b.orderAt))[0];
        const response = await this.getMessagesBefore(thread, firstItem.orderAt);
        const newMessages = response?.data;
        this.hasMoreMessagesBefore = response?.hasMore || false;
        return newMessages;
    }
    onCopyChat(ev) {
        ev.preventDefault();
        const selection = window.getSelection();
        if (!selection)
            return;
        let container = document.createElement("div");
        for (let i = 0; i < selection.rangeCount; i++) {
            container.appendChild(selection.getRangeAt(i).cloneContents());
        }
        const extractMessage = (el) => {
            const titleEl = el.querySelector(".message-title");
            const timeEl = el.querySelector(".message-footer");
            const contentEl = el.querySelector(".collab-md-message");
            const taskEl = el.querySelector('collab-messages-task-102025');
            let author = titleEl?.textContent?.trim();
            const content = contentEl?.innerText?.trim() || "";
            const time = timeEl?.textContent?.trim() || "";
            const task = taskEl?.getAttribute('taskid');
            return {
                author,
                content,
                time,
                task
            };
        };
        const items = container.querySelectorAll(".message-time, .message-card");
        if (items.length === 0) {
            const { author, content, task, time } = extractMessage(container);
            if (content) {
                const msg = `${time ? time : ''} ${author ? author : ''} ${content} ${task ? `(Task:${task})` : ''}`;
                return ev.clipboardData?.setData("text/plain", msg);
            }
            ev.clipboardData?.setData("text/plain", selection.toString());
            return;
        }
        let result = [];
        let lastAuthor = "";
        let currentDate = "";
        items.forEach(el => {
            if (el.classList.contains("message-time")) {
                currentDate = el.textContent?.trim() || '';
                result.push(`--- ${currentDate} ---`);
            }
            else {
                let { author, content, task, time } = extractMessage(el);
                if (!author)
                    author = lastAuthor;
                else
                    lastAuthor = author;
                if (content) {
                    result.push(`${time ? time : ''} ${author ? author : ''} ${content} ${task ? `(Task:${task})` : ''}`);
                }
            }
        });
        if (result.length > 0) {
            ev.clipboardData?.setData("text/plain", result.join("\n"));
        }
    }
    async onChatScroll(e) {
        if (this.scrollLock)
            return;
        this.removeAllModal();
        this.updateTaskNotificationNavDirection();
        if (this.isChangeTopics) {
            this.isChangeTopics = false;
            return;
        }
        if (this.isSystemChangeScroll) {
            this.isSystemChangeScroll = false;
            return;
        }
        const container = e.target;
        this.savedScrollTop = container.scrollTop;
        const threshold = 5;
        this.wasMessagesAtBottom = container.scrollTop + container.clientHeight >= container.scrollHeight - threshold;
        const scrollAnchor = this.getScrollAnchor(container);
        if (container.scrollTop === 0 &&
            !this.isLoadingMoreMessages &&
            this.actualThread &&
            !this.hasMoreMessagesLocalDB &&
            this.hasMoreMessagesBefore) {
            this.isLoadingMoreMessages = true;
            const newMessages = await this.getBeforeMessagesInServer(this.actualThread.thread);
            if (newMessages)
                await this.updateMessagesAfterScrollMore(newMessages.map(item => ({ ...item, footers: [], })), container, scrollAnchor);
            this.isLoadingMoreMessages = false;
            return;
        }
        if (container.scrollTop === 0 &&
            !this.isLoadingMoreMessages &&
            this.actualThread &&
            this.hasMoreMessagesLocalDB) {
            this.isLoadingMoreMessages = true;
            const newOffset = this.messagesOffset + this.messagesLimit;
            const newMessages = await getMessagesByThreadId(this.actualThread.thread.threadId, this.messagesLimit, newOffset);
            if (newMessages.length > 0) {
                this.messagesOffset = newOffset;
                await this.updateMessagesAfterScrollMore(newMessages, container, scrollAnchor);
            }
            else {
                const newMessages = await this.getBeforeMessagesInServer(this.actualThread.thread);
                if (newMessages)
                    await this.updateMessagesAfterScrollMore(newMessages.map(item => ({ ...item, footers: [], })), container, scrollAnchor);
                this.hasMoreMessagesLocalDB = false;
            }
            this.isLoadingMoreMessages = false;
        }
    }
    getFirstPendingTaskNotificationInView() {
        if (!this.actualThread)
            return '';
        const pendingTaskIds = getPendingTaskNotificationsForThread(this.actualThread.thread.threadId);
        if (pendingTaskIds.length === 0)
            return '';
        const renderedTasks = Array.from(this.querySelectorAll('collab-messages-task-102025'));
        const found = renderedTasks.find((item) => pendingTaskIds.includes(item.getAttribute('taskid') || ''));
        return found?.getAttribute('taskid') || '';
    }
    getTaskNotificationElement(taskId) {
        if (!taskId)
            return null;
        return this.querySelector(`collab-messages-task-102025[taskid="${taskId}"]`);
    }
    updateTaskNotificationNavDirection() {
        const taskId = this.getFirstPendingTaskNotificationInView();
        const taskEl = this.getTaskNotificationElement(taskId);
        if (!this.messageContainer || !taskEl) {
            if (this.taskNotificationNavDirection)
                this.taskNotificationNavDirection = '';
            return;
        }
        const containerRect = this.messageContainer.getBoundingClientRect();
        const taskRect = taskEl.getBoundingClientRect();
        let nextDirection = '';
        if (taskRect.bottom < containerRect.top)
            nextDirection = 'up';
        else if (taskRect.top > containerRect.bottom)
            nextDirection = 'down';
        if (this.taskNotificationNavDirection !== nextDirection) {
            this.taskNotificationNavDirection = nextDirection;
        }
    }
    async scrollToTaskNotification(taskId) {
        const taskEl = this.getTaskNotificationElement(taskId);
        if (!taskEl)
            return;
        taskEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await this.nextFrame();
        this.updateTaskNotificationNavDirection();
    }
    groupThreadsByPrefix(threads) {
        const groups = {};
        for (const t of threads) {
            const name = this.getThreadName(t);
            if (name.startsWith('_') && name.includes('/')) {
                const [prefix] = name.split('/');
                if (!groups[prefix])
                    groups[prefix] = [];
                groups[prefix].push(t);
            }
            else {
                if (!groups[name])
                    groups[name] = [];
                groups[name].push(t);
            }
        }
        return groups;
    }
    getOrdenedThreadsByStatus() {
        const threads = this.userThreads[this.group]
            .map((item) => {
            const lastTimestamp = item.thread.lastMessageTime
                ? item.thread.lastMessageTime
                : item.thread.history?.length ? item.thread.history[0]?.timestamp : '';
            const formatedTimestamp = formatTimestamp(lastTimestamp)?.dateFull;
            const lastMessageDate = this.parseLocalDate(formatedTimestamp || '');
            let lastMessageDateArchived;
            let lastMessageDateDeleting;
            if (item.thread.status === 'archived' && item.thread.archivedAt) {
                const formatedTimestampArchived = formatTimestamp(item.thread.archivedAt)?.dateFull;
                lastMessageDateArchived = this.parseLocalDate(formatedTimestampArchived || '');
            }
            if ((item.thread.status === 'deleting' || item.thread.status === 'deleted') && item.thread.deletedAt) {
                const formatedTimestampArchived = formatTimestamp(item.thread.deletedAt)?.dateFull;
                lastMessageDateDeleting = this.parseLocalDate(formatedTimestampArchived || '');
            }
            return {
                ...item,
                _lastMessageDate: lastMessageDate,
                _lastMessageDateArchived: lastMessageDateArchived,
                lastMessageDateDeleting: lastMessageDateDeleting,
            };
        })
            .sort((a, b) => b._lastMessageDate.dateObject.getTime() -
            a._lastMessageDate.dateObject.getTime());
        const result = {
            archived: [],
            deleted: [],
            deleting: [],
            active: [],
        };
        for (const threadInfo of threads) {
            if (threadInfo.thread.status === 'archived') {
                result.archived.push(threadInfo);
            }
            else if (threadInfo.thread.status === 'deleted') {
                result.deleted.push(threadInfo);
            }
            else if (threadInfo.thread.status === 'deleting') {
                result.deleting.push(threadInfo);
            }
            else {
                result.active.push(threadInfo);
            }
        }
        return result;
    }
    getFilteredThreads(ordened) {
        if (!this.searchTerm)
            return ordened;
        const term = this.searchTerm.toLowerCase();
        Object.keys(ordened).forEach((key) => {
            const key2 = key;
            ordened[key2] = ordened[key2].filter(item => {
                const threadName = item.thread.name?.toLowerCase() ?? '';
                if (threadName.startsWith('@')) {
                    const users = item.thread.users
                        .map(u => this.usersAvaliables.find(au => au.userId === u.userId));
                    return users.some(user => (`@${user?.name.toLowerCase()}`).includes(term));
                }
                return threadName.includes(term);
            });
        });
        return ordened;
    }
    async getMessagesAfter(thread, lastOrderAt = '') {
        if (!this.userId)
            return;
        const result = await msgGetMessagesAfter({
            lastOrderAt,
            threadId: thread.threadId,
            userId: this.userId
        });
        if (!result.success || !result.response) {
            console.warn('Failed to fetch messages after:', result.error);
            return;
        }
        return result.response;
    }
    async getMessagesBefore(thread, orderAt = '') {
        if (!this.userId)
            return;
        const result = await msgGetMessagesBefore({
            orderAt,
            threadId: thread.threadId,
            userId: this.userId
        });
        if (!result.success || !result.response) {
            console.warn('Failed to fetch messages before:', result.error);
            return;
        }
        return result.response;
    }
    parseMessages(rawData, topic) {
        const groupedByDay = {};
        [...rawData].forEach(msg => {
            if (topic &&
                msg.content &&
                !(msg.content.startsWith(`${topic} `) ||
                    msg.content.endsWith(` ${topic}`) ||
                    msg.content.includes(` ${topic} `))) {
                return;
            }
            const formatted = formatTimestamp(msg.createAt);
            const dateKey = formatted?.date ||
                msg.createAt
                    .slice(0, 8)
                    .replace(/(\d{4})(\d{2})(\d{2})/, '$1-$2-$3');
            if (!groupedByDay[dateKey]) {
                groupedByDay[dateKey] = [];
            }
            groupedByDay[dateKey].push(msg);
        });
        for (const day in groupedByDay) {
            groupedByDay[day].sort((a, b) => a.orderAt.localeCompare(b.orderAt));
        }
        return this.groupMessages(groupedByDay);
    }
    groupMessages(groupedByDay) {
        const result = {};
        Object.keys(groupedByDay).forEach((key) => {
            let consecutiveCount = 0;
            let lastSenderId = null;
            result[key] = groupedByDay[key].map((msg, index, arr) => {
                let isSame = false;
                if (msg.senderId === lastSenderId) {
                    consecutiveCount++;
                    isSame = true;
                    if (consecutiveCount >= 3) {
                        consecutiveCount = 0;
                        isSame = false;
                    }
                }
                else {
                    consecutiveCount = 0;
                    isSame = false;
                    lastSenderId = msg.senderId;
                }
                return { ...msg, isSame };
            });
        });
        return result;
    }
    parseLocalDate(dateString) {
        const normalized = dateString.includes(' ')
            ? dateString.replace(' ', 'T')
            : `${dateString}T00:00:00`;
        const date = new Date(normalized);
        return {
            dateObject: date,
            datafull: date.toLocaleString(),
            date: date.toLocaleDateString(),
            time: date.toTimeString().split(' ')[0]
        };
    }
    mergeMessages(array1, array2) {
        const map = new Map();
        for (const item of array1) {
            map.set(`${item.threadId}/${item.createAt}`, item);
        }
        for (const item of array2) {
            map.set(`${item.threadId}/${item.createAt}`, { ...map.get(`${item.threadId}/${item.createAt}`), ...item });
        }
        return Array.from(map.values());
    }
    async onThreadClick(threadInfo) {
        this.welcomeMessage = '';
        this.activeScenerie = 'loading';
        this.lastTopicFilter = '';
        this.messagesOffset = 0;
        this.hasMoreMessagesLocalDB = true;
        this.hasMoreMessagesBefore = false;
        this.actualThread = threadInfo;
        const temp = await getThread(this.actualThread.thread.threadId);
        this.unreadCountInSelectedThread = temp?.unreadCount || 0;
        const messagesInDb = await getMessagesByThreadId(this.actualThread.thread.threadId, this.messagesLimit, 0);
        this.actualMessages = messagesInDb;
        this.isSystemChangeScroll = true;
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.activeScenerie = 'details';
        this.isLoadingMessages = true;
        this.isThreadError = false;
        this.threadErrorMsg = '';
        this.checkWelcomeMessage(this.actualThread.thread, messagesInDb);
        this.lastMessageReaded = threadInfo.thread.lastMessageReadTime;
        try {
            if (!this.userId)
                return;
            const threadByServer = await this.getThreadInfo(this.actualThread.thread.threadId, this.userId, threadInfo.thread.lastSync || new Date('2000-01-01').toISOString());
            const threadUpdated = await updateThread(threadByServer.thread.threadId, threadByServer.thread);
            threadInfo = await this.updateMessagesOnDb(threadByServer, threadByServer.messages);
            await updateUsers(threadByServer.users);
            this.actualThread = { ...threadByServer };
            notifyThreadChange(threadUpdated);
            if (threadByServer.hasMore)
                await this.loadAllMessages(threadInfo);
            this.checkForRegisterNotification();
            if (threadByServer.threadsPending) {
                this.updateThreadPendingsInBackground(threadInfo.thread.threadId, threadByServer.threadsPending);
            }
            if (['deleted'].includes(threadByServer.thread.status)) {
                await deleteAllMessagesFromThread(threadByServer.thread.threadId);
                const threadUpdated = await this.clearUnreadMessageFromThread(threadByServer.thread);
                notifyThreadChange(threadUpdated);
            }
            this.checkNotificationsUnreadMessages();
            if (this.taskToOpen) {
                await this.updateComplete;
                this.openTask();
            }
            await this.verifyChatScroll();
        }
        catch (err) {
            this.isThreadError = true;
            this.threadErrorMsg = err.message || 'Error on read thread';
            throw new Error('Error on loading messages: ' + err.message);
        }
        finally {
            this.isLoadingMessages = false;
        }
    }
    async updateThreadPendingsInBackground(threadId, threadsPendings) {
        for await (let threadPending of threadsPendings) {
            let threadId2 = '';
            const parts = threadPending.split(':');
            threadId2 = parts[0];
            if (threadId !== threadId2) {
                removeThreadFromSync(threadId2);
                await getThreadUpdateInBackground(threadPending);
            }
        }
    }
    openTask() {
        let taskEl = null;
        if (this.taskToOpen === 'last') {
            const tasks = this.querySelectorAll('collab-messages-task-102025');
            taskEl = tasks[tasks.length - 1] || null;
        }
        else {
            taskEl = this.querySelector(`collab-messages-task-102025[taskid="${this.taskToOpen}"]`);
        }
        if (taskEl) {
            taskEl.dispatchEvent(new CustomEvent('taskclick', {
                bubbles: true,
                composed: true
            }));
        }
        this.taskToOpen = '';
    }
    checkWelcomeMessage(thread, messagesInDb) {
        if (messagesInDb.length > 0)
            return;
        if (!thread.welcomeMessage)
            return;
        this.welcomeMessage = thread.welcomeMessage;
    }
    async checkNotificationsUnreadMessages() {
        const hasPendingMessages = await checkIfNotificationUnread();
        if (!hasPendingMessages) {
            changeFavIcon(false);
            notifyThreadNotification(false);
        }
    }
    async checkForRegisterNotification() {
        if (this.alreadyCheckForRegisterToken)
            return;
        this.alreadyCheckForRegisterToken = true;
        const notificationPreference = loadNotificationPreferences();
        if (notificationPreference === 'denied')
            return;
        await registerToken();
    }
    async loadAllMessages(threadInfo) {
        const response = await this.getMessagesAfter(threadInfo.thread, threadInfo.thread.lastSync || '');
        if (!response || !response.data || response.data.length === 0 || !this.actualThread || !this.userId) {
            return;
        }
        threadInfo = await this.updateMessagesOnDb(threadInfo, response.data);
        if (!response.hasMore)
            return;
        return this.loadAllMessages(threadInfo);
    }
    async updateMessagesOnDb(threadInfo, messages) {
        if (!messages)
            return threadInfo;
        const newMessages = [];
        for await (let mm of messages) {
            const messageId = this.normalizeMessageId(mm.threadId, mm.orderAt || mm.createAt);
            const messageOld = await getMessage(messageId);
            const tempMessage = { ...mm, footers: messageOld?.footers || [] };
            newMessages.push(tempMessage);
        }
        const lastMessages = newMessages[newMessages.length - 1] || this.actualMessages[0];
        await addMessages(newMessages);
        if (lastMessages && this.actualThread)
            this.actualThread.thread = await updateLastMessageReadTime(threadInfo.thread.threadId, lastMessages.createAt);
        this.actualMessages = this.mergeMessages(this.actualMessages, newMessages);
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        await this.updateLastMessage(threadInfo);
        return threadInfo;
    }
    async clearUnreadMessageFromThread(thread) {
        const _thread = await updateThread(thread.threadId, thread, '', '', 0);
        if (this.actualThread)
            this.actualThread.thread = _thread;
        return _thread;
    }
    async updateLastMessage(threadInfo) {
        const keys = Object.keys(this.actualMessagesParsed).sort();
        const lastKey = keys.length > 0 ? keys[keys.length - 1] : null;
        const lastArray = lastKey ? this.actualMessagesParsed[lastKey] : [];
        const lastMessage = lastArray.length > 0 ? lastArray[lastArray.length - 1] : undefined;
        if (lastMessage) {
            const lastMessageText = `${lastMessage.senderId}:${lastMessage.content}`;
            const thread = await updateThread(threadInfo.thread.threadId, threadInfo.thread, lastMessageText, lastMessage.createAt, 0, lastMessage.createAt);
            threadInfo.thread = thread;
            notifyThreadChange(thread);
        }
    }
    async onTitleClick() {
        await this.updateComplete;
        if (this.activeScenerie === 'task') {
            this.activeScenerie = 'details';
            return;
        }
        if (this.activeScenerie === 'details' || this.activeScenerie === 'threadAdd') {
            this.actualThread = undefined;
            this.activeScenerie = 'list';
            return;
        }
        if (this.activeScenerie === 'threadDetails') {
            this.activeScenerie = 'details';
            return;
        }
    }
    onThreadDetailsClick() {
        this.saveScrollPosition();
        this.activeScenerie = 'threadDetails';
    }
    onThreadAddClick() {
        this.activeScenerie = 'threadAdd';
    }
    async handleSend(value, opt) {
        this.isSystemChangeScroll = true;
        this.lastTopicFilter = '';
        if (this.actualThread) {
            const isDirectMessage = this.isDirectMessage(this.actualThread);
            const isDirectMessageToAgent = this.actualThread.thread.openClawAgents?.some(agent => this.actualThread?.thread.users?.some(user => user.userId === agent.collabUserId));
            if (isDirectMessage && isDirectMessageToAgent && !value.startsWith('@@')) {
                const agentDM = this.actualThread?.thread.users.find((user) => user.userId !== this.userId);
                const alias = this.actualThread.thread.openClawAgents?.find((agentOC) => agentOC.collabUserId === agentDM?.userId)?.alias;
                if (alias)
                    value = `@@${alias.trim()} ${value.trim()}`;
            }
        }
        try {
            if (!opt.isSpecialMention) {
                await this.addMessage(value, opt.replyTo);
            }
            else {
                await this.addMessageIA(value, opt.agentName, opt.replyTo);
            }
            await this.scrollMessagesToBottom();
        }
        catch (err) {
            throw new Error(err.message);
        }
    }
    handlePromptResize(e) {
        if (this.wasMessagesAtBottom) {
            const chatEl = this.querySelector('.chat-container');
            if (chatEl)
                chatEl.scrollTop = chatEl.scrollHeight;
        }
    }
    async scrollMessagesToBottom() {
        this.isSystemChangeScroll = true;
        await this.updateComplete;
        await this.waitingForRenderCodesWebComponents();
        await this.nextFrame();
        if (this.messageContainer) {
            this.messageContainer.scrollTop = this.messageContainer.scrollHeight;
            this.wasMessagesAtBottom = true;
            this.updateTaskNotificationNavDirection();
        }
        this.isSystemChangeScroll = false;
    }
    async addMessage(prompt, replyTo) {
        if (!this.userId || !this.actualThread)
            return;
        this.unreadCountInSelectedThread = 0;
        const message = await this.createTempMessage(prompt, this.userId, this.actualThread.thread.threadId, replyTo);
        try {
            const context = {
                message,
                task: undefined,
                isTest: false
            };
            const contextToBot = await getBotsContext(this.actualThread.thread, prompt, context);
            const result = await msgAddMessage({
                content: prompt,
                threadId: this.actualThread.thread.threadId,
                userId: this.userId,
                ...(replyTo ? { replyTo } : {}),
                ...(contextToBot ? { contextToBot } : {})
            });
            if (!result.success || !result.response?.message) {
                throw new Error(result.error || 'Failed to send message');
            }
            message.isFailed = false;
            message.isFailedError = '';
            await this.updateMessage2(false, true, message, result.response.message, result.response.botOutputs);
            const responseMessages = result.response.messages;
            for (const responseMessage of responseMessages || []) {
                await this.updateMessage2(false, true, responseMessage, responseMessage, undefined);
            }
            await this.scrollMessagesToBottom();
        }
        catch (err) {
            message.isFailed = true;
            message.isFailedError = err?.message || 'Failed to send message';
            message.isLoading = false;
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            console.error('Error sending message:', err);
        }
    }
    async addMessageIA(prompt, agentName, replyTo) {
        if (!this.userId || !this.actualThread)
            return;
        this.unreadCountInSelectedThread = 0;
        const context = getTemporaryContext(this.actualThread.thread.threadId, this.userId, prompt);
        let agentToCall = AGENTDEFAULT;
        if (agentName)
            agentToCall = agentName;
        const message = await this.createTempMessage(prompt, this.userId, this.actualThread.thread.threadId, replyTo);
        try {
            context.message = message;
            environment.agents.executeAgent(agentToCall, context);
        }
        catch (err) {
            console.error('Error on send message:' + err.message);
            if (message.isLoading) {
                message.isLoading = false;
                message.isFailed = true;
                message.isFailedError = err.message;
                this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            }
        }
    }
    async updateMessageAI(context, updateThreadDB, oldContextCreateAt) {
        if (this.activeScenerie !== 'details')
            return;
        if (!context.message)
            return;
        const { content, createAt, orderAt, senderId, threadId, taskId, taskTitle, taskTitleTranslated, taskStatus, taskResults, taskResultsTranslated } = context.message;
        const createAt2 = oldContextCreateAt ? oldContextCreateAt : createAt;
        let messageAdded = this.actualMessages.find((item) => item.senderId === senderId &&
            item.createAt === createAt2 &&
            item.threadId === threadId);
        if (!messageAdded) {
            const newMessage = {
                content,
                createAt,
                orderAt,
                senderId,
                threadId,
                footers: []
            };
            if (updateThreadDB && this.actualThread) {
                const lastMessageText = `${senderId}:${content}`;
                const thread = await updateThread(threadId, this.actualThread.thread, lastMessageText, createAt, 0, createAt);
                if (this.actualThread)
                    this.actualThread.thread = thread;
            }
            if (taskId)
                newMessage.taskId = taskId;
            this.actualMessages.unshift({ context, lastChanged: new Date().getTime(), ...newMessage });
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            await addMessage(newMessage);
            this.requestUpdate();
        }
        else {
            messageAdded.content = content;
            messageAdded.senderId = senderId;
            messageAdded.createAt = createAt;
            messageAdded.threadId = threadId;
            messageAdded.orderAt = orderAt;
            // if (status) messageAdded.status = status;
            if (taskTitle)
                messageAdded.taskTitle = taskTitle;
            if (taskTitleTranslated)
                messageAdded.taskTitleTranslated = taskTitleTranslated;
            if (taskStatus)
                messageAdded.taskStatus = taskStatus;
            if (taskResults)
                messageAdded.taskResults = taskResults;
            if (taskResultsTranslated)
                messageAdded.taskResultsTranslated = taskResultsTranslated;
            messageAdded.context = context;
            messageAdded.isLoading = false;
            messageAdded.lastChanged = new Date().getTime();
            if (taskId)
                messageAdded.taskId = taskId;
            const cloned = structuredClone(messageAdded);
            delete cloned.context;
            delete cloned.isLoading;
            delete cloned.lastChanged;
            if (oldContextCreateAt)
                this.isSystemChangeScroll = true;
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            await addMessage(cloned);
            if (this.actualThread)
                await this.updateLastMessage(this.actualThread);
            this.requestUpdate();
        }
    }
    async createTempMessage(content, senderId, threadId, replyTo, taskId) {
        const now = new Date();
        const formattedDate = now.getUTCFullYear().toString()
            + String(now.getUTCMonth() + 1).padStart(2, '0')
            + String(now.getUTCDate()).padStart(2, '0')
            + String(now.getUTCHours()).padStart(2, '0')
            + String(now.getUTCMinutes()).padStart(2, '0')
            + String(now.getUTCSeconds()).padStart(2, '0')
            + "." + Math.floor(1000 + Math.random() * 9000);
        const newMessage = {
            content,
            createAt: formattedDate,
            orderAt: formattedDate,
            senderId,
            threadId,
            isLoading: true,
            isFailed: false,
            isFailedError: '',
            replyTo,
            footers: []
        };
        if (taskId)
            newMessage.taskId = taskId;
        this.actualMessages.push(newMessage);
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.requestUpdate();
        await this.scrollMessagesToBottom();
        return newMessage;
    }
    async updateMessage2(updateLastSyncThreadDB, updateLastMessageThreadDB, oldMessage, newMessage, outputs) {
        if (this.actualThread && (updateLastSyncThreadDB || updateLastMessageThreadDB)) {
            const lastMessageText = `${newMessage.senderId}:${newMessage.content}`;
            let thread = await updateThread(newMessage.threadId, this.actualThread.thread, updateLastMessageThreadDB ? lastMessageText : undefined, updateLastMessageThreadDB ? newMessage.createAt : undefined, 0, updateLastSyncThreadDB ? newMessage.createAt : undefined);
            thread = await updateLastMessageReadTime(newMessage.threadId, newMessage.createAt);
            if (this.actualThread)
                this.actualThread.thread = thread;
            notifyThreadChange(this.actualThread.thread);
        }
        const footerData = [];
        for await (let item of outputs || []) {
            const footerItem = {
                title: item.botId,
                lines: [item.output]
            };
            const module = await environment.agents.loadAgent(item.botId);
            if (module && module.afterBot && typeof module.afterBot === 'function') {
                const context = {
                    message: newMessage,
                    task: undefined,
                    isTest: false
                };
                try {
                    const response = await module.afterBot(context, item);
                    footerItem.lines = [response];
                }
                catch (err) {
                    footerItem.lines = [err.message];
                }
            }
            footerData.push(footerItem);
        }
        const alreadyExist = this.actualMessages.find(item => item.senderId === oldMessage.senderId &&
            item.createAt === oldMessage.createAt &&
            item.threadId === oldMessage.threadId);
        if (alreadyExist) {
            this.actualMessages = this.actualMessages.map(item => {
                if (item.senderId === oldMessage.senderId &&
                    item.createAt === oldMessage.createAt &&
                    item.threadId === oldMessage.threadId) {
                    const { isLoading, isFailed, isFailedError, ...rest } = { ...newMessage, isSame: oldMessage.isSame, footers: footerData };
                    return rest;
                }
                return item;
            });
        }
        else
            this.actualMessages.unshift({ ...newMessage, footers: footerData });
        const m = newMessage;
        delete m.isLoading;
        delete m.isFailed;
        delete m.isFailedError;
        delete m.isSame;
        if (outputs)
            m.footers = footerData;
        await addMessage(m);
        const messagesInDb = await getMessagesByThreadId(m.threadId, this.messagesLimit, 0);
        this.actualMessages = messagesInDb;
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.requestUpdate();
    }
    async onTaskClick(taskId, messageId, threadId, message) {
        this.saveScrollPosition();
        clearTaskNotification(taskId);
        this.requestUpdate();
        const task = await this.getTaskUpdate(taskId, messageId, threadId);
        addOrUpdateTask(task);
        this.actualTask = task;
        this.actualMessage = message;
        const messageId2 = `${this.actualThread?.thread.threadId}/${this.actualMessage?.createAt}`;
        let rc = await environment.tasks.openTaskDetails(messageId2, this.actualTask.PK || '', this.actualTask, this.actualMessage);
        if (this.hasStudioTaskDetailHost())
            return;
        if (!rc.openLocal)
            rc = this.createLocalTaskDetails(this.actualTask, this.actualMessage);
        if (!rc.openLocal)
            return;
        this.activeScenerie = 'task';
        this.elementTaskDetails = rc.element;
    }
    hasStudioTaskDetailHost() {
        const roots = [document];
        if (window.parent && window.parent !== window) {
            try {
                roots.push(window.parent.document);
            }
            catch {
                // Cross-origin parent is not inspectable; fall back to local behavior.
            }
        }
        return roots.some(root => !!root.querySelector('service-detail-100554'));
    }
    createLocalTaskDetails(task, message) {
        const element = document.createElement('collab-messages-task-info-102025');
        element.task = task;
        element.message = message;
        return { openLocal: true, element };
    }
    onReplyPreviewClick(ev) {
        const messageReply = this.messageContainer?.querySelector(`collab-messages-chat-message-102025[messageid="${ev.detail.messageId}"]`);
        if (!messageReply)
            return;
        messageReply.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    onReplyMessageClick(ev) {
        if (!ev.detail)
            return;
        const data = ev.detail;
        this.collabMessagesPrompt?.setReply({
            messageId: data.createAt,
            senderId: data.senderId,
            preview: data.content.slice(0, 80)
        });
    }
    async getTaskUpdate(taskId, createdAt, threadId) {
        if (!taskId || !createdAt || !threadId) {
            throw new Error('Invalid arguments for getTaskUpdate');
        }
        if (!this.userId) {
            throw new Error('Invalid userId');
        }
        const result = await msgGetTaskUpdate({
            taskId,
            messageId: this.normalizeTaskMessageId(threadId, createdAt),
            userId: this.userId
        });
        if (!result.success || !result.response?.task) {
            if (result.statusCode === 404) {
                await this.refreshThreadFromServer(threadId);
            }
            throw new Error(result.error || 'Failed to fetch task update');
        }
        return result.response.task;
    }
    normalizeTaskMessageId(threadId, messageIdOrOrderAt) {
        if (!messageIdOrOrderAt.includes('/'))
            return `${threadId}/${messageIdOrOrderAt}`;
        const parts = messageIdOrOrderAt.split('/').filter(Boolean);
        if (parts.length === 2)
            return messageIdOrOrderAt;
        return `${parts[0]}/${parts[parts.length - 1]}`;
    }
    normalizeMessageId(threadId, messageIdOrOrderAt) {
        const parts = messageIdOrOrderAt.split('/').filter(Boolean);
        const orderAt = parts[parts.length - 1] || messageIdOrOrderAt;
        return `${threadId}/${orderAt}`;
    }
    async refreshThreadFromServer(threadId) {
        if (!this.userId)
            return;
        await deleteAllMessagesFromThread(threadId);
        const response = await this.getThreadInfo(threadId, this.userId, '20000101000000.0000');
        await updateThread(response.thread.threadId, response.thread);
        if (response.users?.length)
            await updateUsers(response.users);
        if (response.messages?.length) {
            await addMessages(response.messages.map(message => ({ ...message, footers: [] })));
        }
        if (this.actualThread?.thread.threadId === threadId) {
            const messagesInDb = await getMessagesByThreadId(threadId, this.messagesLimit, 0);
            this.actualThread = {
                thread: response.thread,
                users: response.users || this.actualThread.users,
                messages: messagesInDb
            };
            this.actualMessages = messagesInDb;
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            this.requestUpdate();
        }
    }
    async getThreadInfo(threadId, userId, lastOrderAt) {
        const deviceId = loadNotificationDeviceId();
        try {
            const result = await msgGetThreadUpdates({
                threadId,
                userId,
                lastOrderAt,
                deviceId: deviceId || undefined
            });
            removeThreadFromSync(threadId);
            clearThreadNotification(threadId);
            if (!result.success) {
                if (result.statusCode === 403) {
                    throw new Error(result.error || 'Access denied to thread');
                }
                throw new Error(result.error || 'Failed to fetch thread updates');
            }
            if (!result.response) {
                throw new Error('Empty response while fetching thread updates');
            }
            return result.response;
        }
        catch (err) {
            throw new Error(err?.message || 'Unexpected error while fetching thread updates');
        }
    }
    saveScrollPosition() {
        if (this.messageContainer) {
            this.savedScrollTop = this.messageContainer.scrollTop;
        }
    }
    async restoreScrollPosition() {
        if (this.messageContainer) {
            await this.updateComplete;
            await this.waitingForRenderCodesWebComponents();
            this.messageContainer.scrollTop = this.savedScrollTop;
        }
    }
    onMessageChange(e) {
        const customEvent = e;
        const message = customEvent.detail;
        if (!this.actualThread || !message || message.threadId !== this.actualThread.thread.threadId)
            return;
        for (const item of Object.values(this.actualMessagesParsed)) {
            const find = item.find(m => m.createAt === message.createAt);
            if (find) {
                Object.assign(find, message);
                const item = this.messageContainer?.querySelector(`collab-messages-chat-message-102025[messageid="${message.createAt}"]`);
                if (item)
                    item['message'] = message;
                break;
            }
        }
    }
    onVisibilityChange() {
        if (this.activeScenerie === 'details') {
            this.checkNotificationsUnreadMessages();
        }
    }
    async verifyChatScroll() {
        if (!this.messageContainer || !this.isSystemChangeScroll)
            return;
        this.scrollLock = true;
        try {
            await this.updateComplete;
            await this.waitingForRenderCodesWebComponents();
            await this.nextFrame();
            const target = this.unreadEl;
            if (target) {
                target.scrollIntoView({ block: 'center' });
            }
            else {
                this.messageContainer.scrollTop = this.messageContainer.scrollHeight;
            }
        }
        finally {
            await this.nextFrame();
            this.scrollLock = false;
            this.isSystemChangeScroll = false;
        }
    }
    async delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    nextFrame() {
        return new Promise(resolve => requestAnimationFrame(() => resolve()));
    }
    async waitingForRenderCodesWebComponents() {
        await this.nextFrame();
        if (!this.messageContainer)
            return;
        const allMessages = Array.from(this.messageContainer.querySelectorAll('collab-messages-chat-message-102025'));
        await Promise.all(Array.from(allMessages)
            .map(el => el.updateComplete));
        await this.nextFrame();
        const allRichPreviews = Array.from(this.messageContainer.querySelectorAll('collab-messages-rich-preview-text-102025'));
        await Promise.all(Array.from(allRichPreviews)
            .map(el => el.updateComplete));
        await this.nextFrame();
        const allCodes = Array.from(this.messageContainer.querySelectorAll('collab-messages-text-code-102025'));
        await Promise.all(Array.from(allCodes)
            .map(el => el.whenRendered));
    }
};
__decorate([
    query('collab-messages-prompt-102025')
], CollabMessagesChat.prototype, "collabMessagesPrompt", void 0);
__decorate([
    query('.new-messages-label')
], CollabMessagesChat.prototype, "unreadEl", void 0);
__decorate([
    query('.chat-container')
], CollabMessagesChat.prototype, "messageContainer", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "isLoadingThread", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "filteredThreads", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "isThreadError", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "threadErrorMsg", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "lastTopicFilter", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "welcomeMessage", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "usersAvaliables", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "elementTaskDetails", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "taskNotificationNavDirection", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "group", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "userId", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "threadToOpen", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "taskToOpen", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "userDeviceId", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "activeScenerie", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "actualThread", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "actualTask", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "actualMessage", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "actualMessages", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "actualMessagesParsed", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "isLoadingMessages", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "searchTerm", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesChat.prototype, "userThreads", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesChat.prototype, "allThreads", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "lastMessageReaded", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "unreadCountInSelectedThread", void 0);
CollabMessagesChat = __decorate([
    customElement('collab-messages-chat-102025')
], CollabMessagesChat);
export { CollabMessagesChat };
