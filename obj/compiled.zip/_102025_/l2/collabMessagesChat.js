/// <mls fileReference="_102025_/l2/collabMessagesChat.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { repeat } from 'lit/directives/repeat.js';
import { customElement, property, state, query } from 'lit/decorators.js';
import { collab_chevron_left, collab_chevron_right, collab_gear, collab_plus, collab_folder_tree, collab_bell, collab_pin, collab_star, collab_paperclip, collab_circle_exclamation, collab_robot, collab_message, collab_xmark, collab_moments } from '/_102025_/l2/collabMessagesIcons.js';
import { hasUnreadMoments, markMomentsSeen, requestOpenTab } from '/_102025_/l2/collabMessagesMomentsUnread.js';
import { removeThreadFromSync, hasThreadNotificationPending, getPendingTaskNotificationsForThread, getThreadUpdateInBackground, checkIfNotificationUnread, markThreadReadLocally, isHelpCommand, isTestplayCommand, runNotificationTestplay } from '/_102025_/l2/collabMessagesSyncNotifications.js';
import { notifyThreadChange, notifyThreadCreate, notifyThreadNotification } from '/_102025_/l2/collabMessagesEvents.js';
import { isPersonalAgentDm, sendErrorMessage } from '/_102025_/l2/collabMessagesSendError.js';
import { shouldMarkOpenThreadRead } from '/_102025_/l2/collabMessagesReadState.js';
import { pickMessagesAfter, sliceWindowFromTarget } from '/_102025_/l2/collabMessagesChatWindow.js';
import { nextFollowupNotice } from '/_102025_/l2/collabMessagesFollowupNotice.js';
import { addOrUpdateTask, addMessages, addMessage, addThread, updateThread, updateUsers, updateMessage, getMessage, getMessagesByThreadId, getAllMessagesByThreadId, deleteAllMessagesFromThread, deleteTask, listUsers, getThread, updateLastMessageReadTime } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { getBotsContext, loadNotificationDeviceId, generateAgentAvatar, getTemporaryContext, formatTimestamp, changeFavIcon } from '/_102025_/l2/collabMessagesHelper.js';
import { msgGetMessagesAfter, msgGetMessagesBefore, msgGetMessage, msgGetTaskUpdate, msgGetThreadUpdates, msgAddMessage, msgCompleteAttachmentUpload, msgCreateAttachmentUpload, msgReportAttachmentUploadFailure, msgDeleteAttachment, msgUpdateMessage, post } from '/_102025_/l2/shared/api.js';
import { environment } from '/_102036_/l2/environmentContract.js';
import '/_102025_/l2/collabMessagesTask.js';
import '/_102025_/l2/collabMessagesTaskInfo.js';
import '/_102025_/l2/collabMessagesTopics.js';
import '/_102025_/l2/collabMessagesPrompt.js';
import '/_102025_/l2/collabMessagesAvatar.js';
import '/_102025_/l2/collabMessagesThreadDetails.js';
import '/_102025_/l2/collabMessagesUserModal.js';
import '/_102025_/l2/collabMessagesThreadModal.js';
import '/_102025_/l2/collabMessagesFilter.js';
import '/_102025_/l2/collabMessagesAdd.js';
import '/_102025_/l2/collabMessagesChatMessage.js';
import '/_102025_/l2/collabMessagesRichPreviewText.js';
import '/_102025_/l2/collabMessagesE01Memory.js';
import { AGENTDEFAULT } from '/_102025_/l2/collabMessagesHelper.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    btnAddParticipant: 'Adicionar participante',
    threadDetails: 'Detalhes da sala',
    threadAdd: 'Adicionar sala',
    msgNotSend: 'Mensagem não enviada*',
    noThreads: 'Nenhuma sala disponível no momento.',
    placeholderSearch: 'Digite para filtrar',
    threadArchived: 'A thread foi arquivada por [user] em [date]',
    threadDeleting: 'A thread foi deletada em [date]',
    archived: 'Arquivado',
    deleting: 'Deletando',
    deleted: 'Deletada',
    btnNext: 'Continuar',
    promptPlaceholder: '(@ para menções) (@@ para agentes)',
    today: 'Hoje',
    yesterday: 'Ontem',
    newMessages: 'Novas mensagens',
    lastMessagePrefix: 'Você',
    toolbarPins: 'Mensagens fixadas',
    toolbarSaved: 'Favoritos',
    toolbarReadReceipts: 'Follow-up',
    toolbarAttachments: 'Anexos',
    toolbarAgent: 'Agente de resumo',
    toolbarHelpTitle: 'Sobre o recurso',
    toolbarHelpOpen: 'Abrir ajuda',
    toolbarHelpBack: 'Voltar',
    toolbarHelpPinsTitle: 'Mensagens fixadas',
    toolbarHelpPinsText: 'Use para manter mensagens importantes acessiveis no topo da conversa. Quando houver itens, o botao navega entre eles.',
    toolbarHelpSavedTitle: 'Favoritos',
    toolbarHelpSavedText: 'Use para guardar mensagens importantes para voce. Os favoritos sao pessoais e aparecem apenas para o seu usuario.',
    toolbarHelpReadReceiptsTitle: 'Follow-up',
    toolbarHelpReadReceiptsText: 'Use para acompanhar mensagens que precisam de confirmação ou execução. Quando houver pendência para você, o botão chama atenção no toolbar.',
    toolbarHelpAttachmentsTitle: 'Anexos',
    toolbarHelpAttachmentsText: 'Use para navegar rapidamente pelas mensagens com arquivos, imagens, videos ou documentos anexados.',
    toolbarHelpAgentTitle: 'Agente de resumo',
    toolbarHelpAgentText: 'Este espaco esta preparado para recursos de agente que ajudam a reduzir ruido e destacar pontos importantes da conversa.',
    toolbarNavigationError: 'Não foi possível abrir a mensagem',
    replaceOldestPin: 'Já existem 3 mensagens fixadas. Substituir a mais antiga?',
    readOnlyThread: 'Você tem acesso somente leitura nesta sala.',
    forwardMessageTitle: 'Encaminhar mensagem',
    forwardDestinationLabel: 'Digite o nome do canal ou DM',
    forwardDestinationPlaceholder: '#canal ou @user',
    forwardEmpty: 'Nenhum canal ou DM encontrado',
    forwardCancel: 'Cancelar',
    forwardSend: 'Encaminhar',
    forwardSelectDestination: 'Selecione um destino',
    forwardPrefix: 'Mensagem encaminhada',
    taskTitlePrompt: 'Título da task',
    localCommandsHelp: 'Comandos disponíveis:\n/help — mostra esta ajuda\n/testplay — testa som, badge e notificação do sistema',
    personalMemory: 'Minha memória',
    backToConversation: 'Voltar para a conversa',
    newMoments: 'Você tem moments novos',
    couldNotOpenTask: 'Não foi possível abrir a tarefa: {erro}',
    jumpToLatest: 'Ir para a última mensagem',
    followupNoticeOne: 'Você tem 1 mensagem aguardando sua atenção.',
    followupNoticeMany: 'Você tem {n} mensagens aguardando sua atenção.',
    followupNoticeSee: 'Ver',
    openNora: 'Nora',
};
const message_en = {
    loading: 'Loading...',
    btnAddParticipant: 'Add Participant',
    threadDetails: 'Thread details',
    threadAdd: 'Add thread',
    msgNotSend: 'Message not sent*',
    noThreads: 'No threads available at the moment.',
    placeholderSearch: 'Type to filter',
    threadArchived: 'Thread is archived by [user] in [date]',
    threadDeleting: 'Thread was deleted in [date]',
    archived: 'Archived',
    deleting: 'Deleting',
    deleted: 'Deleted',
    btnNext: 'Next',
    promptPlaceholder: '(@ for mentions) (@@ for agents)',
    today: 'Today',
    yesterday: 'Yesterday',
    newMessages: 'New messages',
    lastMessagePrefix: 'You',
    toolbarPins: 'Pinned messages',
    toolbarSaved: 'Saved messages',
    toolbarReadReceipts: 'Follow-up',
    toolbarAttachments: 'Attachments',
    toolbarAgent: 'Summary agent',
    toolbarHelpTitle: 'About this feature',
    toolbarHelpOpen: 'Open help',
    toolbarHelpBack: 'Back',
    toolbarHelpPinsTitle: 'Pinned messages',
    toolbarHelpPinsText: 'Use this to keep important messages easy to reach at the top of the conversation. When there are items, the button navigates through them.',
    toolbarHelpSavedTitle: 'Saved messages',
    toolbarHelpSavedText: 'Use this to save important messages for yourself. Saved messages are personal and visible only to your user.',
    toolbarHelpReadReceiptsTitle: 'Follow-up',
    toolbarHelpReadReceiptsText: 'Use this to track messages that need read or execution confirmation. When you have a pending item, the toolbar button draws attention.',
    toolbarHelpAttachmentsTitle: 'Attachments',
    toolbarHelpAttachmentsText: 'Use this to quickly navigate messages with files, images, videos, or documents attached.',
    toolbarHelpAgentTitle: 'Summary agent',
    toolbarHelpAgentText: 'This area is prepared for agent features that help reduce noise and highlight important conversation points.',
    toolbarNavigationError: 'Could not open the message',
    replaceOldestPin: 'There are already 3 pinned messages. Replace the oldest one?',
    readOnlyThread: 'You have read-only access in this room.',
    forwardMessageTitle: 'Forward message',
    forwardDestinationLabel: 'Type the channel or DM name',
    forwardDestinationPlaceholder: '#channel or @user',
    forwardEmpty: 'No channel or DM found',
    forwardCancel: 'Cancel',
    forwardSend: 'Forward',
    forwardSelectDestination: 'Select a destination',
    forwardPrefix: 'Forwarded message',
    taskTitlePrompt: 'Task title',
    localCommandsHelp: 'Available commands:\n/help — shows this help\n/testplay — tests sound, badge, and system notification',
    personalMemory: 'My memory',
    backToConversation: 'Back to conversation',
    newMoments: 'You have new moments',
    couldNotOpenTask: 'Could not open the task: {error}',
    jumpToLatest: 'Go to latest message',
    followupNoticeOne: 'You have 1 message waiting for your attention.',
    followupNoticeMany: 'You have {n} messages waiting for your attention.',
    followupNoticeSee: 'See',
    openNora: 'Nora',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
let CollabMessagesChat = class CollabMessagesChat extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-chat-102025 {
  position: relative;
  display: flex;
  flex-direction: column;
  height: calc(100% - 52px);
  width: 375px;
  background: var(--cm-panel-bg, #ffffff);
  color: var(--cm-text, #111827);
  font-family: var(--font-family-primary);
}
collab-messages-chat-102025.custom {
  height: 100%;
}
collab-messages-chat-102025 .loader {
  display: inline-block;
  width: 10px;
  height: 10px;
  border: 2px solid #ccc;
  border-top: 2px solid #333;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
collab-messages-chat-102025 .header {
  padding: 0 0.8rem;
  height: 58px;
  min-height: 58px;
  color: var(--cm-text-on-green, #ffffff);
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: var(--font-size-16);
  text-transform: none;
  background: var(--cm-green-dark, #007a3d);
  border-bottom: 1px solid rgba(255, 255, 255, 0.14);
  box-shadow: var(--cm-shadow-sm, 0 1px 3px rgba(0, 0, 0, 0.14));
}
collab-messages-chat-102025 .header svg {
  fill: currentColor;
}
collab-messages-chat-102025 .header collab-messages-filter-102025 {
  width: calc(100% - 50px);
}
collab-messages-chat-102025 .header .header-title {
  max-width: 260px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
collab-messages-chat-102025 .header .header-actions {
  margin-left: auto;
  margin-right: 1rem;
  display: flex;
  gap: 0.5rem;
}
collab-messages-chat-102025 .header .header-actions span {
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  border-radius: 50%;
}
collab-messages-chat-102025 .header .header-actions span:hover {
  background: rgba(255, 255, 255, 0.12);
}
collab-messages-chat-102025 .header .header-actions .personal-memory-entry {
  min-height: 32px;
  border: 1px solid rgba(255, 255, 255, 0.55);
  border-radius: var(--cm-radius-pill, 9999px);
  padding: 0.25rem 0.55rem;
  background: transparent;
  color: inherit;
  font: inherit;
  font-size: 12px;
  cursor: pointer;
}
collab-messages-chat-102025 .header .header-actions .personal-memory-entry:focus-visible {
  outline: 3px solid var(--focus-ring, #ffffff);
  outline-offset: 2px;
}
collab-messages-chat-102025 .header > span {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  flex: 1;
  justify-content: center;
}
collab-messages-chat-102025 .header .personal-memory-back {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  flex: 1;
  border: 0;
  background: transparent;
  color: inherit;
  font: inherit;
  cursor: pointer;
}
collab-messages-chat-102025 .header .personal-memory-back svg {
  fill: currentColor;
}
collab-messages-chat-102025 .header .personal-memory-back:focus-visible {
  outline: 3px solid var(--focus-ring, #ffffff);
  outline-offset: 2px;
}
collab-messages-chat-102025 .header:has(collab-messages-filter-102025) {
  height: 70px;
  min-height: 70px;
  padding: 0 12px;
  background: var(--cm-panel-bg, #ffffff);
  color: var(--cm-text, #111827);
  border-bottom: 1px solid var(--cm-border, #e2e7e3);
  box-shadow: none;
}
collab-messages-chat-102025 .header:has(collab-messages-filter-102025) collab-messages-filter-102025 {
  width: calc(100% - 46px);
}
collab-messages-chat-102025 .header:has(collab-messages-filter-102025) .header-actions {
  margin-right: 0;
}
collab-messages-chat-102025 .header:has(collab-messages-filter-102025) .header-actions span {
  color: var(--cm-green-dark, #007a3d);
}
collab-messages-chat-102025 .header:has(collab-messages-filter-102025) .header-actions span:hover {
  background: rgba(0, 143, 76, 0.08);
}
collab-messages-chat-102025 .thread-toolbar {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.35rem;
  min-height: 34px;
  padding: 0.25rem 0.45rem;
  border-bottom: 1px solid var(--cm-border, #e2e7e3);
  background: var(--cm-panel-muted, #f3f7f4);
  color: var(--cm-text, #111827);
  flex-shrink: 0;
}
collab-messages-chat-102025 .thread-toolbar-btn {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 0.18rem;
  min-width: 36px;
  height: 26px;
  padding: 0 0.42rem;
  border: 1px solid var(--cm-border, #e2e7e3);
  border-radius: var(--cm-radius-pill, 9999px);
  background: var(--cm-panel-bg, #ffffff);
  color: var(--cm-green-dark, #007a3d);
  cursor: pointer;
  line-height: 1;
}
collab-messages-chat-102025 .thread-toolbar-btn svg {
  width: 14px;
  height: 14px;
  fill: currentColor;
  stroke: currentColor;
}
collab-messages-chat-102025 .thread-toolbar-btn:hover,
collab-messages-chat-102025 .thread-toolbar-btn.active {
  border-color: var(--cm-green, #008f4c);
  color: var(--cm-green-dark, #007a3d);
  background: rgba(30, 30, 30, 0.18);
}
collab-messages-chat-102025 .thread-toolbar-btn.important {
  border-color: var(--status-warning-text);
  color: var(--status-warning-text);
}
collab-messages-chat-102025 .thread-toolbar-btn.attention {
  animation: toolbarAttentionPulse 1.6s ease-in-out infinite;
}
collab-messages-chat-102025 .thread-toolbar-btn.loading {
  cursor: progress;
  opacity: 0.72;
}
collab-messages-chat-102025 .thread-toolbar-btn.error {
  border-color: #d92d20;
  color: #d92d20;
}
@keyframes toolbarAttentionPulse {
  0% {
    box-shadow: 0 0 0 0 color-mix(in srgb, var(--status-warning-text) 45%, transparent);
  }
  70% {
    box-shadow: 0 0 0 7px transparent;
  }
  100% {
    box-shadow: 0 0 0 0 transparent;
  }
}
collab-messages-chat-102025 .toolbar-counter {
  font-size: var(--font-size-12);
  font-weight: 700;
  min-width: 8px;
}
collab-messages-chat-102025 .toolbar-alert {
  position: absolute;
  top: -6px;
  right: -3px;
  color: var(--status-warning-text);
  font-weight: 700;
  font-size: var(--font-size-16);
  line-height: 1;
}
collab-messages-chat-102025 .thread-toolbar-btn.error .toolbar-alert {
  color: #d92d20;
}
collab-messages-chat-102025 .toolbar-loading {
  width: 8px;
  height: 8px;
  border: 1px solid currentColor;
  border-top-color: transparent;
  border-radius: 50%;
  animation: toolbarLoadingSpin 0.7s linear infinite;
}
@keyframes toolbarLoadingSpin {
  to {
    transform: rotate(360deg);
  }
}
collab-messages-chat-102025 .read-only-thread {
  padding: 0.65rem 0.8rem;
  border-top: 1px solid var(--cm-border, #e2e7e3);
  background: var(--cm-panel-muted, #f3f7f4);
  color: var(--cm-text-muted, #5b635f);
  font-size: var(--font-size-12);
  text-align: center;
}
collab-messages-chat-102025 .forward-message-scenario {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  height: 100%;
  padding: 1rem;
  color: var(--cm-text, #111827);
  overflow: hidden;
}
collab-messages-chat-102025 .forward-message-scenario label {
  font-size: var(--font-size-12);
  font-weight: 700;
}
collab-messages-chat-102025 .forward-message-scenario input[type="search"] {
  width: 100%;
  padding: 0.55rem 0.75rem;
  border: 1px solid var(--cm-border, #e2e7e3);
  border-radius: 6px;
  background: var(--cm-input-bg, #ffffff);
  color: var(--cm-text, #111827);
  outline: none;
}
collab-messages-chat-102025 .forward-message-scenario .forward-error {
  color: var(--status-error-text);
  font-size: var(--font-size-12);
}
collab-messages-chat-102025 .forward-destination-list {
  flex: 1;
  overflow-y: auto;
  list-style: none;
  margin: 0;
  padding: 0;
  border: 1px solid var(--cm-border, #e2e7e3);
  border-radius: 6px;
  background: var(--cm-panel-bg, #ffffff);
}
collab-messages-chat-102025 .forward-destination-list li {
  border-bottom: 1px solid var(--cm-border, #e2e7e3);
}
collab-messages-chat-102025 .forward-destination-list li:last-child {
  border-bottom: none;
}
collab-messages-chat-102025 .forward-destination-list button {
  width: 100%;
  display: flex;
  align-items: center;
  gap: 0.65rem;
  border: none;
  background: transparent;
  color: var(--cm-text, #111827);
  padding: 0.65rem;
  text-align: left;
  cursor: pointer;
}
collab-messages-chat-102025 .forward-destination-list button:hover,
collab-messages-chat-102025 .forward-destination-list button.selected {
  background: var(--cm-panel-muted, #f3f7f4);
}
collab-messages-chat-102025 .forward-destination-avatar {
  width: 34px;
  height: 34px;
  border-radius: 12px;
  border: 1px solid var(--cm-border, #e2e7e3);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  flex-shrink: 0;
}
collab-messages-chat-102025 .forward-destination-avatar img,
collab-messages-chat-102025 .forward-destination-avatar svg {
  width: 100%;
  height: 100%;
  object-fit: cover;
  fill: currentColor;
}
collab-messages-chat-102025 .forward-destination-name {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
collab-messages-chat-102025 .forward-empty {
  padding: 0.8rem;
  color: var(--cm-text-muted, #5b635f);
  font-size: var(--font-size-12);
}
collab-messages-chat-102025 .forward-actions {
  display: flex;
  justify-content: flex-end;
  gap: 0.5rem;
}
collab-messages-chat-102025 .forward-actions button {
  display: inline-flex;
  align-items: center;
  gap: 0.35rem;
  border: 1px solid var(--cm-border, #e2e7e3);
  border-radius: 6px;
  padding: 0.5rem 0.75rem;
  cursor: pointer;
  color: var(--cm-text, #111827);
  background: var(--cm-panel-bg, #ffffff);
}
collab-messages-chat-102025 .forward-actions button.primary {
  background: var(--button-primary-bg);
  color: var(--cm-text-on-green, #ffffff);
  border-color: var(--button-primary-bg);
}
collab-messages-chat-102025 .forward-actions button:disabled {
  cursor: default;
  opacity: 0.55;
}
collab-messages-chat-102025 .forward-actions button svg {
  width: 14px;
  height: 14px;
  fill: currentColor;
}
collab-messages-chat-102025 .toolbar-help-scenario {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  height: 100%;
  padding: 1rem;
  color: var(--cm-text, #111827);
}
collab-messages-chat-102025 .toolbar-help-scenario .toolbar-help-icon {
  width: 44px;
  height: 44px;
  border-radius: 8px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  background: var(--cm-panel-muted, #f3f7f4);
  color: var(--cm-green, #008f4c);
}
collab-messages-chat-102025 .toolbar-help-scenario .toolbar-help-icon svg {
  width: 24px;
  height: 24px;
  fill: currentColor;
}
collab-messages-chat-102025 .toolbar-help-scenario h3 {
  margin: 0;
  font-size: var(--font-size-16);
}
collab-messages-chat-102025 .toolbar-help-scenario p {
  margin: 0;
  line-height: 1.45;
  color: var(--cm-text-muted, #5b635f);
}
collab-messages-chat-102025 .toolbar-help-scenario button {
  align-self: flex-start;
  display: inline-flex;
  align-items: center;
  gap: 0.35rem;
  border: 1px solid var(--cm-border, #e2e7e3);
  border-radius: 6px;
  padding: 0.5rem 0.75rem;
  cursor: pointer;
  color: var(--cm-text, #111827);
  background: var(--cm-panel-bg, #ffffff);
}
collab-messages-chat-102025 .toolbar-help-scenario button svg {
  width: 14px;
  height: 14px;
  fill: currentColor;
}
collab-messages-chat-102025 .welcome-message {
  padding: 1rem;
}
collab-messages-chat-102025 .welcome-message button {
  background-color: var(--button-primary-bg);
  border-radius: 8px;
  border: none;
  box-shadow: 0px 1px 3px 0px var(--border-default);
  display: flex;
  flex-direction: row;
  justify-content: center;
  gap: 0.2rem;
  font-weight: 700;
  align-items: center;
  height: 40px;
  transition: height 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
  padding: 0.5rem;
  color: var(--cm-text-on-green, #ffffff);
  cursor: pointer;
  width: 100%;
}
collab-messages-chat-102025 .welcome-message button:hover {
  background-color: var(--button-primary-bg-hover);
}
collab-messages-chat-102025 .thread-search {
  width: 100%;
  padding: 0 0.2rem;
}
collab-messages-chat-102025 .thread-search input[type="search"] {
  width: 100%;
  min-height: 38px;
  padding: 0.45rem 1rem;
  font-family: var(--font-family-primary);
  font-size: 0.95rem;
  border: 1px solid rgba(255, 255, 255, 0.35);
  border-radius: var(--cm-radius-pill, 9999px);
  outline: none;
  background: var(--cm-input-bg, #ffffff);
  color: var(--cm-text, #111827);
  transition: border-color 0.2s, box-shadow 0.2s, background-color 0.2s;
  box-shadow: 0 0 0 2px transparent;
}
collab-messages-chat-102025 .thread-search input[type="search"]::placeholder {
  color: var(--cm-text-muted, #5b635f);
}
collab-messages-chat-102025 .thread-search input[type="search"]:focus {
  background: var(--cm-input-bg, #ffffff);
  border-color: var(--cm-border, #e2e7e3);
  box-shadow: 0 0 0 3px rgba(0, 143, 76, 0.12);
}
collab-messages-chat-102025 .nora-entry {
  display: flex;
  align-items: center;
  width: calc(100% - var(--space-16));
  margin: var(--space-8) var(--space-8) 0;
  padding: var(--space-8) var(--space-16);
  border: 1px solid var(--border-default);
  border-radius: var(--radius-medium);
  background: var(--surface-bg);
  color: var(--text-strong);
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-bold);
  text-align: left;
  cursor: pointer;
}
collab-messages-chat-102025 .nora-entry:disabled {
  cursor: default;
  opacity: 0.6;
}
collab-messages-chat-102025 .nora-entry:focus-visible {
  outline: 3px solid var(--link-text);
  outline-offset: 2px;
}
collab-messages-chat-102025 .nora-open-error {
  margin: var(--space-8) var(--space-16) 0;
  color: var(--text-strong);
  font-size: var(--font-size-16);
}
collab-messages-chat-102025 .moments-new-card {
  display: flex;
  align-items: center;
  gap: var(--space-8);
  width: calc(100% - var(--space-16));
  margin: var(--space-8) var(--space-8) 0;
  padding: var(--space-8) var(--space-16);
  border: 1px solid var(--border-default);
  border-radius: var(--radius-medium);
  background: var(--surface-bg);
  color: var(--text-strong);
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-bold);
  text-align: left;
  cursor: pointer;
}
collab-messages-chat-102025 .moments-new-card svg {
  width: 24px;
  height: 24px;
  flex: 0 0 auto;
  fill: currentColor;
}
collab-messages-chat-102025 .moments-new-card:hover {
  background: var(--surface-bg-hover);
}
collab-messages-chat-102025 .moments-new-card:focus-visible {
  outline: 3px solid var(--link-text);
  outline-offset: 2px;
}
collab-messages-chat-102025 .thread-list {
  list-style: none;
  margin: 0;
  padding: 0;
  overflow-y: auto;
  overflow-x: hidden;
  width: 100%;
  background: var(--cm-panel-bg, #ffffff);
}
collab-messages-chat-102025 .thread-list .archived-title {
  background: var(--cm-panel-muted, #f3f7f4);
  text-align: center;
  text-transform: uppercase;
  font-size: var(--font-size-16);
  color: var(--cm-text-muted, #5b635f);
}
collab-messages-chat-102025 .thread-list .unread-count {
  background-color: var(--cm-green, #008f4c);
  color: var(--cm-text-on-green, #ffffff);
  font-size: 0.75rem;
  font-weight: bold;
  padding: 0.2rem 0.48rem;
  border-radius: var(--cm-radius-pill, 9999px);
  margin-left: 1rem;
  white-space: nowrap;
}
collab-messages-chat-102025 .thread-list .thread-group details:not([open]) {
  background: var(--cm-panel-muted, #f3f7f4);
}
collab-messages-chat-102025 .thread-list .thread-group.has-notification summary,
collab-messages-chat-102025 .thread-list .thread-item.has-notification {
  background-color: rgba(174, 232, 196, 0.28);
}
collab-messages-chat-102025 .thread-list .thread-group.has-notification .thread-group-name,
collab-messages-chat-102025 .thread-list .thread-item.has-notification .thread-name {
  font-weight: 700;
}
collab-messages-chat-102025 .thread-list .thread-group.has-notification .last-group-message,
collab-messages-chat-102025 .thread-list .thread-item.has-notification .last-message {
  color: var(--cm-text, #111827);
}
collab-messages-chat-102025 .thread-list .tasks-pendings-count {
  position: relative;
  display: inline-block;
  font-size: 20px;
  fill: var(--status-warning-text);
  color: var(--status-warning-text);
  margin-right: 0.5rem;
}
collab-messages-chat-102025 .thread-list .tasks-pendings-count .notification-badge {
  position: absolute;
  top: -1px;
  right: -3px;
  background: red;
  color: white;
  border-radius: 50%;
  padding: 0.1em 0.1em;
  font-size: 0.49em;
  font-weight: bold;
  line-height: 1;
  min-width: 1em;
  text-align: center;
}
collab-messages-chat-102025 .thread-list .thread-group summary {
  cursor: pointer;
  list-style: none;
  height: 76px;
  transition: background-color 0.2s;
  display: flex;
  align-items: center;
  padding: 0 12px;
  position: relative;
  width: 100%;
  box-sizing: border-box;
  border-bottom: 1px solid var(--cm-border, #e2e7e3);
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-item-header {
  display: flex;
  justify-content: space-between;
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-item-header .thread-group-name {
  font-size: 1rem;
  font-weight: 700;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--cm-text, #111827);
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-item-header .last-group-update {
  font-size: 0.875rem;
  color: var(--cm-text-muted, #5b635f);
  white-space: nowrap;
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-content {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  padding: 0 0 0 12px;
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-avatar {
  width: 52px;
  height: 52px;
  border-radius: 50%;
  background: var(--cm-green-avatar, #cfe9d8);
  color: var(--cm-green, #008f4c);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-avatar svg {
  fill: currentColor;
  width: 28px;
  height: 28px;
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-avatar img {
  border-radius: 50%;
  width: 100%;
  height: 100%;
  object-fit: cover;
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-summary {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
collab-messages-chat-102025 .thread-list .thread-group summary .thread-group-summary .last-group-message {
  font-size: 0.875rem;
  color: var(--cm-text-muted, #5b635f);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  flex: 1;
}
collab-messages-chat-102025 .thread-list .thread-group summary::-webkit-details-marker {
  display: none;
}
collab-messages-chat-102025 .thread-item:hover {
  background-color: var(--cm-panel-muted, #f3f7f4);
}
collab-messages-chat-102025 .thread-item {
  cursor: pointer;
  height: 76px;
  transition: background-color 0.2s;
  display: flex;
  align-items: center;
  padding: 0 12px;
  position: relative;
  width: 100%;
  box-sizing: border-box;
  border-bottom: 1px solid var(--cm-border, #e2e7e3);
}
collab-messages-chat-102025 .thread-item .back-button {
  cursor: pointer;
}
collab-messages-chat-102025 .thread-item .avatar {
  flex: 0 0 auto;
  width: 48px;
  height: 48px;
  border-radius: 50%;
  margin-right: 1rem;
}
collab-messages-chat-102025 .thread-item .thread-content {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  padding: 0 0 0 12px;
}
collab-messages-chat-102025 .thread-item .thread-item-avatar {
  width: 52px;
  height: 52px;
  border-radius: 50%;
  border: none;
  background: var(--cm-green-avatar, #cfe9d8);
  color: var(--cm-green, #008f4c);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  overflow: hidden;
}
collab-messages-chat-102025 .thread-item .thread-item-avatar img,
collab-messages-chat-102025 .thread-item .thread-item-avatar svg {
  border-radius: 50%;
  width: 100%;
  height: 100%;
  object-fit: cover;
}
collab-messages-chat-102025 .thread-item .thread-item-header {
  display: flex;
  justify-content: space-between;
}
collab-messages-chat-102025 .thread-item .thread-item-header .thread-name {
  font-size: 1rem;
  font-weight: 700;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--cm-text, #111827);
}
collab-messages-chat-102025 .thread-item .thread-item-header .last-update,
collab-messages-chat-102025 .thread-item .thread-item-header .archived-at {
  font-size: 0.875rem;
  color: var(--cm-text-muted, #5b635f);
  white-space: nowrap;
}
collab-messages-chat-102025 .thread-item .thread-summary {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
collab-messages-chat-102025 .thread-item .thread-summary .last-message {
  font-size: 0.875rem;
  color: var(--cm-text-muted, #5b635f);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  flex: 1;
}
collab-messages-chat-102025 .unread-messages {
  background: radial-gradient(circle at center, #868686 0%, rgba(255, 255, 255, 0.6) 70%, rgba(255, 255, 255, 0) 100%);
  position: absolute;
  width: 100%;
  top: 50px;
  right: 0;
  color: #FFFFFF;
  text-align: center;
  text-transform: uppercase;
  font-size: 16px;
  animation: pulseLoading 1.5s infinite ease-in-out;
}
collab-messages-chat-102025 .new-messages-label {
  display: flex;
  justify-content: center;
  align-self: center;
  background: var(--cm-date-bg, rgba(255, 255, 255, 0.92));
  color: var(--cm-text-muted, #5b635f);
  text-transform: uppercase;
  font-size: 10px;
  font-weight: bold;
  margin: 5px 0 7px;
  padding: 3px 9px;
  border-radius: var(--cm-radius-pill, 9999px);
  box-shadow: var(--cm-shadow-sm, 0 1px 3px rgba(0, 0, 0, 0.14));
}
collab-messages-chat-102025 .error-messages {
  position: absolute;
  top: 50px;
  left: 0;
  padding-left: 1rem;
  background: var(--surface-alt-bg);
  color: var(--status-error-text);
  font-size: var(--font-size-16);
}
@keyframes pulseLoading {
  0% {
    opacity: 0.6;
  }
  50% {
    opacity: 1;
  }
  100% {
    opacity: 0.6;
  }
}
collab-messages-chat-102025 .chat-container {
  display: flex;
  flex: 1;
  flex-direction: column;
  padding: 10px 10px calc(10px + 1em);
  overflow-y: auto;
  overflow-x: hidden;
  max-height: 100%;
  background-color: var(--cm-chat-bg, #eef5f0);
  background-image: linear-gradient(90deg, transparent 16px, var(--cm-chat-pattern, rgba(0, 122, 61, 0.026)) 16px, var(--cm-chat-pattern, rgba(0, 122, 61, 0.026)) 17px, transparent 17px), linear-gradient(transparent 16px, var(--cm-chat-pattern, rgba(0, 122, 61, 0.026)) 16px, var(--cm-chat-pattern, rgba(0, 122, 61, 0.026)) 17px, transparent 17px);
  background-size: 40px 40px;
}
collab-messages-chat-102025 .chat-container .message-time {
  align-self: center;
  text-align: center;
  font-size: 0.75rem;
  color: var(--cm-text-muted, #5b635f);
  margin: 4px 0 7px;
  padding: 4px 10px;
  background: var(--cm-date-bg, rgba(255, 255, 255, 0.9));
  border-radius: var(--cm-radius-pill, 9999px);
  box-shadow: var(--cm-shadow-sm, 0 1px 3px rgba(0, 0, 0, 0.14));
}
collab-messages-chat-102025 .chat-container .followup-notice {
  align-self: center;
  display: flex;
  align-items: center;
  gap: 8px;
  max-width: 76%;
  margin: 8px 0;
  padding: 8px 12px;
  text-align: center;
  font-size: 0.75rem;
  color: var(--cm-text-muted, #5b635f);
  background: var(--cm-date-bg, rgba(255, 255, 255, 0.9));
  border: 1px solid var(--border-subtle);
  border-radius: var(--cm-radius-pill, 9999px);
  box-shadow: var(--cm-shadow-sm, 0 1px 3px rgba(0, 0, 0, 0.14));
}
collab-messages-chat-102025 .chat-container .followup-notice svg {
  flex: 0 0 auto;
  fill: var(--cm-green, #008f4c);
}
collab-messages-chat-102025 .chat-container .followup-notice-see {
  flex: 0 0 auto;
  border: 1px solid var(--border-subtle);
  border-radius: var(--cm-radius-pill, 9999px);
  background: var(--cm-panel-bg, #ffffff);
  color: var(--cm-green, #008f4c);
  font-size: 0.75rem;
  padding: 2px 10px;
  cursor: pointer;
}
collab-messages-chat-102025 .jump-to-latest {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  bottom: 86px;
  z-index: 5;
  width: 38px;
  height: 38px;
  border: 1px solid var(--border-subtle);
  border-radius: 50%;
  background: var(--cm-panel-bg, #ffffff);
  color: var(--cm-green, #008f4c);
  box-shadow: rgba(0, 0, 0, 0.22) 0 2px 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: background-color 0.15s ease;
}
collab-messages-chat-102025 .jump-to-latest:hover {
  background: var(--cm-panel-muted, #f3f7f4);
}
collab-messages-chat-102025 .task-notification-nav {
  position: absolute;
  right: 18px;
  bottom: 86px;
  z-index: 5;
  width: 38px;
  height: 38px;
  border: 1px solid var(--border-subtle);
  border-radius: 50%;
  background: var(--cm-panel-bg, #ffffff);
  color: var(--cm-green, #008f4c);
  box-shadow: rgba(0, 0, 0, 0.22) 0 2px 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: transform 0.15s ease, background-color 0.15s ease;
}
collab-messages-chat-102025 .task-notification-nav:hover {
  background: var(--cm-panel-muted, #f3f7f4);
  transform: translateY(-1px);
}
`);
        this.msg = messages['en'];
        this.isLoadingThread = false;
        this.filteredThreads = { active: [], archived: [], deleted: [], deleting: [] };
        this.isThreadError = false;
        this.threadErrorMsg = '';
        this.lastTopicFilter = '';
        this.welcomeMessage = '';
        this.usersAvaliables = [];
        this.taskNotificationNavDirection = '';
        this.toolbarView = {};
        this.group = 'CONNECT';
        this.e01RootSessionKey = '';
        this.activeScenerie = 'list';
        this.actualMessages = [];
        this.actualMessagesParsed = {};
        this.isLoadingMessages = false;
        this.searchTerm = '';
        this.userThreads = {};
        this.allThreads = [];
        this.lastMessageReaded = '';
        this.unreadCountInSelectedThread = 0;
        this.noraOpening = false;
        this.noraOpenError = '';
        this.forwardDestinationQuery = '';
        this.forwardDestinationThreadId = '';
        this.forwardError = '';
        this.isForwardingMessage = false;
        this.highlightedMessageId = '';
        this.toolbarNavigationError = '';
        this.cachedToolbarMessages = [];
        this.showPersonalMemory = false;
        this.e01SessionEpoch = 0;
        this.hasNewMoments = false;
        this.showJumpToLatest = false;
        this.followupNotice = { visible: false, lastCount: 0 };
        this.isSystemChangeScroll = false;
        this.savedScrollTop = 0;
        this.hasMoreMessagesLocalDB = true;
        this.hasMoreMessagesBefore = false;
        this.hasMoreMessagesAfter = false;
        this.messagesLimit = 50;
        this.isLoadingMoreMessages = false;
        this.isChangeTopics = false;
        this.wasMessagesAtBottom = true;
        this.ignoreToolbarScrollClearUntil = 0;
        this.isToolbarAutoScroll = false;
        this.closeToolbarHelp = () => {
            this.toolbarHelpKind = undefined;
            this.activeScenerie = 'details';
        };
        this.clearToolbarSelection = () => {
            if (Object.keys(this.toolbarView).length === 0 && !this.highlightedMessageId)
                return;
            this.toolbarView = {};
            this.highlightedMessageId = '';
            this.isToolbarAutoScroll = false;
            if (this.toolbarAutoScrollTimer)
                clearTimeout(this.toolbarAutoScrollTimer);
        };
        this.onNewMomentsClick = async () => {
            await markMomentsSeen();
            this.hasNewMoments = false;
            requestOpenTab('MOMENTS');
        };
        this.openPersonalMemory = async (event) => {
            event.stopPropagation();
            if (!this.isE01Thread())
                return;
            this.personalMemoryTrigger = event.currentTarget;
            this.showPersonalMemory = true;
            await this.updateComplete;
            this.querySelector('.personal-memory-back')?.focus();
        };
        this.onE01OpenSource = async (event) => {
            const ref = event.detail?.messageId;
            const threadId = this.actualThread?.thread.threadId;
            const sessionKey = this.getE01SessionKey();
            const isCurrent = () => this.getE01SessionKey() === sessionKey && this.actualThread?.thread.threadId === threadId;
            if (!ref || !threadId || !ref.startsWith(`${threadId}/`) || !isCurrent())
                return;
            await this.closePersonalMemory(false);
            if (!isCurrent())
                return;
            await this.navigateToMessageId(ref, 'agent', isCurrent, { persist: false, forceServer: true });
        };
        this.onForwardDestinationInput = (ev) => {
            this.forwardDestinationQuery = ev.target.value;
            this.forwardDestinationThreadId = '';
            this.forwardError = '';
        };
        this.cancelForwardMessage = () => {
            this.forwardMessageSource = undefined;
            this.forwardDestinationQuery = '';
            this.forwardDestinationThreadId = '';
            this.forwardError = '';
            this.isForwardingMessage = false;
            this.activeScenerie = 'details';
        };
        this.confirmForwardMessage = async () => {
            if (!this.userId || !this.forwardMessageSource)
                return;
            const targetThread = this.allThreads.find(thread => thread.threadId === this.forwardDestinationThreadId);
            if (!targetThread) {
                this.forwardError = this.msg.forwardSelectDestination;
                return;
            }
            this.isForwardingMessage = true;
            const message = this.forwardMessageSource;
            const content = `${this.msg.forwardPrefix}\n${this.createMessageLink(message)}\n\n${message.content}`;
            try {
                const result = await msgAddMessage({
                    userId: this.userId,
                    threadId: targetThread.threadId,
                    content,
                    senderDeviceId: loadNotificationDeviceId() || undefined
                });
                if (!result.success || !result.response?.message) {
                    throw new Error(result.error || 'Failed to forward message');
                }
                await addMessage(result.response.message);
                const thread = await getThread(targetThread.threadId);
                if (thread) {
                    const lastMessageText = `${this.userId}:${content}`;
                    let updatedThread = await updateThread(targetThread.threadId, thread, lastMessageText, result.response.message.createAt, 0, result.response.message.createAt);
                    updatedThread = await updateLastMessageReadTime(targetThread.threadId, result.response.message.createAt);
                    notifyThreadChange(updatedThread);
                }
                this.cancelForwardMessage();
            }
            catch (err) {
                this.forwardError = err?.message || 'Failed to forward message';
                this.isForwardingMessage = false;
            }
        };
        this.onTaskChange = async (e) => {
            const customEvent = e;
            const message = customEvent.detail.context.message;
            const task = customEvent.detail.context.task;
            const thId = message?.threadId;
            if (!this.actualThread || !thId || thId !== this.actualThread.thread.threadId)
                return;
            await this.updateMessageAI(customEvent.detail.context, false, customEvent.detail.oldContextCreateAt);
            if (task)
                await addOrUpdateTask(customEvent.detail.context.task);
            if (task && customEvent.detail.oldContextCreateAt)
                await this.openCreatedTaskDetails(task, message);
        };
        /*
        private onTaskDetailsClose = async (_e: Event) => {
            const taskId = (_e as CustomEvent).detail;
            clearServiceDetails();
            if (taskId) {
                this.taskToOpen = taskId;
                this.openTask();
            }
        };*/
        this.onThreadChange = async (e) => {
            const customEvent = e;
            await this.updateMessageAI(customEvent.detail, false);
            const thread = customEvent.detail;
            if (this.group === 'CONNECT' && thread.group === 'MOMENTS') {
                void this.refreshNewMoments();
            }
            const threadUpdated = this.userThreads[this.group].find((th) => th.thread.threadId === thread.threadId);
            if (['deleted'].includes(thread.status)) {
                await deleteAllMessagesFromThread(thread.threadId);
            }
            if (threadUpdated)
                threadUpdated.thread = { ...threadUpdated.thread, ...thread };
            else if (thread.group === this.group) {
                this.userThreads[this.group] = [...this.userThreads[this.group], { thread, hasMore: false, users: [] }];
            }
            if (threadUpdated?.thread.threadId === this.actualThread?.thread.threadId) {
                this.actualThread = threadUpdated;
                if (this.actualThread) {
                    const hasUnreadMessages = !!(this.actualThread.thread.unreadCount && this.actualThread.thread.unreadCount > 0);
                    const chatEl = this.querySelector('.chat-container');
                    if (chatEl) {
                        const isScrolledToBottom = chatEl.scrollTop + chatEl.clientHeight >= chatEl.scrollHeight - 1;
                        if (isScrolledToBottom)
                            this.isSystemChangeScroll = true;
                    }
                    const messagesInDb = await getMessagesByThreadId(this.actualThread.thread.threadId, this.messagesLimit, 0);
                    this.hasMoreMessagesAfter = false;
                    this.actualMessages = messagesInDb;
                    this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
                    if (hasUnreadMessages)
                        await this.updateLastMessage(this.actualThread);
                    try {
                        await this.markOpenThreadReadIf('message');
                    }
                    catch (error) {
                        console.error(error);
                    }
                }
            }
            if (this.activeScenerie === 'threadDetails' && (thread.status === 'deleted' ||
                thread.status === 'deleting' ||
                thread.status === 'archived')) {
                this.activeScenerie = 'list';
            }
            this.requestUpdate();
        };
        this.onMessageChange = (e) => {
            const customEvent = e;
            const message = customEvent.detail;
            if (!this.actualThread || !message || message.threadId !== this.actualThread.thread.threadId)
                return;
            let updatedMessage;
            this.actualMessages = this.actualMessages.map(item => {
                if (item.createAt !== message.createAt)
                    return item;
                updatedMessage = {
                    ...item,
                    ...message,
                    footers: item.footers || []
                };
                return updatedMessage;
            });
            for (const item of Object.values(this.actualMessagesParsed)) {
                const find = item.find(m => m.createAt === message.createAt);
                if (find) {
                    Object.assign(find, updatedMessage || message);
                    const item = this.messageContainer?.querySelector(`collab-messages-chat-message-102025[messageid="${message.createAt}"]`);
                    if (item)
                        item['message'] = updatedMessage || message;
                    break;
                }
            }
            this.clearToolbarSelection();
            this.requestUpdate();
        };
        this.onMessageSend = async (e) => {
            const customEvent = e;
            const message = customEvent.detail.context.message;
            const outputs = customEvent.detail.context.botOutput;
            const thId = message?.threadId;
            if (!this.actualThread || !thId || thId !== this.actualThread.thread.threadId)
                return;
            this.updateMessage2(false, true, { ...message, footers: [] }, message, outputs);
        };
        this.onVisibilityChange = () => {
            if (document.visibilityState === 'visible') {
                void this.markOpenThreadReadIf('visible').catch((error) => console.error(error));
            }
            if (this.activeScenerie === 'details') {
                this.checkNotificationsUnreadMessages();
            }
        };
        this.onDocumentClick = () => {
            const all = Array.from(this.querySelectorAll('collab-messages-chat-message-102025'));
            all.forEach((item) => {
                item.openedReactionMessageId = undefined;
                item.reactionPickerTarget = undefined;
                item.openedMenuFor = undefined;
                item.messageMenuTarget = undefined;
                item.openedReactionListMessageId = undefined;
                item.reactionListTarget = undefined;
            });
        };
        this.scrollLock = false;
    }
    willUpdate(changedProperties) {
        const threadChanged = changedProperties.has('actualThread');
        const messagesChanged = changedProperties.has('actualMessages');
        if (!threadChanged && !messagesChanged)
            return;
        if (threadChanged) {
            const previous = changedProperties.get('actualThread');
            if (previous?.thread.threadId !== this.actualThread?.thread.threadId)
                return;
        }
        this.applyFollowupNotice('count');
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('userId') || changedProperties.has('e01RootSessionKey') || changedProperties.has('actualThread')) {
            this.e01SessionEpoch++;
        }
        if (changedProperties.has('activeScenerie') && (this.activeScenerie === 'list')) {
            this.usersAvaliables = await listUsers();
            void this.refreshNewMoments();
        }
        if (changedProperties.has('group')) {
            void this.refreshNewMoments();
        }
        if (changedProperties.has('threadToOpen')) {
            if (this.threadToOpen) {
                if (this.activeScenerie !== 'list') {
                    this.activeScenerie = 'list';
                    await this.updateComplete;
                }
                const threadElement = this.querySelector(`[threadId="${this.threadToOpen}"]`);
                if (!threadElement)
                    return;
                const detailsParent = threadElement.closest('details');
                if (detailsParent && !detailsParent.open) {
                    detailsParent.open = true;
                    await this.updateComplete;
                }
                this.onThreadClick(threadElement.item);
            }
        }
        if (changedProperties.has('activeScenerie')
            && (changedProperties.get('activeScenerie') === 'task'
                || changedProperties.get('activeScenerie') === 'addParticipant'
                || changedProperties.get('activeScenerie') === 'threadDetails'
                || changedProperties.get('activeScenerie') === 'forwardMessage'
                || changedProperties.get('activeScenerie') === 'toolbarHelp')
            && this.activeScenerie === 'details') {
            this.restoreScrollPosition();
        }
        if (changedProperties.has('actualMessagesParsed') && this.actualMessagesParsed !== undefined) {
            await this.verifyChatScroll();
            await this.updateComplete;
            await this.nextFrame();
            this.updateTaskNotificationNavDirection();
        }
    }
    connectedCallback() {
        super.connectedCallback();
        document.addEventListener('click', this.onDocumentClick);
    }
    disconnectedCallback() {
        if (this.actualThread) {
            void this.markOpenThreadReadIf('leave').catch((error) => console.error(error));
        }
        super.disconnectedCallback();
        window.removeEventListener('task-change', this.onTaskChange);
        // window.removeEventListener('task-details-close', this.onTaskDetailsClose);
        window.removeEventListener('thread-change', this.onThreadChange);
        window.removeEventListener('message-change', this.onMessageChange);
        window.removeEventListener('message-send', this.onMessageSend);
        document.removeEventListener("visibilitychange", this.onVisibilityChange);
        document.removeEventListener('click', this.onDocumentClick);
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        window.addEventListener('task-change', this.onTaskChange);
        // window.addEventListener('task-details-close', this.onTaskDetailsClose);
        window.addEventListener('thread-change', this.onThreadChange);
        window.addEventListener('message-change', this.onMessageChange);
        window.addEventListener('message-send', this.onMessageSend);
        document.addEventListener("visibilitychange", this.onVisibilityChange);
        void this.refreshNewMoments();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.activeScenerie === 'loading') {
            return html `<div class="loading">${this.msg.loading}</div>`;
        }
        return html `
            ${this.renderHeader()}
            ${this.renderContent()}`;
    }
    renderHeader() {
        if (this.showPersonalMemory) {
            return html `<div class="header"><button class="personal-memory-back" @click=${this.onTitleClick} aria-label=${this.msg.backToConversation}>${collab_chevron_left}<span class="header-title">${this.msg.personalMemory}</span></button></div>`;
        }
        switch (this.activeScenerie) {
            case 'task':
                return html `
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} <span class="header-title">Task: ${this.actualTask?.PK || ''}</span></span>
                    </div>`;
            case 'details':
                return html `
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} <span class="header-title">Thread: ${this.getThreadName(this.actualThread)}</span></span>
                        ${this.actualThread?.thread.status !== 'deleted' ? html `
                            <div class="header-actions">
                                ${this.isE01Thread() ? html `<button class="personal-memory-entry" @click=${this.openPersonalMemory} aria-label=${this.msg.personalMemory}>${this.msg.personalMemory}</button>` : nothing}
                                <span @click=${this.onThreadDetailsClick}>${collab_gear}</span>
                            </div>
                        ` : ''}                        
                    </div>`;
            case 'list':
                return html `<div class="header">
                    ${this.renderThreadSearch()}
                    <div class="header-actions">
                            <span @click=${this.onThreadAddClick}>${collab_plus}</span>
                    </div>
                </div>`;
            case 'threadDetails':
                return html `
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} ${this.msg.threadDetails}</span>
                    </div>`;
            case 'threadAdd':
                return html `
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} ${this.msg.threadAdd}</span>
                    </div>`;
            case 'forwardMessage':
                return html `
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} ${this.msg.forwardMessageTitle}</span>
                    </div>`;
            case 'toolbarHelp':
                return html `
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} ${this.msg.toolbarHelpTitle}</span>
                    </div>`;
            default:
                return null;
        }
    }
    renderContent() {
        if (this.showPersonalMemory && this.actualThread && this.userId) {
            return html `<collab-messages-e01-memory-102025 .userId=${this.userId} .threadId=${this.actualThread.thread.threadId} .sessionKey=${this.getE01SessionKey()} @e01-open-source=${this.onE01OpenSource}></collab-messages-e01-memory-102025>`;
        }
        switch (this.activeScenerie) {
            case 'list':
                return this.renderListThreads();
            case 'details':
                return this.renderChatMessages();
            case 'task':
                return this.renderTaskDetails();
            case 'threadDetails':
                return this.renderThreadDetails();
            case 'threadAdd':
                return this.renderThreadAdd();
            case 'forwardMessage':
                return this.renderForwardMessage();
            case 'toolbarHelp':
                return this.renderToolbarHelp();
            default:
                return null;
        }
    }
    renderChatMessages() {
        if (!this.actualThread)
            return html ``;
        if (this.welcomeMessage && !['deleting', 'deleted', 'archived'].includes(this.actualThread?.thread.status)) {
            return this.renderWelcomeMessage();
        }
        if (this.actualThread.thread.status === 'deleting' || this.actualThread.thread.status === 'deleted') {
            const formatedTimestamp = formatTimestamp(this.actualThread.thread.deletedAt || '');
            const deletedAt = this.parseLocalDate(formatedTimestamp?.dateFull || '');
            return html `
                <div>${this.msg.threadDeleting.replace('[date]', deletedAt.datafull)}</div>
            `;
        }
        if (this.actualThread.thread.status === 'archived') {
            const formatedTimestamp = formatTimestamp(this.actualThread.thread.archivedAt || '');
            const archivedAt = this.parseLocalDate(formatedTimestamp?.dateFull || '');
            const archivedBy = this.actualThread.users.find((user) => user.userId === this.actualThread?.thread.archivedBy);
            return html `
                <div>${this.msg.threadArchived.replace('[user]', archivedBy?.name || '').replace('[date]', archivedAt.datafull)}</div>
            `;
        }
        const sortedEntries = Object.entries(this.actualMessagesParsed)
            .map(([date, value]) => [date.trim(), value])
            .sort(([a], [b]) => new Date(a).getTime() - new Date(b).getTime());
        const sortedObj = Object.fromEntries(sortedEntries);
        const firstUnreadMessageCreateAt = this.getFirstUnreadMessageCreateAt();
        return html `
            ${this.renderTopics()}
            ${this.renderThreadToolbar()}
            <div
                @scroll=${this.onChatScroll} class="chat-container"
                @wheel=${this.clearToolbarSelection}
                @touchstart=${this.clearToolbarSelection}
                @copy=${this.onCopyChat}
            >
                ${repeat(Object.keys(sortedObj), (key) => key, (key) => {
            const threadMessages = sortedObj[key];
            const messageTime = this.parseLocalDate(key);
            const displayDate = this.formatMessageDate(messageTime.dateObject);
            return html `
                    <div class="message-time">${displayDate}</div>
                        ${repeat(threadMessages, (message) => `${message.threadId}/${message.createAt}`, (message) => {
                return html `
                                ${firstUnreadMessageCreateAt === message.createAt ? html `<div class="new-messages-label">${this.msg.newMessages}</div>` : nothing}
                                <collab-messages-chat-message-102025
                                    messageId=${message.createAt}
                                    .message=${message}
                                    .allThreads=${this.allThreads}
                                    .actualThread=${this.actualThread}
                                    .usersAvaliables=${this.usersAvaliables}
                                    .currentUser=${this.getCurrentUser()}
                                    .toolbarHighlighted=${this.isMessageHighlightedByToolbar(message)}
                                    .userId=${this.userId}
                                    .e01SessionKey=${this.getE01SessionKey()}
                                    .onTaskClick=${this.onTaskClick.bind(this)}
                                    @reply-preview-click=${this.onReplyPreviewClick}
                                    @reply-message=${this.onReplyMessageClick}
                                    @pin-message=${this.onPinMessageClick}
                                    @favorite-message=${this.onFavoriteMessageClick}
                                    @read-confirmation-message=${this.onReadConfirmationMessageClick}
                                    @message-action-message=${this.onMessageActionMessageClick}
                                    @edit-message=${this.onEditMessageClick}
                                    @mark-unread-message=${this.onMarkUnreadMessageClick}
                                    @forward-message=${this.onForwardMessageClick}
                                    @delete-attachment-message=${this.onDeleteAttachmentMessage}
                                    @e01-open-source=${this.onE01OpenSource}
                                    @nora-confirm-reply=${this.onNoraConfirmReply}
                                ></collab-messages-chat-message-102025>`;
            })}`;
        })}
                        ${this.renderFollowupNotice()}
                        ${this.isLoadingMessages ? html `<div class="unread-messages">Loading messages...</div>` : html ``}
                        ${this.isThreadError ? html `<div class="error-messages">${this.threadErrorMsg}</div>` : html ``}
                    </div>
                ${this.renderTaskNotificationNav()}
                ${this.renderJumpToLatest()}
                ${this.renderPrompt()}`;
    }
    applyFollowupNotice(event) {
        const count = this.getReadConfirmationMessageIdsForThread().length;
        const next = nextFollowupNotice(this.followupNotice, event, count);
        if (next.visible === this.followupNotice.visible && next.lastCount === this.followupNotice.lastCount)
            return;
        this.followupNotice = next;
    }
    renderFollowupNotice() {
        if (!this.followupNotice.visible)
            return nothing;
        const count = this.getReadConfirmationMessageIdsForThread().length;
        const text = count === 1
            ? this.msg.followupNoticeOne
            : this.msg.followupNoticeMany.replace('{n}', String(count));
        return html `
            <div class="followup-notice" role="status">
                ${collab_bell}
                <span>${text}</span>
                <button class="followup-notice-see" @click=${() => this.navigateToolbarItem('readReceipts')}>${this.msg.followupNoticeSee}</button>
            </div>
        `;
    }
    renderJumpToLatest() {
        if (!this.showJumpToLatest)
            return nothing;
        return html `
            <button
                class="jump-to-latest"
                @click=${() => this.onJumpToLatest()}
                title=${this.msg.jumpToLatest}
                aria-label=${this.msg.jumpToLatest}
            >
                ${this.renderTaskNotificationNavIcon('down')}
            </button>
        `;
    }
    async onJumpToLatest() {
        if (this.hasMoreMessagesAfter && this.actualThread) {
            const threadId = this.actualThread.thread.threadId;
            const messagesInDb = await getMessagesByThreadId(threadId, this.messagesLimit, 0);
            this.actualMessages = messagesInDb;
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            this.hasMoreMessagesAfter = false;
            await this.scrollMessagesToBottom();
            return;
        }
        if (this.messageContainer) {
            this.messageContainer.scrollTo({ top: this.messageContainer.scrollHeight, behavior: 'smooth' });
        }
    }
    renderTaskNotificationNav() {
        if (!this.actualThread)
            return nothing;
        const taskId = this.getFirstPendingTaskNotificationInView();
        if (!taskId)
            return nothing;
        const direction = this.taskNotificationNavDirection || 'up';
        if (!this.taskNotificationNavDirection)
            return nothing;
        return html `
            <button
                class="task-notification-nav ${direction}"
                @click=${() => this.scrollToTaskNotification(taskId)}
                title="Go to updated task"
            >
                ${this.renderTaskNotificationNavIcon(direction)}
            </button>
        `;
    }
    renderForwardMessage() {
        const destinations = this.getForwardDestinationSuggestions();
        const selectedThread = this.allThreads.find(thread => thread.threadId === this.forwardDestinationThreadId);
        return html `
            <div class="forward-message-scenario">
                <label for="forward-destination">${this.msg.forwardDestinationLabel}</label>
                <input
                    id="forward-destination"
                    type="search"
                    .value=${this.forwardDestinationQuery}
                    placeholder=${this.msg.forwardDestinationPlaceholder}
                    @input=${this.onForwardDestinationInput}
                />
                ${this.forwardError ? html `<small class="forward-error">${this.forwardError}</small>` : nothing}
                <ul class="forward-destination-list">
                    ${destinations.length === 0 ? html `<li class="forward-empty">${this.msg.forwardEmpty}</li>` : nothing}
                    ${destinations.map(thread => this.renderForwardDestination(thread))}
                </ul>
                <div class="forward-actions">
                    <button class="secondary" @click=${this.cancelForwardMessage}>
                        ${collab_xmark}
                        ${this.msg.forwardCancel}
                    </button>
                    <button class="primary" ?disabled=${!selectedThread || this.isForwardingMessage} @click=${this.confirmForwardMessage}>
                        ${collab_chevron_right}
                        ${this.isForwardingMessage ? this.msg.loading : this.msg.forwardSend}
                    </button>
                </div>
            </div>
        `;
    }
    renderForwardDestination(thread) {
        const selected = this.forwardDestinationThreadId === thread.threadId;
        return html `
            <li>
                <button class=${selected ? 'selected' : ''} @click=${() => this.selectForwardDestination(thread)}>
                    <span class="forward-destination-avatar">${this.renderForwardDestinationAvatar(thread)}</span>
                    <span class="forward-destination-name">${this.getForwardThreadName(thread)}</span>
                </button>
            </li>
        `;
    }
    renderToolbarHelp() {
        const kind = this.toolbarHelpKind || 'pins';
        const help = this.getToolbarHelpContent(kind);
        return html `
            <div class="toolbar-help-scenario">
                <div class="toolbar-help-icon">${help.icon}</div>
                <h3>${help.title}</h3>
                <p>${help.text}</p>
                <button @click=${this.closeToolbarHelp}>
                    ${collab_chevron_left}
                    ${this.msg.toolbarHelpBack}
                </button>
            </div>
        `;
    }
    getToolbarHelpContent(kind) {
        switch (kind) {
            case 'pins':
                return { title: this.msg.toolbarHelpPinsTitle, text: this.msg.toolbarHelpPinsText, icon: collab_pin };
            case 'saved':
                return { title: this.msg.toolbarHelpSavedTitle, text: this.msg.toolbarHelpSavedText, icon: collab_star };
            case 'readReceipts':
                return { title: this.msg.toolbarHelpReadReceiptsTitle, text: this.msg.toolbarHelpReadReceiptsText, icon: collab_circle_exclamation };
            case 'attachments':
                return { title: this.msg.toolbarHelpAttachmentsTitle, text: this.msg.toolbarHelpAttachmentsText, icon: collab_paperclip };
            case 'agent':
                return { title: this.msg.toolbarHelpAgentTitle, text: this.msg.toolbarHelpAgentText, icon: collab_robot };
        }
    }
    renderTaskNotificationNavIcon(direction) {
        const rotate = direction === 'down' ? 'rotate(180 12 12)' : '';
        return html `
            <svg width="22" height="22" viewBox="0 0 24 24" aria-hidden="true">
                <g transform="${rotate}" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M7 14l5-5 5 5"></path>
                    <path d="M7 19l5-5 5 5"></path>
                </g>
            </svg>
        `;
    }
    renderWelcomeMessage() {
        return html `
            <div class="welcome-message">
                <p>${this.welcomeMessage}</p>
                <button @click=${() => { this.welcomeMessage = ''; }}>${this.msg.btnNext}</button>       
            </div>`;
    }
    renderTopics() {
        return html `
            <collab-messages-topics-102025
                .selectedTopic=${this.lastTopicFilter === '' ? 'all' : this.lastTopicFilter}
                .messages=${this.actualMessages}
                .threadTopics=${this.actualThread?.thread.defaultTopics || []}
                @topic-selected=${(e) => this.onTopicClick(e)}
            ></collab-messages-topics-102025>
        `;
    }
    renderThreadToolbar() {
        const pinnedMessages = this.actualThread?.thread.pinnedMessages || [];
        const favoriteMessageIds = this.getFavoriteMessageIdsForThread();
        const readConfirmationMessageIds = this.getReadConfirmationMessageIdsForThread();
        const attachments = this.getAttachmentMessages();
        const agentMessages = this.getAgentMessages();
        const hasPendingReadConfirmation = this.hasPendingReadConfirmationsForThread();
        const items = [
            {
                kind: 'pins',
                icon: collab_pin,
                total: pinnedMessages.length,
                active: this.toolbarView.pins !== undefined,
                important: false,
                attention: false,
                loading: this.toolbarNavigationKind === 'pins',
                error: this.toolbarNavigationFailedKind === 'pins',
                onClick: () => this.navigateToolbarItem('pins')
            },
            {
                kind: 'saved',
                icon: collab_star,
                total: favoriteMessageIds.length,
                active: this.toolbarView.saved !== undefined,
                important: false,
                attention: false,
                loading: this.toolbarNavigationKind === 'saved',
                error: this.toolbarNavigationFailedKind === 'saved',
                onClick: () => this.navigateToolbarItem('saved')
            },
            {
                kind: 'readReceipts',
                icon: collab_circle_exclamation,
                total: readConfirmationMessageIds.length,
                active: this.toolbarView.readReceipts !== undefined,
                important: hasPendingReadConfirmation,
                attention: hasPendingReadConfirmation,
                loading: this.toolbarNavigationKind === 'readReceipts',
                error: this.toolbarNavigationFailedKind === 'readReceipts',
                onClick: () => this.navigateToolbarItem('readReceipts')
            },
            {
                kind: 'attachments',
                icon: collab_paperclip,
                total: attachments.length,
                active: this.toolbarView.attachments !== undefined,
                important: false,
                attention: false,
                loading: this.toolbarNavigationKind === 'attachments',
                error: this.toolbarNavigationFailedKind === 'attachments',
                onClick: () => this.navigateToolbarItem('attachments')
            },
            {
                kind: 'agent',
                icon: collab_robot,
                total: agentMessages.length,
                active: this.toolbarView.agent !== undefined,
                important: false,
                attention: false,
                loading: this.toolbarNavigationKind === 'agent',
                error: this.toolbarNavigationFailedKind === 'agent',
                onClick: () => this.navigateToolbarItem('agent')
            }
        ];
        return html `
            <div class="thread-toolbar" role="toolbar">
                ${items.map(item => html `
                    <button
                        class="thread-toolbar-btn ${item.active ? 'active' : ''} ${item.important ? 'important' : ''} ${item.attention ? 'attention' : ''} ${item.loading ? 'loading' : ''} ${item.error ? 'error' : ''}"
                        .title=${item.error ? this.toolbarNavigationError : this.getToolbarTitle(item.kind)}
                        aria-label=${item.error ? this.toolbarNavigationError : this.getToolbarTitle(item.kind)}
                        ?disabled=${item.loading}
                        @click=${item.onClick}
                    >
                        ${item.icon}
                        ${this.renderToolbarCounter(item.kind, item.total)}
                        ${item.loading ? html `<span class="toolbar-loading"></span>` : nothing}
                        ${item.error ? html `<span class="toolbar-alert">!</span>` : item.important ? html `<span class="toolbar-alert">*</span>` : nothing}
                    </button>
                `)}
            </div>
        `;
    }
    renderToolbarCounter(kind, total) {
        if (total <= 0)
            return nothing;
        const index = this.toolbarView[kind];
        const label = index === undefined ? `${total}` : `${Math.min(index + 1, total)}/${total}`;
        return html `<span class="toolbar-counter">(${label})</span>`;
    }
    async navigateToolbarItem(kind) {
        if (this.toolbarNavigationKind)
            return;
        if (kind === 'pins') {
            const pinnedMessages = this.actualThread?.thread.pinnedMessages || [];
            if (pinnedMessages.length === 0)
                return this.openToolbarHelp(kind);
            const nextIndex = this.getNextToolbarIndex(kind, pinnedMessages.length);
            this.toolbarView = { ...this.toolbarView, [kind]: nextIndex };
            await this.navigateToMessageId(pinnedMessages[nextIndex].messageId, kind);
            return;
        }
        if (kind === 'saved') {
            const favoriteMessageIds = this.getFavoriteMessageIdsForThread();
            if (favoriteMessageIds.length === 0)
                return this.openToolbarHelp(kind);
            const nextIndex = this.getNextToolbarIndex(kind, favoriteMessageIds.length);
            this.toolbarView = { ...this.toolbarView, [kind]: nextIndex };
            await this.navigateToMessageId(favoriteMessageIds[nextIndex], kind);
            return;
        }
        if (kind === 'readReceipts') {
            const readConfirmationMessageIds = this.getReadConfirmationMessageIdsForThread();
            if (readConfirmationMessageIds.length === 0)
                return this.openToolbarHelp(kind);
            const nextIndex = this.getNextToolbarIndex(kind, readConfirmationMessageIds.length);
            this.toolbarView = { ...this.toolbarView, [kind]: nextIndex };
            await this.navigateToMessageId(readConfirmationMessageIds[nextIndex], kind);
            return;
        }
        if (kind === 'attachments') {
            const attachments = this.getAttachmentMessages();
            if (attachments.length === 0)
                return this.openToolbarHelp(kind);
            const nextIndex = this.getNextToolbarIndex(kind, attachments.length);
            this.toolbarView = { ...this.toolbarView, [kind]: nextIndex };
            await this.navigateToMessageId(`${attachments[nextIndex].threadId}/${attachments[nextIndex].orderAt || attachments[nextIndex].createAt}`, kind);
            return;
        }
        if (kind === 'agent') {
            const agentMessages = this.getAgentMessages();
            if (agentMessages.length === 0)
                return this.openToolbarHelp(kind);
            const nextIndex = this.getNextToolbarIndex(kind, agentMessages.length);
            this.toolbarView = { ...this.toolbarView, [kind]: nextIndex };
            await this.navigateToMessageId(`${agentMessages[nextIndex].threadId}/${agentMessages[nextIndex].orderAt || agentMessages[nextIndex].createAt}`, kind);
        }
    }
    getToolbarTitle(kind) {
        switch (kind) {
            case 'pins': return this.msg.toolbarPins;
            case 'saved': return this.msg.toolbarSaved;
            case 'readReceipts': return this.msg.toolbarReadReceipts;
            case 'attachments': return this.msg.toolbarAttachments;
            case 'agent': return this.msg.toolbarAgent;
        }
    }
    getNextToolbarIndex(kind, total) {
        const current = this.toolbarView[kind];
        if (current === undefined || current >= total - 1)
            return 0;
        return current + 1;
    }
    getAttachmentMessages() {
        return this.getMessagesKnownToToolbar().filter(message => {
            const hasActiveAttachments = !!message.attachments?.some(attachment => attachment.status === 'active');
            return hasActiveAttachments || !!message.url || (!!message.type && message.type !== 'text' && !message.attachments?.length);
        });
    }
    getAgentMessages() {
        return this.getMessagesKnownToToolbar().filter(message => !!message.footers?.length ||
            !!message.taskResults?.length ||
            !!message.taskResultsTranslated);
    }
    getMessagesKnownToToolbar() {
        const messagesById = new Map();
        for (const message of [...this.cachedToolbarMessages, ...this.actualMessages]) {
            const messageId = this.getMessageCacheKey(message);
            messagesById.set(messageId, {
                ...messagesById.get(messageId),
                ...message
            });
        }
        return [...messagesById.values()].sort((a, b) => (a.orderAt || a.createAt).localeCompare(b.orderAt || b.createAt));
    }
    openToolbarHelp(kind) {
        this.toolbarHelpKind = kind;
        this.saveScrollPosition();
        this.activeScenerie = 'toolbarHelp';
    }
    getFavoriteMessageIdsForThread() {
        const threadId = this.actualThread?.thread.threadId;
        if (!threadId)
            return [];
        return (this.getCurrentUser()?.favorites || []).filter(messageId => messageId.startsWith(`${threadId}/`));
    }
    getReadConfirmationMessageIdsForThread() {
        const threadId = this.actualThread?.thread.threadId;
        if (!threadId)
            return [];
        const readConfirmations = this.getCurrentUser()?.readConfirmations || {};
        return [...new Set([
                ...(readConfirmations.pending || []),
                ...(readConfirmations.requested || []),
                ...this.getReadConfirmationMessageIdsFromLoadedMessages(),
            ])]
            .filter(messageId => messageId.startsWith(`${threadId}/`))
            .filter(messageId => {
            const loadedMessage = this.getLoadedMessageById(messageId);
            return loadedMessage ? this.isReadConfirmationRelevantForCurrentUser(loadedMessage) : true;
        });
    }
    hasPendingReadConfirmationsForThread() {
        const threadId = this.actualThread?.thread.threadId;
        if (!threadId)
            return false;
        return !!this.getCurrentUser()?.readConfirmations?.pending?.some(messageId => {
            if (!messageId.startsWith(`${threadId}/`))
                return false;
            const loadedMessage = this.getLoadedMessageById(messageId);
            return loadedMessage ? this.isReadConfirmationPendingForCurrentUser(loadedMessage) : true;
        }) ||
            this.getMessagesKnownToToolbar().some(message => this.isReadConfirmationPendingForCurrentUser(message));
    }
    getLoadedMessageById(messageId) {
        return this.getMessagesKnownToToolbar().find(message => this.isSameMessageId(message, messageId));
    }
    getReadConfirmationMessageIdsFromLoadedMessages() {
        return this.getMessagesKnownToToolbar()
            .filter(message => this.isReadConfirmationRelevantForCurrentUser(message))
            .map(message => `${message.threadId}/${message.orderAt || message.createAt}`);
    }
    isReadConfirmationRelevantForCurrentUser(message) {
        return this.isReadConfirmationPendingForCurrentUser(message) ||
            this.isReadConfirmationRequestedByCurrentUser(message);
    }
    isReadConfirmationPendingForCurrentUser(message) {
        if (!this.userId)
            return false;
        return !!message.readConfirmations?.some(request => !request.canceledAt &&
            ((this.getReadConfirmationKind(request) === 'read' &&
                request.targetUserIds.includes(this.userId) && !request.confirmedBy?.[this.userId]) ||
                (this.getReadConfirmationKind(request) === 'execution' &&
                    request.targetUserIds.includes(this.userId) && !this.getFollowupReactionForUser(message, this.userId))));
    }
    isReadConfirmationRequestedByCurrentUser(message) {
        if (!this.userId)
            return false;
        return !!message.readConfirmations?.some(request => !request.canceledAt &&
            request.requestedBy === this.userId &&
            ((this.getReadConfirmationKind(request) === 'read' &&
                request.targetUserIds.some(userId => !request.confirmedBy?.[userId])) ||
                (this.getReadConfirmationKind(request) === 'execution' &&
                    this.getFollowupReactionForUser(message, this.userId) !== 'followup_revisado')));
    }
    getReadConfirmationKind(request) {
        return request.kind || 'read';
    }
    getFollowupReactionForUser(message, userId) {
        const reactions = message.reactions || {};
        for (const [reaction, users] of Object.entries(reactions)) {
            if (reaction.startsWith('followup_') && users.includes(userId))
                return reaction;
        }
        return undefined;
    }
    getCurrentUser() {
        if (!this.userId)
            return undefined;
        return [
            ...this.usersAvaliables,
            ...(this.actualThread?.users || [])
        ].find(user => user.userId === this.userId);
    }
    async navigateToMessageId(messageId, kind, isCurrent = () => true, options = {}) {
        if (!isCurrent())
            return;
        const normalizedMessageId = this.normalizeToolbarMessageId(messageId);
        if (!normalizedMessageId)
            return;
        this.toolbarNavigationKind = kind;
        this.toolbarNavigationFailedKind = undefined;
        this.toolbarNavigationError = '';
        try {
            if (!isCurrent())
                return;
            if (!options.forceServer && this.scrollToMessageId(normalizedMessageId))
                return;
            if (options.forceServer) {
                await this.renderMessageWindowFromServer(normalizedMessageId, isCurrent, options.persist !== false);
            }
            else {
                const localMessage = await this.getLocalMessageById(normalizedMessageId);
                if (!isCurrent())
                    return;
                if (localMessage) {
                    await this.renderMessageWindowFromLocalCache(localMessage, isCurrent);
                }
                else {
                    await this.renderMessageWindowFromServer(normalizedMessageId, isCurrent, options.persist !== false);
                }
            }
            await this.updateComplete;
            if (!isCurrent())
                return;
            await this.waitingForRenderCodesWebComponents();
            if (!isCurrent())
                return;
            await this.nextFrame();
            if (!isCurrent())
                return;
            await this.nextFrame();
            if (!isCurrent())
                return;
            if (!this.scrollToMessageId(normalizedMessageId)) {
                throw new Error(this.msg.toolbarNavigationError);
            }
        }
        catch (err) {
            if (!isCurrent())
                return;
            this.toolbarNavigationFailedKind = kind;
            this.toolbarNavigationError = err?.message || this.msg.toolbarNavigationError;
        }
        finally {
            if (isCurrent())
                this.toolbarNavigationKind = undefined;
        }
    }
    normalizeToolbarMessageId(messageId) {
        const threadId = this.actualThread?.thread.threadId;
        if (!threadId)
            return undefined;
        return this.normalizeMessageId(threadId, messageId);
    }
    async getLocalMessageById(messageId) {
        const messageFromKey = await getMessage(messageId);
        if (messageFromKey)
            return messageFromKey;
        const { threadId, orderAt } = this.parseMessageId(messageId);
        if (!threadId || !orderAt)
            return undefined;
        const messages = await getAllMessagesByThreadId(threadId);
        return messages.find(message => message.threadId === threadId &&
            (message.orderAt === orderAt || message.createAt === orderAt));
    }
    async renderMessageWindowFromLocalCache(targetMessage, isCurrent = () => true) {
        const allMessages = await getAllMessagesByThreadId(targetMessage.threadId);
        if (!isCurrent())
            return;
        const messageWindow = this.buildMessageWindowFromTarget(allMessages, targetMessage);
        if (!isCurrent())
            return;
        this.hasMoreMessagesAfter = messageWindow.hasMoreAfter;
        this.applyToolbarMessageWindow(messageWindow.messages);
        await this.refreshCachedToolbarMessages(isCurrent);
    }
    async renderMessageWindowFromServer(messageId, isCurrent = () => true, persist = true) {
        if (!isCurrent())
            return;
        if (!this.userId || !this.actualThread)
            throw new Error(this.msg.toolbarNavigationError);
        const { threadId } = this.parseMessageId(messageId);
        if (!threadId || threadId !== this.actualThread.thread.threadId)
            throw new Error(this.msg.toolbarNavigationError);
        const messageResult = await msgGetMessage({
            threadId,
            messageId,
            userId: this.userId
        });
        if (!isCurrent())
            return;
        if (!messageResult.success || !messageResult.response?.message) {
            throw new Error(messageResult.error || this.msg.toolbarNavigationError);
        }
        const targetMessage = messageResult.response.message;
        const afterResponse = await this.getMessagesAfter(this.actualThread.thread, targetMessage.orderAt || targetMessage.createAt);
        if (!isCurrent())
            return;
        const messages = [targetMessage, ...(afterResponse?.data || [])]
            .slice(0, this.messagesLimit)
            .map(message => ({ ...message, footers: [] }));
        this.hasMoreMessagesAfter = (afterResponse?.hasMore ?? false) || (1 + (afterResponse?.data.length ?? 0)) > this.messagesLimit;
        if (persist) {
            if (!isCurrent())
                return;
            await addMessages(messages);
            if (!isCurrent())
                return;
        }
        this.hasMoreMessagesBefore = true;
        this.applyToolbarMessageWindow(messages);
        await this.refreshCachedToolbarMessages(isCurrent);
    }
    buildMessageWindowFromTarget(messages, targetMessage) {
        const targetId = this.getMessageCacheKey(targetMessage);
        const messagesById = new Map();
        for (const message of [...messages, targetMessage]) {
            messagesById.set(this.getMessageCacheKey(message), {
                ...messagesById.get(this.getMessageCacheKey(message)),
                ...message
            });
        }
        const sortedMessages = [...messagesById.values()].sort((a, b) => (a.orderAt || a.createAt).localeCompare(b.orderAt || b.createAt));
        const targetIndex = sortedMessages.findIndex(message => this.getMessageCacheKey(message) === targetId ||
            this.isSameMessageId(message, targetId));
        const startIndex = targetIndex >= 0 ? targetIndex : 0;
        const window = sliceWindowFromTarget(sortedMessages, startIndex, this.messagesLimit);
        return {
            messages: window.messages,
            hasMoreAfter: window.hasMoreAfter,
        };
    }
    applyToolbarMessageWindow(messages) {
        this.actualMessages = messages;
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.hasMoreMessagesLocalDB = true;
        this.isSystemChangeScroll = true;
    }
    parseMessageId(messageId) {
        const parts = messageId.split('/').filter(Boolean);
        return {
            threadId: parts[0] || '',
            orderAt: parts[parts.length - 1] || ''
        };
    }
    getMessageCacheKey(message) {
        return `${message.threadId}/${message.orderAt || message.createAt}`;
    }
    isSameMessageId(message, messageId) {
        const { threadId, orderAt } = this.parseMessageId(messageId);
        return message.threadId === threadId && (message.orderAt === orderAt || message.createAt === orderAt);
    }
    scrollToMessageId(messageId) {
        this.highlightedMessageId = messageId;
        this.isToolbarAutoScroll = true;
        this.ignoreToolbarScrollClearUntil = Date.now() + 2000;
        this.deferToolbarAutoScrollEnd();
        const orderAt = messageId.split('/').pop();
        if (!orderAt)
            return false;
        const message = this.getLoadedMessageById(messageId);
        const domIds = [...new Set([orderAt, message?.createAt].filter((item) => !!item))];
        let messageEl = null;
        for (const domId of domIds) {
            messageEl = this.messageContainer?.querySelector(`collab-messages-chat-message-102025[messageid="${domId}"]`) || null;
            if (messageEl)
                break;
        }
        if (!messageEl)
            return false;
        messageEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return true;
    }
    deferToolbarAutoScrollEnd() {
        if (this.toolbarAutoScrollTimer)
            clearTimeout(this.toolbarAutoScrollTimer);
        this.toolbarAutoScrollTimer = setTimeout(() => {
            this.isToolbarAutoScroll = false;
        }, 500);
    }
    isMessageHighlightedByToolbar(message) {
        return this.isSameMessageId(message, this.highlightedMessageId);
    }
    async onTopicClick(e) {
        this.lastTopicFilter = e.detail.topic === 'all' ? '' : e.detail.topic;
        this.isChangeTopics = true;
        this.isSystemChangeScroll = true;
        if (e.detail.topic === 'all') {
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        }
        else
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        /*if (this.messageContainer) {
            const newHeight = this.messageContainer.scrollHeight;
            this.messageContainer.scrollTop = newHeight;
        }*/
    }
    removeAllModal() {
        const all = this.querySelectorAll('collab-messages-user-modal-102025');
        const all2 = this.querySelectorAll('collab-messages-thread-modal-102025');
        [...all, ...all2].forEach((item) => item.remove());
    }
    renderPrompt() {
        if (!this.canWriteCurrentThread()) {
            return html `<div class="read-only-thread">${this.msg.readOnlyThread}</div>`;
        }
        return html `
            <collab-messages-prompt-102025
                acceptAutoCompleteAgents="true"
                acceptAutoCompleteUser="true"
                enableRichPreview="true"
                threadId=${this.actualThread?.thread.threadId}
                .onSend=${this.handleSend.bind(this)}
                placeholder=${this.msg.promptPlaceholder}
                @textarea-resize=${this.handlePromptResize}
                scope="*"
            ></collab-messages-prompt-102025>
        `;
    }
    getCurrentThreadUserAuth() {
        return this.actualThread?.thread.users.find(user => user.userId === this.userId)?.auth;
    }
    canWriteCurrentThread() {
        const auth = this.getCurrentThreadUserAuth();
        return auth === 'admin' || auth === 'moderator' || auth === 'write';
    }
    showReadOnlyThreadError() {
        this.isThreadError = true;
        this.threadErrorMsg = this.msg.readOnlyThread;
    }
    renderNoraEntry() {
        if (this.group !== 'CONNECT')
            return nothing;
        return html `<button type="button" class="nora-entry" ?disabled=${this.noraOpening} @click=${this.onOpenNora}>${this.msg.openNora}</button>${this.noraOpenError ? html `<p class="nora-open-error">${this.noraOpenError}</p>` : nothing}`;
    }
    async onOpenNora() {
        if (!this.userId || this.noraOpening)
            return;
        this.noraOpening = true;
        this.noraOpenError = '';
        try {
            const args = {
                action: 'ensureAssistantDm',
                userId: this.userId,
            };
            const reply = await post(args);
            const threadId = reply.threadId;
            if (!threadId)
                throw new Error('assistant conversation was not created');
            const info = await msgGetThreadUpdates({ threadId, userId: this.userId });
            if (!info.success || !info.response?.thread) {
                throw new Error(info.error || 'assistant conversation was not created');
            }
            // Keep the thread in the local store before anything reads or updates it: opening a Nora
            // conversation this browser never synced otherwise fails with "Thread not found".
            const stored = await addThread(info.response.thread);
            notifyThreadCreate(stored);
            await this.onThreadClick({
                thread: info.response.thread,
                users: info.response.users,
                threadsPending: info.response.threadsPending,
                hasMore: info.response.hasMore,
                messages: info.response.messages,
            });
        }
        catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            console.error(message, error);
            this.noraOpenError = sendErrorMessage(message, this.getMessageKey(messages));
        }
        finally {
            this.noraOpening = false;
        }
    }
    renderNewMomentsCard() {
        if (this.group !== 'CONNECT' || !this.hasNewMoments)
            return nothing;
        return html `<button type="button" class="moments-new-card" @click=${this.onNewMomentsClick}>${collab_moments}<span>${this.msg.newMoments}</span></button>`;
    }
    async refreshNewMoments() {
        if (this.group !== 'CONNECT') {
            this.hasNewMoments = false;
            return;
        }
        try {
            this.hasNewMoments = await hasUnreadMoments();
        }
        catch (error) {
            console.error(error);
        }
    }
    renderListThreads() {
        if (!this.userThreads[this.group] || (this.userThreads[this.group].length === 0 && !this.isLoadingThread)) {
            return html `${this.renderNoraEntry()}${this.renderNewMomentsCard()}<div style="padding:1rem;">${this.msg.noThreads}</div>`;
        }
        const ordenedThreads = this.getOrdenedThreadsByStatus();
        this.filteredThreads = this.getFilteredThreads(ordenedThreads);
        return html `
            ${this.renderNoraEntry()}
            ${this.renderNewMomentsCard()}
            ${this.renderThreadsByStatus2()}
            ${this.isLoadingThread ? html `<div>${this.msg.loading}</div>` : ''}
        `;
    }
    getThreadAvatar(item) {
        let threadAvatar = generateAgentAvatar(item.thread.name);
        if (item.thread.name.startsWith('@') && item.thread.users.length === 2) {
            const user = item.users.find((user) => user.userId !== this.userId);
            if (user && user.avatar_url)
                threadAvatar = user.avatar_url;
        }
        else if (item.thread.avatar_url) {
            threadAvatar = item.thread.avatar_url;
        }
        return threadAvatar;
    }
    getThreadName(item) {
        if (!item)
            return '';
        if (this.isDirectMessage(item)) {
            const user = item.users.find((user) => user.userId !== this.userId);
            if (user)
                return '@' + user.name;
        }
        return item.thread.name || item.thread.threadId;
    }
    isDirectMessage(item) {
        return item.thread.name.startsWith('@') && item.thread.users.length === 2;
    }
    renderThreadsByStatus2() {
        const groups = this.groupThreadsByPrefix(this.filteredThreads.active);
        return html `
        <ul class="thread-list">
            ${Object.entries(groups).map(([prefix, items]) => {
            if (items.length === 1) {
                return this.renderThreadItemLi(items[0]);
            }
            else {
                const lastItem = items[0];
                const unreadCount = items.reduce((total, item) => total + (item.thread?.unreadCount || 0), 0);
                const hasPendingNotification = items.some((item) => hasThreadNotificationPending(item.thread.threadId));
                const pendingTasksCount = items.reduce((total, item) => total + (item?.thread?.pendingTasks?.length || 0), 0);
                const now = new Date();
                const isToday = lastItem._lastMessageDate.dateObject.getFullYear() === now.getFullYear() &&
                    lastItem._lastMessageDate.dateObject.getMonth() === now.getMonth() &&
                    lastItem._lastMessageDate.dateObject.getDate() === now.getDate();
                const displayDate = isToday
                    ? lastItem._lastMessageDate.time
                    : this.formatMessageDate(lastItem._lastMessageDate.dateObject);
                return html `
                        <li class="thread-group ${hasPendingNotification ? 'has-notification' : ''}">
                            <details>
                                <summary class="group-title">
                                    <div class="thread-group-avatar">
                                        ${collab_folder_tree}
                                    </div>
                                    <div class="thread-group-content">
                                        <div class="thread-group-item-header">
                                            <span class="thread-group-name">${prefix}</span>
                                            <span class="last-group-update">
                                                ${this.renderTaskPendingsCount(pendingTasksCount)}
                                                ${displayDate}
                                            
                                            </span>
                                        </div>
                                        <div class="thread-group-summary">
                                            <span class="last-group-message">${items.length} Threads </span>
                                            ${unreadCount > 0 ? html `<span class="unread-count">${unreadCount}</span>` : hasPendingNotification ? html `<span class="unread-count">•</span>` : nothing}
                                        </div>
                                    </div>                                
                                </summary>
                                <ul class="group-items">
                                    ${items.map(item => this.renderThreadItemLi(item, prefix))}
                                </ul>
                            </details>
                        </li>
                    `;
            }
        })}
        
            ${this.renderArchivedThreads()}
            ${this.renderDeletingThreads()}
            ${this.renderDeletedThreads()}

        </ul>
    `;
    }
    renderThreadItemLi(item, prefix) {
        let threadAvatar = this.getThreadAvatar(item);
        let threadName = this.getThreadName(item);
        if (prefix)
            threadName = threadName.replace(prefix + '/', '');
        const isDirectMessage = this.isDirectMessage(item);
        let lastMessage = item.thread.lastMessage || '';
        const firstColonIndex = lastMessage.indexOf(':');
        let userMessageId = lastMessage.slice(0, firstColonIndex);
        let userMessage = lastMessage.slice(firstColonIndex + 1);
        const unreadCount = item.thread.unreadCount || 0;
        const hasPendingNotification = hasThreadNotificationPending(item.thread.threadId);
        const pendingTasksCount = item.thread.pendingTasks?.length || 0;
        const now = new Date();
        const isToday = item._lastMessageDate.dateObject.getFullYear() === now.getFullYear() &&
            item._lastMessageDate.dateObject.getMonth() === now.getMonth() &&
            item._lastMessageDate.dateObject.getDate() === now.getDate();
        const displayDate = isToday
            ? item._lastMessageDate.time
            : this.formatMessageDate(item._lastMessageDate.dateObject);
        if (item.users.length > 0) {
            const sortedUsers = [...item.users].sort((a, b) => b.name.length - a.name.length);
            if (userMessageId === this.userId)
                userMessageId = this.msg.lastMessagePrefix;
            else
                userMessageId = sortedUsers.find(u => u.userId === userMessageId)?.name || '';
            userMessage = userMessage.replace(/\[@([^\]]+)\]\(([^)]+)\)/g, (_m, name, userId) => {
                const user = sortedUsers.find(u => u.userId === userId);
                if (!user)
                    return `@${name}`;
                return `@${user.name}`;
            });
        }
        return html `
        <li .item=${item} threadId=${item.thread.threadId} 
            @click=${() => this.onThreadClick(item)} 
            class="thread-item ${hasPendingNotification ? 'has-notification' : ''}">
            <div class="thread-item-avatar">
                ${threadAvatar.startsWith('<') && threadAvatar.endsWith('>') ?
            html `${unsafeHTML(threadAvatar)}` :
            html `<img src="${threadAvatar}"></img>`}
            </div>
            <div class="thread-content">
                <div class="thread-item-header">
                    <span class="thread-name">${threadName}</span>
                    <span class="last-update">
                        ${this.renderTaskPendingsCount(pendingTasksCount)}
                        ${displayDate}
                    </span>
                </div>
                <div class="thread-summary">
                    ${userMessage ? html `
                            <span class="last-message">${userMessageId && !isDirectMessage ? html `<span>${userMessageId}:</span>` : nothing}${userMessage || ''}</span>
                        ` : nothing}
                    
                    ${unreadCount > 0 ? html `<span class="unread-count">${unreadCount}</span>` : hasPendingNotification ? html `<span class="unread-count">•</span>` : nothing}
                </div>
            </div>
        </li>
    `;
    }
    renderTaskPendingsCount(pendingTasksCount) {
        return html `
            ${pendingTasksCount > 0 ? html `
                <span class="tasks-pendings-count">
                    ${collab_bell}
                    <span class="notification-badge">${pendingTasksCount}</span>
                </span>` : nothing}
        `;
    }
    formatMessageDate(input) {
        const date = typeof input === 'string' ? new Date(input) : input;
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const target = new Date(date.getFullYear(), date.getMonth(), date.getDate());
        const diffTime = today.getTime() - target.getTime();
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
        if (diffDays === 0)
            return this.msg.today;
        if (diffDays === 1)
            return this.msg.yesterday;
        const lang = document.querySelector('html')?.lang || 'pt-BR';
        if (diffDays > 1 && diffDays < 7) {
            return target.toLocaleDateString(lang, {
                weekday: 'short',
            });
        }
        return target.toLocaleDateString(lang);
    }
    renderArchivedThreads() {
        if (this.filteredThreads.archived.length === 0)
            return html `${nothing}`;
        return html `        
            ${this.filteredThreads.archived.map((item) => {
            let threadAvatar = this.getThreadAvatar(item);
            const unreadCount = item.thread.unreadCount || 0;
            function isWithinLastWeek(date) {
                const now = new Date();
                const oneWeekAgo = new Date();
                oneWeekAgo.setDate(now.getDate() - 7);
                return date >= oneWeekAgo;
            }
            if (!item._lastMessageDateArchived)
                return html ``;
            return html `
                ${!isWithinLastWeek(item._lastMessageDateArchived.dateObject)
                ? html `${nothing}`
                : html `
                        <li @click=${() => this.onThreadClick(item)} class="thread-item">
                            <div class="thread-item-avatar">
                                    ${threadAvatar.startsWith('<') && threadAvatar.endsWith('>') ?
                    html `${unsafeHTML(threadAvatar)}` :
                    html `<img src="${threadAvatar}"></img>`}
                            </div>
                            <div class="thread-content">
                                <div class="thread-item-header">
                                    <span class="thread-name">(${this.msg.archived}) ${item.thread.name || item.thread.threadId}</span>
                                    ${unreadCount > 0 ? html `<span class="unread-count">*</span>` : nothing}
                                </div>
                            </div>
                        </li>`}`;
        })}
        `;
    }
    renderDeletingThreads() {
        if (this.filteredThreads.deleting.length === 0)
            return html ``;
        return html `        
            ${this.filteredThreads.deleting.map((item) => {
            let threadAvatar = this.getThreadAvatar(item);
            const unreadCount = item.thread.unreadCount || 0;
            function isWithinLastWeek(date) {
                const now = new Date();
                const oneWeekAgo = new Date();
                oneWeekAgo.setDate(now.getDate() - 7);
                return date >= oneWeekAgo;
            }
            if (!item.lastMessageDateDeleting)
                return html ``;
            return html `
                ${!isWithinLastWeek(item.lastMessageDateDeleting.dateObject)
                ? html ``
                : html `
                        <li @click=${() => this.onThreadClick(item)} class="thread-item">
                            <div class="thread-item-avatar">
                                    ${threadAvatar.startsWith('<') && threadAvatar.endsWith('>') ?
                    html `${unsafeHTML(threadAvatar)}` :
                    html `<img src="${threadAvatar}"></img>`}
                            </div>
                            <div class="thread-content">
                                <div class="thread-item-header">
                                    <span class="thread-name">(${this.msg.deleting}) ${item.thread.name || item.thread.threadId}</span>
                                    ${unreadCount > 0 ? html `<span class="unread-count">*</span>` : nothing}

                                </div>
                            </div>
                        </li>`}`;
        })}
        `;
    }
    renderDeletedThreads() {
        if (this.filteredThreads.deleted.length === 0)
            return html ``;
        return html `      
          
            ${this.filteredThreads.deleted.map((item) => {
            let threadAvatar = this.getThreadAvatar(item);
            if (!item.lastMessageDateDeleting)
                return html ``;
            const unreadCount = item.thread.unreadCount || 0;
            return html `
                <li @click=${() => this.onThreadClick(item)} class="thread-item">
                    <div class="thread-item-avatar">
                            ${threadAvatar.startsWith('<') && threadAvatar.endsWith('>') ?
                html `${unsafeHTML(threadAvatar)}` :
                html `<img src="${threadAvatar}"></img>`}
                    </div>
                    <div class="thread-content">
                        <div class="thread-item-header">
                            <span class="thread-name" style="text-decoration: line-through;">(${this.msg.deleted}) ${item.thread.name || item.thread.threadId}</span>
                            ${unreadCount > 0 ? html `<span class="unread-count">*</span>` : nothing}
                        </div>
                    </div>
                </li>`;
        })}
        `;
    }
    renderThreadSearch() {
        return html `
		<collab-messages-filter-102025
			@search-change=${this.onSearchInput}
            .expanded=${this.searchTerm !== ''}
            .query=${this.searchTerm}
			placeholder=${this.msg.placeholderSearch}>
		</collab-messages-filter-102025>
	`;
    }
    renderTaskDetails() {
        if (this.elementTaskDetails) {
            return html `${this.elementTaskDetails}`;
        }
        return html `<span> No find any widget to show task details <span>`;
    }
    renderThreadDetails() {
        return html `<collab-messages-thread-details-102025 userId=${this.userId} .threadDetails=${{ ...this.actualThread }}></collab-messages-thread-details-102025>`;
    }
    renderThreadAdd() {
        return html `
            <collab-messages-add-102025 
                .onAddSuccess = ${() => { this.activeScenerie = 'list'; }}
                .group=${this.group}
                userId=${this.userId} 
            ></collab-messages-add-102025>`;
    }
    onSearchInput(e) {
        this.searchTerm = e.detail.toLowerCase();
        const ordenedThreads = this.getOrdenedThreadsByStatus();
        this.filteredThreads = this.getFilteredThreads(ordenedThreads);
    }
    getScrollAnchor(container) {
        const containerRect = container.getBoundingClientRect();
        const messages = Array.from(container.querySelectorAll('collab-messages-chat-message-102025'));
        for (const message of messages) {
            const rect = message.getBoundingClientRect();
            if (rect.bottom >= containerRect.top) {
                const messageId = message.getAttribute('messageid');
                if (!messageId)
                    return;
                return {
                    messageId,
                    offsetTop: rect.top - containerRect.top
                };
            }
        }
    }
    restoreScrollAnchor(container, anchor) {
        if (!anchor)
            return;
        const target = container.querySelector(`collab-messages-chat-message-102025[messageid="${anchor.messageId}"]`);
        if (!target)
            return;
        const containerRect = container.getBoundingClientRect();
        const targetRect = target.getBoundingClientRect();
        container.scrollTop += targetRect.top - containerRect.top - anchor.offsetTop;
        this.savedScrollTop = container.scrollTop;
    }
    async updateMessagesAfterScrollMore(newMessages, container, anchor) {
        this.actualMessages = [...this.actualMessages, ...newMessages];
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        await this.updateComplete;
        await this.waitingForRenderCodesWebComponents();
        await this.nextFrame();
        await this.nextFrame();
        this.restoreScrollAnchor(container, anchor);
    }
    maxLoadedOrderAt() {
        let maxOrderAt = '';
        for (const message of this.actualMessages) {
            const orderAt = message.orderAt || message.createAt;
            if (orderAt > maxOrderAt)
                maxOrderAt = orderAt;
        }
        return maxOrderAt;
    }
    async loadMessagesAfterWindow() {
        if (!this.actualThread)
            return;
        const lastOrderAt = this.maxLoadedOrderAt();
        if (!lastOrderAt)
            return;
        const loadedKeys = new Set(this.actualMessages.map(message => this.getMessageCacheKey(message)));
        const localMessages = await getAllMessagesByThreadId(this.actualThread.thread.threadId);
        const picked = pickMessagesAfter(localMessages, lastOrderAt, loadedKeys, this.messagesLimit);
        let page = picked.messages;
        let hasMoreAfter = picked.hasMoreAfter;
        if (page.length === 0) {
            let afterResponse;
            try {
                afterResponse = await this.getMessagesAfter(this.actualThread.thread, lastOrderAt);
            }
            catch (error) {
                console.error(error);
                return;
            }
            if (!afterResponse) {
                console.error('Failed to fetch messages after the open window');
                return;
            }
            const data = afterResponse.data || [];
            page = data.slice(0, this.messagesLimit).map(message => ({ ...message, footers: [] }));
            hasMoreAfter = !!afterResponse.hasMore || data.length > this.messagesLimit;
        }
        this.actualMessages = [...this.actualMessages, ...page];
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.hasMoreMessagesAfter = hasMoreAfter;
    }
    async getBeforeMessagesInServer(thread) {
        const firstItem = [...this.actualMessages]
            .sort((a, b) => (a.orderAt || a.createAt).localeCompare(b.orderAt || b.createAt))[0];
        if (!firstItem)
            return [];
        const response = await this.getMessagesBefore(thread, firstItem.orderAt || firstItem.createAt);
        const newMessages = response?.data;
        this.hasMoreMessagesBefore = response?.hasMore || false;
        return newMessages;
    }
    async getBeforeMessagesInLocalDb(threadId) {
        const firstItem = [...this.actualMessages]
            .sort((a, b) => (a.orderAt || a.createAt).localeCompare(b.orderAt || b.createAt))[0];
        if (!firstItem)
            return [];
        const firstOrderAt = firstItem.orderAt || firstItem.createAt;
        const loadedMessageIds = new Set(this.actualMessages.map(message => this.getMessageCacheKey(message)));
        const messages = await getAllMessagesByThreadId(threadId);
        return messages
            .filter(message => (message.orderAt || message.createAt) < firstOrderAt &&
            !loadedMessageIds.has(this.getMessageCacheKey(message)))
            .sort((a, b) => (b.orderAt || b.createAt).localeCompare(a.orderAt || a.createAt))
            .slice(0, this.messagesLimit);
    }
    onCopyChat(ev) {
        ev.preventDefault();
        const selection = window.getSelection();
        if (!selection)
            return;
        let container = document.createElement("div");
        for (let i = 0; i < selection.rangeCount; i++) {
            container.appendChild(selection.getRangeAt(i).cloneContents());
        }
        const extractMessage = (el) => {
            const titleEl = el.querySelector(".message-title");
            const timeEl = el.querySelector(".message-footer");
            const contentEl = el.querySelector(".collab-md-message");
            const taskEl = el.querySelector('collab-messages-task-102025');
            let author = titleEl?.textContent?.trim();
            const content = contentEl?.innerText?.trim() || "";
            const time = timeEl?.textContent?.trim() || "";
            const task = taskEl?.getAttribute('taskid');
            return {
                author,
                content,
                time,
                task
            };
        };
        const items = container.querySelectorAll(".message-time, .message-card");
        if (items.length === 0) {
            const { author, content, task, time } = extractMessage(container);
            if (content) {
                const msg = `${time ? time : ''} ${author ? author : ''} ${content} ${task ? `(Task:${task})` : ''}`;
                return ev.clipboardData?.setData("text/plain", msg);
            }
            ev.clipboardData?.setData("text/plain", selection.toString());
            return;
        }
        let result = [];
        let lastAuthor = "";
        let currentDate = "";
        items.forEach(el => {
            if (el.classList.contains("message-time")) {
                currentDate = el.textContent?.trim() || '';
                result.push(`--- ${currentDate} ---`);
            }
            else {
                let { author, content, task, time } = extractMessage(el);
                if (!author)
                    author = lastAuthor;
                else
                    lastAuthor = author;
                if (content) {
                    result.push(`${time ? time : ''} ${author ? author : ''} ${content} ${task ? `(Task:${task})` : ''}`);
                }
            }
        });
        if (result.length > 0) {
            ev.clipboardData?.setData("text/plain", result.join("\n"));
        }
    }
    async onChatScroll(e) {
        if (this.scrollLock)
            return;
        this.removeAllModal();
        this.updateTaskNotificationNavDirection();
        if (this.isChangeTopics) {
            this.isChangeTopics = false;
            return;
        }
        if (this.isSystemChangeScroll) {
            this.isSystemChangeScroll = false;
            const systemContainer = e.target;
            const systemThreshold = 5;
            const systemAtBottom = systemContainer.scrollTop + systemContainer.clientHeight >= systemContainer.scrollHeight - systemThreshold;
            if (systemAtBottom) {
                void this.markOpenThreadReadIf('systemScroll').catch((error) => console.error(error));
            }
            return;
        }
        this.applyFollowupNotice('userScroll');
        if (this.isToolbarAutoScroll || Date.now() <= this.ignoreToolbarScrollClearUntil) {
            this.deferToolbarAutoScrollEnd();
        }
        else {
            this.clearToolbarSelection();
        }
        const container = e.target;
        this.savedScrollTop = container.scrollTop;
        const threshold = 5;
        const atBottom = container.scrollTop + container.clientHeight >= container.scrollHeight - threshold;
        this.wasMessagesAtBottom = this.hasMoreMessagesAfter ? false : atBottom;
        const nextShowJumpToLatest = this.hasMoreMessagesAfter ||
            (container.scrollHeight - container.scrollTop - container.clientHeight > container.clientHeight);
        if (nextShowJumpToLatest !== this.showJumpToLatest)
            this.showJumpToLatest = nextShowJumpToLatest;
        if (this.wasMessagesAtBottom &&
            this.actualThread &&
            (this.unreadCountInSelectedThread > 0 || hasThreadNotificationPending(this.actualThread.thread.threadId))) {
            await this.clearUnreadMarkerForActualThread();
        }
        if (atBottom &&
            this.hasMoreMessagesAfter &&
            !this.isLoadingMoreMessages &&
            this.actualThread) {
            this.isLoadingMoreMessages = true;
            try {
                await this.loadMessagesAfterWindow();
            }
            finally {
                this.isLoadingMoreMessages = false;
            }
            return;
        }
        const scrollAnchor = this.getScrollAnchor(container);
        if (container.scrollTop === 0 &&
            !this.isLoadingMoreMessages &&
            this.actualThread &&
            !this.hasMoreMessagesLocalDB &&
            this.hasMoreMessagesBefore) {
            this.isLoadingMoreMessages = true;
            const newMessages = await this.getBeforeMessagesInServer(this.actualThread.thread);
            if (newMessages)
                await this.updateMessagesAfterScrollMore(newMessages.map(item => ({ ...item, footers: [], })), container, scrollAnchor);
            this.isLoadingMoreMessages = false;
            return;
        }
        if (container.scrollTop === 0 &&
            !this.isLoadingMoreMessages &&
            this.actualThread &&
            this.hasMoreMessagesLocalDB) {
            this.isLoadingMoreMessages = true;
            const newMessages = await this.getBeforeMessagesInLocalDb(this.actualThread.thread.threadId);
            if (newMessages.length > 0) {
                await this.updateMessagesAfterScrollMore(newMessages, container, scrollAnchor);
            }
            else {
                const newMessages = await this.getBeforeMessagesInServer(this.actualThread.thread);
                if (newMessages)
                    await this.updateMessagesAfterScrollMore(newMessages.map(item => ({ ...item, footers: [], })), container, scrollAnchor);
                this.hasMoreMessagesLocalDB = false;
            }
            this.isLoadingMoreMessages = false;
        }
    }
    getFirstPendingTaskNotificationInView() {
        if (!this.actualThread)
            return '';
        const pendingTaskIds = getPendingTaskNotificationsForThread(this.actualThread.thread.threadId);
        if (pendingTaskIds.length === 0)
            return '';
        const renderedTasks = Array.from(this.querySelectorAll('collab-messages-task-102025'));
        const found = renderedTasks.find((item) => pendingTaskIds.includes(item.getAttribute('taskid') || ''));
        return found?.getAttribute('taskid') || '';
    }
    getTaskNotificationElement(taskId) {
        if (!taskId)
            return null;
        return this.querySelector(`collab-messages-task-102025[taskid="${taskId}"]`);
    }
    updateTaskNotificationNavDirection() {
        const taskId = this.getFirstPendingTaskNotificationInView();
        const taskEl = this.getTaskNotificationElement(taskId);
        if (!this.messageContainer || !taskEl) {
            if (this.taskNotificationNavDirection)
                this.taskNotificationNavDirection = '';
            return;
        }
        const containerRect = this.messageContainer.getBoundingClientRect();
        const taskRect = taskEl.getBoundingClientRect();
        let nextDirection = '';
        if (taskRect.bottom < containerRect.top)
            nextDirection = 'up';
        else if (taskRect.top > containerRect.bottom)
            nextDirection = 'down';
        if (this.taskNotificationNavDirection !== nextDirection) {
            this.taskNotificationNavDirection = nextDirection;
        }
    }
    async scrollToTaskNotification(taskId) {
        const taskEl = this.getTaskNotificationElement(taskId);
        if (!taskEl)
            return;
        taskEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await this.nextFrame();
        this.updateTaskNotificationNavDirection();
    }
    groupThreadsByPrefix(threads) {
        const groups = {};
        for (const t of threads) {
            const name = this.getThreadName(t);
            if (name.startsWith('_') && name.includes('/')) {
                const [prefix] = name.split('/');
                if (!groups[prefix])
                    groups[prefix] = [];
                groups[prefix].push(t);
            }
            else {
                if (!groups[name])
                    groups[name] = [];
                groups[name].push(t);
            }
        }
        return groups;
    }
    getOrdenedThreadsByStatus() {
        const threads = this.userThreads[this.group]
            .map((item) => {
            const lastTimestamp = item.thread.lastMessageTime
                ? item.thread.lastMessageTime
                : item.thread.history?.length ? item.thread.history[0]?.timestamp : '';
            const formatedTimestamp = formatTimestamp(lastTimestamp)?.dateFull;
            const lastMessageDate = this.parseLocalDate(formatedTimestamp || '');
            let lastMessageDateArchived;
            let lastMessageDateDeleting;
            if (item.thread.status === 'archived' && item.thread.archivedAt) {
                const formatedTimestampArchived = formatTimestamp(item.thread.archivedAt)?.dateFull;
                lastMessageDateArchived = this.parseLocalDate(formatedTimestampArchived || '');
            }
            if ((item.thread.status === 'deleting' || item.thread.status === 'deleted') && item.thread.deletedAt) {
                const formatedTimestampArchived = formatTimestamp(item.thread.deletedAt)?.dateFull;
                lastMessageDateDeleting = this.parseLocalDate(formatedTimestampArchived || '');
            }
            return {
                ...item,
                _lastMessageDate: lastMessageDate,
                _lastMessageDateArchived: lastMessageDateArchived,
                lastMessageDateDeleting: lastMessageDateDeleting,
            };
        })
            .sort((a, b) => b._lastMessageDate.dateObject.getTime() -
            a._lastMessageDate.dateObject.getTime());
        const result = {
            archived: [],
            deleted: [],
            deleting: [],
            active: [],
        };
        for (const threadInfo of threads) {
            if (threadInfo.thread.status === 'archived') {
                result.archived.push(threadInfo);
            }
            else if (threadInfo.thread.status === 'deleted') {
                result.deleted.push(threadInfo);
            }
            else if (threadInfo.thread.status === 'deleting') {
                result.deleting.push(threadInfo);
            }
            else {
                result.active.push(threadInfo);
            }
        }
        return result;
    }
    getFilteredThreads(ordened) {
        if (!this.searchTerm)
            return ordened;
        const term = this.searchTerm.toLowerCase();
        Object.keys(ordened).forEach((key) => {
            const key2 = key;
            ordened[key2] = ordened[key2].filter(item => {
                const threadName = item.thread.name?.toLowerCase() ?? '';
                if (threadName.startsWith('@')) {
                    const users = item.thread.users
                        .map(u => this.usersAvaliables.find(au => au.userId === u.userId));
                    return users.some(user => (`@${user?.name.toLowerCase()}`).includes(term));
                }
                return threadName.includes(term);
            });
        });
        return ordened;
    }
    async getMessagesAfter(thread, lastOrderAt = '') {
        if (!this.userId)
            return;
        const result = await msgGetMessagesAfter({
            lastOrderAt,
            threadId: thread.threadId,
            userId: this.userId
        });
        if (!result.success || !result.response) {
            console.warn('Failed to fetch messages after:', result.error);
            return;
        }
        return result.response;
    }
    async getMessagesBefore(thread, orderAt = '') {
        if (!this.userId)
            return;
        const result = await msgGetMessagesBefore({
            orderAt,
            threadId: thread.threadId,
            userId: this.userId
        });
        if (!result.success || !result.response) {
            console.warn('Failed to fetch messages before:', result.error);
            return;
        }
        return result.response;
    }
    parseMessages(rawData, topic) {
        const groupedByDay = {};
        [...rawData].forEach(msg => {
            if (topic &&
                msg.content &&
                !(msg.content.startsWith(`${topic} `) ||
                    msg.content.endsWith(` ${topic}`) ||
                    msg.content.includes(` ${topic} `))) {
                return;
            }
            const formatted = formatTimestamp(msg.createAt);
            const dateKey = formatted?.date ||
                msg.createAt
                    .slice(0, 8)
                    .replace(/(\d{4})(\d{2})(\d{2})/, '$1-$2-$3');
            if (!groupedByDay[dateKey]) {
                groupedByDay[dateKey] = [];
            }
            groupedByDay[dateKey].push(msg);
        });
        for (const day in groupedByDay) {
            groupedByDay[day].sort((a, b) => a.orderAt.localeCompare(b.orderAt));
        }
        return this.groupMessages(groupedByDay);
    }
    groupMessages(groupedByDay) {
        const result = {};
        Object.keys(groupedByDay).forEach((key) => {
            let consecutiveCount = 0;
            let lastSenderId = null;
            result[key] = groupedByDay[key].map((msg, index, arr) => {
                let isSame = false;
                if (msg.senderId === lastSenderId) {
                    consecutiveCount++;
                    isSame = true;
                    if (consecutiveCount >= 3) {
                        consecutiveCount = 0;
                        isSame = false;
                    }
                }
                else {
                    consecutiveCount = 0;
                    isSame = false;
                    lastSenderId = msg.senderId;
                }
                return { ...msg, isSame };
            });
        });
        return result;
    }
    parseLocalDate(dateString) {
        const normalized = dateString.includes(' ')
            ? dateString.replace(' ', 'T')
            : `${dateString}T00:00:00`;
        const date = new Date(normalized);
        return {
            dateObject: date,
            datafull: date.toLocaleString(),
            date: date.toLocaleDateString(),
            time: date.toTimeString().split(' ')[0]
        };
    }
    mergeMessages(array1, array2) {
        const map = new Map();
        for (const item of array1) {
            map.set(`${item.threadId}/${item.createAt}`, item);
        }
        for (const item of array2) {
            map.set(`${item.threadId}/${item.createAt}`, { ...map.get(`${item.threadId}/${item.createAt}`), ...item });
        }
        return Array.from(map.values());
    }
    async onThreadClick(threadInfo) {
        this.showPersonalMemory = false;
        this.welcomeMessage = '';
        this.activeScenerie = 'loading';
        this.lastTopicFilter = '';
        this.hasMoreMessagesLocalDB = true;
        this.hasMoreMessagesBefore = false;
        this.hasMoreMessagesAfter = false;
        this.showJumpToLatest = false;
        this.toolbarView = {};
        this.toolbarNavigationKind = undefined;
        this.toolbarNavigationFailedKind = undefined;
        this.toolbarNavigationError = '';
        this.cachedToolbarMessages = [];
        this.ignoreToolbarScrollClearUntil = 0;
        this.actualThread = threadInfo;
        const temp = await getThread(this.actualThread.thread.threadId);
        this.unreadCountInSelectedThread = temp?.unreadCount ?? threadInfo.thread.unreadCount ?? 0;
        this.lastMessageReaded = temp?.lastMessageReadTime || threadInfo.thread.lastMessageReadTime || '';
        const messagesInDb = await getMessagesByThreadId(this.actualThread.thread.threadId, this.messagesLimit, 0);
        this.actualMessages = messagesInDb;
        await this.refreshCachedToolbarMessages();
        this.applyFollowupNotice('open');
        this.isSystemChangeScroll = true;
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.activeScenerie = 'details';
        this.isLoadingMessages = true;
        this.isThreadError = false;
        this.threadErrorMsg = '';
        this.checkWelcomeMessage(this.actualThread.thread, messagesInDb);
        try {
            if (!this.userId)
                return;
            const threadByServer = await this.getThreadInfo(this.actualThread.thread.threadId, this.userId, threadInfo.thread.lastSync || new Date('2000-01-01').toISOString());
            const threadUpdated = await updateThread(threadByServer.thread.threadId, threadByServer.thread);
            threadInfo = await this.updateMessagesOnDb(threadByServer, threadByServer.messages);
            await updateUsers(threadByServer.users);
            this.actualThread = { ...threadByServer };
            this.updateUsersInState(threadByServer.users);
            notifyThreadChange(threadUpdated);
            if (threadByServer.hasMore)
                await this.loadAllMessages(threadInfo);
            await this.clearUnreadMarkerForActualThread();
            if (threadByServer.threadsPending) {
                this.updateThreadPendingsInBackground(threadInfo.thread.threadId, threadByServer.threadsPending);
            }
            if (['deleted'].includes(threadByServer.thread.status)) {
                await deleteAllMessagesFromThread(threadByServer.thread.threadId);
                const threadUpdated = await this.clearUnreadMessageFromThread(threadByServer.thread);
                notifyThreadChange(threadUpdated);
            }
            this.checkNotificationsUnreadMessages();
            if (this.taskToOpen) {
                await this.updateComplete;
                this.openTask();
            }
            await this.verifyChatScroll();
        }
        catch (err) {
            this.isThreadError = true;
            this.threadErrorMsg = err.message || 'Error on read thread';
            throw new Error('Error on loading messages: ' + err.message);
        }
        finally {
            this.isLoadingMessages = false;
        }
    }
    async updateThreadPendingsInBackground(threadId, threadsPendings) {
        for await (let threadPending of threadsPendings) {
            let threadId2 = '';
            const parts = threadPending.split(':');
            threadId2 = parts[0];
            if (threadId !== threadId2) {
                removeThreadFromSync(threadId2);
                await getThreadUpdateInBackground(threadPending);
            }
        }
    }
    async markActualThreadRead(threadId) {
        const lastMessageReadTime = this.getLastKnownMessageCreateAt();
        const thread = await markThreadReadLocally(threadId, lastMessageReadTime);
        if (thread && this.actualThread?.thread.threadId === threadId) {
            this.actualThread.thread = thread;
        }
    }
    async clearUnreadMarkerForActualThread() {
        if (!this.actualThread)
            return;
        const lastMessageReadTime = this.getLastKnownMessageCreateAt();
        const thread = await markThreadReadLocally(this.actualThread.thread.threadId, lastMessageReadTime);
        if (thread)
            this.actualThread.thread = thread;
        this.unreadCountInSelectedThread = 0;
        this.lastMessageReaded = lastMessageReadTime || '';
    }
    async markOpenThreadReadIf(reason) {
        // `leave` no disconnectedCallback corre com isConnected já false; os outros reasons vêm de listener.
        if (!this.isConnected && reason !== 'leave')
            return;
        if (!shouldMarkOpenThreadRead({
            hasOpenThread: !!this.actualThread,
            pageVisible: document.visibilityState === 'visible',
            inDetails: this.activeScenerie === 'details',
            reason,
        }))
            return;
        if (reason !== 'leave' &&
            this.actualThread &&
            this.unreadCountInSelectedThread === 0 &&
            (this.actualThread.thread.unreadCount ?? 0) === 0 &&
            !hasThreadNotificationPending(this.actualThread.thread.threadId))
            return;
        await this.clearUnreadMarkerForActualThread();
    }
    getLastKnownMessageCreateAt() {
        const lastMessage = [...this.actualMessages]
            .sort((a, b) => (a.orderAt || a.createAt).localeCompare(b.orderAt || b.createAt))[this.actualMessages.length - 1];
        return lastMessage?.createAt;
    }
    openTask() {
        let taskEl = null;
        if (this.taskToOpen === 'last') {
            const tasks = this.querySelectorAll('collab-messages-task-102025');
            taskEl = tasks[tasks.length - 1] || null;
        }
        else {
            taskEl = this.querySelector(`collab-messages-task-102025[taskid="${this.taskToOpen}"]`);
        }
        if (taskEl) {
            taskEl.dispatchEvent(new CustomEvent('taskclick', {
                bubbles: true,
                composed: true
            }));
        }
        this.taskToOpen = '';
    }
    checkWelcomeMessage(thread, messagesInDb) {
        if (messagesInDb.length > 0)
            return;
        if (!thread.welcomeMessage)
            return;
        this.welcomeMessage = thread.welcomeMessage;
    }
    async refreshCachedToolbarMessages(isCurrent = () => true) {
        const threadId = this.actualThread?.thread.threadId;
        if (!threadId) {
            if (isCurrent())
                this.cachedToolbarMessages = [];
            return;
        }
        try {
            const messages = await getAllMessagesByThreadId(threadId);
            if (isCurrent())
                this.cachedToolbarMessages = messages;
        }
        catch (err) {
            if (!isCurrent())
                return;
            console.warn('Failed to refresh toolbar messages from cache:', err);
            this.cachedToolbarMessages = [];
        }
    }
    async checkNotificationsUnreadMessages() {
        const hasPendingMessages = await checkIfNotificationUnread();
        if (!hasPendingMessages) {
            changeFavIcon(false);
            notifyThreadNotification(false);
        }
    }
    async loadAllMessages(threadInfo) {
        const response = await this.getMessagesAfter(threadInfo.thread, threadInfo.thread.lastSync || '');
        if (!response || !response.data || response.data.length === 0 || !this.actualThread || !this.userId) {
            return;
        }
        threadInfo = await this.updateMessagesOnDb(threadInfo, response.data);
        if (!response.hasMore)
            return;
        return this.loadAllMessages(threadInfo);
    }
    async updateMessagesOnDb(threadInfo, messages) {
        if (!messages)
            return threadInfo;
        const newMessages = [];
        for await (let mm of messages) {
            const messageId = this.normalizeMessageId(mm.threadId, mm.orderAt || mm.createAt);
            const messageOld = await getMessage(messageId);
            const tempMessage = { ...mm, footers: messageOld?.footers || [] };
            newMessages.push(tempMessage);
        }
        const lastMessages = newMessages[newMessages.length - 1] || this.actualMessages[0];
        await addMessages(newMessages);
        let maxOrderAt = '';
        for (const message of newMessages) {
            const orderAt = message.orderAt || '';
            if (orderAt > maxOrderAt)
                maxOrderAt = orderAt;
        }
        const currentLastSync = threadInfo.thread.lastSync || '';
        if (maxOrderAt > currentLastSync) {
            threadInfo.thread.lastSync = maxOrderAt;
            const savedThread = await updateThread(threadInfo.thread.threadId, threadInfo.thread, undefined, undefined, undefined, maxOrderAt);
            threadInfo.thread = savedThread;
        }
        const preserveUnreadMarker = this.shouldPreserveUnreadMarker(threadInfo.thread.threadId);
        if (lastMessages && this.actualThread && !preserveUnreadMarker)
            this.actualThread.thread = await updateLastMessageReadTime(threadInfo.thread.threadId, lastMessages.createAt);
        this.actualMessages = this.mergeMessages(this.actualMessages, newMessages);
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        await this.refreshCachedToolbarMessages();
        await this.updateLastMessage(threadInfo, preserveUnreadMarker);
        return threadInfo;
    }
    async clearUnreadMessageFromThread(thread) {
        const _thread = await updateThread(thread.threadId, thread, '', '', 0);
        if (this.actualThread)
            this.actualThread.thread = _thread;
        return _thread;
    }
    shouldPreserveUnreadMarker(threadId) {
        return this.actualThread?.thread.threadId === threadId && this.unreadCountInSelectedThread > 0;
    }
    getFirstUnreadMessageCreateAt() {
        if (!this.unreadCountInSelectedThread)
            return '';
        const sortedMessages = [...this.actualMessages].sort((a, b) => (a.orderAt || a.createAt).localeCompare(b.orderAt || b.createAt));
        if (!this.lastMessageReaded)
            return sortedMessages[0]?.createAt || '';
        const lastReadIndex = sortedMessages.findIndex(message => message.createAt === this.lastMessageReaded);
        return sortedMessages[lastReadIndex + 1]?.createAt || '';
    }
    getUnreadMessagesCount() {
        const firstUnreadMessageCreateAt = this.getFirstUnreadMessageCreateAt();
        if (!firstUnreadMessageCreateAt)
            return 0;
        const sortedMessages = [...this.actualMessages].sort((a, b) => (a.orderAt || a.createAt).localeCompare(b.orderAt || b.createAt));
        const firstUnreadIndex = sortedMessages.findIndex(message => message.createAt === firstUnreadMessageCreateAt);
        return firstUnreadIndex >= 0 ? sortedMessages.length - firstUnreadIndex : 0;
    }
    async updateLastMessage(threadInfo, preserveUnreadMarker = false) {
        const keys = Object.keys(this.actualMessagesParsed).sort();
        const lastKey = keys.length > 0 ? keys[keys.length - 1] : null;
        const lastArray = lastKey ? this.actualMessagesParsed[lastKey] : [];
        const lastMessage = lastArray.length > 0 ? lastArray[lastArray.length - 1] : undefined;
        if (lastMessage) {
            const lastMessageText = `${lastMessage.senderId}:${lastMessage.content}`;
            const unreadCount = preserveUnreadMarker ? this.getUnreadMessagesCount() : 0;
            const thread = await updateThread(threadInfo.thread.threadId, threadInfo.thread, lastMessageText, lastMessage.createAt, unreadCount, lastMessage.createAt);
            if (preserveUnreadMarker)
                this.unreadCountInSelectedThread = unreadCount;
            threadInfo.thread = thread;
            notifyThreadChange(thread);
        }
    }
    async onTitleClick() {
        await this.updateComplete;
        if (this.showPersonalMemory) {
            await this.closePersonalMemory(true);
            return;
        }
        if (this.activeScenerie === 'task') {
            this.activeScenerie = 'details';
            return;
        }
        if (this.activeScenerie === 'details' || this.activeScenerie === 'threadAdd') {
            try {
                await this.markOpenThreadReadIf('leave');
            }
            catch (error) {
                console.error(error);
            }
            this.actualThread = undefined;
            this.activeScenerie = 'list';
            return;
        }
        if (this.activeScenerie === 'threadDetails') {
            this.activeScenerie = 'details';
            return;
        }
        if (this.activeScenerie === 'forwardMessage') {
            this.cancelForwardMessage();
            return;
        }
        if (this.activeScenerie === 'toolbarHelp') {
            this.closeToolbarHelp();
            return;
        }
    }
    onThreadDetailsClick() {
        this.saveScrollPosition();
        this.activeScenerie = 'threadDetails';
    }
    isE01Thread() {
        return isPersonalAgentDm(this.actualThread?.thread, this.userId);
    }
    async closePersonalMemory(restoreFocus) {
        const trigger = this.personalMemoryTrigger;
        this.showPersonalMemory = false;
        await this.updateComplete;
        if (restoreFocus && trigger?.isConnected)
            trigger.focus();
        this.personalMemoryTrigger = undefined;
    }
    getE01SessionKey() {
        return `${this.e01RootSessionKey}:${this.e01SessionEpoch}:${this.userId || ''}:${this.actualThread?.thread.threadId || ''}`;
    }
    onThreadAddClick() {
        this.activeScenerie = 'threadAdd';
    }
    async showLocalSystemMessage(content) {
        if (!this.actualThread)
            return;
        const message = await this.createTempMessage(content, 'system', this.actualThread.thread.threadId, undefined);
        message.isLoading = false;
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.requestUpdate();
    }
    async handleSend(value, opt) {
        if (isHelpCommand(value)) {
            await this.showLocalSystemMessage(this.msg.localCommandsHelp);
            return;
        }
        if (isTestplayCommand(value)) {
            const report = await runNotificationTestplay();
            await this.showLocalSystemMessage(report);
            return;
        }
        if (!this.canWriteCurrentThread()) {
            throw new Error(this.msg.readOnlyThread);
        }
        this.isSystemChangeScroll = true;
        this.lastTopicFilter = '';
        if (this.actualThread) {
            const isDirectMessage = this.isDirectMessage(this.actualThread);
            const isDirectMessageToAgent = this.actualThread.thread.openClawAgents?.some(agent => this.actualThread?.thread.users?.some(user => user.userId === agent.collabUserId));
            if (isDirectMessage && isDirectMessageToAgent && !value.startsWith('@@')) {
                const agentDM = this.actualThread?.thread.users.find((user) => user.userId !== this.userId);
                const alias = this.actualThread.thread.openClawAgents?.find((agentOC) => agentOC.collabUserId === agentDM?.userId)?.alias;
                if (alias)
                    value = `@@${alias.trim()} ${value.trim()}`;
            }
        }
        try {
            if (opt.attachments?.length) {
                await this.addAttachmentMessage(value, opt.attachments, opt.replyTo);
            }
            else if (!opt.isSpecialMention) {
                await this.addMessage(value, opt.replyTo);
            }
            else {
                await this.addMessageIA(value, opt.agentName, opt.replyTo);
            }
            await this.scrollMessagesToBottom();
        }
        catch (err) {
            throw new Error(err.message);
        }
    }
    handlePromptResize(e) {
        if (this.wasMessagesAtBottom) {
            const chatEl = this.querySelector('.chat-container');
            if (chatEl)
                chatEl.scrollTop = chatEl.scrollHeight;
        }
    }
    async scrollMessagesToBottom() {
        this.isSystemChangeScroll = true;
        await this.updateComplete;
        await this.waitingForRenderCodesWebComponents();
        await this.nextFrame();
        if (this.messageContainer) {
            this.messageContainer.scrollTop = this.messageContainer.scrollHeight;
            this.wasMessagesAtBottom = true;
            this.updateTaskNotificationNavDirection();
        }
        this.showJumpToLatest = false;
        this.isSystemChangeScroll = false;
    }
    async addMessage(prompt, replyTo) {
        if (!this.userId || !this.actualThread)
            return;
        this.unreadCountInSelectedThread = 0;
        const message = await this.createTempMessage(prompt, this.userId, this.actualThread.thread.threadId, replyTo);
        try {
            const context = {
                message,
                task: undefined,
                isTest: false
            };
            const contextToBot = await getBotsContext(this.actualThread.thread, prompt, context);
            const result = await msgAddMessage({
                content: prompt,
                threadId: this.actualThread.thread.threadId,
                userId: this.userId,
                ...(replyTo ? { replyTo } : {}),
                ...(contextToBot ? { contextToBot } : {}),
                senderDeviceId: loadNotificationDeviceId() || undefined
            });
            if (!result.success || !result.response?.message) {
                throw new Error(result.error || 'Failed to send message');
            }
            message.isFailed = false;
            message.isFailedError = '';
            await this.updateMessage2(false, true, message, result.response.message, result.response.botOutputs);
            const responseMessages = result.response.messages;
            for (const responseMessage of responseMessages || []) {
                await this.updateMessage2(false, true, responseMessage, responseMessage, undefined);
            }
            await this.scrollMessagesToBottom();
            await this.clearUnreadMarkerForActualThread();
        }
        catch (err) {
            message.isFailed = true;
            message.isFailedError = sendErrorMessage(err?.message || 'Failed to send message', this.getMessageKey(messages));
            message.isLoading = false;
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            console.error('Error sending message:', err);
        }
    }
    async addAttachmentMessage(prompt, files, replyTo) {
        if (!this.userId || !this.actualThread)
            return;
        if (files.length === 0)
            return;
        const threadId = this.actualThread.thread.threadId;
        const attachments = [];
        for (const file of files.slice(0, 6)) {
            const contentType = file.type || 'application/octet-stream';
            const createResult = await msgCreateAttachmentUpload({
                userId: this.userId,
                threadId,
                fileName: file.name,
                contentType,
                sizeBytes: file.size
            });
            if (!createResult.success || !createResult.response) {
                throw new Error(createResult.error || 'Failed to create attachment upload');
            }
            const reportUploadFailure = async (failure, httpStatus) => {
                const reportResult = await msgReportAttachmentUploadFailure({
                    userId: this.userId,
                    threadId,
                    attachmentId: createResult.response.attachmentId,
                    storageKey: createResult.response.storageKey,
                    fileName: file.name,
                    contentType,
                    sizeBytes: file.size,
                    stage: 'storage_put',
                    failure,
                    ...(httpStatus !== undefined ? { httpStatus } : {}),
                    pageOrigin: window.location.origin
                });
                if (!reportResult.success) {
                    console.error(`Failed to report attachment upload failure: ${reportResult.error}`);
                }
            };
            let uploadResponse;
            try {
                uploadResponse = await fetch(createResult.response.uploadUrl, {
                    method: 'PUT',
                    headers: createResult.response.headers,
                    body: file
                });
            }
            catch (err) {
                if (navigator.onLine) {
                    await reportUploadFailure('network');
                }
                throw err;
            }
            if (!uploadResponse.ok) {
                await reportUploadFailure('http', uploadResponse.status);
                throw new Error(`Failed to upload attachment: ${file.name}`);
            }
            attachments.push({
                attachmentId: createResult.response.attachmentId,
                storageKey: createResult.response.storageKey,
                fileName: file.name,
                contentType: file.type || 'application/octet-stream',
                sizeBytes: file.size
            });
        }
        const result = await msgCompleteAttachmentUpload({
            userId: this.userId,
            threadId,
            content: prompt,
            ...(replyTo ? { replyTo } : {}),
            attachments
        });
        if (!result.success || !result.response?.message) {
            throw new Error(result.error || 'Failed to complete attachment upload');
        }
        await this.updateMessage2(false, true, result.response.message, result.response.message, undefined);
        this.clearToolbarSelection();
        await this.scrollMessagesToBottom();
        await this.clearUnreadMarkerForActualThread();
    }
    async addMessageIA(prompt, agentName, replyTo) {
        if (!this.userId || !this.actualThread)
            return;
        this.unreadCountInSelectedThread = 0;
        const context = getTemporaryContext(this.actualThread.thread.threadId, this.userId, prompt);
        let agentToCall = AGENTDEFAULT;
        if (agentName)
            agentToCall = agentName;
        const message = await this.createTempMessage(prompt, this.userId, this.actualThread.thread.threadId, replyTo);
        try {
            context.message = message;
            environment.agents.executeAgent(agentToCall, context);
        }
        catch (err) {
            console.error('Error on send message:' + err.message);
            if (message.isLoading) {
                message.isLoading = false;
                message.isFailed = true;
                message.isFailedError = err.message;
                this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            }
        }
    }
    async updateMessageAI(context, updateThreadDB, oldContextCreateAt) {
        // 'task': the details panel is open over the chat; the task card in the
        // message list reads context/lastChanged from here, so it would freeze.
        if (this.activeScenerie !== 'details' && this.activeScenerie !== 'task')
            return;
        if (!context.message)
            return;
        const { content, createAt, orderAt, senderId, threadId, taskId, taskTitle, taskTitleTranslated, taskStatus, taskResults, taskResultsTranslated } = context.message;
        const createAt2 = oldContextCreateAt ? oldContextCreateAt : createAt;
        let messageAdded = this.actualMessages.find((item) => item.senderId === senderId &&
            item.createAt === createAt2 &&
            item.threadId === threadId);
        if (!messageAdded) {
            const newMessage = {
                content,
                createAt,
                orderAt,
                senderId,
                threadId,
                footers: []
            };
            if (updateThreadDB && this.actualThread) {
                const lastMessageText = `${senderId}:${content}`;
                const thread = await updateThread(threadId, this.actualThread.thread, lastMessageText, createAt, 0, createAt);
                if (this.actualThread)
                    this.actualThread.thread = thread;
            }
            if (taskId)
                newMessage.taskId = taskId;
            this.actualMessages.unshift({ context, lastChanged: new Date().getTime(), ...newMessage });
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            await addMessage(newMessage);
            this.requestUpdate();
        }
        else {
            messageAdded.content = content;
            messageAdded.senderId = senderId;
            messageAdded.createAt = createAt;
            messageAdded.threadId = threadId;
            messageAdded.orderAt = orderAt;
            // if (status) messageAdded.status = status;
            if (taskTitle)
                messageAdded.taskTitle = taskTitle;
            if (taskTitleTranslated)
                messageAdded.taskTitleTranslated = taskTitleTranslated;
            if (taskStatus)
                messageAdded.taskStatus = taskStatus;
            if (taskResults)
                messageAdded.taskResults = taskResults;
            if (taskResultsTranslated)
                messageAdded.taskResultsTranslated = taskResultsTranslated;
            messageAdded.context = context;
            messageAdded.isLoading = false;
            messageAdded.lastChanged = new Date().getTime();
            if (taskId)
                messageAdded.taskId = taskId;
            const cloned = structuredClone(messageAdded);
            delete cloned.context;
            delete cloned.isLoading;
            delete cloned.lastChanged;
            if (oldContextCreateAt)
                this.isSystemChangeScroll = true;
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            await addMessage(cloned);
            if (this.actualThread)
                await this.updateLastMessage(this.actualThread);
            this.requestUpdate();
        }
    }
    async createTempMessage(content, senderId, threadId, replyTo, taskId) {
        const now = new Date();
        const formattedDate = now.getUTCFullYear().toString()
            + String(now.getUTCMonth() + 1).padStart(2, '0')
            + String(now.getUTCDate()).padStart(2, '0')
            + String(now.getUTCHours()).padStart(2, '0')
            + String(now.getUTCMinutes()).padStart(2, '0')
            + String(now.getUTCSeconds()).padStart(2, '0')
            + "." + Math.floor(1000 + Math.random() * 9000);
        const newMessage = {
            content,
            createAt: formattedDate,
            orderAt: formattedDate,
            senderId,
            threadId,
            isLoading: true,
            isFailed: false,
            isFailedError: '',
            replyTo,
            footers: []
        };
        if (taskId)
            newMessage.taskId = taskId;
        this.actualMessages.push(newMessage);
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.requestUpdate();
        await this.scrollMessagesToBottom();
        return newMessage;
    }
    async updateMessage2(updateLastSyncThreadDB, updateLastMessageThreadDB, oldMessage, newMessage, outputs) {
        if (this.actualThread && (updateLastSyncThreadDB || updateLastMessageThreadDB)) {
            const lastMessageText = `${newMessage.senderId}:${newMessage.content}`;
            let thread = await updateThread(newMessage.threadId, this.actualThread.thread, updateLastMessageThreadDB ? lastMessageText : undefined, updateLastMessageThreadDB ? newMessage.createAt : undefined, 0, updateLastSyncThreadDB ? newMessage.createAt : undefined);
            thread = await updateLastMessageReadTime(newMessage.threadId, newMessage.createAt);
            if (this.actualThread)
                this.actualThread.thread = thread;
            notifyThreadChange(this.actualThread.thread);
        }
        const footerData = [];
        for await (let item of outputs || []) {
            const footerItem = {
                title: item.botId,
                lines: [item.output]
            };
            const module = await environment.agents.loadAgent(item.botId);
            if (module && module.afterBot && typeof module.afterBot === 'function') {
                const context = {
                    message: newMessage,
                    task: undefined,
                    isTest: false
                };
                try {
                    const response = await module.afterBot(context, item);
                    footerItem.lines = [response];
                }
                catch (err) {
                    footerItem.lines = [err.message];
                }
            }
            footerData.push(footerItem);
        }
        const alreadyExist = this.actualMessages.find(item => item.senderId === oldMessage.senderId &&
            item.createAt === oldMessage.createAt &&
            item.threadId === oldMessage.threadId);
        if (alreadyExist) {
            this.actualMessages = this.actualMessages.map(item => {
                if (item.senderId === oldMessage.senderId &&
                    item.createAt === oldMessage.createAt &&
                    item.threadId === oldMessage.threadId) {
                    const { isLoading, isFailed, isFailedError, ...rest } = { ...newMessage, isSame: oldMessage.isSame, footers: footerData };
                    return rest;
                }
                return item;
            });
        }
        else
            this.actualMessages.unshift({ ...newMessage, footers: footerData });
        const m = newMessage;
        delete m.isLoading;
        delete m.isFailed;
        delete m.isFailedError;
        delete m.isSame;
        if (outputs)
            m.footers = footerData;
        await addMessage(m);
        const messagesInDb = await getMessagesByThreadId(m.threadId, this.messagesLimit, 0);
        this.hasMoreMessagesAfter = false;
        this.actualMessages = messagesInDb;
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.requestUpdate();
    }
    async onTaskClick(taskId, messageId, threadId, message) {
        try {
            const task = await this.getTaskUpdate(taskId, messageId, threadId);
            if (!task)
                return;
            addOrUpdateTask(task);
            await this.openTaskDetailsPanel(task, message);
        }
        catch (error) {
            const detail = error instanceof Error ? error.message : String(error);
            console.error(detail);
            await this.showLocalSystemMessage(this.msg.couldNotOpenTask.replace('{erro}', detail).replace('{error}', detail));
        }
    }
    async openTaskDetailsPanel(task, message) {
        this.saveScrollPosition();
        this.actualTask = task;
        this.actualMessage = message;
        const messageId2 = `${this.actualThread?.thread.threadId}/${this.actualMessage?.createAt}`;
        let rc = await environment.tasks.openTaskDetails(messageId2, this.actualTask.PK || '', this.actualTask, this.actualMessage);
        if (this.hasStudioTaskDetailHost())
            return;
        if (!rc.openLocal)
            rc = this.createLocalTaskDetails(this.actualTask, this.actualMessage);
        if (!rc.openLocal)
            return;
        this.activeScenerie = 'task';
        this.elementTaskDetails = rc.element;
    }
    hasStudioTaskDetailHost() {
        const roots = [document];
        if (window.parent && window.parent !== window) {
            try {
                roots.push(window.parent.document);
            }
            catch {
                // Cross-origin parent is not inspectable; fall back to local behavior.
            }
        }
        return roots.some(root => !!root.querySelector('service-detail-100554'));
    }
    createLocalTaskDetails(task, message) {
        const element = document.createElement('collab-messages-task-info-102025');
        element.task = task;
        element.message = message;
        return { openLocal: true, element };
    }
    onReplyPreviewClick(ev) {
        const messageReply = this.messageContainer?.querySelector(`collab-messages-chat-message-102025[messageid="${ev.detail.messageId}"]`);
        if (!messageReply)
            return;
        messageReply.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    onNoraConfirmReply(ev) {
        const text = ev.detail?.text;
        if (typeof text !== 'string' || !text.trim())
            return;
        void this.handleSend(text, { isSpecialMention: false, agentName: '' });
    }
    onReplyMessageClick(ev) {
        if (!ev.detail)
            return;
        const data = ev.detail;
        this.collabMessagesPrompt?.setReply({
            messageId: data.createAt,
            senderId: data.senderId,
            preview: data.content.slice(0, 80)
        });
    }
    async onPinMessageClick(ev) {
        if (!this.userId || !this.actualThread)
            return;
        if (!this.canWriteCurrentThread()) {
            this.showReadOnlyThreadError();
            return;
        }
        const data = ev.detail;
        const message = data.message;
        const messageId = `${message.threadId}/${message.orderAt || message.createAt}`;
        const pinnedMessages = this.actualThread.thread.pinnedMessages || [];
        const alreadyPinned = pinnedMessages.some(item => item.messageId === messageId);
        if (data.pin && !alreadyPinned && pinnedMessages.length >= 3 && !window.confirm(this.msg.replaceOldestPin))
            return;
        const result = await msgUpdateMessage({
            userId: this.userId,
            threadId: this.actualThread.thread.threadId,
            messageId: message.orderAt || message.createAt,
            pin: data.pin
        });
        if (!result.success || !result.response?.message) {
            throw new Error(result.error || 'Failed to update message pin');
        }
        await updateMessage(result.response.message);
        if (result.response.thread) {
            const updatedThread = await updateThread(result.response.thread.threadId, result.response.thread);
            this.actualThread.thread = updatedThread;
            notifyThreadChange(updatedThread);
        }
        this.actualMessages = this.actualMessages.map(item => item.threadId === result.response.message.threadId && item.createAt === result.response.message.createAt
            ? { ...item, ...result.response.message }
            : item);
        for (const responseMessage of result.response.messages || []) {
            await this.updateMessage2(false, true, responseMessage, responseMessage, undefined);
        }
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.requestUpdate();
    }
    async onFavoriteMessageClick(ev) {
        if (!this.userId || !this.actualThread)
            return;
        const data = ev.detail;
        const message = data.message;
        const result = await msgUpdateMessage({
            userId: this.userId,
            threadId: this.actualThread.thread.threadId,
            messageId: message.orderAt || message.createAt,
            favorite: data.favorite
        });
        if (!result.success || !result.response?.user) {
            throw new Error(result.error || 'Failed to update message favorite');
        }
        await updateUsers([result.response.user]);
        this.updateCurrentUser(result.response.user);
        if (!data.favorite)
            this.clearToolbarSelection();
        this.requestUpdate();
    }
    async onReadConfirmationMessageClick(ev) {
        if (!this.userId || !this.actualThread)
            return;
        if (!this.canWriteCurrentThread()) {
            this.showReadOnlyThreadError();
            return;
        }
        const data = ev.detail;
        const message = data.message;
        const result = await msgUpdateMessage({
            userId: this.userId,
            threadId: this.actualThread.thread.threadId,
            messageId: message.orderAt || message.createAt,
            readConfirmation: data.action
        });
        if (!result.success || !result.response?.message) {
            throw new Error(result.error || 'Failed to update read confirmation');
        }
        await updateMessage(result.response.message);
        this.actualMessages = this.actualMessages.map(item => item.threadId === result.response.message.threadId && item.createAt === result.response.message.createAt
            ? { ...item, ...result.response.message }
            : item);
        const users = result.response.users || [];
        if (users.length > 0) {
            await updateUsers(users);
            this.updateUsersInState(users);
        }
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.requestUpdate();
    }
    async onMessageActionMessageClick(ev) {
        if (!this.userId || !this.actualThread)
            return;
        if (!this.canWriteCurrentThread()) {
            this.showReadOnlyThreadError();
            return;
        }
        const data = ev.detail;
        const message = data.message;
        const taskTitle = data.action === 'createTask'
            ? window.prompt(this.msg.taskTitlePrompt, this.createTaskTitleFromMessage(message)) || undefined
            : undefined;
        if (data.action === 'createTask' && !taskTitle)
            return;
        const result = await msgUpdateMessage({
            userId: this.userId,
            threadId: this.actualThread.thread.threadId,
            messageId: message.orderAt || message.createAt,
            messageAction: data.action,
            ...(taskTitle ? { taskTitle } : {})
        });
        if (!result.success || !result.response?.message) {
            throw new Error(result.error || 'Failed to update message');
        }
        await this.applyMessageUpdateResponse(result.response);
    }
    async onEditMessageClick(ev) {
        if (!this.userId || !this.actualThread)
            return;
        const data = ev.detail;
        const result = await msgUpdateMessage({
            userId: this.userId,
            threadId: this.actualThread.thread.threadId,
            messageId: data.message.orderAt || data.message.createAt,
            editContent: data.content
        });
        if (!result.success || !result.response?.message) {
            throw new Error(result.error || 'Failed to edit message');
        }
        await this.applyMessageUpdateResponse(result.response);
    }
    async applyMessageUpdateResponse(response) {
        await updateMessage(response.message);
        this.actualMessages = this.actualMessages.map(item => item.threadId === response.message.threadId && item.createAt === response.message.createAt
            ? { ...item, ...response.message }
            : item);
        if (response.task)
            await addOrUpdateTask(response.task);
        if (response.taskRoomThread) {
            const existingThread = await getThread(response.taskRoomThread.threadId);
            const threadCache = existingThread
                ? await updateThread(response.taskRoomThread.threadId, response.taskRoomThread)
                : await addThread(response.taskRoomThread);
            notifyThreadChange(threadCache);
        }
        if (response.thread) {
            const updatedThread = await updateThread(response.thread.threadId, response.thread);
            if (this.actualThread && updatedThread.threadId === this.actualThread.thread.threadId) {
                this.actualThread.thread = updatedThread;
            }
            notifyThreadChange(updatedThread);
        }
        this.clearToolbarSelection();
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.requestUpdate();
    }
    async onMarkUnreadMessageClick(ev) {
        if (!this.actualThread)
            return;
        const message = ev.detail.message;
        const sortedMessages = [...this.actualMessages].sort((a, b) => (a.orderAt || a.createAt).localeCompare(b.orderAt || b.createAt));
        const index = sortedMessages.findIndex(item => item.threadId === message.threadId && item.createAt === message.createAt);
        if (index < 0)
            return;
        const previous = sortedMessages[index - 1];
        const unreadCount = sortedMessages.length - index;
        let updatedThread = await updateThread(this.actualThread.thread.threadId, this.actualThread.thread, undefined, undefined, unreadCount);
        const lastReadMessageId = previous?.createAt || '';
        updatedThread = await updateLastMessageReadTime(this.actualThread.thread.threadId, lastReadMessageId);
        this.lastMessageReaded = previous?.createAt || '';
        this.unreadCountInSelectedThread = unreadCount;
        this.actualThread.thread = updatedThread;
        notifyThreadChange(updatedThread);
        this.requestUpdate();
    }
    onForwardMessageClick(ev) {
        if (!this.actualThread)
            return;
        const message = ev.detail.message;
        this.forwardMessageSource = message;
        this.forwardDestinationQuery = '';
        this.forwardDestinationThreadId = '';
        this.forwardError = '';
        this.isForwardingMessage = false;
        this.saveScrollPosition();
        this.activeScenerie = 'forwardMessage';
    }
    selectForwardDestination(thread) {
        this.forwardDestinationThreadId = thread.threadId;
        this.forwardDestinationQuery = this.getForwardThreadName(thread);
        this.forwardError = '';
    }
    getForwardDestinationSuggestions() {
        const query = this.forwardDestinationQuery.trim().toLowerCase();
        const prefix = query[0];
        const search = prefix === '#' || prefix === '@' ? query.slice(1) : query;
        return this.allThreads
            .filter(thread => this.isForwardDestinationAllowed(thread))
            .filter(thread => {
            const isDm = this.isDirectMessageThread(thread);
            const name = this.getForwardThreadName(thread).toLowerCase();
            if (!query)
                return true;
            if (prefix === '#')
                return !isDm && name.includes(search);
            if (prefix === '@')
                return isDm && name.replace(/^@/, '').includes(search);
            return name.includes(search) || thread.threadId.toLowerCase().includes(search);
        })
            .sort((a, b) => this.getForwardThreadSortTime(b).localeCompare(this.getForwardThreadSortTime(a)))
            .slice(0, 25);
    }
    isForwardDestinationAllowed(thread) {
        if (thread.threadId === this.actualThread?.thread.threadId)
            return false;
        if (!thread.users.some(threadUser => threadUser.userId === this.userId))
            return false;
        return !['archived', 'deleting', 'deleted'].includes(thread.status || '');
    }
    getForwardThreadSortTime(thread) {
        return thread.lastMessageTime || thread.createdAt || thread.threadId;
    }
    isDirectMessageThread(thread) {
        return thread.name?.startsWith('@') && thread.users.length === 2;
    }
    getForwardThreadName(thread) {
        if (this.isDirectMessageThread(thread)) {
            const otherThreadUser = thread.users.find(item => item.userId !== this.userId);
            const user = this.usersAvaliables.find(item => item.userId === otherThreadUser?.userId);
            return `@${user?.name || otherThreadUser?.userId || thread.name.replace(/^@/, '')}`;
        }
        return thread.name || thread.threadId;
    }
    renderForwardDestinationAvatar(thread) {
        if (this.isDirectMessageThread(thread)) {
            const otherThreadUser = thread.users.find(item => item.userId !== this.userId);
            const user = this.usersAvaliables.find(item => item.userId === otherThreadUser?.userId);
            if (user?.avatar_url)
                return html `<img src=${user.avatar_url} alt=${user.name} />`;
            return collab_message;
        }
        if (thread.avatar_url)
            return html `<img src=${thread.avatar_url} alt=${this.getForwardThreadName(thread)} />`;
        return collab_folder_tree;
    }
    createTaskTitleFromMessage(message) {
        return (message.content || '').replace(/\s+/g, ' ').trim().slice(0, 80) || this.msg.taskTitlePrompt;
    }
    createMessageLink(message) {
        const messageId = encodeURIComponent(message.orderAt || message.createAt);
        const threadId = encodeURIComponent(message.threadId);
        const url = new URL(window.location.href);
        url.hash = `message/${threadId}/${messageId}`;
        return url.toString();
    }
    async onDeleteAttachmentMessage(ev) {
        if (!this.userId || !this.actualThread)
            return;
        if (!this.canWriteCurrentThread()) {
            this.showReadOnlyThreadError();
            return;
        }
        const data = ev.detail;
        const message = data.message;
        const result = await msgDeleteAttachment({
            userId: this.userId,
            threadId: this.actualThread.thread.threadId,
            messageId: message.orderAt || message.createAt,
            attachmentId: data.attachmentId
        });
        if (!result.success || !result.response?.message) {
            throw new Error(result.error || 'Failed to delete attachment');
        }
        await updateMessage(result.response.message);
        this.actualMessages = this.actualMessages.map(item => item.threadId === result.response.message.threadId && item.createAt === result.response.message.createAt
            ? { ...item, ...result.response.message }
            : item);
        this.clearToolbarSelection();
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.requestUpdate();
    }
    updateCurrentUser(user) {
        this.updateUsersInState([user]);
    }
    updateUsersInState(users) {
        this.usersAvaliables = users.reduce((items, user) => this.replaceUser(items, user), this.usersAvaliables);
        if (this.actualThread) {
            this.actualThread = {
                ...this.actualThread,
                users: users.reduce((items, user) => this.replaceUser(items, user), this.actualThread.users),
            };
        }
    }
    replaceUser(users, user) {
        const exists = users.some(item => item.userId === user.userId);
        if (!exists)
            return [...users, user];
        return users.map(item => item.userId === user.userId ? user : item);
    }
    async getTaskUpdate(taskId, createdAt, threadId) {
        if (!taskId || !createdAt || !threadId) {
            throw new Error('Invalid arguments for getTaskUpdate');
        }
        if (!this.userId) {
            throw new Error('Invalid userId');
        }
        const result = await msgGetTaskUpdate({
            taskId,
            messageId: this.normalizeTaskMessageId(threadId, createdAt),
            userId: this.userId
        });
        if (!result.success || !result.response?.task) {
            if (result.statusCode === 404) {
                await this.clearMissingTaskReference(taskId, createdAt, threadId);
                return undefined;
            }
            throw new Error(result.error || 'Failed to fetch task update');
        }
        return result.response.task;
    }
    async clearMissingTaskReference(taskId, messageIdOrOrderAt, threadId) {
        await deleteTask(taskId);
        const messageId = this.normalizeMessageId(threadId, messageIdOrOrderAt);
        const message = await getMessage(messageId);
        if (!message || message.taskId !== taskId)
            return;
        const cleanedMessage = { ...message };
        delete cleanedMessage.taskId;
        delete cleanedMessage.stepId;
        delete cleanedMessage.taskTitle;
        delete cleanedMessage.taskStatus;
        delete cleanedMessage.taskResults;
        delete cleanedMessage.taskResultsTranslated;
        delete cleanedMessage.taskTitleTranslated;
        await updateMessage(cleanedMessage);
        if (this.actualThread?.thread.threadId !== threadId)
            return;
        this.actualMessages = this.actualMessages.map(item => item.threadId === cleanedMessage.threadId && item.createAt === cleanedMessage.createAt
            ? cleanedMessage
            : item);
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.requestUpdate();
    }
    normalizeTaskMessageId(threadId, messageIdOrOrderAt) {
        if (!messageIdOrOrderAt.includes('/'))
            return `${threadId}/${messageIdOrOrderAt}`;
        const parts = messageIdOrOrderAt.split('/').filter(Boolean);
        if (parts.length === 2)
            return messageIdOrOrderAt;
        return `${parts[0]}/${parts[parts.length - 1]}`;
    }
    normalizeMessageId(threadId, messageIdOrOrderAt) {
        const parts = messageIdOrOrderAt.split('/').filter(Boolean);
        const orderAt = parts[parts.length - 1] || messageIdOrOrderAt;
        return `${threadId}/${orderAt}`;
    }
    async getThreadInfo(threadId, userId, lastOrderAt) {
        const deviceId = loadNotificationDeviceId();
        try {
            const result = await msgGetThreadUpdates({
                threadId,
                userId,
                lastOrderAt,
                deviceId: deviceId || undefined
            });
            removeThreadFromSync(threadId);
            if (!result.success) {
                if (result.statusCode === 403) {
                    throw new Error(result.error || 'Access denied to thread');
                }
                throw new Error(result.error || 'Failed to fetch thread updates');
            }
            if (!result.response) {
                throw new Error('Empty response while fetching thread updates');
            }
            return result.response;
        }
        catch (err) {
            throw new Error(err?.message || 'Unexpected error while fetching thread updates');
        }
    }
    saveScrollPosition() {
        if (this.messageContainer) {
            this.savedScrollTop = this.messageContainer.scrollTop;
        }
    }
    async restoreScrollPosition() {
        if (this.messageContainer) {
            await this.updateComplete;
            await this.waitingForRenderCodesWebComponents();
            this.messageContainer.scrollTop = this.savedScrollTop;
        }
    }
    // oldContextCreateAt is only carried by the task-change of the add-message-ai
    // intent, which is the one that creates the task — so this opens the details
    // once, right after creation (a pending clarification lives inside the panel).
    async openCreatedTaskDetails(task, message) {
        if (this.activeScenerie !== 'details')
            return;
        const messageInList = this.actualMessages.find((item) => item.senderId === message.senderId &&
            item.createAt === message.createAt &&
            item.threadId === message.threadId);
        if (!messageInList)
            return;
        await this.openTaskDetailsPanel(task, messageInList);
    }
    async verifyChatScroll() {
        if (!this.messageContainer || !this.isSystemChangeScroll)
            return;
        this.scrollLock = true;
        try {
            await this.updateComplete;
            await this.waitingForRenderCodesWebComponents();
            await this.nextFrame();
            const target = this.unreadEl;
            if (target) {
                target.scrollIntoView({ block: 'center' });
            }
            else {
                this.messageContainer.scrollTop = this.messageContainer.scrollHeight;
            }
        }
        finally {
            await this.nextFrame();
            this.scrollLock = false;
            this.isSystemChangeScroll = false;
        }
    }
    async delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    nextFrame() {
        return new Promise(resolve => requestAnimationFrame(() => resolve()));
    }
    async waitingForRenderCodesWebComponents() {
        await this.nextFrame();
        if (!this.messageContainer)
            return;
        const allMessages = Array.from(this.messageContainer.querySelectorAll('collab-messages-chat-message-102025'));
        await Promise.all(Array.from(allMessages)
            .map(el => el.updateComplete));
        await this.nextFrame();
        const allRichPreviews = Array.from(this.messageContainer.querySelectorAll('collab-messages-rich-preview-text-102025'));
        await Promise.all(Array.from(allRichPreviews)
            .map(el => el.updateComplete));
        await this.nextFrame();
        const allCodes = Array.from(this.messageContainer.querySelectorAll('collab-messages-text-code-102025'));
        await Promise.all(Array.from(allCodes)
            .map(el => el.whenRendered));
    }
};
__decorate([
    query('collab-messages-prompt-102025')
], CollabMessagesChat.prototype, "collabMessagesPrompt", void 0);
__decorate([
    query('.new-messages-label')
], CollabMessagesChat.prototype, "unreadEl", void 0);
__decorate([
    query('.chat-container')
], CollabMessagesChat.prototype, "messageContainer", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "isLoadingThread", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "filteredThreads", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "isThreadError", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "threadErrorMsg", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "lastTopicFilter", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "welcomeMessage", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "usersAvaliables", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "elementTaskDetails", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "taskNotificationNavDirection", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "toolbarView", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "group", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "userId", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "threadToOpen", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "taskToOpen", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "userDeviceId", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "e01RootSessionKey", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "activeScenerie", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "actualThread", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "actualTask", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "actualMessage", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "actualMessages", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "actualMessagesParsed", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "isLoadingMessages", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "searchTerm", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesChat.prototype, "userThreads", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesChat.prototype, "allThreads", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "lastMessageReaded", void 0);
__decorate([
    property()
], CollabMessagesChat.prototype, "unreadCountInSelectedThread", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "noraOpening", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "noraOpenError", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "forwardMessageSource", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "forwardDestinationQuery", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "forwardDestinationThreadId", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "forwardError", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "isForwardingMessage", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "highlightedMessageId", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "toolbarHelpKind", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "toolbarNavigationKind", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "toolbarNavigationFailedKind", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "toolbarNavigationError", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "cachedToolbarMessages", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "showPersonalMemory", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "e01SessionEpoch", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "hasNewMoments", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "showJumpToLatest", void 0);
__decorate([
    state()
], CollabMessagesChat.prototype, "followupNotice", void 0);
CollabMessagesChat = __decorate([
    customElement('collab-messages-chat-102025')
], CollabMessagesChat);
export { CollabMessagesChat };
