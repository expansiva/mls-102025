/// <mls fileReference="_102025_/l2/collabMessagesSyncNotifications.ts" enhancement="_102027_/l2/enhancementLit" />
import { getUserId, loadNotificationDeviceId, loadNotificationPreferences, loadNotificationPreferencesAudio, loadLastAlertTime, registerToken, saveLastAlertTime, saveNotificationDeviceId, } from "/_102025_/l2/collabMessagesHelper.js";
import { hasPushSubscriptionCapability, MLS_LIB_RETRIES, MLS_LIB_RETRY_MS, } from '/_102025_/l2/notificationsRuntime.js';
import { getThread, updateThread, getMessage, addMessages, getAllThreads, addThread, getCompactUTC, updateMessage, updateLastMessageReadTime } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { dispatchThreadOpen, notifyThreadChange, notifyMessageChange, notifyThreadNotification } from '/_102025_/l2/collabMessagesEvents.js';
import { changeFavIcon } from '/_102025_/l2/collabMessagesHelper.js';
import { msgGetMessage, msgGetThreadUpdates, post } from '/_102025_/l2/shared/api.js';
import { environment } from '/_102036_/l2/environmentContract.js';
const TRACE_LS_KEY = 'collabTraceNotification';
export function isNotificationTraceEnabled() {
    try {
        if (typeof window !== 'undefined' && window.isTraceNotification)
            return true;
        return typeof localStorage !== 'undefined' && localStorage.getItem(TRACE_LS_KEY) === 'true';
    }
    catch {
        return false;
    }
}
export function traceNotification(event, fields) {
    if (!isNotificationTraceEnabled())
        return;
    if (fields?.reference !== undefined)
        console.info(`[NOTIFICATION] ${event}`, fields.reference, fields);
    else
        console.info(`[NOTIFICATION] ${event}`, fields ?? '');
}
function tellServiceWorkerNotificationTrace(enabled) {
    const payload = { type: 'collab-trace-notification', enabled };
    const sw = globalThis.navigator?.serviceWorker;
    if (!sw)
        return;
    try {
        sw.controller?.postMessage(payload);
    }
    catch {
        // no controller yet
    }
    void sw.ready?.then((reg) => { reg.active?.postMessage(payload); }).catch(() => undefined);
}
/** Boot: localStorage.collabTraceNotification === 'true' liga o trace sem rebuild. */
export function applyNotificationTraceFromStorage() {
    try {
        if (typeof localStorage !== 'undefined' && localStorage.getItem(TRACE_LS_KEY) === 'true') {
            window.isTraceNotification = true;
            tellServiceWorkerNotificationTrace(true);
        }
    }
    catch {
        // private mode / missing storage
    }
    return isNotificationTraceEnabled();
}
export const threadSyncMap = new Map();
let hasNotificationMessages = false;
let syncTimeout = null;
let notificationSound = null;
let soundLoadAttempted = false;
let notificationSoundUnlocked = false;
const SOUND_UNLOCK_EVENTS = ['click', 'keydown', 'touchstart'];
let soundUnlockHandler = null;
const pendingNotificationThreads = new Set();
/** Counts of OS notifications the SW already showed, keyed by threadId. One aviso per message. */
const systemNotificationShownByThread = new Map();
const pendingTaskRoomNotifications = new Set();
const pendingTaskRoomParentThreads = new Map();
export function removeThreadFromSync(threadId) {
    threadSyncMap.delete(threadId);
}
export function clearThreadNotification(threadId) {
    clearPendingThreadNotification(threadId);
    void refreshNotificationIndicator();
}
export function clearTaskNotification(taskId) {
    const parentThreadId = clearPendingTaskNotification(taskId);
    void refreshNotificationIndicator();
    if (parentThreadId)
        void notifyThreadChangeById(parentThreadId);
}
function clearPendingThreadNotification(threadId) {
    const hasTaskRoomNotification = Array.from(pendingTaskRoomParentThreads.values()).some((parentThreadId) => parentThreadId === threadId);
    if (hasTaskRoomNotification)
        return;
    pendingNotificationThreads.delete(threadId);
}
function clearPendingTaskNotification(taskId) {
    const parentThreadId = pendingTaskRoomParentThreads.get(taskId);
    pendingTaskRoomNotifications.delete(taskId);
    pendingTaskRoomParentThreads.delete(taskId);
    if (parentThreadId) {
        const hasOtherTaskNotification = Array.from(pendingTaskRoomParentThreads.values()).some((threadId) => threadId === parentThreadId);
        if (!hasOtherTaskNotification)
            pendingNotificationThreads.delete(parentThreadId);
    }
    return parentThreadId;
}
function clearPendingNotificationTarget(target) {
    clearPendingThreadNotification(target.threadId);
    if (target.taskId)
        return clearPendingTaskNotification(target.taskId);
    return undefined;
}
export async function refreshNotificationIndicator() {
    const hasPendingMessages = await checkIfNotificationUnread();
    hasNotificationMessages = hasPendingMessages;
    changeFavIcon(hasPendingMessages);
    notifyThreadNotification(hasPendingMessages);
}
export async function markThreadReadLocally(threadId, lastMessageReadTime, notificationTarget) {
    let thread = await getThread(threadId);
    if (thread) {
        thread = await updateThread(threadId, thread, undefined, undefined, 0);
        if (lastMessageReadTime) {
            thread = await updateLastMessageReadTime(threadId, lastMessageReadTime);
        }
        notifyThreadChange(thread);
    }
    if (notificationTarget)
        clearPendingNotificationTarget(notificationTarget);
    else
        clearPendingThreadNotification(threadId);
    if (notificationTarget?.taskId && notificationTarget.threadId !== threadId) {
        void notifyThreadChangeById(notificationTarget.threadId);
    }
    await refreshNotificationIndicator();
    return thread;
}
export function hasThreadNotificationPending(threadId) {
    return pendingNotificationThreads.has(threadId);
}
export function hasTaskNotificationPending(taskId) {
    return pendingTaskRoomNotifications.has(taskId);
}
export function getPendingTaskNotificationsForThread(threadId) {
    const result = [];
    for (const taskId of pendingTaskRoomNotifications) {
        const parentThreadId = pendingTaskRoomParentThreads.get(taskId);
        if (parentThreadId === threadId)
            result.push(taskId);
    }
    return result;
}
export async function checkIfNotificationUnread() {
    if (pendingNotificationThreads.size > 0 || pendingTaskRoomNotifications.size > 0)
        return true;
    const threads = await getAllThreads();
    let hasPendingMessages = false;
    const parentThreadsToNotify = new Set();
    for (let thread of threads) {
        if (thread.unreadCount && thread.unreadCount > 0) {
            const parentThreadId = hydratePendingTaskRoomNotification(thread);
            if (parentThreadId)
                parentThreadsToNotify.add(parentThreadId);
            hasPendingMessages = true;
        }
    }
    for (const parentThreadId of parentThreadsToNotify) {
        void notifyThreadChangeById(parentThreadId);
    }
    return hasPendingMessages;
}
function hydratePendingTaskRoomNotification(thread) {
    if (thread.kind !== 'task-room' || !thread.taskRoom?.parentThreadId || !thread.taskRoom.taskId)
        return undefined;
    pendingNotificationThreads.add(thread.taskRoom.parentThreadId);
    pendingTaskRoomNotifications.add(thread.taskRoom.taskId);
    pendingTaskRoomParentThreads.set(thread.taskRoom.taskId, thread.taskRoom.parentThreadId);
    return thread.taskRoom.parentThreadId;
}
async function notifyThreadChangeById(threadId) {
    const thread = await getThread(threadId);
    if (thread)
        notifyThreadChange(thread);
}
const ONE_WEEK_MS = 7 * 24 * 60 * 60 * 1000;
let sessionChecked = false;
let inFlight = null;
let acceptedThisSession = false;
let listeningToThreadEvents = false;
let notificationOffer = 'none';
export function getNotificationOffer() {
    return notificationOffer;
}
export function resetNotificationSession() {
    sessionChecked = false;
    inFlight = null;
    acceptedThisSession = false;
    listeningToThreadEvents = false;
    notificationOffer = 'none';
    systemNotificationShownByThread.clear();
    stopPresenceHeartbeat();
    unbindSoundUnlock();
    notificationSound = null;
    soundLoadAttempted = false;
    notificationSoundUnlocked = false;
    if (typeof window !== 'undefined')
        delete window.isTraceNotification;
}
function unbindSoundUnlock() {
    if (!soundUnlockHandler || typeof document === 'undefined' || typeof document.removeEventListener !== 'function') {
        soundUnlockHandler = null;
        return;
    }
    const opts = { capture: true };
    for (const type of SOUND_UNLOCK_EVENTS) {
        document.removeEventListener(type, soundUnlockHandler, opts);
    }
    soundUnlockHandler = null;
}
function tryUnlockNotificationSound() {
    const el = notificationSound;
    if (!el)
        return;
    try {
        el.muted = true;
        const playing = el.play();
        el.pause();
        el.currentTime = 0;
        el.muted = false;
        void playing.then(() => { notificationSoundUnlocked = true; }).catch(() => undefined);
    }
    catch {
        // gesture unlock is best-effort
    }
}
/** Idempotent. Binds click/keydown/touchstart once so later programmatic play() is allowed. */
export function unlockNotificationSound() {
    if (soundUnlockHandler)
        return;
    if (typeof document === 'undefined' || typeof document.addEventListener !== 'function')
        return;
    const handler = () => { tryUnlockNotificationSound(); };
    soundUnlockHandler = handler;
    const opts = { once: true, capture: true };
    for (const type of SOUND_UNLOCK_EVENTS) {
        document.addEventListener(type, handler, opts);
    }
}
export function setNotificationSoundForTests(el) {
    notificationSound = el;
}
export function isTestplayCommand(value) {
    const t = value.trim();
    return t === '/testplay' || t.startsWith('/testplay ');
}
export function isHelpCommand(value) {
    const t = value.trim();
    return t === '/help' || t.startsWith('/help ');
}
export function isNotificationSoundUnlocked() {
    return notificationSoundUnlocked;
}
async function playTestplaySound() {
    await ensureNotificationSound();
    const el = notificationSound;
    if (!el)
        return 'sound: blocked (no-sound)';
    try {
        el.currentTime = 0;
    }
    catch {
        // some test fakes have no currentTime setter
    }
    try {
        await el.play();
        traceNotification('sound.played', { reference: 'testplay' });
        return 'sound: played';
    }
    catch (err) {
        const name = err instanceof Error ? err.name : 'Error';
        traceNotification('sound.blocked', { reference: 'testplay', reason: 'play-failed', name });
        return `sound: blocked (${name})`;
    }
}
async function reportTestplayBadge() {
    const link = typeof document !== 'undefined' ? document.querySelector("[rel~='icon']") : null;
    await changeFavIcon(true);
    return link ? 'badge: on' : 'badge: skipped (no-icon-link)';
}
async function reportTestplayNotification() {
    if (typeof Notification === 'undefined' || Notification.permission === 'default') {
        return 'notification: permission default';
    }
    if (Notification.permission === 'denied') {
        return 'notification: permission denied';
    }
    const sw = globalThis.navigator?.serviceWorker;
    if (!sw || typeof sw.ready?.then !== 'function') {
        return 'notification: no service worker';
    }
    try {
        const reg = await sw.ready;
        if (!reg || typeof reg.showNotification !== 'function') {
            return 'notification: no service worker';
        }
        await reg.showNotification('collab-messages', { body: '/testplay', tag: 'collab-testplay' });
        return 'notification: shown';
    }
    catch {
        return 'notification: no service worker';
    }
}
async function reportTestplaySoundFile() {
    const url = await environment.notifications.getNotifySoundUrl();
    if (!url)
        return 'sound-file: (none)';
    const probe = async (method) => {
        const res = await fetch(url, { method });
        const contentType = res.headers?.get?.('content-type') || '';
        return { status: res.status, contentType };
    };
    try {
        const head = await probe('HEAD');
        return `sound-file: ${url} status ${head.status} content-type ${head.contentType || '(none)'}`;
    }
    catch {
        try {
            const get = await probe('GET');
            return `sound-file: ${url} status ${get.status} content-type ${get.contentType || '(none)'}`;
        }
        catch (err) {
            const name = err instanceof Error ? err.name : 'Error';
            return `sound-file: ${url} status ${name} content-type (none)`;
        }
    }
}
/** Local diagnostic: sound + badge + OS notification, no network, no addMessage. */
export async function runNotificationTestplay() {
    const lines = [
        `unlocked: ${notificationSoundUnlocked ? 'true' : 'false'}`,
        await playTestplaySound(),
        await reportTestplayBadge(),
        await reportTestplayNotification(),
        await reportTestplaySoundFile(),
        'both: sound and notification (explicit /testplay)',
    ];
    return lines.join('\n');
}
export function startPageNotificationSound(threadId, reference) {
    if (!notificationSound)
        return;
    notificationSound.currentTime = 0;
    notificationSound.play()
        .then(() => { traceNotification('sound.played', { reference, threadId }); })
        .catch((err) => {
        const name = err instanceof Error ? err.name : undefined;
        traceNotification('sound.blocked', { reference, threadId, reason: 'play-failed', name });
        console.warn('Erro on play notification audio:', err);
    });
}
export function markSystemNotificationShown(threadId) {
    if (!threadId)
        return;
    systemNotificationShownByThread.set(threadId, (systemNotificationShownByThread.get(threadId) ?? 0) + 1);
}
export function consumeSystemNotificationShown(threadId) {
    const n = systemNotificationShownByThread.get(threadId) ?? 0;
    if (n <= 0)
        return false;
    if (n === 1)
        systemNotificationShownByThread.delete(threadId);
    else
        systemNotificationShownByThread.set(threadId, n - 1);
    return true;
}
/** One aviso per message: if the SW showed the OS notification, the page does not play too. */
export function shouldPlayPageNotificationSound(opts) {
    return opts.audioEnabled && opts.hasSound && !opts.systemNotificationShown;
}
async function waitForPushCapability() {
    if (hasPushSubscriptionCapability())
        return true;
    let left = MLS_LIB_RETRIES;
    while (left > 0) {
        left -= 1;
        await new Promise((resolve) => setTimeout(resolve, MLS_LIB_RETRY_MS));
        if (hasPushSubscriptionCapability())
            return true;
    }
    return hasPushSubscriptionCapability();
}
function isWithinWeeklyAlertWindow() {
    const lastShown = Number(loadLastAlertTime() || 0);
    if (!lastShown)
        return false;
    return (Date.now() - lastShown) <= ONE_WEEK_MS;
}
async function ensureNotificationSound() {
    if (notificationSound || soundLoadAttempted)
        return;
    soundLoadAttempted = true;
    try {
        notificationSound = await getNotificationSound();
    }
    catch {
        notificationSound = null;
    }
}
/** Idempotent. Called by the collab-messages root once the user is known (post-login). */
export async function initNotifications() {
    applyNotificationTraceFromStorage();
    // Presence owner: this function (post-login). Not listenToThreadEvents —
    // being online is "logged in"; receiving push is "permission granted".
    startPresenceHeartbeat();
    await ensureNotificationSound();
    unlockNotificationSound();
    if (sessionChecked)
        return;
    if (inFlight)
        return inFlight;
    inFlight = initNotificationsOnce();
    try {
        await inFlight;
    }
    finally {
        inFlight = null;
    }
}
async function initNotificationsOnce() {
    const ready = await waitForPushCapability();
    if (!ready)
        return;
    sessionChecked = true;
    if (typeof Notification === 'undefined')
        return;
    const permission = Notification.permission;
    const pref = loadNotificationPreferences();
    if (permission === 'granted' || pref === 'granted') {
        try {
            await listenToThreadEvents();
        }
        catch (err) {
            console.error('Error on listen notifications' + err.message);
        }
        return;
    }
    if (permission === 'denied')
        return;
    if (isWithinWeeklyAlertWindow())
        return;
    notificationOffer = 'offer';
}
export async function acceptNotificationOffer() {
    notificationOffer = 'none';
    if (acceptedThisSession)
        return;
    acceptedThisSession = true;
    const subscription = await registerToken();
    if (subscription) {
        await listenToThreadEvents();
    }
}
export function dismissNotificationOffer() {
    notificationOffer = 'none';
    saveLastAlertTime(Date.now());
}
export async function listenToThreadEvents() {
    if (listeningToThreadEvents)
        return;
    listeningToThreadEvents = true;
    try {
        await ensureNotificationSound();
        unlockNotificationSound();
        navigator.serviceWorker.addEventListener('message', async (event) => {
            const incomingReference = event.data?.data?.reference;
            traceNotification('push.received', { reference: incomingReference });
            if (event.data?.type === 'system-notification-shown') {
                const threadId = event.data.data?.threadId || String(event.data.data?.reference || '').split(':')[0];
                if (threadId)
                    markSystemNotificationShown(threadId);
                traceNotification('push.shown', { reference: incomingReference, threadId });
                return;
            }
            const id = event.data?.id;
            if (id) {
                traceNotification('push.ack', { reference: incomingReference, id });
                await environment.notifications.sendACK(id);
            }
            const reference = event.data?.data?.reference;
            if (!reference)
                return;
            let threadId = '';
            const parts = reference.split(':');
            const typeNotification = parts.length === 2 ? 'message-update' : 'thread-update';
            threadId = parts[0];
            await enqueueThreadForSync(reference);
            if (event.data?.data?.open && threadId) {
                dispatchThreadOpen(threadId);
            }
            if (window.isTraceNotification) {
                console.info(`[NOTIFICATION] : queued ${typeNotification} ${threadId}`);
            }
        });
        if (window.isTraceNotification)
            console.info('[NOTIFICATION] : sendRequestMissed');
        await environment.notifications.sendRequestMissed();
    }
    catch (err) {
        listeningToThreadEvents = false;
        throw err;
    }
}
const HEARTBEAT_MS = 60000;
let heartbeatTimer = null;
let heartbeatVisibilityBound = false;
function startPresenceHeartbeat() {
    if (typeof document === 'undefined' || typeof document.visibilityState !== 'string')
        return;
    if (heartbeatVisibilityBound)
        return;
    heartbeatVisibilityBound = true;
    document.addEventListener('visibilitychange', onHeartbeatVisibility);
    syncHeartbeatInterval();
}
function stopPresenceHeartbeat() {
    if (heartbeatTimer !== null) {
        clearInterval(heartbeatTimer);
        heartbeatTimer = null;
    }
    if (heartbeatVisibilityBound && typeof document !== 'undefined') {
        document.removeEventListener('visibilitychange', onHeartbeatVisibility);
        heartbeatVisibilityBound = false;
    }
}
function onHeartbeatVisibility() {
    syncHeartbeatInterval();
}
function syncHeartbeatInterval() {
    const visible = typeof document !== 'undefined' && document.visibilityState === 'visible';
    if (visible) {
        if (heartbeatTimer === null) {
            void beatOnce();
            heartbeatTimer = setInterval(() => { void beatOnce(); }, HEARTBEAT_MS);
        }
    }
    else if (heartbeatTimer !== null) {
        clearInterval(heartbeatTimer);
        heartbeatTimer = null;
    }
}
async function beatOnce() {
    if (typeof document !== 'undefined' && document.visibilityState !== 'visible')
        return;
    const userId = getUserId();
    if (!userId)
        return;
    let deviceId = loadNotificationDeviceId();
    if (!deviceId) {
        deviceId = crypto.randomUUID();
        saveNotificationDeviceId(deviceId);
    }
    try {
        const res = await post({
            action: 'heartbeat',
            userId,
            deviceId,
        });
        if (!res.pending)
            return;
        for (const reference of res.pending) {
            enqueueThreadForSync(reference);
        }
    }
    catch {
        // safety net — network failure is silent
    }
}
function enqueueThreadForSync(reference) {
    traceNotification('sync.enqueued', { reference });
    threadSyncMap.set(reference, true);
    return scheduleNextSync();
}
async function scheduleNextSync() {
    if (syncTimeout || threadSyncMap.size === 0)
        return;
    syncTimeout = setTimeout(async () => {
        syncTimeout = null;
        const entry = threadSyncMap.entries().next().value;
        if (!entry)
            return;
        const [reference] = entry;
        threadSyncMap.delete(reference);
        try {
            if (window.isTraceNotification)
                console.info(`[NOTIFICATION] : refreshThread : ${reference}`);
            await getThreadUpdateInBackground(reference);
        }
        catch (err) {
            console.error(`Error on sync thread ${reference}`, err);
        }
        return scheduleNextSync();
    }, 500);
}
// reference: threadId or threadId:messageId
export async function getThreadUpdateInBackground(reference) {
    const userId = getUserId();
    const deviceId = loadNotificationDeviceId();
    if (!userId)
        throw new Error('Invalid user id');
    let threadId = '';
    let messageId = '';
    const parts = reference.split(':');
    const typeNotification = parts.length === 2 ? 'message-update' : 'thread-update';
    threadId = parts[0];
    messageId = parts.slice(1).join(':');
    if (typeNotification === 'thread-update') {
        await updateThreadInBackground(threadId, userId, deviceId);
    }
    if (typeNotification === 'message-update') {
        await updateMessageInBackground(threadId, messageId, userId, deviceId);
        await updateThreadInBackground(threadId, userId, deviceId);
    }
}
async function updateMessageInBackground(threadId, messageId, userId, deviceId) {
    try {
        const normalizedMessageId = normalizeMessageId(threadId, messageId);
        const result = await msgGetMessage({
            messageId: normalizedMessageId,
            threadId,
            userId
        });
        if (!result.success || !result.response?.message) {
            throw new Error(result.error || 'Failed to fetch message');
        }
        if (window.isTraceNotification) {
            console.info(`[NOTIFICATION] : getMessageUpdateInBackground: ${result.response.message}`);
        }
        await updateMessage(result.response.message);
        notifyMessageChange(result.response.message);
    }
    catch (err) {
        throw new Error(err?.message || 'Unexpected error while updating message');
    }
}
function normalizeMessageId(threadId, messageIdOrOrderAt) {
    const parts = messageIdOrOrderAt.split('/').filter(Boolean);
    const orderAt = parts[parts.length - 1] || messageIdOrOrderAt;
    return `${threadId}/${orderAt}`;
}
async function updateThreadInBackground(threadId, userId, deviceId) {
    let threadDB = await getThread(threadId);
    const lastOrderAt = threadDB?.lastSync || new Date('2000-01-01').toISOString();
    try {
        const result = await msgGetThreadUpdates({
            threadId,
            userId,
            lastOrderAt,
            deviceId: deviceId || undefined
        });
        if (!result.success || !result.response?.thread) {
            throw new Error(result.error || 'Failed to fetch thread update');
        }
        const response = result.response;
        if (window.isTraceNotification) {
            console.info(`[NOTIFICATION] : getThreadUpdateInBackground threadsPending: ${response.threadsPending}`);
        }
        if (response.threadsPending) {
            for (let threadsPending of response.threadsPending) {
                await enqueueThreadForSync(threadsPending);
            }
        }
        const statusChanged = threadDB && threadDB.status !== response.thread.status;
        const newMessagesFiltered = response.messages?.filter((message) => message.senderId !== userId) || [];
        const hasMessagesToCache = (response.messages?.length || 0) > 0;
        if (!statusChanged && !hasMessagesToCache)
            return;
        const notificationTarget = getNotificationTarget(response.thread);
        const isNotificationTargetVisible = isNotificationTargetOpenedAndVisible(notificationTarget);
        if (statusChanged && !hasMessagesToCache) {
            const thread = await updateThread(threadId, response.thread, '', '', isNotificationTargetVisible ? 0 : 1, getCompactUTC());
            notifyThreadChange(thread);
            if (isNotificationTargetVisible) {
                const parentThreadId = clearPendingNotificationTarget(notificationTarget);
                if (parentThreadId)
                    void notifyThreadChangeById(parentThreadId);
                await refreshNotificationIndicator();
                return;
            }
            if (await shouldNotifyByThreadPreference(notificationTarget, [], userId)) {
                hasNotificationMessages = true;
                await showThreadNotificationIfNeeded(notificationTarget);
            }
            else {
                clearNotificationTarget(notificationTarget);
            }
            return;
        }
        if (!response.messages)
            return;
        const lastMessage = response.messages[response.messages.length - 1];
        const lastUnreadCount = threadDB && threadDB.unreadCount
            ? threadDB.unreadCount
            : 0;
        if (!threadDB) {
            threadDB = await addThread(response.thread);
        }
        const lastMessageText = `${lastMessage.senderId}:${lastMessage.content}`;
        const thread = await updateThread(threadId, response.thread, lastMessageText, lastMessage.createAt, isNotificationTargetVisible ? 0 : newMessagesFiltered.length + lastUnreadCount, lastMessage.createAt);
        const newMessages = [];
        for await (let mm of response.messages) {
            const messageId = `${mm.threadId}/${mm.createAt}`;
            const messageOld = await getMessage(messageId);
            const tempMessage = {
                ...mm,
                footers: messageOld?.footers || []
            };
            newMessages.push(tempMessage);
        }
        await addMessages(newMessages);
        if (isNotificationTargetVisible) {
            await markThreadReadLocally(threadId, lastMessage.createAt, notificationTarget);
            return;
        }
        notifyThreadChange(thread);
        if (await shouldNotifyByThreadPreference(notificationTarget, newMessagesFiltered, userId)) {
            await showThreadNotificationIfNeeded(notificationTarget);
        }
        else {
            clearNotificationTarget(notificationTarget);
        }
    }
    catch (err) {
        throw new Error(err?.message ||
            'Unexpected error while updating thread in background');
    }
}
function getNotificationTarget(thread) {
    if (thread.kind === 'task-room' && thread.taskRoom?.parentThreadId) {
        return {
            threadId: thread.taskRoom.parentThreadId,
            sourceThreadId: thread.threadId,
            taskId: thread.taskRoom.taskId
        };
    }
    return { threadId: thread.threadId, sourceThreadId: thread.threadId };
}
function clearNotificationTarget(target) {
    const parentThreadId = clearPendingNotificationTarget(target);
    void refreshNotificationIndicator();
    if (parentThreadId)
        void notifyThreadChangeById(parentThreadId);
}
async function shouldNotifyByThreadPreference(target, messages, userId) {
    const parentThread = await getThread(target.threadId);
    const notification = parentThread?.users?.find(user => user.userId === userId)?.notification || 'all';
    if (notification === 'all')
        return true;
    if (notification === 'never')
        return false;
    return messages.some(message => hasUserMention(message.content || '', userId));
}
function hasUserMention(messageContent, userId) {
    const escapedUserId = userId.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return new RegExp(`\\[@[^\\]]+\\]\\(${escapedUserId}\\)`).test(messageContent);
}
function getActiveChat() {
    const search = (root) => {
        const chat = root.querySelector?.('collab-messages-chat-102025');
        if (chat)
            return chat;
        const elements = Array.from(root.querySelectorAll?.('*') || []);
        for (const element of elements) {
            if (element.shadowRoot) {
                const found = search(element.shadowRoot);
                if (found)
                    return found;
            }
        }
    };
    return search(document);
}
function shouldShowThreadNotification(threadId) {
    const chat = getActiveChat();
    const actualThreadId = chat?.actualThread?.thread?.threadId;
    const isThreadOpened = actualThreadId === threadId;
    return !isThreadOpened || document.visibilityState === 'hidden';
}
function isThreadOpenedAndVisible(threadId) {
    return !shouldShowThreadNotification(threadId);
}
function isTaskRoomOpenedAndVisible(threadId) {
    if (document.visibilityState === 'hidden')
        return false;
    const search = (root) => {
        const taskRooms = Array.from(root.querySelectorAll?.('collab-messages-task-room-102025') || []);
        if (taskRooms.some((taskRoom) => taskRoom.roomThread?.threadId === threadId || taskRoom.task?.taskRoom?.threadId === threadId))
            return true;
        const elements = Array.from(root.querySelectorAll?.('*') || []);
        for (const element of elements) {
            if (element.shadowRoot && search(element.shadowRoot))
                return true;
        }
        return false;
    };
    return search(document);
}
function isNotificationTargetOpenedAndVisible(target) {
    if (target.taskId)
        return isTaskRoomOpenedAndVisible(target.sourceThreadId);
    return isThreadOpenedAndVisible(target.threadId);
}
async function showThreadNotificationIfNeeded(target) {
    const { threadId, taskId } = target;
    if (isNotificationTargetOpenedAndVisible(target)) {
        clearNotificationTarget(target);
        return;
    }
    pendingNotificationThreads.add(threadId);
    if (taskId) {
        pendingTaskRoomNotifications.add(taskId);
        pendingTaskRoomParentThreads.set(taskId, threadId);
    }
    hasNotificationMessages = true;
    const parentThread = await getThread(threadId);
    if (parentThread)
        notifyThreadChange(parentThread);
    changeFavIcon(true);
    notifyThreadNotification(true);
    const audioEnabled = loadNotificationPreferencesAudio();
    const skipSound = consumeSystemNotificationShown(threadId);
    const soundReference = target.sourceThreadId;
    if (shouldPlayPageNotificationSound({
        audioEnabled,
        hasSound: !!notificationSound,
        systemNotificationShown: skipSound,
    }) && notificationSound) {
        startPageNotificationSound(threadId, soundReference);
    }
    else if (skipSound) {
        traceNotification('sound.blocked', { reference: soundReference, threadId, reason: 'system-shown' });
    }
    else if (!audioEnabled) {
        traceNotification('sound.blocked', { reference: soundReference, threadId, reason: 'audio-disabled' });
    }
}
async function getNotificationSound() {
    const notifySoundUrl = await environment.notifications.getNotifySoundUrl();
    let notificationSound = null;
    if (notifySoundUrl) {
        notificationSound = new Audio(notifySoundUrl);
        notificationSound.preload = 'auto';
        notificationSound.volume = 1;
    }
    return notificationSound;
}
