/// <mls fileReference="_102025_/l2/collabMessagesSyncNotifications.ts" enhancement="_102027_/l2/enhancementLit" />
import { getUserId, loadNotificationDeviceId, loadNotificationPreferencesAudio } from "/_102025_/l2/collabMessagesHelper.js";
import { getThread, updateThread, getMessage, addMessages, getAllThreads, addThread, getCompactUTC, updateMessage, updateLastMessageReadTime } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { notifyThreadChange, notifyMessageChange, notifyThreadNotification } from '/_102025_/l2/collabMessagesEvents.js';
import { changeFavIcon } from '/_102025_/l2/collabMessagesHelper.js';
import { msgGetMessage, msgGetThreadUpdates } from '/_102025_/l2/shared/api.js';
import { environment } from '/_102036_/l2/environmentContract.js';
export const threadSyncMap = new Map();
let hasNotificationMessages = false;
let syncTimeout = null;
let notificationSound = null;
const pendingNotificationThreads = new Set();
const pendingTaskRoomNotifications = new Set();
const pendingTaskRoomParentThreads = new Map();
export function removeThreadFromSync(threadId) {
    threadSyncMap.delete(threadId);
}
export function clearThreadNotification(threadId) {
    clearPendingThreadNotification(threadId);
    void refreshNotificationIndicator();
}
export function clearTaskNotification(taskId) {
    clearPendingTaskNotification(taskId);
    void refreshNotificationIndicator();
}
function clearPendingThreadNotification(threadId) {
    const hasTaskRoomNotification = Array.from(pendingTaskRoomParentThreads.values()).some((parentThreadId) => parentThreadId === threadId);
    if (hasTaskRoomNotification)
        return;
    pendingNotificationThreads.delete(threadId);
}
function clearPendingTaskNotification(taskId) {
    const parentThreadId = pendingTaskRoomParentThreads.get(taskId);
    pendingTaskRoomNotifications.delete(taskId);
    pendingTaskRoomParentThreads.delete(taskId);
    if (parentThreadId) {
        const hasOtherTaskNotification = Array.from(pendingTaskRoomParentThreads.values()).some((threadId) => threadId === parentThreadId);
        if (!hasOtherTaskNotification)
            pendingNotificationThreads.delete(parentThreadId);
    }
}
function clearPendingNotificationTarget(target) {
    clearPendingThreadNotification(target.threadId);
    if (target.taskId)
        clearPendingTaskNotification(target.taskId);
}
export async function refreshNotificationIndicator() {
    const hasPendingMessages = await checkIfNotificationUnread();
    hasNotificationMessages = hasPendingMessages;
    changeFavIcon(hasPendingMessages);
    notifyThreadNotification(hasPendingMessages);
}
export async function markThreadReadLocally(threadId, lastMessageReadTime, notificationTarget) {
    let thread = await getThread(threadId);
    if (thread) {
        thread = await updateThread(threadId, thread, undefined, undefined, 0);
        if (lastMessageReadTime) {
            thread = await updateLastMessageReadTime(threadId, lastMessageReadTime);
        }
        notifyThreadChange(thread);
    }
    if (notificationTarget)
        clearPendingNotificationTarget(notificationTarget);
    else
        clearPendingThreadNotification(threadId);
    await refreshNotificationIndicator();
    return thread;
}
export function hasThreadNotificationPending(threadId) {
    return pendingNotificationThreads.has(threadId);
}
export function hasTaskNotificationPending(taskId) {
    return pendingTaskRoomNotifications.has(taskId);
}
export function getPendingTaskNotificationsForThread(threadId) {
    const result = [];
    for (const taskId of pendingTaskRoomNotifications) {
        const parentThreadId = pendingTaskRoomParentThreads.get(taskId);
        if (parentThreadId === threadId)
            result.push(taskId);
    }
    return result;
}
export async function checkIfNotificationUnread() {
    if (pendingNotificationThreads.size > 0 || pendingTaskRoomNotifications.size > 0)
        return true;
    const threads = await getAllThreads();
    let hasPendingMessages = false;
    for (let thread of threads) {
        if (thread.unreadCount && thread.unreadCount > 0) {
            hasPendingMessages = true;
            break;
        }
    }
    return hasPendingMessages;
}
export async function listenToThreadEvents() {
    notificationSound = await getNotificationSound();
    navigator.serviceWorker.addEventListener('message', async (event) => {
        if (window.isTraceNotification)
            console.info(`[NOTIFICATION] Received`);
        if (window.isTraceNotification)
            console.info(`[NOTIFICATION] Data`, event?.data);
        const id = event.data.id;
        if (window.isTraceNotification)
            console.info(`[NOTIFICATION] : sendACK id: ${id}`);
        await environment.notifications.sendACK(id);
        const reference = event.data?.data?.reference;
        if (!reference)
            return;
        let threadId = '';
        const parts = reference.split(':');
        const typeNotification = parts.length === 2 ? 'message-update' : 'thread-update';
        threadId = parts[0];
        await enqueueThreadForSync(reference);
        if (window.isTraceNotification) {
            console.info(`[NOTIFICATION] : queued ${typeNotification} ${threadId}`);
        }
    });
    if (window.isTraceNotification)
        console.info('[NOTIFICATION] : sendRequestMissed');
    await environment.notifications.sendRequestMissed();
}
function enqueueThreadForSync(reference) {
    threadSyncMap.set(reference, true);
    return scheduleNextSync();
}
async function scheduleNextSync() {
    if (syncTimeout || threadSyncMap.size === 0)
        return;
    syncTimeout = setTimeout(async () => {
        syncTimeout = null;
        const [reference] = threadSyncMap.entries().next().value;
        if (!reference)
            return;
        threadSyncMap.delete(reference);
        try {
            if (window.isTraceNotification)
                console.info(`[NOTIFICATION] : refreshThread : ${reference}`);
            await getThreadUpdateInBackground(reference);
        }
        catch (err) {
            console.error(`Error on sync thread ${reference}`, err);
        }
        return scheduleNextSync();
    }, 500);
}
// reference: threadId or threadId:messageId
export async function getThreadUpdateInBackground(reference) {
    const userId = getUserId();
    const deviceId = loadNotificationDeviceId();
    if (!userId)
        throw new Error('Invalid user id');
    let threadId = '';
    let messageId = '';
    const parts = reference.split(':');
    const typeNotification = parts.length === 2 ? 'message-update' : 'thread-update';
    threadId = parts[0];
    messageId = parts.slice(1).join(':');
    if (typeNotification === 'thread-update') {
        await updateThreadInBackground(threadId, userId, deviceId);
    }
    if (typeNotification === 'message-update') {
        await updateMessageInBackground(threadId, messageId, userId, deviceId);
        await updateThreadInBackground(threadId, userId, deviceId);
    }
}
async function updateMessageInBackground(threadId, messageId, userId, deviceId) {
    try {
        const normalizedMessageId = normalizeMessageId(threadId, messageId);
        const result = await msgGetMessage({
            messageId: normalizedMessageId,
            threadId,
            userId
        });
        if (!result.success || !result.response?.message) {
            throw new Error(result.error || 'Failed to fetch message');
        }
        if (window.isTraceNotification) {
            console.info(`[NOTIFICATION] : getMessageUpdateInBackground: ${result.response.message}`);
        }
        await updateMessage(result.response.message);
        notifyMessageChange(result.response.message);
    }
    catch (err) {
        throw new Error(err?.message || 'Unexpected error while updating message');
    }
}
function normalizeMessageId(threadId, messageIdOrOrderAt) {
    const parts = messageIdOrOrderAt.split('/').filter(Boolean);
    const orderAt = parts[parts.length - 1] || messageIdOrOrderAt;
    return `${threadId}/${orderAt}`;
}
async function updateThreadInBackground(threadId, userId, deviceId) {
    let threadDB = await getThread(threadId);
    const lastOrderAt = threadDB?.lastSync || new Date('2000-01-01').toISOString();
    try {
        const result = await msgGetThreadUpdates({
            threadId,
            userId,
            lastOrderAt,
            deviceId: deviceId || undefined
        });
        if (!result.success || !result.response?.thread) {
            throw new Error(result.error || 'Failed to fetch thread update');
        }
        const response = result.response;
        if (window.isTraceNotification) {
            console.info(`[NOTIFICATION] : getThreadUpdateInBackground threadsPending: ${response.threadsPending}`);
        }
        if (response.threadsPending) {
            for (let threadsPending of response.threadsPending) {
                await enqueueThreadForSync(threadsPending);
            }
        }
        const statusChanged = threadDB && threadDB.status !== response.thread.status;
        const newMessagesFiltered = response.messages?.filter((message) => message.senderId !== userId) || [];
        const hasMessagesToCache = (response.messages?.length || 0) > 0;
        if (!statusChanged && !hasMessagesToCache)
            return;
        const notificationTarget = getNotificationTarget(response.thread);
        const isActiveThreadVisible = isThreadOpenedAndVisible(notificationTarget.threadId);
        if (statusChanged && !hasMessagesToCache) {
            const thread = await updateThread(threadId, response.thread, '', '', isActiveThreadVisible ? 0 : 1, getCompactUTC());
            notifyThreadChange(thread);
            if (isActiveThreadVisible) {
                clearPendingNotificationTarget(notificationTarget);
                await refreshNotificationIndicator();
                return;
            }
            if (await shouldNotifyByThreadPreference(notificationTarget, [], userId)) {
                hasNotificationMessages = true;
                await showThreadNotificationIfNeeded(notificationTarget);
            }
            else {
                clearNotificationTarget(notificationTarget);
            }
            return;
        }
        if (!response.messages)
            return;
        const lastMessage = response.messages[response.messages.length - 1];
        const lastUnreadCount = threadDB && threadDB.unreadCount
            ? threadDB.unreadCount
            : 0;
        if (!threadDB) {
            threadDB = await addThread(response.thread);
        }
        const lastMessageText = `${lastMessage.senderId}:${lastMessage.content}`;
        const thread = await updateThread(threadId, response.thread, lastMessageText, lastMessage.createAt, isActiveThreadVisible ? 0 : newMessagesFiltered.length + lastUnreadCount, lastMessage.createAt);
        const newMessages = [];
        for await (let mm of response.messages) {
            const messageId = `${mm.threadId}/${mm.createAt}`;
            const messageOld = await getMessage(messageId);
            const tempMessage = {
                ...mm,
                footers: messageOld?.footers || []
            };
            newMessages.push(tempMessage);
        }
        await addMessages(newMessages);
        if (isActiveThreadVisible) {
            await markThreadReadLocally(threadId, lastMessage.createAt, notificationTarget);
            return;
        }
        notifyThreadChange(thread);
        if (await shouldNotifyByThreadPreference(notificationTarget, newMessagesFiltered, userId)) {
            await showThreadNotificationIfNeeded(notificationTarget);
        }
        else {
            clearNotificationTarget(notificationTarget);
        }
    }
    catch (err) {
        throw new Error(err?.message ||
            'Unexpected error while updating thread in background');
    }
}
function getNotificationTarget(thread) {
    if (thread.kind === 'task-room' && thread.taskRoom?.parentThreadId) {
        return {
            threadId: thread.taskRoom.parentThreadId,
            taskId: thread.taskRoom.taskId
        };
    }
    return { threadId: thread.threadId };
}
function clearNotificationTarget(target) {
    clearPendingNotificationTarget(target);
    void refreshNotificationIndicator();
}
async function shouldNotifyByThreadPreference(target, messages, userId) {
    const parentThread = await getThread(target.threadId);
    const notification = parentThread?.users?.find(user => user.userId === userId)?.notification || 'all';
    if (notification === 'all')
        return true;
    if (notification === 'never')
        return false;
    return messages.some(message => hasUserMention(message.content || '', userId));
}
function hasUserMention(messageContent, userId) {
    const escapedUserId = userId.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return new RegExp(`\\[@[^\\]]+\\]\\(${escapedUserId}\\)`).test(messageContent);
}
function getActiveChat() {
    const search = (root) => {
        const chat = root.querySelector?.('collab-messages-chat-102025');
        if (chat)
            return chat;
        const elements = Array.from(root.querySelectorAll?.('*') || []);
        for (const element of elements) {
            if (element.shadowRoot) {
                const found = search(element.shadowRoot);
                if (found)
                    return found;
            }
        }
    };
    return search(document);
}
function shouldShowThreadNotification(threadId) {
    const chat = getActiveChat();
    const actualThreadId = chat?.actualThread?.thread?.threadId;
    const isThreadOpened = actualThreadId === threadId;
    return !isThreadOpened || document.visibilityState === 'hidden';
}
function isThreadOpenedAndVisible(threadId) {
    return !shouldShowThreadNotification(threadId);
}
async function showThreadNotificationIfNeeded(target) {
    const { threadId, taskId } = target;
    if (!shouldShowThreadNotification(threadId)) {
        clearThreadNotification(threadId);
        if (taskId)
            clearTaskNotification(taskId);
        return;
    }
    pendingNotificationThreads.add(threadId);
    if (taskId) {
        pendingTaskRoomNotifications.add(taskId);
        pendingTaskRoomParentThreads.set(taskId, threadId);
    }
    hasNotificationMessages = true;
    const parentThread = await getThread(threadId);
    if (parentThread)
        notifyThreadChange(parentThread);
    changeFavIcon(true);
    notifyThreadNotification(true);
    const audioEnabled = loadNotificationPreferencesAudio();
    if (audioEnabled && notificationSound) {
        notificationSound.currentTime = 0;
        notificationSound.play().catch(err => console.warn('Erro on play notification audio:', err));
    }
}
async function getNotificationSound() {
    const notifySoundUrl = await environment.notifications.getNotifySoundUrl();
    let notificationSound = null;
    if (notifySoundUrl) {
        notificationSound = new Audio(notifySoundUrl);
        notificationSound.preload = 'auto';
        notificationSound.volume = 1;
    }
    return notificationSound;
}
