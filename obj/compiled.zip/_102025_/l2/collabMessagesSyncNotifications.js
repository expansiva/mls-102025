/// <mls fileReference="_102025_/l2/collabMessagesSyncNotifications.ts" enhancement="_102027_/l2/enhancementLit" />
import { getUserId, loadNotificationDeviceId, loadNotificationPreferencesAudio } from "/_102025_/l2/collabMessagesHelper.js";
import { getThread, updateThread, getMessage, addMessages, getAllThreads, addThread, getCompactUTC, updateMessage } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { notifyThreadChange, notifyMessageChange, notifyThreadNotification } from '/_102025_/l2/collabMessagesEvents.js';
import { changeFavIcon } from '/_102025_/l2/collabMessagesHelper.js';
import { msgGetMessage, msgGetThreadUpdates } from '/_102025_/l2/shared/api.js';
import { environment } from '/_102036_/l2/environmentContract.js';
export const threadSyncMap = new Map();
let hasNotificationMessages = false;
let syncTimeout = null;
let notificationSound = null;
const pendingNotificationThreads = new Set();
export function removeThreadFromSync(threadId) {
    threadSyncMap.delete(threadId);
}
export function clearThreadNotification(threadId) {
    pendingNotificationThreads.delete(threadId);
    if (pendingNotificationThreads.size === 0) {
        hasNotificationMessages = false;
    }
}
export function hasThreadNotificationPending(threadId) {
    return pendingNotificationThreads.has(threadId);
}
export async function checkIfNotificationUnread() {
    if (pendingNotificationThreads.size > 0)
        return true;
    const threads = await getAllThreads();
    let hasPendingMessages = false;
    for (let thread of threads) {
        if (thread.unreadCount && thread.unreadCount > 0) {
            hasPendingMessages = true;
            break;
        }
    }
    return hasPendingMessages;
}
export async function listenToThreadEvents() {
    notificationSound = await getNotificationSound();
    navigator.serviceWorker.addEventListener('message', async (event) => {
        if (window.isTraceNotification)
            console.info(`[NOTIFICATION] Received`);
        if (window.isTraceNotification)
            console.info(`[NOTIFICATION] Data`, event?.data);
        const id = event.data.id;
        if (window.isTraceNotification)
            console.info(`[NOTIFICATION] : sendACK id: ${id}`);
        await environment.notifications.sendACK(id);
        const reference = event.data?.data?.reference;
        if (!reference)
            return;
        let threadId = '';
        const parts = reference.split(':');
        const typeNotification = parts.length === 2 ? 'message-update' : 'thread-update';
        threadId = parts[0];
        await enqueueThreadForSync(reference);
        if (window.isTraceNotification) {
            console.info(`[NOTIFICATION] : queued ${typeNotification} ${threadId}`);
        }
    });
    if (window.isTraceNotification)
        console.info('[NOTIFICATION] : sendRequestMissed');
    await environment.notifications.sendRequestMissed();
}
function enqueueThreadForSync(reference) {
    threadSyncMap.set(reference, true);
    return scheduleNextSync();
}
async function scheduleNextSync() {
    if (syncTimeout || threadSyncMap.size === 0)
        return;
    syncTimeout = setTimeout(async () => {
        syncTimeout = null;
        const [reference] = threadSyncMap.entries().next().value;
        if (!reference)
            return;
        threadSyncMap.delete(reference);
        try {
            if (window.isTraceNotification)
                console.info(`[NOTIFICATION] : refreshThread : ${reference}`);
            await getThreadUpdateInBackground(reference);
        }
        catch (err) {
            console.error(`Error on sync thread ${reference}`, err);
        }
        return scheduleNextSync();
    }, 500);
}
// reference: threadId or threadId:messageId
export async function getThreadUpdateInBackground(reference) {
    const userId = getUserId();
    const deviceId = loadNotificationDeviceId();
    if (!userId)
        throw new Error('Invalid user id');
    let threadId = '';
    let messageId = '';
    const parts = reference.split(':');
    const typeNotification = parts.length === 2 ? 'message-update' : 'thread-update';
    threadId = parts[0];
    messageId = parts[1];
    if (typeNotification === 'thread-update') {
        await updateThreadInBackground(threadId, userId, deviceId);
    }
    if (typeNotification === 'message-update') {
        await updateMessageInBackground(threadId, messageId, userId, deviceId);
        await updateThreadInBackground(threadId, userId, deviceId);
    }
}
async function updateMessageInBackground(threadId, messageId, userId, deviceId) {
    try {
        const result = await msgGetMessage({
            messageId: `${threadId}/${messageId}`,
            threadId,
            userId
        });
        if (!result.success || !result.response?.message) {
            throw new Error(result.error || 'Failed to fetch message');
        }
        if (window.isTraceNotification) {
            console.info(`[NOTIFICATION] : getMessageUpdateInBackground: ${result.response.message}`);
        }
        await updateMessage(result.response.message);
        notifyMessageChange(result.response.message);
    }
    catch (err) {
        throw new Error(err?.message || 'Unexpected error while updating message');
    }
}
async function updateThreadInBackground(threadId, userId, deviceId) {
    let threadDB = await getThread(threadId);
    const lastOrderAt = threadDB?.lastSync || new Date('2000-01-01').toISOString();
    try {
        const result = await msgGetThreadUpdates({
            threadId,
            userId,
            lastOrderAt,
            deviceId: deviceId || undefined
        });
        if (!result.success || !result.response?.thread) {
            throw new Error(result.error || 'Failed to fetch thread update');
        }
        const response = result.response;
        if (window.isTraceNotification) {
            console.info(`[NOTIFICATION] : getThreadUpdateInBackground threadsPending: ${response.threadsPending}`);
        }
        if (response.threadsPending) {
            for (let threadsPending of response.threadsPending) {
                await enqueueThreadForSync(threadsPending);
            }
        }
        const statusChanged = threadDB && threadDB.status !== response.thread.status;
        const newMessagesFiltered = response.messages?.filter((message) => message.senderId !== userId) || [];
        const hasMessagesToCache = (response.messages?.length || 0) > 0;
        if (!statusChanged && !hasMessagesToCache)
            return;
        if (statusChanged && !hasMessagesToCache) {
            const thread = await updateThread(threadId, response.thread, '', '', 1, getCompactUTC());
            notifyThreadChange(thread);
            hasNotificationMessages = true;
            await showThreadNotificationIfNeeded(threadId);
            return;
        }
        if (!response.messages)
            return;
        const lastMessage = response.messages[response.messages.length - 1];
        const lastUnreadCount = threadDB && threadDB.unreadCount
            ? threadDB.unreadCount
            : 0;
        if (!threadDB) {
            threadDB = await addThread(response.thread);
        }
        const lastMessageText = `${lastMessage.senderId}:${lastMessage.content}`;
        const thread = await updateThread(threadId, response.thread, lastMessageText, lastMessage.createAt, newMessagesFiltered.length + lastUnreadCount, lastMessage.createAt);
        const newMessages = [];
        for await (let mm of response.messages) {
            const messageId = `${mm.threadId}/${mm.createAt}`;
            const messageOld = await getMessage(messageId);
            const tempMessage = {
                ...mm,
                footers: messageOld?.footers || []
            };
            newMessages.push(tempMessage);
        }
        await addMessages(newMessages);
        notifyThreadChange(thread);
        await showThreadNotificationIfNeeded(threadId);
    }
    catch (err) {
        throw new Error(err?.message ||
            'Unexpected error while updating thread in background');
    }
}
function getActiveChat() {
    const search = (root) => {
        const chat = root.querySelector?.('collab-messages-chat-102025');
        if (chat)
            return chat;
        const elements = Array.from(root.querySelectorAll?.('*') || []);
        for (const element of elements) {
            if (element.shadowRoot) {
                const found = search(element.shadowRoot);
                if (found)
                    return found;
            }
        }
    };
    return search(document);
}
function shouldShowThreadNotification(threadId) {
    const chat = getActiveChat();
    const actualThreadId = chat?.actualThread?.thread?.threadId;
    const isThreadOpened = actualThreadId === threadId;
    return !isThreadOpened || document.visibilityState === 'hidden';
}
async function showThreadNotificationIfNeeded(threadId) {
    if (!shouldShowThreadNotification(threadId)) {
        clearThreadNotification(threadId);
        return;
    }
    pendingNotificationThreads.add(threadId);
    hasNotificationMessages = true;
    changeFavIcon(true);
    notifyThreadNotification(true);
    const audioEnabled = loadNotificationPreferencesAudio();
    if (audioEnabled && notificationSound) {
        notificationSound.currentTime = 0;
        notificationSound.play().catch(err => console.warn('Erro on play notification audio:', err));
    }
}
async function getNotificationSound() {
    const notifySoundUrl = await environment.notifications.getNotifySoundUrl();
    let notificationSound = null;
    if (notifySoundUrl) {
        notificationSound = new Audio(notifySoundUrl);
        notificationSound.preload = 'auto';
        notificationSound.volume = 1;
    }
    return notificationSound;
}
