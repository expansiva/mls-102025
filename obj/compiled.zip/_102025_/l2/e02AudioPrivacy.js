/// <mls fileReference="_102025_/l2/e02AudioPrivacy.ts" enhancement="_blank" />
export function e02ErrorStatus(error) {
    if (!error || typeof error !== 'object')
        return null;
    const status = error.statusCode;
    return typeof status === 'number' && Number.isFinite(status) ? status : null;
}
export function isE02AccessRevokedError(error) {
    const status = e02ErrorStatus(error);
    return status === 403 || status === 404;
}
/** Pure fail-closed reducer used by the UI and its privacy regression tests. */
export function clearE02PrivateCacheOnAccessError(error, current) {
    if (!isE02AccessRevokedError(error))
        return { revoked: false, cache: current };
    return {
        revoked: true,
        cache: {
            audioUrl: '', processingId: '', processing: undefined, correctionDraft: '',
            interpretationRequest: '', selectedVersion: null, feedback: '',
        },
    };
}
