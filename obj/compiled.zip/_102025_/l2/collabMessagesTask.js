/// <mls fileReference="_102025_/l2/collabMessagesTask.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { getTask, getMessage, deleteTask, addOrUpdateTask } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { msgGetTaskUpdate } from '/_102025_/l2/shared/api.js';
import { collab_money, collab_pause, collab_bell, collab_chevron_right, collab_clock, collab_check, collab_bug } from '/_102025_/l2/collabMessagesIcons.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    'llm.provider.unavailable': 'Estamos com dificuldades técnicas. Tente novamente mais tarde.',
};
const message_en = {
    loading: 'Loading...',
    'llm.provider.unavailable': 'We are experiencing technical difficulties. Please try again later.',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
function collectSteps(firstStep) {
    if (!firstStep || firstStep.length < 1)
        return [];
    const allSteps = [];
    const queue = [...firstStep];
    while (queue.length > 0) {
        const currentStep = queue.shift();
        allSteps.push(currentStep);
        if (currentStep.nextSteps)
            queue.push(...currentStep.nextSteps);
        if (currentStep.interaction?.payload)
            queue.push(...currentStep.interaction.payload);
    }
    return allSteps;
}
function nextPendingStep(task) {
    return collectSteps(task.iaCompressed?.nextSteps).find(step => step.status === 'pending') || null;
}
function currentModuleStage(task) {
    const root = task.iaCompressed?.nextSteps?.[0];
    if (!root || root.type !== 'module')
        return undefined;
    const children = root.nextSteps ?? [];
    return children.find((step) => step.type === 'module' && step.status === 'in_progress');
}
export function taskCardIconStatus(task, userId) {
    const pending = nextPendingStep(task);
    if (pending?.type === 'clarification')
        return 'waitingforuser';
    const stage = currentModuleStage(task);
    if (userId && stage?.module.kind === 'human' && stage.module.actorNow === userId) {
        return 'waitingforuser';
    }
    return task.status;
}
export function taskNeedsServerSync(task, userId, hasContext, hasMessageRef) {
    if (!task)
        return hasMessageRef;
    return task.status === 'in progress' && task.owner === userId && !hasContext;
}
let CollabMessagesTask = class CollabMessagesTask extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-task-102025 {
  box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
  overflow: hidden;
  cursor: pointer;
  background-color: #fff;
  color: #000000;
  height: 40px;
  display: flex;
  align-items: center;
  border-radius: 10px;
}
collab-messages-task-102025 .card.no-details {
  display: block;
}
collab-messages-task-102025 .card {
  display: block;
  padding: var(--space-16);
  width: 100%;
  position: relative;
}
collab-messages-task-102025 .card.has-notification {
  padding-right: 1.65rem;
}
collab-messages-task-102025 .card .task-room-notification {
  position: absolute;
  top: 0.25rem;
  right: 0.35rem;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--status-success-text);
  fill: var(--status-success-text);
  pointer-events: none;
}
collab-messages-task-102025 .card .task-room-notification svg {
  width: 12px;
  height: 12px;
}
collab-messages-task-102025 .card .task-icon .icon-wrapper {
  position: relative;
  display: inline-block;
  font-size: 20px;
}
collab-messages-task-102025 .card .task-icon .notification-badge {
  position: absolute;
  top: -1px;
  right: -3px;
  background: red;
  color: white;
  border-radius: 50%;
  padding: 0.1em 0.1em;
  font-size: 0.49em;
  font-weight: bold;
  line-height: 1;
  min-width: 1em;
  text-align: center;
}
collab-messages-task-102025 .card .task-icon.failed {
  fill: var(--status-error-text);
  color: var(--status-error-text);
}
collab-messages-task-102025 .card .task-icon.done {
  fill: var(--status-success-text);
  color: var(--status-success-text);
}
collab-messages-task-102025 .card .task-icon.waitingforuser {
  fill: var(--status-warning-text);
  color: var(--status-warning-text);
}
collab-messages-task-102025 .card .card-header {
  display: flex;
  justify-content: space-between;
  gap: 0.4rem;
  align-items: center;
}
collab-messages-task-102025 .card .card-header .card-user {
  color: #be069c;
}
collab-messages-task-102025 .card .card-header .card-title {
  font-size: var(--font-size-12);
  font-weight: bold;
  max-width: 115px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
collab-messages-task-102025 .card .card-header .card-time {
  font-size: 0.75rem;
  color: gray;
  text-align: right;
  transition: color 0.3s ease;
}
collab-messages-task-102025 .card .card-header .card-time.over-minute {
  color: red;
  animation: pulse 1s infinite alternate;
}
@keyframes pulse {
  0% {
    transform: scale(1);
  }
  100% {
    transform: scale(1.2);
  }
}
collab-messages-task-102025 .card .card-header .card-price {
  display: flex;
  align-items: center;
  gap: 0.2rem;
  font-size: var(--font-size-12);
}
collab-messages-task-102025 .card .card-header .card-price svg {
  width: 12px;
  height: 12px;
}
collab-messages-task-102025 .card .card-header .card-actions {
  display: flex;
  gap: 0.4rem;
  align-items: center;
}
collab-messages-task-102025 .card .card-header .card-actions i {
  cursor: pointer;
}
collab-messages-task-102025 .card .card-header .card-actions i:hover {
  transform: scale(1.1);
}
collab-messages-task-102025 .card .card-header .card-actions svg {
  width: 12px;
  height: 12px;
}
collab-messages-task-102025 .card .card-header .card-status {
  text-transform: uppercase;
  font-size: var(--font-size-12);
  border: 1px solid;
  padding: 0 0.3rem;
  border-radius: 4px;
  white-space: nowrap;
}
collab-messages-task-102025 .card .card-header .card-status.todo {
  color: var(--text-muted);
}
collab-messages-task-102025 .card .card-header .card-status.done {
  color: var(--status-success-text);
}
collab-messages-task-102025 .card .card-header .card-status.in-progress {
  color: var(--selected-text);
}
collab-messages-task-102025 .card .card-header .card-status.waitingforuser {
  color: var(--status-warning-text);
}
collab-messages-task-102025 .card .card-header .card-status.paused {
  color: var(--status-info-text-disabled);
}
collab-messages-task-102025 .card .card-body {
  margin-top: var(--space-16);
}
collab-messages-task-102025 .card .card-body .card-message {
  font-size: var(--font-size-16);
}
`);
        this.msg = messages['en'];
        this.taskid = '';
        this.threadId = '';
        this.userId = '';
        this.messageid = '';
        this.lastChanged = '';
        this.status = '';
        this.notificationPending = false;
        this.secondsPassed = 0;
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        if (this.timerId) {
            clearInterval(this.timerId);
            this.timerId = undefined;
        }
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('lastChanged')) {
            if (this.context && this.context.task) {
                this.task = this.context.task;
                const nextStep = this.getNextPendentStep(this.task);
                if (!nextStep || nextStep.type === 'clarification') {
                    this.resetTimer();
                    this.lastStep = undefined;
                }
                else {
                    if (this.lastStep !== nextStep.stepId) {
                        this.resetTimer();
                        this.lastStep = nextStep.stepId;
                    }
                }
                if (this.shouldSyncFailedSnapshot(this.task)) {
                    await this.syncTaskFromServer(this.task.PK || this.taskid);
                }
            }
        }
        if (changedProperties.has('taskid') && changedProperties.get('taskid') !== '') {
            this.getTaskLocal(this.taskid);
        }
    }
    render() {
        const isOverMinute = this.secondsPassed >= 60;
        const timeClass = isOverMinute ? 'card-time over-minute' : 'card-time';
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.task) {
            return html `<div @click=${this.onCardClick} class="card no-details"> 
            <div class="card-header">
                <span class="card-title">Task</span>
                ${collab_chevron_right}
            </div>
         </div>`;
        }
        const price = this.task ? this.getTotalCost(this.task) || '0.00' : '';
        const title = this.task?.title || '';
        const timeDisplay = this.formatTime(this.secondsPassed);
        return html `<div @click=${this.onCardClick} class="card ${this.notificationPending ? 'has-notification' : ''}"> 
        <div class="card-header">
            ${this.renderIconTask()}
            <span class="card-title"> ${title}</span>
            ${this.notificationPending ? html `<span class="task-room-notification">${collab_bell}</span>` : ''}
            <span class="card-price"> ${price ? collab_money : ''}${price}</span>
            ${this.lastStep ? html `<span class="${timeClass}">${timeDisplay}</span>` : ''}
        </div>
     </div>`;
    }
    renderIconTask() {
        const taskObj = {
            '': html ``,
            'pending': collab_clock,
            'paused': collab_pause,
            'todo': collab_clock,
            'in progress': collab_clock,
            'done': collab_check,
            'failed': collab_bug,
            'waitingforuser': html `
                    <span class="icon-wrapper">
                        ${collab_bell}
                        <span class="notification-badge">1</span>
                    </span>`,
        };
        let status = this.status;
        if (this.task) {
            status = taskCardIconStatus(this.task, this.userId);
        }
        if (!status)
            return html `<span class="task-icon in progress ">${collab_clock}</span>`;
        const providerHint = this.task?.status === 'paused' && String(this.task.last_update_log || '').includes('llm.provider.')
            ? this.msg['llm.provider.unavailable']
            : '';
        return html `<span class="task-icon ${status.split(' ').join('-')} " title=${providerHint}>${taskObj[status]}</span>`;
    }
    resetTimer() {
        this.secondsPassed = 0;
        if (this.timerId) {
            clearInterval(this.timerId);
        }
        this.timerId = window.setInterval(() => {
            this.secondsPassed++;
            this.requestUpdate();
        }, 1000);
    }
    resetTimerState() {
        this.secondsPassed = 0;
        this.lastStep = undefined;
        if (this.timerId) {
            clearInterval(this.timerId);
            this.timerId = undefined;
        }
    }
    formatTime(seconds) {
        const min = Math.floor(seconds / 60).toString().padStart(2, '0');
        const sec = (seconds % 60).toString().padStart(2, '0');
        return `${min}:${sec}`;
    }
    async getTaskLocal(taskId) {
        const task = await getTask(taskId);
        const hasMessageRef = !!(this.threadId && this.messageid);
        if (!task) {
            if (taskNeedsServerSync(undefined, this.userId, !!this.context, hasMessageRef)) {
                await this.syncTaskFromServer(taskId);
            }
            return;
        }
        this.task = task;
        const shouldSync = taskNeedsServerSync(task, this.userId, !!this.context, hasMessageRef) ||
            this.shouldSyncFailedSnapshot(task);
        if (!shouldSync)
            return;
        await this.syncTaskFromServer(taskId);
    }
    shouldSyncFailedSnapshot(task) {
        const syncKey = this.getTaskSnapshotKey(task);
        return !!task &&
            task.status === 'failed' &&
            task.owner === this.userId &&
            this.finalSnapshotSyncedKey !== syncKey;
    }
    getTaskSnapshotKey(task) {
        return `${task?.PK || this.taskid}:${task?.last_updated || ''}`;
    }
    async syncTaskFromServer(taskId) {
        const messageId = this.normalizeMessageId(this.threadId, this.messageid);
        try {
            const result = await msgGetTaskUpdate({
                messageId,
                taskId,
                userId: this.userId
            });
            if (!result.success || !result.response?.task) {
                if (result.statusCode === 404) {
                    await deleteTask(taskId);
                    this.task = undefined;
                    this.context = undefined;
                    this.resetTimerState();
                }
                return;
            }
            const syncedTask = result.response.task;
            if (syncedTask.status === 'failed') {
                this.finalSnapshotSyncedKey = this.getTaskSnapshotKey(syncedTask);
            }
            this.task = syncedTask;
            await addOrUpdateTask(syncedTask);
            const message = await getMessage(messageId);
            if (!message)
                return;
            this.context = {
                task: syncedTask,
                message,
                isTest: false
            };
            this.lastChanged = Date.now().toString();
        }
        catch (err) {
            console.error('Error fetching task update:', err);
        }
    }
    onCardClick() {
        const event = new CustomEvent('taskclick', {
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(event);
    }
    normalizeMessageId(threadId, messageIdOrOrderAt) {
        if (!messageIdOrOrderAt.includes('/'))
            return `${threadId}/${messageIdOrOrderAt}`;
        const parts = messageIdOrOrderAt.split('/').filter(Boolean);
        if (parts.length === 2)
            return messageIdOrOrderAt;
        return `${parts[0]}/${parts[parts.length - 1]}`;
    }
    getNextPendentStep(task) {
        return nextPendingStep(task);
    }
    ;
    getTotalCost(task) {
        let tot = 0;
        const nextSteps = task.iaCompressed?.nextSteps;
        if (!nextSteps || nextSteps.length === 0)
            return "$ 0.01"; // garante saída mínima
        const sumCosts = (payload) => {
            payload.forEach((pay) => {
                const { interaction, nextSteps } = pay;
                if (interaction) {
                    tot += interaction.cost ? interaction.cost : 0;
                    if (interaction.payload)
                        sumCosts(interaction.payload);
                }
                if (nextSteps) {
                    nextSteps.forEach((next) => sumCosts([next]));
                }
            });
        };
        nextSteps.forEach((step) => sumCosts([step]));
        const rounded = Math.ceil(tot * 100) / 100;
        return `${rounded.toFixed(2)}`;
    }
};
__decorate([
    property()
], CollabMessagesTask.prototype, "taskid", void 0);
__decorate([
    property()
], CollabMessagesTask.prototype, "threadId", void 0);
__decorate([
    property()
], CollabMessagesTask.prototype, "userId", void 0);
__decorate([
    property()
], CollabMessagesTask.prototype, "messageid", void 0);
__decorate([
    property()
], CollabMessagesTask.prototype, "lastChanged", void 0);
__decorate([
    property()
], CollabMessagesTask.prototype, "status", void 0);
__decorate([
    property({ type: Boolean })
], CollabMessagesTask.prototype, "notificationPending", void 0);
__decorate([
    state()
], CollabMessagesTask.prototype, "task", void 0);
__decorate([
    state()
], CollabMessagesTask.prototype, "context", void 0);
__decorate([
    state()
], CollabMessagesTask.prototype, "secondsPassed", void 0);
__decorate([
    state()
], CollabMessagesTask.prototype, "lastStep", void 0);
CollabMessagesTask = __decorate([
    customElement('collab-messages-task-102025')
], CollabMessagesTask);
export { CollabMessagesTask };
