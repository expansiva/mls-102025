/// <mls fileReference="_102025_/l2/collabMessagesTaskPreviewRaw.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { getTotalCost } from '/_102027_/l2/aiAgentHelper.js';
import { collab_money } from '/_102025_/l2/collabMessagesIcons.js';
let CollabMessagesTaskPreviewRaw = class CollabMessagesTaskPreviewRaw extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-task-preview-raw-102025 {
  display: block;
  background: #ffffff;
  position: relative;
  height: calc(100% - 62px);
  min-height: 0;
  color: #3c3c3c;
}
collab-messages-task-preview-raw-102025 .raw-shell {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
}
collab-messages-task-preview-raw-102025 .tab-header {
  display: flex;
  justify-content: space-between;
  border-bottom: 1px solid #ccc;
  background-color: #f0f0f0;
  overflow: hidden;
  flex-shrink: 0;
}
collab-messages-task-preview-raw-102025 .tab-group-left {
  display: flex;
  overflow-x: auto;
  flex: 1;
  min-width: 0;
  scrollbar-width: thin;
}
collab-messages-task-preview-raw-102025 .tab-group-left::-webkit-scrollbar {
  height: 6px;
}
collab-messages-task-preview-raw-102025 .tab-group-left::-webkit-scrollbar-thumb {
  background-color: var(--border-default-focus);
  border-radius: 4px;
}
collab-messages-task-preview-raw-102025 .tab-group-right {
  display: flex;
  flex-shrink: 0;
}
collab-messages-task-preview-raw-102025 .tab-button {
  padding: 10px 16px;
  cursor: pointer;
  background: none;
  border: none;
  border-right: 1px solid #ddd;
  font-size: 14px;
  transition: background-color 0.2s ease;
  display: flex;
  flex-direction: column;
}
collab-messages-task-preview-raw-102025 .tab-button:hover {
  background-color: #e0e0e0;
}
collab-messages-task-preview-raw-102025 .tab-button.active {
  background-color: #ffffff;
  font-weight: bold;
  border-bottom: 2px solid #007bff;
}
collab-messages-task-preview-raw-102025 .tab-content {
  position: relative;
  padding: 0;
  margin: 0;
  background-color: #ffffff;
  display: flex;
  flex: 1;
  min-height: 0;
  flex-direction: column;
  font-size: 14px;
  overflow-y: auto;
}
collab-messages-task-preview-raw-102025 .containerinputs {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  align-items: center;
  padding: 1rem;
}
collab-messages-task-preview-raw-102025 .containerinputs details {
  width: 100%;
  max-width: 900px;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  background-color: #fafafa;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  font-family: 'Inter', sans-serif;
  transition: all 0.3s ease;
}
collab-messages-task-preview-raw-102025 .containerinputs details[open] .title {
  display: none;
}
collab-messages-task-preview-raw-102025 .containerinputs details .chevron {
  transition: transform 0.3s;
}
collab-messages-task-preview-raw-102025 .containerinputs details[open] .chevron {
  transform: rotate(90deg);
}
collab-messages-task-preview-raw-102025 .containerinputs details[open] .moveelement {
  display: none !important;
}
collab-messages-task-preview-raw-102025 .containerinputs details summary {
  position: relative;
  cursor: pointer;
  padding: 1rem;
  border-bottom: 1px solid #e0e0e0;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
collab-messages-task-preview-raw-102025 .containerinputs details summary:hover .moveelement {
  display: flex;
}
collab-messages-task-preview-raw-102025 .containerinputs details summary .trash {
  z-index: 9999;
}
collab-messages-task-preview-raw-102025 .containerinputs details summary .pheader {
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
collab-messages-task-preview-raw-102025 .containerinputs details summary .pheader .title {
  margin-left: 1rem;
}
collab-messages-task-preview-raw-102025 .containerinputs details summary .pheader .type .typeMode {
  appearance: none;
  padding: 0.4rem 1rem;
  font-size: 0.95rem;
  border: 1px solid #ccc;
  border-radius: 6px;
  background-color: white;
  transition: border 0.3s ease;
}
collab-messages-task-preview-raw-102025 .containerinputs details > div {
  padding: 1rem;
}
collab-messages-task-preview-raw-102025 .containerinputs details > div pre.content {
  width: calc(100% - 2rem);
  border: none;
  resize: vertical;
  padding: 1rem;
  font-size: 0.95rem;
  font-family: 'Fira Code', monospace;
  background-color: #fff;
  border-radius: 6px;
  color: #333;
  box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.05);
  line-height: 1.5;
  word-break: break-word;
  white-space: pre-wrap;
}
collab-messages-task-preview-raw-102025 ul {
  list-style: none;
  padding: 1rem;
  margin: 1rem 0;
  border-radius: 12px;
  color: #333;
}
collab-messages-task-preview-raw-102025 ul li {
  margin-bottom: 0.75rem;
  padding: 0.5rem 0.75rem;
  background: white;
  border-radius: 8px;
  transition: background 0.3s;
}
collab-messages-task-preview-raw-102025 ul li code {
  font-family: 'Courier New', monospace;
  background-color: #eee;
  padding: 2px 6px;
  border-radius: 4px;
}
`);
        this.mode = 'flexible';
        this.message = null;
        this.task = null;
        this.step = null;
        this.msize = '';
        // ── Editor config ─────────────────────────────────────────────────────────
        this.editorConf = {
            contextmenu: true,
            autoIndent: 'full',
            wordWrap: 'on',
            wrappingIndent: 'indent',
            tabCompletion: 'on',
            renderControlCharacters: false,
            showUnused: true,
            glyphMargin: true,
            minimap: { enabled: false },
            useTabStops: true,
            scrollBeyondLastColumn: 2,
            scrollBeyondLastLine: false,
            formatOnType: true,
            fixedOverflowWidgets: true,
            codeLens: true,
            showFoldingControls: 'mouseover',
            suggestSelection: 'first',
            stickyScroll: { enabled: false, maxLineCount: 3 },
            stickyTabStops: true,
            fontSize: 14,
            automaticLayout: true,
        };
    }
    get sharedEditor() {
        return window.elEditorTaskView;
    }
    get sharedMonaco() {
        return window.editorTaskView;
    }
    async firstUpdated() {
        if (this.mode === 'flexible') {
            this.mountEditor();
            this.updateEditorContent();
        }
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this.resizeObserver?.disconnect();
    }
    updated(changedProps) {
        if (this.mode === 'flexible') {
            // The shared editor is a single DOM node moved between previews; a
            // re-render can recreate #elEditor empty, or another instance can
            // steal the editor. Re-mount whenever it isn't inside our host.
            const detached = !!this.elEditor && (!this.sharedEditor || this.sharedEditor.parentElement !== this.elEditor);
            if (detached || changedProps.has('mode')) {
                this.mountEditor();
                this.updateEditorContent();
            }
            else if (changedProps.has('step')) {
                this.updateEditorContent();
            }
        }
        if (changedProps.has('msize')) {
            this.sharedEditor?.setAttribute('msize', this.msize);
            this.layoutEditor();
        }
    }
    // ── Editor lifecycle ──────────────────────────────────────────────────────
    ensureEditorCreated() {
        if (this.sharedMonaco)
            return;
        if (typeof monaco === 'undefined')
            return;
        try {
            const editorEl = document.createElement('mls-editor-100529');
            editorEl.style.cssText = 'width:100%; height: calc(100% - 102px)';
            const model = this.createModel();
            const ed1 = monaco.editor.create(editorEl, this.editorConf);
            monaco.languages.typescript.javascriptDefaults.setCompilerOptions({ noImplicitAny: true });
            ed1.updateOptions({ readOnly: true });
            ed1.setModel(model);
            editorEl.mlsEditor = ed1;
            window.elEditorTaskView = editorEl;
            window.editorTaskView = ed1;
        }
        catch (e) {
            console.warn('collabMessagesTaskPreviewRaw: monaco editor not ready', e);
        }
    }
    /**
     * Called every time the flexible tab becomes visible.
     * Creates the shared editor once, then re-appends it to the fresh #elEditor node.
     */
    mountEditor() {
        if (!this.elEditor)
            return;
        this.ensureEditorCreated();
        if (!this.sharedEditor)
            return;
        this.elEditor.appendChild(this.sharedEditor);
        this.observeEditorHost();
        this.layoutEditor();
    }
    observeEditorHost() {
        if (!this.elEditor)
            return;
        this.resizeObserver?.disconnect();
        this.resizeObserver = new ResizeObserver(() => this.layoutEditor());
        this.resizeObserver.observe(this.elEditor);
    }
    createModel() {
        const uri = monaco.Uri.parse('file://server/taskViewModel.ts');
        return monaco.editor.getModel(uri)
            ?? monaco.editor.createModel('', 'javascript', uri);
    }
    updateEditorContent() {
        const ed1 = this.sharedMonaco;
        if (!ed1 || !this.task)
            return;
        const value = JSON.stringify(this.task, null, 2);
        ed1.getModel()?.setValue(value);
        this.layoutEditor();
    }
    layoutEditor() {
        const editor = this.sharedMonaco;
        const host = this.elEditor;
        if (!editor || !host)
            return;
        requestAnimationFrame(() => {
            const rect = host.getBoundingClientRect();
            if (rect.width > 0 && rect.height > 0) {
                editor.layout({ width: rect.width, height: rect.height });
            }
            else {
                editor.layout();
            }
        });
    }
    // ── Render ────────────────────────────────────────────────────────────────
    render() {
        return html `
            <div class="raw-shell">
                <div class="tab-header">
                    <div class="tab-group-left">
                        <button class="tab-button ${this.mode === 'info' ? 'active' : ''}"
                            @click=${() => this.setMode('info')}>Info</button>
                        <button class="tab-button ${this.mode === 'flexible' ? 'active' : ''}"
                            @click=${() => this.setMode('flexible')}>Raw</button>
                    </div>
                </div>
                <div class="tab-content">
                    ${this.renderMode()}
                </div>
            </div>
        `;
    }
    setMode(mode) {
        this.mode = mode;
    }
    renderMode() {
        switch (this.mode) {
            case 'flexible': return this.renderFlexible();
            case 'info': return this.renderInfo();
            case 'result': return this.renderResults();
            default: return this.renderInfo();
        }
    }
    renderInfo() {
        if (!this.task)
            return html `Not found!`;
        return html `
            <div class="containerinputs">
                <details open>
                    <summary>${this.renderSummary('Task')}</summary>
                    <div>
                        <b>${this.task.PK}</b> 
                        <span>${this.task.status}</span> 
                        <span>${collab_money} ${getTotalCost(this.task)}</span>
                    </div>
                    ${this.renderTaskModeDetails()}
                </details>
            </div>
        `;
    }
    renderTaskModeDetails() {
        return html `
            ${this.renderTaskInfo()}
            ${this.renderlLongMemory()}
        `;
    }
    renderTaskInfo() {
        if (!this.task)
            return html ``;
        const cloneTask = Object.assign({}, this.task);
        delete cloneTask.iaCompressed;
        return html `
            <div class="task-info">
                <h4>Details</h4>
                <ul>
                    ${Object.keys(cloneTask).map((key) => {
            return html `
                            <li>${key}: 
                            ${cloneTask && typeof cloneTask[key] === 'string'
                ? cloneTask[key]
                : cloneTask[key].toString()} </li>`;
        })}
                </ul>             
            </div>
        `;
    }
    renderlLongMemory() {
        if (!this.task || !this.task.iaCompressed?.longMemory)
            return html ``;
        return html `
            
            <div class="task-info">
                <h4>LongMemory</h4>
                <ul>
                ${Object.keys(this.task.iaCompressed?.longMemory).map((key) => {
            return html `<li>${key}:${this.task?.iaCompressed?.longMemory[key]}</li>`;
        })}
            </ul>
            </div>
        `;
    }
    renderSummary(title) {
        return html `
            <div class="pheader">
                <div style="display:flex; align-items:center; gap:.5rem">
                    <span>${title}</span>
                </div>
                <div style="display:flex; gap:.5rem">
                    <div class="chevron">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" style="width:10px">
                            <path d="M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"/>
                        </svg>
                    </div>
                </div>
            </div>
        `;
    }
    renderFlexible() {
        return html `<div id="elEditor" style="width:100%; height:100%"></div>`;
    }
    renderResults() {
        if (!this.step)
            return html `Not found step`;
        const nextOptions = [
            ...(this.step.interaction?.payload ?? []),
            ...(this.step.nextSteps ?? []),
        ];
        return html `
            <ul>
                ${nextOptions.length === 0
            ? html `<li><em>Not next step</em></li>`
            : nextOptions.map((ns) => html `<li>[${ns.stepId}] ${ns.type} - ${ns.agentName}</li>`)}
            </ul>
        `;
    }
};
__decorate([
    state()
], CollabMessagesTaskPreviewRaw.prototype, "mode", void 0);
__decorate([
    property({ type: Object })
], CollabMessagesTaskPreviewRaw.prototype, "message", void 0);
__decorate([
    property({ type: Object })
], CollabMessagesTaskPreviewRaw.prototype, "task", void 0);
__decorate([
    property({ type: Object })
], CollabMessagesTaskPreviewRaw.prototype, "step", void 0);
__decorate([
    property({ type: String })
], CollabMessagesTaskPreviewRaw.prototype, "msize", void 0);
__decorate([
    query('#elEditor')
], CollabMessagesTaskPreviewRaw.prototype, "elEditor", void 0);
CollabMessagesTaskPreviewRaw = __decorate([
    customElement('collab-messages-task-preview-raw-102025')
], CollabMessagesTaskPreviewRaw);
export { CollabMessagesTaskPreviewRaw };
