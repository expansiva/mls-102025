/// <mls fileReference="_102025_/l2/collabMessagesTaskPreviewRaw.ts" enhancement="_102025_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { CollabLitElement } from '/_102027_/l2/collabLitElement.js';
import { getTotalCost } from '/_102027_/l2/aiAgentHelper.js';
import { collab_money } from '/_102025_/l2/collabMessagesIcons.js';
let CollabMessagesTaskPreviewRaw = class CollabMessagesTaskPreviewRaw extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.mode = 'flexible';
        this.message = null;
        this.task = null;
        this.step = null;
        this.msize = '';
        // ── Editor config ─────────────────────────────────────────────────────────
        this.editorConf = {
            contextmenu: true,
            autoIndent: 'full',
            wordWrap: 'on',
            wrappingIndent: 'indent',
            tabCompletion: 'on',
            renderControlCharacters: false,
            showUnused: true,
            glyphMargin: true,
            minimap: { enabled: false },
            useTabStops: true,
            scrollBeyondLastColumn: 2,
            scrollBeyondLastLine: false,
            formatOnType: true,
            fixedOverflowWidgets: true,
            codeLens: true,
            showFoldingControls: 'mouseover',
            suggestSelection: 'first',
            stickyScroll: { enabled: false, maxLineCount: 3 },
            stickyTabStops: true,
            fontSize: 14,
            automaticLayout: true,
        };
    }
    get sharedEditor() {
        return window.elEditorTaskView;
    }
    get sharedMonaco() {
        return window.editorTaskView;
    }
    async firstUpdated() {
        if (this.mode === 'flexible') {
            this.mountEditor();
            this.updateEditorContent();
        }
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this.resizeObserver?.disconnect();
    }
    updated(changedProps) {
        if (changedProps.has('mode') && this.mode === 'flexible') {
            this.mountEditor();
            this.updateEditorContent();
        }
        if (changedProps.has('step') && this.mode === 'flexible') {
            this.updateEditorContent();
        }
        if (changedProps.has('msize')) {
            this.sharedEditor?.setAttribute('msize', this.msize);
            this.layoutEditor();
        }
    }
    // ── Editor lifecycle ──────────────────────────────────────────────────────
    ensureEditorCreated() {
        if (this.sharedMonaco)
            return;
        const editorEl = document.createElement('mls-editor-100529');
        editorEl.style.cssText = 'width:100%; height: calc(100% - 102px)';
        const model = this.createModel();
        const ed1 = monaco.editor.create(editorEl, this.editorConf);
        monaco.languages.typescript.javascriptDefaults.setCompilerOptions({ noImplicitAny: true });
        ed1.updateOptions({ readOnly: true });
        ed1.setModel(model);
        editorEl.mlsEditor = ed1;
        window.elEditorTaskView = editorEl;
        window.editorTaskView = ed1;
    }
    /**
     * Called every time the flexible tab becomes visible.
     * Creates the shared editor once, then re-appends it to the fresh #elEditor node.
     */
    mountEditor() {
        if (!this.elEditor)
            return;
        this.ensureEditorCreated();
        this.elEditor.appendChild(this.sharedEditor);
        this.observeEditorHost();
        this.layoutEditor();
    }
    observeEditorHost() {
        if (!this.elEditor)
            return;
        this.resizeObserver?.disconnect();
        this.resizeObserver = new ResizeObserver(() => this.layoutEditor());
        this.resizeObserver.observe(this.elEditor);
    }
    createModel() {
        const uri = monaco.Uri.parse('file://server/taskViewModel.ts');
        return monaco.editor.getModel(uri)
            ?? monaco.editor.createModel('', 'javascript', uri);
    }
    updateEditorContent() {
        const ed1 = this.sharedMonaco;
        if (!ed1 || !this.task)
            return;
        const value = JSON.stringify(this.task, null, 2);
        ed1.getModel()?.setValue(value);
        this.layoutEditor();
    }
    layoutEditor() {
        const editor = this.sharedMonaco;
        const host = this.elEditor;
        if (!editor || !host)
            return;
        requestAnimationFrame(() => {
            const rect = host.getBoundingClientRect();
            if (rect.width > 0 && rect.height > 0) {
                editor.layout({ width: rect.width, height: rect.height });
            }
            else {
                editor.layout();
            }
        });
    }
    // ── Render ────────────────────────────────────────────────────────────────
    render() {
        return html `
            <div class="raw-shell">
                <div class="tab-header">
                    <div class="tab-group-left">
                        <button class="tab-button ${this.mode === 'info' ? 'active' : ''}"
                            @click=${() => this.setMode('info')}>Info</button>
                        <button class="tab-button ${this.mode === 'flexible' ? 'active' : ''}"
                            @click=${() => this.setMode('flexible')}>Raw</button>
                    </div>
                </div>
                <div class="tab-content">
                    ${this.renderMode()}
                </div>
            </div>
        `;
    }
    setMode(mode) {
        this.mode = mode;
    }
    renderMode() {
        switch (this.mode) {
            case 'flexible': return this.renderFlexible();
            case 'info': return this.renderInfo();
            case 'result': return this.renderResults();
            default: return this.renderInfo();
        }
    }
    renderInfo() {
        if (!this.task)
            return html `Not found!`;
        return html `
            <div class="containerinputs">
                <details open>
                    <summary>${this.renderSummary('Task')}</summary>
                    <div>
                        <b>${this.task.PK}</b> 
                        <span>${this.task.status}</span> 
                        <span>${collab_money} ${getTotalCost(this.task)}</span>
                    </div>
                    ${this.renderTaskModeDetails()}
                </details>
            </div>
        `;
    }
    renderTaskModeDetails() {
        return html `
            ${this.renderTaskInfo()}
            ${this.renderlLongMemory()}
        `;
    }
    renderTaskInfo() {
        if (!this.task)
            return html ``;
        const cloneTask = Object.assign({}, this.task);
        delete cloneTask.iaCompressed;
        return html `
            <div class="task-info">
                <h4>Details</h4>
                <ul>
                    ${Object.keys(cloneTask).map((key) => {
            return html `
                            <li>${key}: 
                            ${cloneTask && typeof cloneTask[key] === 'string'
                ? cloneTask[key]
                : cloneTask[key].toString()} </li>`;
        })}
                </ul>             
            </div>
        `;
    }
    renderlLongMemory() {
        if (!this.task || !this.task.iaCompressed?.longMemory)
            return html ``;
        return html `
            
            <div class="task-info">
                <h4>LongMemory</h4>
                <ul>
                ${Object.keys(this.task.iaCompressed?.longMemory).map((key) => {
            return html `<li>${key}:${this.task?.iaCompressed?.longMemory[key]}</li>`;
        })}
            </ul>
            </div>
        `;
    }
    renderSummary(title) {
        return html `
            <div class="pheader">
                <div style="display:flex; align-items:center; gap:.5rem">
                    <span>${title}</span>
                </div>
                <div style="display:flex; gap:.5rem">
                    <div class="chevron">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" style="width:10px">
                            <path d="M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"/>
                        </svg>
                    </div>
                </div>
            </div>
        `;
    }
    renderFlexible() {
        return html `<div id="elEditor" style="width:100%; height:100%"></div>`;
    }
    renderResults() {
        if (!this.step)
            return html `Not found step`;
        const nextOptions = [
            ...(this.step.interaction?.payload ?? []),
            ...(this.step.nextSteps ?? []),
        ];
        return html `
            <ul>
                ${nextOptions.length === 0
            ? html `<li><em>Not next step</em></li>`
            : nextOptions.map((ns) => html `<li>[${ns.stepId}] ${ns.type} - ${ns.agentName}</li>`)}
            </ul>
        `;
    }
};
__decorate([
    state()
], CollabMessagesTaskPreviewRaw.prototype, "mode", void 0);
__decorate([
    property({ type: Object })
], CollabMessagesTaskPreviewRaw.prototype, "message", void 0);
__decorate([
    property({ type: Object })
], CollabMessagesTaskPreviewRaw.prototype, "task", void 0);
__decorate([
    property({ type: Object })
], CollabMessagesTaskPreviewRaw.prototype, "step", void 0);
__decorate([
    property({ type: String })
], CollabMessagesTaskPreviewRaw.prototype, "msize", void 0);
__decorate([
    query('#elEditor')
], CollabMessagesTaskPreviewRaw.prototype, "elEditor", void 0);
CollabMessagesTaskPreviewRaw = __decorate([
    customElement('collab-messages-task-preview-raw-102025')
], CollabMessagesTaskPreviewRaw);
export { CollabMessagesTaskPreviewRaw };
