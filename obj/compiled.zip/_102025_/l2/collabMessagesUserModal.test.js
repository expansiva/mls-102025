/// <mls fileReference="_102025_/l2/collabMessagesUserModal.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
