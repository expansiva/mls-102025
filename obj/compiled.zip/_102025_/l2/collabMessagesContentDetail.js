/// <mls fileReference="_102025_/l2/collabMessagesContentDetail.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { environment } from '/_102036_/l2/environmentContract.js';
import '/_102025_/l2/collabMessagesRichPreviewText.js';
let CollabMessagesContentDetail102025 = class CollabMessagesContentDetail102025 extends StateLitElement {
    constructor() {
        super(...arguments);
        // Not `title`: that is the native HTMLElement tooltip and would show over the whole panel.
        this.heading = '';
        this.text = '';
    }
    render() {
        return html `
            <div class="content-detail-title">${this.heading}</div>
            <collab-messages-rich-preview-text-102025
                .text=${this.text}
                .collapseCodeBlocks=${false}>
            </collab-messages-rich-preview-text-102025>
        `;
    }
};
__decorate([
    property({ type: String })
], CollabMessagesContentDetail102025.prototype, "heading", void 0);
__decorate([
    property({ type: String })
], CollabMessagesContentDetail102025.prototype, "text", void 0);
CollabMessagesContentDetail102025 = __decorate([
    customElement('collab-messages-content-detail-102025')
], CollabMessagesContentDetail102025);
export { CollabMessagesContentDetail102025 };
export function openContentInDetails(input) {
    const element = document.createElement('collab-messages-content-detail-102025');
    element.heading = input.title;
    element.text = input.text;
    return environment.details.openContent({ id: input.id, title: input.title, element });
}
