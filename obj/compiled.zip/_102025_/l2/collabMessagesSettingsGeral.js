/// <mls fileReference="_102025_/l2/collabMessagesSettingsGeral.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102025_/l2/collabMessagesSettingsOpenClaw.js';
import '/_102025_/l2/collabMessagesSettingsChatPreferences.js';
import '/_102025_/l2/collabMessagesSettingsUser.js';
import '/_102025_/l2/collabMessagesSettingsNotificationPreferences.js';
import { msgGetUserUpdate } from '/_102025_/l2/shared/api.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando informações...',
};
const message_en = {
    loading: 'Loading...',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesSettingsGeral102025 = class CollabMessagesSettingsGeral102025 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-settings-geral-102025 {
  display: block;
  overflow: auto;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-primary-color);
  background-color: var(--bg-primary-color);
  padding: 1rem;
  height: calc(100% - 41px);
  width: 375px;
}
collab-messages-settings-geral-102025 > section {
  margin-bottom: 1.25rem;
}
collab-messages-settings-geral-102025 > section.hidden {
  display: none;
}
`);
        this.msg = messages['en'];
        this.viewMode = 'all';
        this.scrollPositions = new Map();
    }
    show(section) {
        return this.viewMode === 'all' || this.viewMode === section;
    }
    async firstUpdated(changedProperties) {
        super.updated(changedProperties);
        this.userPerfil = await this.getUserPerfil();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.userPerfil) {
            return html `<div>${this.msg.loading}</div>`;
        }
        return html `
        <section style=${this.show('user') ? 'display:block' : 'display:none'}>
            ${this.renderUser()}
        </section>

        <section style=${this.show('chat') ? 'display:block' : 'display:none'}>
            ${this.renderChatPreferences()}
        </section>

        <section style=${this.show('notification') ? 'display:block' : 'display:none'}>
            ${this.renderPreferencesNotifications()}
        </section>

        <section style=${this.show('openclaw') ? 'display:block' : 'display:none'}>
            ${this.renderOpenClawConnectors()}
        </section>
    `;
    }
    renderUser() {
        return html `<collab-messages-settings-user-102025></collab-messages-settings-user-102025>`;
    }
    renderChatPreferences() {
        return html `<collab-messages-settings-chat-preferences-102025></collab-messages-settings-chat-preferences-102025>`;
    }
    renderPreferencesNotifications() {
        return html `<collab-messages-settings-notification-preferences-102025></collab-messages-settings-notification-preferences-102025>`;
    }
    renderOpenClawConnectors() {
        return html `<collab-messages-settings-open-claw-102025
            @settings-change=${this.onSettingsChange}
            .userId=${this.userPerfil?.userId}
        ></collab-messages-settings-open-claw-102025>`;
    }
    onSettingsChange(ev) {
        const ev2 = ev;
        const details = ev2.detail;
        if (!details || details.mode !== 'view')
            return;
        this.navigateTo(details.viewMode);
    }
    async getUserPerfil() {
        try {
            const result = await msgGetUserUpdate({ userId: "" });
            if (!result.success || !result.response?.user) {
                throw new Error(result.error || 'Failed to fetch user profile');
            }
            return result.response.user;
        }
        catch (err) {
            throw new Error(err?.message || 'Unexpected error while fetching user profile');
        }
    }
    saveScrollPosition() {
        const container = this.renderRoot;
        if (container) {
            this.scrollPositions.set(this.viewMode, container.scrollTop);
        }
    }
    restoreScrollPosition(view) {
        const container = this.renderRoot;
        if (container) {
            const savedPosition = this.scrollPositions.get(view) || 0;
            requestAnimationFrame(() => {
                container.scrollTop = savedPosition;
            });
        }
    }
    navigateTo(newView, resetScroll = false) {
        this.saveScrollPosition();
        this.viewMode = newView;
        if (resetScroll) {
            requestAnimationFrame(() => {
                const container = this.renderRoot;
                if (container)
                    container.scrollTop = 0;
            });
        }
        else {
            this.restoreScrollPosition(newView);
        }
    }
};
__decorate([
    property()
], CollabMessagesSettingsGeral102025.prototype, "viewMode", void 0);
__decorate([
    state()
], CollabMessagesSettingsGeral102025.prototype, "userPerfil", void 0);
__decorate([
    state()
], CollabMessagesSettingsGeral102025.prototype, "scrollPositions", void 0);
CollabMessagesSettingsGeral102025 = __decorate([
    customElement('collab-messages-settings-geral-102025')
], CollabMessagesSettingsGeral102025);
export { CollabMessagesSettingsGeral102025 };
