/// <mls fileReference="_102025_/l2/collabMessagesTaskPreview.ts" enhancement="_102025_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { CollabLitElement } from '/_102027_/l2/collabLitElement.js';
import '/_102025_/l2/collabMessagesTaskPreviewAgent.js';
import '/_102025_/l2/collabMessagesTaskPreviewClarification.js';
import '/_102025_/l2/collabMessagesTaskPreviewFlexible.js';
import '/_102025_/l2/collabMessagesTaskPreviewTools.js';
import '/_102025_/l2/collabMessagesTaskPreviewResult.js';
import '/_102025_/l2/collabMessagesTaskPreviewRaw.js';
let CollabMessagesTaskPreview = class CollabMessagesTaskPreview extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.message = null;
        this.task = null;
        this.modeTest = false;
        this.initialStep = '';
        this.stepMap = new Map();
        this.navigationStack = [];
        this.currentStepId = null;
        this.allSteps = [];
        this.lastStepId = 0;
        this.tryNext = 0;
    }
    disconnectedCallback() {
        window.removeEventListener('task-change', this.onTaskChange.bind(this));
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (this.modeTest)
            return;
        this.init();
        window.addEventListener('task-change', this.onTaskChange.bind(this));
    }
    render() {
        if (!this.task) {
            return html `<p>Task not provided.</p>`;
        }
        return html `${this.renderStep()}`;
    }
    renderStep() {
        if (!this.task) {
            return html `<p>Task not provided.</p>`;
        }
        if (this.currentStepId === 0 || !this.currentStepId) {
            return html `
            ${this.renderNavigation(0)}
            <div class="container">
            ${this.renderStepDetails(undefined)}
            </div>
        `;
        }
        const step = this.stepMap.get(this.currentStepId);
        if (!step) {
            return html `<p>Step not found: ${this.currentStepId}</p>`;
        }
        return html `
            ${this.renderNavigation(step.stepId || 0)}
            <div class="container">
            ${this.renderStepDetails(step)}
            </div>
            ${this.renderBreadcrumb()}
        `;
    }
    renderNavigation(stepId) {
        const goToPrevious = () => {
            this.goBack();
        };
        const goToNext = () => {
            this.navigateToStep(stepId + 1);
        };
        const step = this.stepMap.get(stepId);
        const all = this.allSteps.length.toString().padStart(2, '0');
        let name = `00/${all}`;
        if (step)
            name = `${stepId.toString().padStart(2, '0')}/${all}`;
        return html `
            <div class="tabAction">
                <button @click=${goToPrevious} ><svg style="width:13px; fill:#fff; transform: rotateY(180deg);" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M438.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-160-160c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L338.8 224 32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l306.7 0L233.4 393.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l160-160z"/></svg></button>
                <span>${name}</span>
                <button @click=${goToNext} ><svg style="width:13px; fill:#fff" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M438.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-160-160c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L338.8 224 32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l306.7 0L233.4 393.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l160-160z"/></svg></button>
            </div>
        `;
    }
    renderStepDetails(step) {
        if (!step && this.currentStepId === 0) {
            return this.renderRaw();
        }
        if (!step) {
            return "Not found step";
        }
        switch (step.type) {
            case 'agent': return this.renderAgent(step);
            case 'clarification': return this.renderClarification(step);
            case 'flexible': return this.renderFlexible(step);
            case 'tool': return this.renderTools(step);
            case 'result': return this.renderResult(step);
            case 'dynamicWorkflow':
            case 'staticWorkflow': return this.renderWorkflow(step);
            default: return html `Not found type: renderStepDetails`;
        }
    }
    renderBreadcrumb() {
        return html `
            <nav class="breadcrumb">
                ${this.navigationStack.map((stepId, idx) => {
            const step = this.stepMap.get(stepId);
            if (!step) {
                return;
            }
            return html ` <span
                            @click=${() => {
                this.navigationStack = this.navigationStack.slice(0, idx + 1);
                this.currentStepId = stepId;
            }} >${step.agentName ? step.agentName : step.type}</span>
                            `;
        })}
            </nav>
        `;
    }
    renderRaw() {
        return html ` <collab-messages-task-preview-raw-102025  .message=${this.message} .task=${this.task}></collab-messages-task-preview-raw-102025> `;
    }
    renderAgent(step) {
        return html ` <collab-messages-task-preview-agent-102025 .step=${step} .message=${this.message} .task=${this.task} key="${step.stepId}"></collab-messages-task-preview-agent-102025> `;
    }
    renderClarification(step) {
        return html ` <collab-messages-task-preview-clarification-102025 .step=${step} .message=${this.message}  .task=${this.task} key="${step.stepId}"></collab-messages-task-preview-clarification-102025> `;
    }
    renderFlexible(step) {
        return html ` <collab-messages-task-preview-flexible-102025 .step=${step} .message=${this.message}  .task=${this.task} key="${step.stepId}"></collab-messages-task-preview-flexible-102025> `;
    }
    renderTools(step) {
        return html ` <collab-messages-task-preview-tools-102025 .step=${step} .message=${this.message}  .task=${this.task} key="${step.stepId}"></collab-messages-task-preview-tools-102025> `;
    }
    renderResult(step) {
        return html ` <collab-messages-task-preview-result-102025 .step=${step} .message=${this.message}  .task=${this.task} key="${step.stepId}"></collab-messages-task-preview-result-102025> `;
    }
    renderWorkflow(step) {
        return html `
            <div class="workflow-step">
                <div class="workflow-step-title">${step.workflowName || this.task?.title || 'Workflow'}</div>
                <div class="workflow-step-meta">
                    <span>Step ${step.stepId}</span>
                    <span>${step.type}</span>
                    <span>${step.status || 'pending'}</span>
                </div>
                <p>Messages and updates for this workflow are handled in the Chat tab.</p>
                ${step.nextSteps?.length
            ? html `<button @click=${() => this.navigateToStep(step.nextSteps?.[0]?.stepId)}>Open next step</button>`
            : html ``}
            </div>
        `;
    }
    //------IMPLEMENTATION--------
    init() {
        if (!this.task || !this.task.iaCompressed)
            return;
        this.stepMap.clear();
        this.buildStepMap(this.task.iaCompressed.nextSteps);
        //this.currentStepId = 0;
        this.navigationStack = [0];
        if (this.currentStepId && this.currentStepId > 0) {
            this.navigationStack = [];
            for (let i = 0; i <= this.currentStepId; i++) {
                this.navigationStack.push(i);
            }
        }
        this.allSteps = getAllSteps(this.task.iaCompressed.nextSteps);
        this.lastStepId = this.allSteps[this.allSteps.length - 1]?.stepId || 0;
    }
    onTaskChange(e) {
        if (!this.task)
            return;
        const customEvent = e;
        const task = customEvent.detail.context.task;
        if (task.PK !== this.task.PK)
            return;
        this.task = task;
        if (!this.task || !this.task.iaCompressed)
            return;
        this.stepMap.clear();
        this.buildStepMap(this.task.iaCompressed.nextSteps);
        this.allSteps = getAllSteps(this.task.iaCompressed.nextSteps);
    }
    buildStepMap(steps) {
        for (const step of steps) {
            this.stepMap.set(step.stepId, step);
            if (step.interaction?.payload) {
                this.buildStepMap(step.interaction.payload);
            }
            if (step.nextSteps) {
                this.buildStepMap(step.nextSteps);
            }
        }
    }
    navigateToStep(stepId) {
        if (!this.stepMap.has(stepId)) {
            if (stepId < this.lastStepId && this.tryNext < 200) {
                this.tryNext++;
                this.navigateToStep(stepId + 1);
            }
            return;
        }
        this.tryNext = 0;
        this.currentStepId = stepId;
        if (this.father)
            this.father.currentStepId = this.currentStepId;
        this.navigationStack = [...this.navigationStack, stepId];
    }
    goBack() {
        if (this.navigationStack.length > 1) {
            this.navigationStack.pop();
            this.currentStepId = this.navigationStack[this.navigationStack.length - 1];
            if (!this.stepMap.has(this.currentStepId)) {
                this.goBack();
            }
        }
        else {
            this.currentStepId = 0;
        }
    }
};
__decorate([
    property({ type: Object })
], CollabMessagesTaskPreview.prototype, "message", void 0);
__decorate([
    property({ type: Object })
], CollabMessagesTaskPreview.prototype, "task", void 0);
__decorate([
    property()
], CollabMessagesTaskPreview.prototype, "modeTest", void 0);
__decorate([
    property()
], CollabMessagesTaskPreview.prototype, "father", void 0);
__decorate([
    property()
], CollabMessagesTaskPreview.prototype, "initialStep", void 0);
__decorate([
    state()
], CollabMessagesTaskPreview.prototype, "stepMap", void 0);
__decorate([
    state()
], CollabMessagesTaskPreview.prototype, "navigationStack", void 0);
__decorate([
    state()
], CollabMessagesTaskPreview.prototype, "currentStepId", void 0);
__decorate([
    state()
], CollabMessagesTaskPreview.prototype, "allSteps", void 0);
CollabMessagesTaskPreview = __decorate([
    customElement('collab-messages-task-preview-102025')
], CollabMessagesTaskPreview);
export { CollabMessagesTaskPreview };
