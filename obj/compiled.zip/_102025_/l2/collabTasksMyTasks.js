/// <mls fileReference="_102025_/l2/collabTasksMyTasks.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    title: 'Meus processos',
    subtitle: 'tarefas atribuídas a mim',
    active: 'Em andamento',
    closed: 'Concluídos',
    emptyTitle: 'Sem tarefas atribuídas.',
    emptySubtitle: 'Tarefas de workflow aparecerão aqui quando atribuídas a você.',
    loadError: 'Não consegui carregar as tarefas.',
    retry: 'Tentar de novo',
    reload: 'Recarregar',
    todo: 'A fazer',
    inProgress: 'Em andamento',
    paused: 'Pausado',
    done: 'Concluído',
    failed: 'Falhou',
    priorityLow: 'baixa',
    priorityNormal: 'normal',
    priorityHigh: 'alta',
    priorityUrgent: 'urgente',
    noDueDate: 'sem prazo',
    today: 'hoje',
    tomorrow: 'amanhã',
    overdue: 'atrasado',
    noWorkflow: 'sem workflow',
    openTask: 'Abrir task',
};
const message_en = {
    title: 'My tasks',
    subtitle: 'tasks assigned to me',
    active: 'Active',
    closed: 'Closed',
    emptyTitle: 'No tasks assigned.',
    emptySubtitle: 'Workflow tasks will appear here when assigned to you.',
    loadError: 'Could not load tasks.',
    retry: 'Retry',
    reload: 'Reload',
    todo: 'To do',
    inProgress: 'In progress',
    paused: 'Paused',
    done: 'Done',
    failed: 'Failed',
    priorityLow: 'low',
    priorityNormal: 'normal',
    priorityHigh: 'high',
    priorityUrgent: 'urgent',
    noDueDate: 'no due date',
    today: 'today',
    tomorrow: 'tomorrow',
    overdue: 'overdue',
    noWorkflow: 'no workflow',
    openTask: 'Open task',
};
/// **collab_i18n_end**
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { msgListTasks } from '/_102025_/l2/shared/api.js';
import { openElementInServiceDetails } from '/_102027_/l2/libCommom.js';
import { getUserId } from '/_102025_/l2/collabMessagesHelper.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
// ── Priority order ──────────────────────────────────────────────────────────
const PRIORITY_ORDER = {
    urgent: 0, high: 1, normal: 2, low: 3,
};
const STATUS_ORDER = {
    'in progress': 0, 'todo': 1, 'paused': 2, 'done': 3, 'failed': 4,
};
function sortActive(tasks) {
    return [...tasks].sort((a, b) => {
        const pA = PRIORITY_ORDER[a.priority ?? 'normal'] ?? 2;
        const pB = PRIORITY_ORDER[b.priority ?? 'normal'] ?? 2;
        if (pA !== pB)
            return pA - pB;
        const sA = STATUS_ORDER[a.status] ?? 9;
        const sB = STATUS_ORDER[b.status] ?? 9;
        if (sA !== sB)
            return sA - sB;
        return (b.last_updated ?? 0) - (a.last_updated ?? 0);
    });
}
function dueDateLabel(dueDate, m) {
    if (!dueDate)
        return '';
    const now = new Date();
    const due = new Date(dueDate + 'T00:00:00');
    const todayStr = now.toISOString().slice(0, 10);
    const tomorrowDate = new Date(now);
    tomorrowDate.setDate(tomorrowDate.getDate() + 1);
    const tomorrowStr = tomorrowDate.toISOString().slice(0, 10);
    if (dueDate === todayStr)
        return m.today;
    if (dueDate === tomorrowStr)
        return m.tomorrow;
    if (due < now)
        return m.overdue;
    return dueDate;
}
function isOverdue(dueDate) {
    if (!dueDate)
        return false;
    return new Date(dueDate + 'T23:59:59') < new Date();
}
let CollabTasksMyTasks = class CollabTasksMyTasks extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-tasks-my-tasks-102025 {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
}
collab-tasks-my-tasks-102025 .mytasks-header {
  display: flex;
  align-items: center;
  height: 44px;
  padding: 0 16px;
  gap: 8px;
  flex-shrink: 0;
  background: var(--color-background-primary, #ffffff);
  border-bottom: 0.5px solid var(--color-border-tertiary, rgba(0, 0, 0, 0.08));
}
collab-tasks-my-tasks-102025 .mytasks-header-left {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: 1;
  min-width: 0;
}
collab-tasks-my-tasks-102025 .mytasks-title {
  font-size: 14px;
  font-weight: 500;
  color: var(--color-text-primary, #1a1a18);
  white-space: nowrap;
}
collab-tasks-my-tasks-102025 .mytasks-sep {
  font-size: 13px;
  color: var(--color-text-tertiary, #888780);
}
collab-tasks-my-tasks-102025 .mytasks-sub {
  font-size: 12px;
  color: var(--color-text-tertiary, #888780);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
collab-tasks-my-tasks-102025 .mytasks-header-right {
  flex-shrink: 0;
}
collab-tasks-my-tasks-102025 .mytasks-icon-btn {
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: none;
  border: 0.5px solid transparent;
  border-radius: 7px;
  cursor: pointer;
  color: var(--color-text-tertiary, #888780);
  transition: background 0.12s, border-color 0.12s, color 0.12s;
}
collab-tasks-my-tasks-102025 .mytasks-icon-btn:hover {
  background: var(--color-background-secondary, #f5f4f0);
  border-color: var(--color-border-tertiary, rgba(0, 0, 0, 0.08));
  color: var(--color-text-secondary, #5f5e5a);
}
collab-tasks-my-tasks-102025 .mytasks-body {
  flex: 1;
  overflow-y: auto;
  padding: 14px 16px;
  display: flex;
  flex-direction: column;
  gap: 0;
}
collab-tasks-my-tasks-102025 .mytasks-error {
  background: var(--color-background-danger, #fcebeb);
  color: var(--color-text-danger, #a32d2d);
  border-radius: 8px;
  padding: 10px 14px;
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 13px;
  margin-bottom: 12px;
}
collab-tasks-my-tasks-102025 .mytasks-error button {
  background: none;
  border: none;
  cursor: pointer;
  color: inherit;
  text-decoration: underline;
  font-size: 13px;
  padding: 0;
}
collab-tasks-my-tasks-102025 .mytasks-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 48px 24px;
  text-align: center;
  color: var(--color-text-tertiary, #888780);
}
collab-tasks-my-tasks-102025 .mytasks-empty .empty-icon {
  color: var(--color-text-tertiary, #888780);
  margin-bottom: 4px;
}
collab-tasks-my-tasks-102025 .mytasks-empty .empty-title {
  font-size: 14px;
  font-weight: 500;
  color: var(--color-text-secondary, #5f5e5a);
}
collab-tasks-my-tasks-102025 .mytasks-empty .empty-sub {
  font-size: 12px;
  max-width: 280px;
  line-height: 1.5;
}
collab-tasks-my-tasks-102025 .mytasks-section-label {
  font-size: 10px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--color-text-tertiary, #888780);
  padding: 0 2px 7px;
  display: flex;
  align-items: center;
  gap: 6px;
}
collab-tasks-my-tasks-102025 .mytasks-section-label:not(:first-child) {
  padding-top: 16px;
}
collab-tasks-my-tasks-102025 .mytasks-section-label.closed-toggle {
  cursor: pointer;
  user-select: none;
}
collab-tasks-my-tasks-102025 .mytasks-section-label.closed-toggle:hover {
  color: var(--color-text-secondary, #5f5e5a);
}
collab-tasks-my-tasks-102025 .mytasks-section-label .toggle-chevron {
  transition: transform 0.15s ease;
}
collab-tasks-my-tasks-102025 .mytasks-section-label .toggle-chevron.open {
  transform: rotate(180deg);
}
collab-tasks-my-tasks-102025 .section-count {
  font-size: 10px;
  font-weight: 500;
  padding: 1px 5px;
  border-radius: 8px;
  background: var(--color-background-secondary, #f5f4f0);
  color: var(--color-text-tertiary, #888780);
  text-transform: none;
  letter-spacing: 0;
}
collab-tasks-my-tasks-102025 .mytasks-list {
  display: flex;
  flex-direction: column;
  gap: 0;
}
collab-tasks-my-tasks-102025 .mytasks-list.closed {
  opacity: 0.75;
}
collab-tasks-my-tasks-102025 .task-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 10px;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.1s;
  outline: none;
  position: relative;
}
collab-tasks-my-tasks-102025 .task-row + .task-row::before {
  content: '';
  position: absolute;
  top: 0;
  left: 44px;
  right: 10px;
  height: 0.5px;
  background: var(--color-border-tertiary, rgba(0, 0, 0, 0.06));
}
collab-tasks-my-tasks-102025 .task-row:hover {
  background: var(--color-background-secondary, #f5f4f0);
}
collab-tasks-my-tasks-102025 .task-row:focus-visible {
  outline: 2px solid var(--color-text-info, #185fa5);
  outline-offset: -2px;
  border-radius: 8px;
}
collab-tasks-my-tasks-102025 .task-row.is-closed .task-title {
  text-decoration: line-through;
  color: var(--color-text-tertiary, #888780);
}
collab-tasks-my-tasks-102025 .task-check {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  flex-shrink: 0;
  border: 1.5px solid var(--color-border-secondary, rgba(0, 0, 0, 0.18));
  display: flex;
  align-items: center;
  justify-content: center;
  background: transparent;
  transition: border-color 0.12s, background 0.12s;
}
collab-tasks-my-tasks-102025 .task-check.status-in-progress {
  border-color: #854f0b;
  background: #faeeda;
  color: #854f0b;
  background: conic-gradient(#854f0b 50%, #faeeda 50%);
  box-shadow: inset 0 0 0 3px var(--color-background-primary, #fff);
}
collab-tasks-my-tasks-102025 .task-check.status-todo {
  border-color: var(--color-border-secondary, rgba(0, 0, 0, 0.22));
}
collab-tasks-my-tasks-102025 .task-check.status-paused {
  border-color: #6b7280;
  background: #f3f4f6;
  color: #6b7280;
}
collab-tasks-my-tasks-102025 .task-check.status-done {
  border-color: #3b6d11;
  background: #eaf3de;
  color: #3b6d11;
}
collab-tasks-my-tasks-102025 .task-check.status-failed {
  border-color: #a32d2d;
  background: #fcebeb;
  color: #a32d2d;
}
collab-tasks-my-tasks-102025 .task-info {
  flex: 1;
  min-width: 0;
}
collab-tasks-my-tasks-102025 .task-title {
  font-size: 13px;
  font-weight: 500;
  color: var(--color-text-primary, #1a1a18);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  margin-bottom: 2px;
  line-height: 1.35;
}
collab-tasks-my-tasks-102025 .task-meta {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-wrap: nowrap;
  overflow: hidden;
}
collab-tasks-my-tasks-102025 .status-pill {
  font-size: 10px;
  font-weight: 500;
  white-space: nowrap;
  color: var(--color-text-tertiary, #888780);
}
collab-tasks-my-tasks-102025 .status-pill.status-in-progress {
  color: #854f0b;
}
collab-tasks-my-tasks-102025 .status-pill.status-done {
  color: #3b6d11;
}
collab-tasks-my-tasks-102025 .status-pill.status-failed {
  color: #a32d2d;
}
collab-tasks-my-tasks-102025 .status-pill.status-paused {
  color: #6b7280;
}
collab-tasks-my-tasks-102025 .meta-sep {
  font-size: 10px;
  color: var(--color-text-tertiary, rgba(0, 0, 0, 0.25));
  flex-shrink: 0;
}
collab-tasks-my-tasks-102025 .pma-ref {
  font-size: 10px;
  color: var(--color-text-tertiary, #888780);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
collab-tasks-my-tasks-102025 .tag-chip {
  font-size: 9px;
  font-weight: 500;
  padding: 1px 5px;
  border-radius: 6px;
  background: var(--color-background-secondary, #f5f4f0);
  color: var(--color-text-tertiary, #888780);
  white-space: nowrap;
}
collab-tasks-my-tasks-102025 .task-right {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 3px;
  flex-shrink: 0;
}
collab-tasks-my-tasks-102025 .priority-badge {
  font-size: 9px;
  font-weight: 500;
  padding: 2px 6px;
  border-radius: 7px;
  white-space: nowrap;
}
collab-tasks-my-tasks-102025 .priority-badge.priority-urgent {
  background: #fcebeb;
  color: #a32d2d;
}
collab-tasks-my-tasks-102025 .priority-badge.priority-high {
  background: #faeeda;
  color: #854f0b;
}
collab-tasks-my-tasks-102025 .priority-badge.priority-normal {
  background: var(--color-background-secondary, #f5f4f0);
  color: var(--color-text-tertiary, #888780);
}
collab-tasks-my-tasks-102025 .priority-badge.priority-low {
  background: var(--color-background-secondary, #f5f4f0);
  color: var(--color-text-tertiary, #888780);
  opacity: 0.7;
}
collab-tasks-my-tasks-102025 .due-label {
  font-size: 10px;
  color: var(--color-text-tertiary, #888780);
  white-space: nowrap;
}
collab-tasks-my-tasks-102025 .due-label.overdue {
  color: #a32d2d;
  font-weight: 500;
}
collab-tasks-my-tasks-102025 .mytasks-loading-closed {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 16px;
  opacity: 0.4;
}
@keyframes dot-pulse {
  0%,
  80%,
  100% {
    transform: scale(0.6);
    opacity: 0.4;
  }
  40% {
    transform: scale(1);
    opacity: 1;
  }
}
collab-tasks-my-tasks-102025 .loading-dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--color-text-tertiary, #888780);
  animation: dot-pulse 1.2s ease-in-out infinite;
}
collab-tasks-my-tasks-102025 .loading-dot:nth-child(2) {
  animation-delay: 0.2s;
}
collab-tasks-my-tasks-102025 .loading-dot:nth-child(3) {
  animation-delay: 0.4s;
}
@keyframes shimmer {
  0% {
    background-position: -200% 0;
  }
  100% {
    background-position: 200% 0;
  }
}
@keyframes skeleton-fade {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
collab-tasks-my-tasks-102025 .task-row-skeleton {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 10px;
  animation: skeleton-fade 200ms ease-out both;
}
collab-tasks-my-tasks-102025 .skel {
  border-radius: 4px;
  background: linear-gradient(90deg, var(--color-background-secondary, #eceae3) 0%, rgba(255, 255, 255, 0.22) 50%, var(--color-background-secondary, #eceae3) 100%);
  background-size: 200% 100%;
  animation: shimmer 1.4s ease-in-out infinite;
}
collab-tasks-my-tasks-102025 .skel-check {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  flex-shrink: 0;
}
collab-tasks-my-tasks-102025 .skel-body {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 5px;
}
collab-tasks-my-tasks-102025 .skel-title {
  height: 12px;
}
collab-tasks-my-tasks-102025 .skel-meta {
  height: 9px;
}
collab-tasks-my-tasks-102025 .skel-badge {
  width: 36px;
  height: 16px;
  border-radius: 7px;
  flex-shrink: 0;
}
@media (prefers-reduced-motion: reduce) {
  collab-tasks-my-tasks-102025 .skel {
    animation: none;
  }
  collab-tasks-my-tasks-102025 .loading-dot {
    animation: none;
  }
  collab-tasks-my-tasks-102025 .toggle-chevron {
    transition: none;
  }
}
`);
        this.userId = '';
        this.activeTasks = [];
        this.closedTasks = [];
        this.loadingActive = true;
        this.loadingClosed = true;
        this.error = null;
        this.showClosed = false;
        this._refetchTimer = null;
    }
    connectedCallback() {
        super.connectedCallback();
        if (!this.userId)
            this.userId = getUserId() || '';
        this._onTaskChange = (e) => this._handleTaskChange(e);
        this._onTaskMetaChanged = (e) => this._handleTaskMetaChanged(e);
        const w = window?.top ?? window;
        w.addEventListener('task-change', this._onTaskChange);
        w.addEventListener('task-meta-changed', this._onTaskMetaChanged);
        this._fetchAll();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        const w = window?.top ?? window;
        w.removeEventListener('task-change', this._onTaskChange);
        w.removeEventListener('task-meta-changed', this._onTaskMetaChanged);
        if (this._refetchTimer)
            clearTimeout(this._refetchTimer);
    }
    async _fetchAll() {
        this.loadingActive = true;
        this.loadingClosed = true;
        this.error = null;
        try {
            const activeResult = await msgListTasks({ userId: this.userId, view: 'active', pageSize: 200 });
            if (!activeResult.success) {
                this.error = activeResult.error ?? 'error';
                this.loadingActive = false;
                this.loadingClosed = false;
                return;
            }
            this.activeTasks = sortActive(activeResult.response?.tasks ?? []);
            this.loadingActive = false;
            this._fetchClosed();
        }
        catch (err) {
            this.error = err?.message ?? 'error';
            this.loadingActive = false;
            this.loadingClosed = false;
        }
    }
    async _fetchClosed() {
        this.loadingClosed = true;
        try {
            const result = await msgListTasks({ userId: this.userId, view: 'closed', pageSize: 50 });
            if (result.success) {
                this.closedTasks = (result.response?.tasks ?? []).sort((a, b) => (b.last_updated ?? 0) - (a.last_updated ?? 0));
            }
        }
        catch { /* silent */ }
        this.loadingClosed = false;
    }
    _scheduleRefetch() {
        if (this._refetchTimer)
            clearTimeout(this._refetchTimer);
        this._refetchTimer = setTimeout(() => this._fetchAll(), 300);
    }
    _handleTaskChange(e) {
        const task = e.detail?.context?.task;
        if (!task) {
            this._scheduleRefetch();
            return;
        }
        const isClosed = task.status === 'done' || task.status === 'failed';
        const activeIdx = this.activeTasks.findIndex(t => t.PK === task.PK);
        const closedIdx = this.closedTasks.findIndex(t => t.PK === task.PK);
        if (activeIdx >= 0) {
            if (isClosed) {
                const updated = this.activeTasks.filter(t => t.PK !== task.PK);
                this.activeTasks = sortActive(updated);
                this.closedTasks = [task, ...this.closedTasks];
            }
            else {
                const updated = [...this.activeTasks];
                updated[activeIdx] = task;
                this.activeTasks = sortActive(updated);
            }
        }
        else if (closedIdx >= 0) {
            const updated = [...this.closedTasks];
            updated[closedIdx] = task;
            this.closedTasks = updated;
        }
        else {
            this._scheduleRefetch();
        }
    }
    _handleTaskMetaChanged(e) {
        const { taskId, taskTitle } = e.detail;
        const pk = `task/#${taskId}`;
        const activeIdx = this.activeTasks.findIndex(t => t.PK === pk);
        if (activeIdx >= 0) {
            const updated = [...this.activeTasks];
            updated[activeIdx] = { ...updated[activeIdx], title: taskTitle };
            this.activeTasks = updated;
            return;
        }
        const closedIdx = this.closedTasks.findIndex(t => t.PK === pk);
        if (closedIdx >= 0) {
            const updated = [...this.closedTasks];
            updated[closedIdx] = { ...updated[closedIdx], title: taskTitle };
            this.closedTasks = updated;
        }
    }
    async _openTask(task) {
        await import('/_102025_/l2/collabMessagesTaskRoom.js');
        const room = document.createElement('collab-messages-task-room-102025');
        room.task = task;
        room.userId = this.userId;
        openElementInServiceDetails(room);
    }
    render() {
        const m = getMsg();
        return html `
      <div class="mytasks-header">
        <div class="mytasks-header-left">
          <span class="mytasks-title">${m.title}</span>
          <span class="mytasks-sep">·</span>
          <span class="mytasks-sub">${m.subtitle}</span>
        </div>
        <div class="mytasks-header-right">
          <button
            class="mytasks-icon-btn"
            title="${m.reload}"
            @click=${() => this._fetchAll()}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="23 4 23 10 17 10"></polyline>
              <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
            </svg>
          </button>
        </div>
      </div>

      <div class="mytasks-body">
        ${this.error && this.activeTasks.length === 0 ? html `
          <div class="mytasks-error">
            <span>${m.loadError}</span>
            <button @click=${() => this._fetchAll()}>${m.retry}</button>
          </div>
        ` : nothing}

        ${this.loadingActive
            ? this._renderSkeletons(4)
            : this.activeTasks.length === 0 && this.closedTasks.length === 0 && !this.loadingClosed
                ? html `
              <div class="mytasks-empty">
                <div class="empty-icon">
                  <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                    <circle cx="16" cy="16" r="14" stroke="currentColor" stroke-width="1.2" opacity=".3"/>
                    <path d="M11 16l3 3 7-7" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" opacity=".4"/>
                  </svg>
                </div>
                <div class="empty-title">${m.emptyTitle}</div>
                <div class="empty-sub">${m.emptySubtitle}</div>
              </div>
            `
                : html `
              ${this.activeTasks.length > 0 ? html `
                <div class="mytasks-section-label">${m.active} <span class="section-count">${this.activeTasks.length}</span></div>
                <div class="mytasks-list">
                  ${this.activeTasks.map(task => this._renderTaskRow(task, m))}
                </div>
              ` : nothing}

              ${!this.loadingClosed && this.closedTasks.length > 0 ? html `
                <div
                  class="mytasks-section-label closed-toggle"
                  @click=${() => { this.showClosed = !this.showClosed; }}
                >
                  <svg class="toggle-chevron ${this.showClosed ? 'open' : ''}"
                    width="12" height="12" viewBox="0 0 12 12" fill="none"
                    stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
                    <path d="M3 4.5l3 3 3-3"/>
                  </svg>
                  ${m.closed} <span class="section-count">${this.closedTasks.length}</span>
                </div>
                ${this.showClosed ? html `
                  <div class="mytasks-list closed">
                    ${this.closedTasks.map(task => this._renderTaskRow(task, m))}
                  </div>
                ` : nothing}
              ` : nothing}

              ${this.loadingClosed ? html `
                <div class="mytasks-loading-closed">
                  <div class="loading-dot"></div>
                  <div class="loading-dot"></div>
                  <div class="loading-dot"></div>
                </div>
              ` : nothing}
            `}
      </div>
    `;
    }
    _renderTaskRow(task, m) {
        const isClosed = task.status === 'done' || task.status === 'failed';
        const pmaId = task.taskRoom?.pmaId;
        const dueLabel = dueDateLabel(task.dueDate, m);
        const overdue = !isClosed && isOverdue(task.dueDate);
        const statusLabel = task.status === 'in progress'
            ? m.inProgress
            : m[task.status] ?? task.status;
        const priorityLabel = task.priority
            ? m[`priority${task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}`] ?? task.priority
            : null;
        return html `
      <div
        class="task-row ${isClosed ? 'is-closed' : ''} priority-${task.priority ?? 'normal'}"
        role="button"
        tabindex="0"
        title="${m.openTask}"
        @click=${() => this._openTask(task)}
        @keydown=${(e) => { if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this._openTask(task);
        } }}
      >
        <div class="task-check status-${task.status.replace(' ', '-')}">
          ${isClosed ? html `
            <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
              <path d="M2 5l2.5 2.5 3.5-4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          ` : nothing}
        </div>

        <div class="task-info">
          <div class="task-title">${task.title}</div>
          <div class="task-meta">
            <span class="status-pill status-${task.status.replace(' ', '-')}">${statusLabel}</span>
            ${pmaId ? html `<span class="meta-sep">·</span><span class="pma-ref">${pmaId}</span>` : nothing}
            ${task.tags?.[0] ? html `<span class="meta-sep">·</span><span class="tag-chip">${task.tags[0]}</span>` : nothing}
          </div>
        </div>

        <div class="task-right">
          ${priorityLabel && !isClosed ? html `
            <span class="priority-badge priority-${task.priority}">${priorityLabel}</span>
          ` : nothing}
          ${dueLabel ? html `
            <span class="due-label ${overdue ? 'overdue' : ''}">${dueLabel}</span>
          ` : nothing}
        </div>
      </div>
    `;
    }
    _renderSkeletons(count) {
        return html `
      <div class="mytasks-list">
        ${Array.from({ length: count }, (_, i) => html `
          <div class="task-row-skeleton" aria-hidden="true" style="animation-delay: ${i * 60}ms">
            <div class="skel skel-check"></div>
            <div class="skel-body">
              <div class="skel skel-title" style="width: ${55 + (i % 3) * 12}%"></div>
              <div class="skel skel-meta" style="width: ${30 + (i % 2) * 10}%"></div>
            </div>
            <div class="skel skel-badge"></div>
          </div>
        `)}
      </div>
    `;
    }
};
__decorate([
    property({ type: String })
], CollabTasksMyTasks.prototype, "userId", void 0);
__decorate([
    state()
], CollabTasksMyTasks.prototype, "activeTasks", void 0);
__decorate([
    state()
], CollabTasksMyTasks.prototype, "closedTasks", void 0);
__decorate([
    state()
], CollabTasksMyTasks.prototype, "loadingActive", void 0);
__decorate([
    state()
], CollabTasksMyTasks.prototype, "loadingClosed", void 0);
__decorate([
    state()
], CollabTasksMyTasks.prototype, "error", void 0);
__decorate([
    state()
], CollabTasksMyTasks.prototype, "showClosed", void 0);
CollabTasksMyTasks = __decorate([
    customElement('collab-tasks-my-tasks-102025')
], CollabTasksMyTasks);
export { CollabTasksMyTasks };
