/// <mls fileReference="_102025_/l2/collabMessagesChatWindow.ts" enhancement="_blank"/>
export function sliceWindowFromTarget(sorted, targetIndex, limit) {
    const startIndex = targetIndex >= 0 ? targetIndex : 0;
    return {
        messages: sorted.slice(startIndex, startIndex + limit),
        hasMoreAfter: sorted.length > startIndex + limit,
    };
}
export function pickMessagesAfter(all, lastOrderAt, loadedKeys, limit) {
    const newer = all
        .filter(message => (message.orderAt || message.createAt) > lastOrderAt)
        .filter(message => !loadedKeys.has(`${message.threadId}/${message.orderAt || message.createAt}`))
        .sort((a, b) => (a.orderAt || a.createAt).localeCompare(b.orderAt || b.createAt));
    return {
        messages: newer.slice(0, limit),
        hasMoreAfter: newer.length > limit,
    };
}
