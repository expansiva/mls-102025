var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102025_/l2/collabMessagesTaskLogPreview.ts" enhancement="_102027_/l2/enhancementLit" />
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { getRootAgent } from '/_102027_/l2/aiAgentHelper.js';
import { loadAgent } from '/_102027_/l2/aiAgentOrchestration.js';
import '/_102025_/l2/aiAgentDefaultFeedback.js';
let PluginTaskLogPreview102025 = class PluginTaskLogPreview102025 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-task-log-preview-102025 {
  display: block;
}
collab-messages-task-log-preview-102025 .task-feedback.workflow {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}
collab-messages-task-log-preview-102025 .workflow-step-row {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  gap: 0.75rem;
  align-items: center;
  width: 100%;
  border: 1px solid var(--grey-color);
  background: var(--bg-primary-color);
  color: var(--text-primary-color);
  border-radius: 4px;
  padding: 0.6rem 0.75rem;
  cursor: pointer;
  text-align: left;
}
collab-messages-task-log-preview-102025 .workflow-step-row:hover {
  background: var(--bg-secondary-color-lighter);
}
collab-messages-task-log-preview-102025 .workflow-step-row span {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
`);
        this.currentStepId = 0;
        this.task = undefined;
        this.message = undefined;
        this.onTaskChange = async (e) => {
            if (!this.task)
                return;
            const customEvent = e;
            const context = customEvent.detail.context;
            const message = context.message;
            const _task = context.task;
            if (this.task.PK !== _task.PK)
                return;
            this.task = _task;
            this.createFeedBack();
        };
    }
    async firstUpdated(changedProperties) {
        window.addEventListener('task-change', this.onTaskChange);
        //this.task = await getTask('20250917143000.1001');
        this.createFeedBack();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        window.removeEventListener('task-change', this.onTaskChange);
    }
    updated(changedProperties) {
        if (changedProperties.has('currentStepId')) {
            const oldValue = changedProperties.get('currentStepId');
            const newValue = +this.currentStepId;
            if (!this.father || newValue === 0)
                return;
            this.father.currentStepId = newValue;
            this.father.activeTab = 'step';
        }
    }
    render() {
        return html `
    <div>${this.template}</div>`;
    }
    async createFeedBack() {
        if (!this.task)
            return;
        const firstAgent = getRootAgent(this.task);
        if (!firstAgent)
            return;
        const agentName = firstAgent.agentName;
        const agent = await loadAgent(agentName);
        if (!agent || !agent.getFeedBack) {
            this.template = html `<ai-agent-default-feedback-102025 .task=${this.task} .message=${this.message} .father=${this}></ai-agent-default-feedback-102025>`;
            return;
        }
        const html2 = await agent.getFeedBack(this.task);
        this.template = html2;
    }
};
__decorate([
    state()
], PluginTaskLogPreview102025.prototype, "currentStepId", void 0);
__decorate([
    property()
], PluginTaskLogPreview102025.prototype, "task", void 0);
__decorate([
    property()
], PluginTaskLogPreview102025.prototype, "message", void 0);
__decorate([
    property()
], PluginTaskLogPreview102025.prototype, "father", void 0);
__decorate([
    state()
], PluginTaskLogPreview102025.prototype, "template", void 0);
PluginTaskLogPreview102025 = __decorate([
    customElement('collab-messages-task-log-preview-102025')
], PluginTaskLogPreview102025);
export { PluginTaskLogPreview102025 };
