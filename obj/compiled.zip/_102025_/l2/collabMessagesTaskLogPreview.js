/// <mls fileReference="_102025_/l2/collabMessagesTaskLogPreview.ts" enhancement="_102025_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { getRootAgent } from '/_102027_/l2/aiAgentHelper.js';
import { loadAgent } from '/_102027_/l2/aiAgentOrchestration.js';
let CollabMessagesTaskLogPreview102025 = class CollabMessagesTaskLogPreview102025 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.currentStepId = 0;
        this.task = undefined;
        this.message = undefined;
        this.onTaskChange = async (e) => {
            if (!this.task)
                return;
            const customEvent = e;
            const context = customEvent.detail.context;
            const message = context.message;
            const _task = context.task;
            if (this.task.PK !== _task.PK)
                return;
            this.task = _task;
            this.createFeedBack();
        };
    }
    async firstUpdated(changedProperties) {
        window.addEventListener('task-change', this.onTaskChange);
        //this.task = await getTask('20250917143000.1001');
        this.createFeedBack();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        window.removeEventListener('task-change', this.onTaskChange);
    }
    updated(changedProperties) {
        if (changedProperties.has('currentStepId')) {
            const oldValue = changedProperties.get('currentStepId');
            const newValue = +this.currentStepId;
            if (!this.father || newValue === 0)
                return;
            this.father.currentStepId = newValue;
            this.father.activeTab = 'step';
        }
    }
    render() {
        return html `
    <div>${this.template}</div>`;
    }
    async createFeedBack() {
        if (!this.task)
            return;
        const firstStep = this.task.iaCompressed?.nextSteps?.[0];
        if (firstStep && (firstStep.type === 'dynamicWorkflow' || firstStep.type === 'staticWorkflow')) {
            this.template = html `
        <div class="task-feedback workflow">
          <strong>${this.task.title || this.task.PK}</strong>
          <button class="workflow-step-row" @click=${() => this.currentStepId = firstStep.stepId}>
            <span>Step ${firstStep.stepId}</span>
            <span>${firstStep.workflowName || firstStep.type}</span>
            <span>${firstStep.status || this.task.status}</span>
          </button>
        </div>
      `;
            return;
        }
        const firstAgent = getRootAgent(this.task);
        if (!firstAgent)
            return;
        const agentName = firstAgent.agentName;
        const agent = await loadAgent(agentName);
        if (!agent || !agent.getFeedBack) {
            this.template = html `
        <div class="task-feedback">
          <strong>${this.task.title || this.task.PK}</strong>
          <p>${this.task.status}</p>
        </div>
      `;
            return;
        }
        const html2 = await agent.getFeedBack(this.task);
        this.template = html2;
    }
};
__decorate([
    state()
], CollabMessagesTaskLogPreview102025.prototype, "currentStepId", void 0);
__decorate([
    property()
], CollabMessagesTaskLogPreview102025.prototype, "task", void 0);
__decorate([
    property()
], CollabMessagesTaskLogPreview102025.prototype, "message", void 0);
__decorate([
    property()
], CollabMessagesTaskLogPreview102025.prototype, "father", void 0);
__decorate([
    state()
], CollabMessagesTaskLogPreview102025.prototype, "template", void 0);
CollabMessagesTaskLogPreview102025 = __decorate([
    customElement('collab-messages-task-log-preview-102025')
], CollabMessagesTaskLogPreview102025);
export { CollabMessagesTaskLogPreview102025 };
