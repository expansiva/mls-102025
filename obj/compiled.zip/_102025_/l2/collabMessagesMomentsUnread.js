/// <mls fileReference="_102025_/l2/collabMessagesMomentsUnread.ts" enhancement="_blank"/>
import { getAllThreads } from '/_102036_/l2/collabMessagesIndexedDB.js';
import { hasThreadNotificationPending, markThreadReadLocally } from '/_102025_/l2/collabMessagesSyncNotifications.js';
export const OPEN_TAB_EVENT = 'collab-messages-open-tab';
export function isUnreadMomentsThread(thread, isPending) {
    if (thread.group !== 'MOMENTS')
        return false;
    return (thread.unreadCount ?? 0) > 0 || isPending(thread.threadId);
}
export async function hasUnreadMoments() {
    const threads = await getAllThreads();
    return threads.some((thread) => isUnreadMomentsThread(thread, hasThreadNotificationPending));
}
export async function markMomentsSeen() {
    try {
        const threads = await getAllThreads();
        for (const thread of threads) {
            if (!isUnreadMomentsThread(thread, hasThreadNotificationPending))
                continue;
            try {
                await markThreadReadLocally(thread.threadId);
            }
            catch (error) {
                console.error(error);
            }
        }
    }
    catch (error) {
        console.error(error);
    }
}
export function requestOpenTab(tab) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent(OPEN_TAB_EVENT, {
        detail: { tab },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
