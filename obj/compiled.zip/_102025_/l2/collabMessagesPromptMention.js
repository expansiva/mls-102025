/// <mls fileReference="_102025_/l2/collabMessagesPromptMention.ts" enhancement="_blank" />
/**
 * The list of an `@`: first the people of the conversation, then the virtual employees that can be called, each one once (a callable
 * that is already among the people is not repeated). The typed text filters both, by the start of the name, in any case.
 */
export function buildUserSuggestions(people, callable, query) {
    const wanted = query.toLowerCase();
    const matches = (user) => user.name.toLowerCase().startsWith(wanted);
    const seen = new Set();
    const result = [];
    for (const user of people) {
        if (!matches(user))
            continue;
        seen.add(user.userId);
        result.push({ userId: user.userId, name: user.name, avatar_url: user.avatar_url, callable: false });
    }
    for (const user of callable) {
        if (seen.has(user.userId) || !matches(user))
            continue;
        seen.add(user.userId);
        result.push({ userId: user.userId, name: user.name, avatar_url: user.avatar_url, callable: true });
    }
    return result;
}
