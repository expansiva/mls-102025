/// <mls fileReference="_102025_/l2/collabMessagesModuleStepper.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { getUser } from '/_102025_/l2/collabMessagesIndexedDB.js';
/// **collab_i18n_start**
const message_en = {
    completed: 'Completed',
    inProgress: 'Current',
    pending: 'Upcoming',
    actor: 'Actor',
    passes: 'passes',
    noStages: 'No process stages.',
};
const message_pt = {
    completed: 'Concluída',
    inProgress: 'Atual',
    pending: 'Futura',
    actor: 'Ator',
    passes: 'passagens',
    noStages: 'Sem etapas do processo.',
};
const messages = { en: message_en, pt: message_pt };
let CollabMessagesModuleStepper = class CollabMessagesModuleStepper extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-module-stepper-102025 {
  display: block;
  width: 100%;
  box-sizing: border-box;
  font-family: var(--font-family-primary);
  color: var(--text-default);
}
collab-messages-module-stepper-102025 .stepper-empty {
  padding: 0.5rem 0;
  color: var(--text-default-disabled);
  font-size: 0.9rem;
}
collab-messages-module-stepper-102025 .stepper {
  list-style: none;
  margin: 0;
  padding: 0.25rem 0 0.75rem;
}
collab-messages-module-stepper-102025 .stepper.horizontal {
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  overflow-x: auto;
  gap: 0;
}
collab-messages-module-stepper-102025 .stepper.vertical {
  display: flex;
  flex-direction: column;
  align-items: stretch;
}
collab-messages-module-stepper-102025 .stage {
  display: flex;
  flex-direction: column;
  align-items: center;
  min-width: 7rem;
  max-width: 11rem;
  cursor: pointer;
  flex: 0 0 auto;
  gap: 0.25rem;
  color: var(--text-default-disabled);
}
collab-messages-module-stepper-102025 .stepper.vertical .stage {
  flex-direction: row;
  align-items: center;
  min-width: 0;
  max-width: none;
  gap: 0.75rem;
  padding: 0.35rem 0;
}
collab-messages-module-stepper-102025 .mark {
  width: 1.75rem;
  height: 1.75rem;
  border-radius: 50%;
  border: 2px solid var(--border-default);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 0.8rem;
  font-weight: 600;
  background: var(--surface-bg);
  flex-shrink: 0;
}
collab-messages-module-stepper-102025 .body {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  gap: 0.1rem;
  font-size: 0.8rem;
  line-height: 1.3;
  min-width: 0;
  max-width: 100%;
}
collab-messages-module-stepper-102025 .stepper.horizontal .stage {
  width: 11rem;
  overflow: hidden;
}
collab-messages-module-stepper-102025 .stepper.horizontal .body {
  width: 100%;
  align-items: stretch;
}
collab-messages-module-stepper-102025 .stepper.horizontal .title,
collab-messages-module-stepper-102025 .stepper.horizontal .actor {
  display: block;
  width: 100%;
  box-sizing: border-box;
}
collab-messages-module-stepper-102025 .stepper.vertical .body {
  align-items: flex-start;
  text-align: left;
  flex: 1 1 auto;
}
collab-messages-module-stepper-102025 .title {
  font-weight: 600;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
collab-messages-module-stepper-102025 .stepper.vertical .title {
  white-space: normal;
  overflow: visible;
  overflow-wrap: anywhere;
}
collab-messages-module-stepper-102025 .actor {
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
collab-messages-module-stepper-102025 .stepper.vertical .actor {
  white-space: normal;
  overflow: visible;
  overflow-wrap: anywhere;
}
collab-messages-module-stepper-102025 .actor,
collab-messages-module-stepper-102025 .passes {
  font-size: 0.75rem;
  font-weight: 400;
}
collab-messages-module-stepper-102025 .stage.pending .title {
  font-weight: 400;
}
collab-messages-module-stepper-102025 .stage.in_progress {
  color: var(--text-muted-focus);
}
collab-messages-module-stepper-102025 .stage.in_progress .mark {
  border-color: var(--link-text);
  background: var(--link-text);
  color: var(--surface-bg);
}
collab-messages-module-stepper-102025 .stage.completed {
  color: var(--text-default);
}
collab-messages-module-stepper-102025 .stage.completed .mark {
  border-color: var(--link-text);
  color: var(--link-text);
}
collab-messages-module-stepper-102025 .connector {
  flex: 1 1 1.5rem;
  min-width: 1.5rem;
  height: 2px;
  margin-top: 0.85rem;
  background: var(--border-default);
  align-self: flex-start;
}
collab-messages-module-stepper-102025 .stepper.vertical .connector {
  width: 2px;
  height: 0.75rem;
  min-width: 0;
  margin: 0 0 0 0.85rem;
  flex: 0 0 auto;
  align-self: stretch;
}
collab-messages-module-stepper-102025 .connector.completed,
collab-messages-module-stepper-102025 .connector.in_progress {
  background: var(--link-text);
}
`);
        this.task = undefined;
        this.vertical = false;
        this.actorNames = {};
        this.msg = messages.en;
        this.actorLoads = new Set();
    }
    connectedCallback() {
        super.connectedCallback();
        this.resizeObserver = new ResizeObserver((entries) => {
            const width = entries[0]?.contentRect.width ?? this.clientWidth;
            const next = width < 480;
            if (next !== this.vertical)
                this.vertical = next;
        });
        this.resizeObserver.observe(this);
    }
    disconnectedCallback() {
        this.resizeObserver?.disconnect();
        super.disconnectedCallback();
    }
    render() {
        this.msg = messages[this.getMessageKey(messages)];
        const stages = this.getStages();
        if (stages.length === 0) {
            return html `<div class="stepper-empty">${this.msg.noStages}</div>`;
        }
        return html `
            <ol class="stepper ${this.vertical ? 'vertical' : 'horizontal'}" role="list">
                ${stages.map((stage, index) => this.renderStage(stage, index, stages.length))}
            </ol>
        `;
    }
    getStages() {
        const root = this.task?.iaCompressed?.nextSteps?.[0];
        if (!root || root.type !== 'module')
            return [];
        const children = (root.nextSteps ?? []);
        return children.filter((step) => step.type === 'module');
    }
    renderStage(stage, index, total) {
        const title = stage.stepTitle || stage.module.key;
        const status = stage.status === 'completed' || stage.status === 'in_progress' ? stage.status : 'pending';
        const passes = stage.module.passes > 1
            ? html `<span class="passes" title="${this.msg.passes}">×${stage.module.passes}</span>`
            : html ``;
        const actorName = status === 'in_progress' ? this.actorName(stage.module.actorNow) : '';
        const actor = actorName
            ? html `<span class="actor">${this.msg.actor}: ${actorName}</span>`
            : html ``;
        const mark = status === 'completed' ? '✓' : String(index + 1);
        const statusLabel = status === 'completed'
            ? this.msg.completed
            : status === 'in_progress'
                ? this.msg.inProgress
                : this.msg.pending;
        return html `
            <li
                class="stage ${status}"
                role="listitem"
                title="${statusLabel}"
                @click=${() => this.selectStage(stage.stepId)}
            >
                <span class="mark" aria-hidden="true">${mark}</span>
                <span class="body">
                    <span class="title" title="${title}">${title}</span>
                    ${actor}
                    ${passes}
                </span>
            </li>
            ${index < total - 1 ? html `<li class="connector ${status}" aria-hidden="true"></li>` : html ``}
        `;
    }
    actorName(actorNow) {
        if (!actorNow)
            return '';
        const known = this.actorNames[actorNow];
        if (known !== undefined)
            return known;
        if (!this.actorLoads.has(actorNow)) {
            this.actorLoads.add(actorNow);
            getUser(actorNow).then((user) => {
                this.actorNames = { ...this.actorNames, [actorNow]: user?.name ?? '' };
            }).catch((err) => {
                console.error('Failed to read the stage actor from local users.', err);
                this.actorNames = { ...this.actorNames, [actorNow]: '' };
            });
        }
        return '';
    }
    selectStage(stepId) {
        this.dispatchEvent(new CustomEvent('step-select', {
            detail: stepId,
            bubbles: true,
            composed: true,
        }));
    }
};
__decorate([
    property({ attribute: false })
], CollabMessagesModuleStepper.prototype, "task", void 0);
__decorate([
    state()
], CollabMessagesModuleStepper.prototype, "vertical", void 0);
__decorate([
    state()
], CollabMessagesModuleStepper.prototype, "actorNames", void 0);
CollabMessagesModuleStepper = __decorate([
    customElement('collab-messages-module-stepper-102025')
], CollabMessagesModuleStepper);
export { CollabMessagesModuleStepper };
