/// <mls fileReference="_102025_/l2/agents/agentGenerateAvatarSvg.ts" enhancement="_blank" />
import { svg_agent } from '/_100554_/l2/aiAgentBase';
import { getPromptByHtml } from '/_100554_/l2/aiPrompts';
import { getAgentStepByAgentName, getNextInProgressStepByAgentName, updateStepStatus, updateTaskTitle, } from "/_100554_/l2/aiAgentHelper";
import { startNewAiTask, executeNextStep } from "/_100554_/l2/aiAgentOrchestration";
const agentName = "agentGenerateAvatarSvg";
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "Responsavel por criar svg avatar",
        visibility: "private",
        scope: [],
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        },
    };
}
;
const _beforePrompt = async (context) => {
    const taskTitle = "Creating";
    if (!context || !context.message)
        throw new Error("Invalid context");
    if (!context.task) {
        const inputs = await getPrompts(context.message.content);
        await startNewAiTask(agentName, taskTitle, context.message.content, context.message.threadId, context.message.senderId, inputs, context, _afterPrompt).catch((err) => {
            throw new Error(err.message);
        });
    }
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] afterPrompt: No pending interaction found.`);
    context = await updateStepStatus(context, step.stepId, "completed");
    if (!context.task)
        throw new Error("Invalid context task");
    context.task = await updateTaskTitle(context.task, "Svg created");
    await executeNextStep(context);
};
async function getPrompts(data) {
    const dataPrompt = {
        userPrompt: JSON.stringify(data)
    };
    const rc = await getPromptByHtml({ folder: 'agents', project: 102025, shortName: agentName, data: dataPrompt });
    return rc;
}
export function getPayload(context) {
    if (!context || !context.task)
        throw new Error(`[${agentName}] [getPayload] Invalid context`);
    const agentStep = getAgentStepByAgentName(context.task, agentName); // Only one agent execution must exist in this task
    if (!agentStep)
        throw new Error(`[${agentName}] [getPayload] no agent found`);
    const resultStep = agentStep.interaction?.payload?.[0];
    if (!resultStep || resultStep.type !== "flexible" || !resultStep.result)
        throw new Error(`[${agentName}] [getPayload] No step flexible found for this agent.`);
    let payload3 = resultStep.result;
    return payload3;
}
