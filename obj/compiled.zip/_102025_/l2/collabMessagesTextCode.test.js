/// <mls fileReference="_102025_/l2/collabMessagesTextCode.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
