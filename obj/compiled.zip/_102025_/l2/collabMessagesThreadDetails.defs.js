"use strict";
/// <mls shortName="collabMessagesThreadDetails" project="102025" enhancement="_blank" folder="" />
