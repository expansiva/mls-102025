/// <mls fileReference="_102025_/l2/collabMessagesSettingsUser.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { updateUsers } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { msgGetUserUpdate, msgUpdateUserDetails } from '/_102025_/l2/shared/api.js';
import { collab_user, collab_minus, collab_ban, collab_dot, collab_edit, collab_xmark, collab_floppy_disk, collab_check, collab_chevron_left, } from '/_102025_/l2/collabMessagesIcons.js';
/// **collab_i18n_start**
const message_pt = {
    userTitle: 'Usuário',
    save: 'Salvar',
    cancel: 'Cancelar',
    status: 'Status',
    userid: 'Id do usuário',
    username: 'Nome do usuário',
    errorUserName: 'Nome do usuário não pode ser vazio',
    successSavingUser: 'Perfil do usuário atualizado com sucesso',
    changeAvatar: 'Alterar',
    editAvatar: 'Editar Avatar',
    avatarUrl: 'URL do Avatar',
    avatarUrlPlaceholder: 'https://exemplo.com/imagem.png',
    invalidAvatarUrl: 'URL inválida ou imagem não encontrada',
};
const message_en = {
    userTitle: 'User',
    save: 'Save',
    cancel: 'Cancel',
    status: 'Status',
    userid: 'User Id',
    username: 'UserName',
    errorUserName: 'User name cannot be empty',
    successSavingUser: 'User profile updated successfully',
    changeAvatar: 'Change',
    editAvatar: 'Edit Avatar',
    avatarUrl: 'Avatar URL',
    avatarUrlPlaceholder: 'https://example.com/image.png',
    invalidAvatarUrl: 'Invalid URL or image not found',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
let CollabMessagesSettingsUser = class CollabMessagesSettingsUser extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-settings-user-102025 {
  display: block;
}
collab-messages-settings-user-102025 .section {
  padding: 1.4rem 0.75rem;
  border-radius: 10px;
  box-shadow: #e7e3e3 0px 1px 4px;
  background-color: var(--bg-primary-color-darker);
  margin-bottom: 1.5rem;
}
collab-messages-settings-user-102025 .section h4 {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  margin-bottom: 0.75rem;
  margin-block-start: 0;
  padding-bottom: 0.4rem;
  border-bottom: 1px solid #d2d2d2;
}
collab-messages-settings-user-102025 .section h4 svg {
  fill: currentColor;
  width: 20px;
  height: 20px;
}
collab-messages-settings-user-102025 .section .loader {
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid #ccc;
  border-top: 2px solid #333;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
collab-messages-settings-user-102025 .section .saving-ok {
  color: var(--success-color);
  font-size: var(--font-size-12);
}
collab-messages-settings-user-102025 .section .saving-error {
  color: var(--error-color);
  font-size: var(--font-size-12);
}
collab-messages-settings-user-102025 .section .form-actions {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: 0.75rem;
  margin-top: 1.5rem;
  padding-top: 1rem;
  border-top: 1px solid var(--grey-color);
}
collab-messages-settings-user-102025 .section input {
  display: flex;
  font-size: 1rem;
  line-height: 1.5;
  color: #000000;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  outline: none;
  max-height: 30px;
  height: 30px;
  padding: 0 0.5rem;
}
collab-messages-settings-user-102025 .section button {
  background-color: var(--info-color);
  box-shadow: 0px 1px 3px 0px var(--grey-color);
  flex-direction: row;
  justify-content: center;
  width: max-content;
  transition: height 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
  color: #ffffff;
  padding: 0.5rem 1rem;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: var(--font-size-12);
  font-weight: var(--font-weight-bold);
  display: flex;
  align-items: center;
  gap: 0.25rem;
  white-space: nowrap;
  flex-shrink: 0;
}
collab-messages-settings-user-102025 .section button svg {
  flex-shrink: 0;
  fill: currentColor;
}
collab-messages-settings-user-102025 .section button:hover {
  background-color: var(--info-color-hover);
}
collab-messages-settings-user-102025 .section button.btn-small {
  height: 32px;
  font-size: var(--font-size-12);
  padding: 0.25rem 0.5rem;
  display: inline-flex;
  align-items: center;
  gap: 0.3rem;
}
collab-messages-settings-user-102025 .section button.btn-small svg {
  width: 14px;
  height: 14px;
}
collab-messages-settings-user-102025 .section button.btn-secondary {
  background-color: var(--bg-secondary-color);
  color: var(--text-primary-color);
}
collab-messages-settings-user-102025 .section button.btn-secondary:hover {
  background-color: var(--bg-secondary-color-hover);
}
collab-messages-settings-user-102025 .section button.btn-link {
  border: none;
  background-color: transparent;
  color: var(--active-color);
  box-shadow: none;
  cursor: pointer;
}
collab-messages-settings-user-102025 .section button.btn-link:hover {
  text-decoration: underline;
}
collab-messages-settings-user-102025 .section button.btn-back {
  width: 32px;
  height: 32px;
  padding: 0.25rem;
  border-radius: 6px;
  background-color: transparent;
  color: var(--text-primary-color);
  box-shadow: none;
  margin-right: 0.5rem;
}
collab-messages-settings-user-102025 .section button.btn-back:hover {
  background-color: var(--bg-secondary-color);
}
collab-messages-settings-user-102025 .section button.btn-back svg {
  width: 20px;
  height: 20px;
}
collab-messages-settings-user-102025 .user .user-content {
  display: flex;
  gap: 1.5rem;
  align-items: flex-start;
}
@media (max-width: 768px) {
  collab-messages-settings-user-102025 .user .user-content {
    flex-direction: column;
    align-items: center;
  }
}
collab-messages-settings-user-102025 .user .avatar-section {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.75rem;
  flex-shrink: 0;
}
collab-messages-settings-user-102025 .user .avatar img {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid var(--grey-color);
}
collab-messages-settings-user-102025 .user .avatar .avatar-placeholder {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background-color: var(--grey-color);
  display: flex;
  align-items: center;
  justify-content: center;
  border: 2px solid var(--grey-color-dark);
}
collab-messages-settings-user-102025 .user .avatar .avatar-placeholder svg {
  width: 36px;
  height: 36px;
  color: var(--text-primary-color-lighter);
}
collab-messages-settings-user-102025 .user .user-info {
  flex: 1;
  min-width: 0;
  width: 100%;
}
@media (max-width: 768px) {
  collab-messages-settings-user-102025 .user .user-info {
    width: 100%;
  }
}
collab-messages-settings-user-102025 .user .user-info-item {
  margin-bottom: 1rem;
}
collab-messages-settings-user-102025 .user .user-info-item label {
  display: block;
  font-size: var(--font-size-12);
  color: var(--text-primary-color-lighter);
  margin-bottom: 0.25rem;
}
collab-messages-settings-user-102025 .user .user-info-item input {
  width: 100%;
  padding: 0.5rem;
  height: auto;
  max-height: none;
  box-sizing: border-box;
}
collab-messages-settings-user-102025 .user .user-info-item span {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: var(--font-size-16);
}
collab-messages-settings-user-102025 .user .user-info-item .user-id {
  font-family: monospace;
  font-size: var(--font-size-12);
  color: var(--text-primary-color-lighter);
  word-break: break-all;
}
collab-messages-settings-user-102025 .user .user-info-item.status .blocked svg {
  color: var(--error-color);
  fill: var(--error-color);
}
collab-messages-settings-user-102025 .user .user-info-item.status .active svg {
  color: var(--success-color);
  fill: var(--success-color);
}
collab-messages-settings-user-102025 .user .user-info-row {
  display: flex;
  flex-wrap: wrap;
}
collab-messages-settings-user-102025 .user .user-info-row .user-info-item {
  flex: 1;
  min-width: 120px;
}
collab-messages-settings-user-102025 .edit-avatar .avatar-edit-content {
  display: flex;
  align-items: flex-start;
  gap: 1.5rem;
}
@media (max-width: 544px) {
  collab-messages-settings-user-102025 .edit-avatar .avatar-edit-content {
    flex-direction: column;
    align-items: center;
  }
}
collab-messages-settings-user-102025 .edit-avatar .avatar-preview-small {
  flex-shrink: 0;
}
collab-messages-settings-user-102025 .edit-avatar .avatar-preview-small img {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid var(--grey-color);
}
collab-messages-settings-user-102025 .edit-avatar .avatar-preview-small .avatar-placeholder {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background-color: var(--grey-color);
  display: flex;
  align-items: center;
  justify-content: center;
  border: 2px solid var(--grey-color-dark);
}
collab-messages-settings-user-102025 .edit-avatar .avatar-preview-small .avatar-placeholder svg {
  width: 36px;
  height: 36px;
  color: var(--text-primary-color-lighter);
}
collab-messages-settings-user-102025 .edit-avatar .avatar-preview-small .avatar-loading {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background-color: var(--grey-color-light);
  display: flex;
  align-items: center;
  justify-content: center;
  border: 2px solid var(--grey-color);
}
collab-messages-settings-user-102025 .edit-avatar .avatar-url-field {
  flex: 1;
  min-width: 0;
}
@media (max-width: 544px) {
  collab-messages-settings-user-102025 .edit-avatar .avatar-url-field {
    width: 100%;
  }
}
collab-messages-settings-user-102025 .edit-avatar .avatar-url-field label {
  display: block;
  font-size: var(--font-size-12);
  color: var(--text-primary-color-lighter);
  margin-bottom: 0.25rem;
}
collab-messages-settings-user-102025 .edit-avatar .avatar-url-field input {
  width: 100%;
  padding: 0.5rem;
  height: auto;
  max-height: none;
  box-sizing: border-box;
}
collab-messages-settings-user-102025 .edit-avatar .avatar-url-field .saving-error {
  display: block;
  margin-top: 0.25rem;
}
`);
        this.msg = messages['en'];
        this.viewMode = 'main';
        this.isSaving = false;
        this.labelOk = '';
        this.labelError = '';
        // Avatar edit states
        this.tempAvatarUrl = '';
        this.avatarUrlValid = true;
        this.avatarLoading = false;
    }
    async firstUpdated() {
        this.userPerfil = await this.getUserPerfil();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.viewMode === 'editAvatar') {
            return this.renderEditAvatarView();
        }
        return this.renderUserSection();
    }
    renderUserSection() {
        const avatarUrl = this.userPerfil?.avatar_url;
        const iconByStatus = {
            'active': collab_dot,
            'deleted': collab_minus,
            'blocked': collab_ban,
            '': '',
        };
        const icon = iconByStatus[this.userPerfil?.status || ''];
        return html `
        <div class="section user">
            <h4>${collab_user} ${this.msg.userTitle}</h4>

            <div class="user-content">
                <div class="avatar-section">
                    <div class="avatar">
                        ${avatarUrl
            ? html `<img src="${avatarUrl}" alt="Avatar" />`
            : html `<div class="avatar-placeholder">${collab_user}</div>`}
                    </div>
                    <button class="btn-small btn-link" @click=${this.handleOpenEditAvatar}>
                        ${collab_edit} ${this.msg.changeAvatar}
                    </button>
                </div>

                <div class="user-info">
                    <div class="user-info-item">
                        <label>${this.msg.username}</label>
                        <input
                            .value=${this.userPerfil?.name ?? ''} 
                            type="text" 
                            @input=${this.handleNameInput}
                        />
                    </div>
                    <div class="user-info-row">
                        <div class="user-info-item">
                            <label>${this.msg.userid}</label>
                            <span class="user-id">${this.userPerfil?.userId ?? ''}</span>
                        </div>
                        <div class="user-info-item status">
                            <label>${this.msg.status}</label>
                            <span class=${this.userPerfil?.status}>${this.userPerfil?.status ?? 'N/A'} ${icon}</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="form-actions">
                <button @click=${this.handleSave} ?disabled=${this.isSaving}>
                    ${this.isSaving ? html `<span class="loader"></span>` : html `${collab_floppy_disk} ${this.msg.save}`}
                </button>
            </div>
            ${this.labelOk ? html `<small class="saving-ok">${this.labelOk}</small>` : ''}
            ${this.labelError ? html `<small class="saving-error">${this.labelError}</small>` : ''}      
        </div>
        `;
    }
    renderEditAvatarView() {
        const previewUrl = this.tempAvatarUrl || this.userPerfil?.avatar_url || '';
        return html `
        <div class="section edit-avatar">
            <h4>
                <button class="btn-back" @click=${this.handleCancelEditAvatar}>
                    ${collab_chevron_left}
                </button>
                ${collab_user} ${this.msg.editAvatar}
            </h4>

            <div class="avatar-edit-content">
                <div class="avatar-preview-small">
                    ${this.avatarLoading
            ? html `<div class="avatar-loading"><span class="loader"></span></div>`
            : previewUrl && this.avatarUrlValid
                ? html `<img src="${previewUrl}" alt="Preview" @error=${this.handleAvatarError} />`
                : html `<div class="avatar-placeholder">${collab_user}</div>`}
                </div>
                <div class="avatar-url-field">
                    <label>${this.msg.avatarUrl}</label>
                    <input 
                        type="url" 
                        .value=${this.tempAvatarUrl}
                        @input=${this.handleAvatarUrlInput}
                        placeholder="${this.msg.avatarUrlPlaceholder}"
                    />
                    ${!this.avatarUrlValid && this.tempAvatarUrl
            ? html `<small class="saving-error">${this.msg.invalidAvatarUrl}</small>`
            : ''}
                </div>
            </div>

            <div class="form-actions">
                <button class="btn-secondary" @click=${this.handleCancelEditAvatar}>
                    ${collab_xmark} ${this.msg.cancel}
                </button>
                <button @click=${this.handleSaveAvatar} ?disabled=${!this.avatarUrlValid || this.avatarLoading}>
                    ${collab_check} ${this.msg.changeAvatar}
                </button>
            </div>
        </div>
        `;
    }
    // ========== API ==========
    async getUserPerfil() {
        try {
            const result = await msgGetUserUpdate({ userId: "" });
            if (!result.success || !result.response?.user) {
                throw new Error(result.error || 'Failed to fetch user profile');
            }
            return result.response.user;
        }
        catch (err) {
            throw new Error(err?.message || 'Unexpected error while fetching user profile');
        }
    }
    // ========== HANDLERS ==========
    handleNameInput(e) {
        if (!this.userPerfil)
            return;
        const target = e.target;
        this.userPerfil = { ...this.userPerfil, name: target.value };
    }
    async handleSave() {
        this.labelError = '';
        this.labelOk = '';
        if (!this.userPerfil || !this.userPerfil.name) {
            this.labelError = this.msg.errorUserName;
            return;
        }
        this.isSaving = true;
        try {
            const result = await msgUpdateUserDetails({
                userId: this.userPerfil.userId,
                avatar_url: this.userPerfil.avatar_url,
                name: this.userPerfil.name,
                status: this.userPerfil.status,
                deviceId: this.userPerfil.notifications?.[0]?.deviceId || '',
                notificationToken: this.userPerfil.notifications?.[0]?.notificationToken || '',
            });
            if (!result.success || !result.response?.user) {
                this.labelError = result.error || 'Failed to update user profile.';
                return;
            }
            this.labelOk = this.msg.successSavingUser;
            await updateUsers([result.response.user]);
            this.dispatchEvent(new CustomEvent('user-saved', {
                detail: { user: result.response.user },
                bubbles: true,
                composed: true
            }));
        }
        catch (error) {
            console.error('Error updating user profile:', error);
            this.labelError = error?.message || 'An unexpected error occurred.';
        }
        finally {
            this.isSaving = false;
        }
    }
    // ========== AVATAR HANDLERS ==========
    handleOpenEditAvatar() {
        this.tempAvatarUrl = this.userPerfil?.avatar_url || '';
        this.avatarUrlValid = true;
        this.avatarLoading = false;
        this.viewMode = 'editAvatar';
    }
    handleCancelEditAvatar() {
        this.tempAvatarUrl = '';
        this.avatarUrlValid = true;
        this.avatarLoading = false;
        this.viewMode = 'main';
    }
    handleAvatarUrlInput(e) {
        const input = e.target;
        this.tempAvatarUrl = input.value;
        if (!this.tempAvatarUrl) {
            this.avatarUrlValid = true;
            return;
        }
        try {
            new URL(this.tempAvatarUrl);
        }
        catch {
            this.avatarUrlValid = false;
            return;
        }
        this.avatarLoading = true;
        const img = new Image();
        img.onload = () => {
            this.avatarLoading = false;
            this.avatarUrlValid = true;
        };
        img.onerror = () => {
            this.avatarLoading = false;
            this.avatarUrlValid = false;
        };
        img.src = this.tempAvatarUrl;
    }
    handleAvatarError() {
        this.avatarUrlValid = false;
    }
    handleSaveAvatar() {
        if (!this.avatarUrlValid || this.avatarLoading)
            return;
        if (this.userPerfil) {
            this.userPerfil = { ...this.userPerfil, avatar_url: this.tempAvatarUrl };
        }
        this.viewMode = 'main';
    }
};
__decorate([
    state()
], CollabMessagesSettingsUser.prototype, "userPerfil", void 0);
__decorate([
    state()
], CollabMessagesSettingsUser.prototype, "viewMode", void 0);
__decorate([
    state()
], CollabMessagesSettingsUser.prototype, "isSaving", void 0);
__decorate([
    state()
], CollabMessagesSettingsUser.prototype, "labelOk", void 0);
__decorate([
    state()
], CollabMessagesSettingsUser.prototype, "labelError", void 0);
__decorate([
    state()
], CollabMessagesSettingsUser.prototype, "tempAvatarUrl", void 0);
__decorate([
    state()
], CollabMessagesSettingsUser.prototype, "avatarUrlValid", void 0);
__decorate([
    state()
], CollabMessagesSettingsUser.prototype, "avatarLoading", void 0);
CollabMessagesSettingsUser = __decorate([
    customElement('collab-messages-settings-user-102025')
], CollabMessagesSettingsUser);
export { CollabMessagesSettingsUser };
