/// <mls fileReference="_102025_/l2/aiAgentDefaultFeedback.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing, svg } from 'lit';
import { customElement, state, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { continuePoolingTask, pauseOrContinueTask, loadAgent } from '/_102027_/l2/aiAgentOrchestration.js';
import { getNextPendentStep, getAllSteps } from "/_102027_/l2/aiAgentHelper.js";
import { countCollapsedRows, isBranchCompleted, isTransparentCompletedStep } from '/_102025_/l2/aiAgentDefaultFeedbackTree.js';
import { STEP_TITLE_LOCAL_EVENT, getLocalStepTitleEventScope } from '/_102025_/l2/collabMessagesEvents.js';
import { applyLocalStepTitle, displayedStepTitle, dropLocalTitleIfStatusChanged, dropLocalTitlesOnTaskChange, } from '/_102025_/l2/aiAgentDefaultFeedbackLocalTitle.js';
// Process-wide cache: does an agent implement openStepView? (Avoids re-importing agents per render.)
const openStepViewCache = new Map();
async function agentHasOpenStepView(agentName) {
    if (openStepViewCache.has(agentName))
        return openStepViewCache.get(agentName);
    let has = false;
    try {
        const agent = await loadAgent(agentName);
        has = !!agent && typeof agent.openStepView === 'function';
    }
    catch {
        has = false;
    }
    openStepViewCache.set(agentName, has);
    return has;
}
const collab_bell = svg `<svg width="16" height="16" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 448 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M224 0c-17.7 0-32 14.3-32 32l0 19.2C119 66 64 130.6 64 208l0 18.8c0 47-17.3 92.4-48.5 127.6l-7.4 8.3c-8.4 9.4-10.4 22.9-5.3 34.4S19.4 416 32 416l384 0c12.6 0 24-7.4 29.2-18.9s3.1-25-5.3-34.4l-7.4-8.3C401.3 319.2 384 273.9 384 226.8l0-18.8c0-77.4-55-142-128-156.8L256 32c0-17.7-14.3-32-32-32zm45.3 493.3c12-12 18.7-28.3 18.7-45.3l-64 0-64 0c0 17 6.7 33.3 18.7 45.3s28.3 18.7 45.3 18.7s33.3-6.7 45.3-18.7z"/> </svg>`;
const collab_play = svg `
    <svg width="14" height="14" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 384 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80V432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z"/></svg>
`;
const collab_pause = svg `
    <svg width="14" height="14" viewBox="0 0 320 512" fill="currentColor"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M48 64C21.5 64 0 85.5 0 112V400c0 26.5 21.5 48 48 48H80c26.5 0 48-21.5 48-48V112c0-26.5-21.5-48-48-48H48zm192 0c-26.5 0-48 21.5-48 48V400c0 26.5 21.5 48 48 48h32c26.5 0 48-21.5 48-48V112c0-26.5-21.5-48-48-48H240z"/></svg>
`;
let AiAgentDefaultFeedback102025 = class AiAgentDefaultFeedback102025 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`ai-agent-default-feedback-102025 {
  display: block;
  padding: 1rem;
  font-size: 14px;
  font-family: 'Inter', sans-serif;
}
ai-agent-default-feedback-102025 .feedback-section a {
  color: var(--selected-text);
}
ai-agent-default-feedback-102025 .feedback-section a:hover {
  color: var(--selected-text-hover);
}
ai-agent-default-feedback-102025 .feedback-section .step {
  font-family: monospace;
  margin: 4px 0;
}
ai-agent-default-feedback-102025 .feedback-section .notification-badge {
  position: absolute;
  top: -7px;
  right: -3px;
  background: red;
  color: white;
  border-radius: 50%;
  padding: 0.1em 0.1em;
  font-weight: bold;
  line-height: 1;
  min-width: 1em;
  text-align: center;
  font-size: 10px;
}
ai-agent-default-feedback-102025 .feedback-section .icon {
  position: relative;
  margin-left: -8px;
}
ai-agent-default-feedback-102025 .feedback-section .icon svg {
  height: 16px;
  width: 16px;
}
ai-agent-default-feedback-102025 .feedback-section .icon .success {
  fill: var(--status-success-text);
}
ai-agent-default-feedback-102025 .feedback-section .icon .error {
  fill: var(--status-error-text);
  color: var(--status-error-text);
}
ai-agent-default-feedback-102025 .feedback-section .icon .waiting {
  fill: currentColor;
}
ai-agent-default-feedback-102025 .feedback-section .icon .play {
  cursor: pointer;
}
ai-agent-default-feedback-102025 .feedback-section .actions {
  margin-left: auto;
}
ai-agent-default-feedback-102025 .feedback-section .actions .icon {
  cursor: pointer;
}
ai-agent-default-feedback-102025 .feedback-section .row {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 3px 6px;
  border-radius: 3px;
  transition: background-color 0.15s ease;
}
ai-agent-default-feedback-102025 .feedback-section .row.odd {
  background-color: rgba(128, 128, 128, 0.1);
}
ai-agent-default-feedback-102025 .feedback-section .row:hover {
  background-color: rgba(128, 128, 128, 0.2);
}
ai-agent-default-feedback-102025 .feedback-section .title {
  font-weight: 500;
}
ai-agent-default-feedback-102025 .feedback-section .branch-toggle {
  border: 0;
  background: transparent;
  color: inherit;
  cursor: pointer;
  font: inherit;
  line-height: 1;
  padding: 0 2px;
}
ai-agent-default-feedback-102025 .feedback-section .branch-title {
  cursor: pointer;
}
ai-agent-default-feedback-102025 .feedback-section .collapsed-count {
  color: var(--status-success-text);
  font-size: 12px;
  margin-left: 4px;
}
ai-agent-default-feedback-102025 .feedback-section .actions {
  display: flex;
  gap: 0.5rem;
  align-items: center;
}
ai-agent-default-feedback-102025 .feedback-section .actions .paused-label {
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  padding: 2px 8px;
  border-radius: 10px;
  color: #b8860b;
  background-color: rgba(255, 196, 0, 0.15);
}
ai-agent-default-feedback-102025 .feedback-section .actions a {
  font-size: 11px;
  cursor: pointer;
}
ai-agent-default-feedback-102025 .feedback-section .actions a:not(:last-child) {
  padding-right: 0.4rem;
  border-right: 1px solid;
}
ai-agent-default-feedback-102025 .feedback-section .details pre {
  padding: 12px;
  overflow: auto;
}
ai-agent-default-feedback-102025 .feedback-section .back {
  margin-bottom: 12px;
}
ai-agent-default-feedback-102025 .feedback-section .log-item {
  margin-bottom: 8px;
}
ai-agent-default-feedback-102025 .progress {
  margin: 12px 0 16px;
  font-size: 13px;
}
ai-agent-default-feedback-102025 .progress-info {
  display: flex;
  justify-content: space-between;
  margin-bottom: 6px;
  opacity: 0.8;
}
ai-agent-default-feedback-102025 .bar {
  height: 8px;
  background: #e5e5e5;
  border-radius: 999px;
  overflow: hidden;
}
ai-agent-default-feedback-102025 .fill {
  height: 100%;
  width: 0%;
  background: linear-gradient(90deg, var(--button-primary-bg), var(--status-success-text));
  transition: width 350ms ease;
  position: relative;
}
ai-agent-default-feedback-102025 .fill.done {
  background: var(--status-success-text);
}
ai-agent-default-feedback-102025 .fill.failed {
  background: var(--button-danger-bg);
}
ai-agent-default-feedback-102025 .fill:not(.failed):not(.done)::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
  animation: shimmer 1.4s infinite;
}
@keyframes shimmer {
  0% {
    transform: translateX(-100%);
  }
  100% {
    transform: translateX(100%);
  }
}
ai-agent-default-feedback-102025 .log-card {
  border-radius: 8px;
  padding: 10px;
  font-size: 12px;
}
ai-agent-default-feedback-102025 .log-card > div {
  display: flex;
  gap: 0.5rem;
  align-items: center;
}
ai-agent-default-feedback-102025 .log-card svg {
  height: 16px;
  width: 16px;
}
ai-agent-default-feedback-102025 .log-card .success {
  fill: var(--status-success-text);
}
ai-agent-default-feedback-102025 .log-card .error {
  fill: var(--status-error-text);
  color: var(--status-error-text);
}
ai-agent-default-feedback-102025 .log-list {
  list-style: none;
  padding-inline-start: 0;
}
ai-agent-default-feedback-102025 .log-list pre {
  margin-left: var(--space-16);
}
ai-agent-default-feedback-102025 .trace-steps {
  margin: 6px 0 0;
  padding-left: 16px;
}
ai-agent-default-feedback-102025 .trace-steps li {
  margin-bottom: 4px;
}
ai-agent-default-feedback-102025 .loader {
  display: inline-block;
  width: 8px;
  height: 8px;
  border: 2px solid #ccc;
  border-top: 2px solid #333;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
`);
        this.selectedStep = null;
        this.selectedTraceStep = null;
        this.isAgentParallelMode = false;
        // Agent names (in this task) whose agent implements openStepView → show an "open" link.
        this.openCapableAgents = new Set();
        this.openedView = null;
        this.userExpanded = new Set();
        this.userCollapsed = new Set();
        this.localTitles = new Map();
        this.onLocalStepTitle = (e) => {
            const detail = e.detail;
            const next = applyLocalStepTitle(this.localTitles, this.task?.PK, detail || {}, this.statusOf(detail?.stepId));
            if (next !== this.localTitles)
                this.localTitles = next;
        };
        this.onDurableTaskChange = (e) => {
            const taskPK = e.detail?.context?.task?.PK;
            const next = dropLocalTitlesOnTaskChange(this.localTitles, this.task?.PK, taskPK);
            if (next !== this.localTitles)
                this.localTitles = next;
        };
        // Running row counter for zebra striping (reset each render in renderTree).
        this.rowIndex = 0;
        this.iconError = svg `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="256" height="256" viewBox="0 0 256 256" xml:space="preserve" fill="currentColor">
<g style="stroke: none; stroke-width: 0; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: none; fill-rule: nonzero; opacity: 1;" transform="translate(1.4065934065934016 1.4065934065934016) scale(2.81 2.81)">
	<path d="M 24.959 68.04 c -0.768 0 -1.536 -0.293 -2.121 -0.879 c -1.172 -1.171 -1.172 -3.071 0 -4.242 l 40.081 -40.081 c 1.172 -1.172 3.07 -1.172 4.242 0 c 1.172 1.171 1.172 3.071 0 4.242 L 27.081 67.161 C 26.495 67.747 25.727 68.04 24.959 68.04 z" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: currentColor; fill-rule: nonzero; opacity: 1;" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round"/>
	<path d="M 65.04 68.04 c -0.768 0 -1.535 -0.293 -2.121 -0.879 L 22.838 27.081 c -1.172 -1.171 -1.172 -3.071 0 -4.242 c 1.171 -1.172 3.071 -1.172 4.242 0 l 40.081 40.081 c 1.172 1.171 1.172 3.071 0 4.242 C 66.575 67.747 65.808 68.04 65.04 68.04 z" style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: currentColor; fill-rule: nonzero; opacity: 1;" transform=" matrix(1 0 0 1 0 0) " stroke-linecap="round"/>
		<rect
			x="0"
			y="0"
			width="90"
			height="90"
			rx="25"
			fill="none"
			stroke="currentColor"
			stroke-width="6"
		/>
</g>
</svg>`;
        this.iconPending = svg `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="256" height="256" viewBox="0 0 256 256" xml:space="preserve" fill="currentColor">
<g style="stroke: none; stroke-width: 0; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: none; fill-rule: nonzero; opacity: 1;" transform="translate(1.4065934065934016 1.4065934065934016) scale(2.81 2.81)">
	<rect
			x="0"
			y="0"
			width="90"
			height="90"
			rx="25"
			fill="none"
			stroke="currentColor"
			stroke-width="6"
		/>
</g>
</svg>`;
        this.iconTaskPaused = svg `
        <svg xmlns="http://www.w3.org/2000/svg"
            width="256"
            height="256"
            viewBox="0 0 256 256"
            fill="currentColor">

            <g
                style="stroke: none; stroke-width: 0; fill: none;"
                transform="translate(1.4065934065934016 1.4065934065934016) scale(2.81 2.81)">

                <!-- contorno externo (idêntico ao pending) -->
                <rect
                    x="0"
                    y="0"
                    width="90"
                    height="90"
                    rx="25"
                    fill="none"
                    stroke="currentColor"
                    stroke-width="6"
                />

                <!-- pause -->
                <rect x="30" y="24" width="8" height="42" rx="2" fill="currentColor"/>
                <rect x="52" y="24" width="8" height="42" rx="2" fill="currentColor"/>

            </g>
        </svg>
    `;
        this.iconOk = svg `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><title>45-Check</title><g id="_45-Check" data-name="45-Check"><path d="M30,15V25a5,5,0,0,1-5,5H7a5,5,0,0,1-5-5V7A5,5,0,0,1,7,2H17V0H7A7,7,0,0,0,0,7V25a7,7,0,0,0,7,7H25a7,7,0,0,0,7-7V15Z"/><path d="M7.71,13.29,6.29,14.71l7,7a1,1,0,0,0,1.41,0l16-16L29.29,4.29,14,19.59Z"/></g></svg></div>`;
        this.iconWaitingHumam = svg `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><g data-name="18-Clock"><path d="M2 18a12 12 0 0 1 23.08-4.62l1.85-.77A14 14 0 0 0 16 4.14V2h1a2 2 0 0 0 2-2l-8 .06A.22.22 0 0 1 11 0H9a2 2 0 0 0 2 2h1v2.16A14 14 0 0 0 14 32v-2A12 12 0 0 1 2 18z"/><path d="M15 11h-2v7a1 1 0 0 0 .29.71l3 3 1.41-1.41-2.7-2.71zM31 27.23V24a6 6 0 0 0-5-5.91V17h-2v1.09A6 6 0 0 0 19 24v3.23A1.89 1.89 0 0 0 18 29l2-.1a.15.15 0 0 1-.15.1h2.33a3 3 0 0 0 5.63 0H32a1.89 1.89 0 0 0-1-1.77zM29 27h-8v-3a4 4 0 0 1 8 0z"/></g></svg>`;
        this.iconWaitingAfter = svg `<svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 25 25"><defs></defs><g id="clock_1" data-name="clock 1"><path class="cls-1" d="M12.5 1A11.5 11.5 0 1 0 24 12.5 11.51 11.51 0 0 0 12.5 1zm0 22A10.5 10.5 0 1 1 23 12.5 10.51 10.51 0 0 1 12.5 23z"/><path class="cls-1" d="M13 12.6V5.5a.5.5 0 0 0-1 0v7.32a.48.48 0 0 0 .16.36l5 4.68a.45.45 0 0 0 .34.14.5.5 0 0 0 .34-.86z"/></g></svg>`;
    }
    connectedCallback() {
        super.connectedCallback();
        const w = getLocalStepTitleEventScope();
        if (!w)
            return;
        w.addEventListener(STEP_TITLE_LOCAL_EVENT, this.onLocalStepTitle);
        w.addEventListener('task-change', this.onDurableTaskChange);
    }
    disconnectedCallback() {
        const w = getLocalStepTitleEventScope();
        if (w) {
            w.removeEventListener(STEP_TITLE_LOCAL_EVENT, this.onLocalStepTitle);
            w.removeEventListener('task-change', this.onDurableTaskChange);
        }
        super.disconnectedCallback();
    }
    statusOf(stepId) {
        if (stepId == null || !this.task)
            return undefined;
        for (const s of getAllSteps(this.task.iaCompressed?.nextSteps)) {
            if (s.stepId === stepId)
                return s.status;
        }
    }
    async firstUpdated() {
        //this.task = await getTask('20250917143000.1001');
        //this.task = await getTask('20251205185425.1001');
        //this.task = await getTask('20251127123524.1001');
        //this.task = await getTask('20260126134300.1001');
        //this.task = await getTask('20260126125152.1001');
        //this.task = await getTask('20260127122706.1001');
        //this.task = await getTask('20260212124748.1001');
        //console.info(this.task);
        this.isAgentParallelMode = !!this.task?.iaCompressed?.nextSteps[0].progress;
        void this.resolveOpenCapableAgents();
    }
    updated(_changedProperties) {
        super.updated(_changedProperties);
        if (_changedProperties.has('task')) {
            const previousTask = _changedProperties.get('task');
            if (previousTask?.PK !== this.task?.PK) {
                this.userExpanded = new Set();
                this.userCollapsed = new Set();
                if (this.localTitles.size)
                    this.localTitles = new Map();
            }
            else if (this.localTitles.size) {
                let next = this.localTitles;
                for (const s of getAllSteps(this.task?.iaCompressed?.nextSteps)) {
                    next = dropLocalTitleIfStatusChanged(next, s.stepId, s.status);
                }
                if (next !== this.localTitles)
                    this.localTitles = next;
            }
            this.isAgentParallelMode = !!this.task?.iaCompressed?.nextSteps[0].progress;
            void this.resolveOpenCapableAgents();
        }
    }
    // Resolve which agent steps in this task expose openStepView, so renderStep (sync) can show the
    // "open" link. Result is stored in state so the view re-renders once resolved.
    async resolveOpenCapableAgents() {
        if (!this.task)
            return;
        const names = new Set();
        for (const s of getAllSteps(this.task.iaCompressed?.nextSteps)) {
            const name = s.agentName;
            if (s.type === 'agent' && name)
                names.add(name);
        }
        const capable = new Set();
        for (const name of names) {
            if (await agentHasOpenStepView(name))
                capable.add(name);
        }
        this.openCapableAgents = capable;
    }
    async clickOpen(step) {
        if (!this.task)
            return;
        try {
            const agent = await loadAgent(step.agentName);
            const open = agent?.openStepView;
            if (!agent || typeof open !== 'function')
                return;
            const context = { task: this.task, message: this.message, isTest: false };
            this.openedView = await open(agent, context, step);
        }
        catch (error) {
            console.warn('[aiAgentDefaultFeedback](clickOpen) failed', error);
        }
    }
    renderOpenedView() {
        const lang = (document.documentElement.lang || '').toLowerCase();
        const back = lang.startsWith('pt') ? '← voltar' : '← back';
        return html `
            <section class="details">
                <a class="back" href="#" @click=${(e) => { e.preventDefault(); this.openedView = null; }}>
                    ${back}
                </a>
                ${this.openedView}
            </section>
        `;
    }
    getTitle(step) {
        return displayedStepTitle(step, this.localTitles);
    }
    getIconStep(status) {
        switch (status) {
            case 'completed': return html `<div class="success">${this.iconOk}</div>`;
            case 'in_progress': return html `<div class="loader"></div>`;
            case 'failed': return html `<div class="error">${this.iconError}</div>`;
            case 'pending': return html `<div class="pending">${this.iconPending}</div>`;
            case 'waiting_after_prompt': return html `<div class="waiting">${this.iconWaitingAfter}</div>`;
            case 'waiting_human_input': return html `<div class="waiting">${this.iconWaitingHumam}</div>`;
            default: return '•';
        }
    }
    getIconTask(status) {
        if (!this.task)
            return '';
        let _status = status;
        const step = getNextPendentStep(this.task);
        if (step && step.type === "clarification")
            _status = 'clarification';
        switch (_status) {
            case 'done': return html `<div class="success">${this.iconOk}</div>`;
            case 'in progress': return html `<div class="loader"></div>`;
            case 'failed': return html `<div class="error">${this.iconError}</div>`;
            case 'paused': return html `<div class="paused">${this.iconTaskPaused}</div>`;
            case 'clarification': return html `
                <span class="icon-wrapper">
                    ${collab_bell}
                    <span class="notification-badge">1</span>
                </span>`;
            default: return '•';
        }
    }
    getChildren(step) {
        return [
            ...(step.nextSteps ?? []),
            ...(step.interaction?.payload ?? [])
        ];
    }
    toggleBranch(event, stepId, collapsed) {
        event.preventDefault();
        event.stopPropagation();
        if (collapsed) {
            this.userCollapsed.delete(stepId);
            this.userExpanded.add(stepId);
        }
        else {
            this.userExpanded.delete(stepId);
            this.userCollapsed.add(stepId);
        }
        this.userExpanded = new Set(this.userExpanded);
        this.userCollapsed = new Set(this.userCollapsed);
    }
    renderStep(step, depth = 0) {
        const children = this.getChildren(step);
        const hasChildren = children.length > 0;
        const visibleChildRows = countCollapsedRows(step);
        const hasVisibleChildren = visibleChildRows > 0;
        if (isTransparentCompletedStep(step)) {
            return html `
             ${hasChildren
                ? children.map((s) => this.renderStep(s, depth))
                : nothing}
             `;
        }
        const eligibleForAutoCollapse = isBranchCompleted(step);
        const collapsed = hasVisibleChildren && (this.userCollapsed.has(step.stepId)
            || (eligibleForAutoCollapse && !this.userExpanded.has(step.stepId)));
        const toggleBranch = (event) => this.toggleBranch(event, step.stepId, collapsed);
        return html `
        <div class="step" style="padding-left:${depth + 15}px; ${depth !== 0 ? 'border-left:1px solid #cecece' : ''}" >

            <div class="row ${this.rowIndex++ % 2 === 0 ? 'even' : 'odd'}">
                <span class="icon">${this.getIconStep(step.status)}</span>

                ${hasVisibleChildren ? html `
                    <button class="branch-toggle" type="button" @click=${toggleBranch}
                        aria-label=${collapsed ? 'Expand step' : 'Collapse step'}>${collapsed ? '▸' : '▾'}</button>
                ` : nothing}

                <span class="title ${hasVisibleChildren ? 'branch-title' : ''}" @click=${hasVisibleChildren ? toggleBranch : nothing}>
                    ${this.getTitle(step)}
                    ${collapsed ? html `<span class="collapsed-count">(${visibleChildRows})</span>` : nothing}
                </span>

                <span class="actions">
                    ${step.type === 'agent' && this.openCapableAgents.has(step.agentName)
            ? html `<a href="#" @click=${(e) => { e.preventDefault(); this.clickOpen(step); }}>
                        ${(document.documentElement.lang || '').toLowerCase().startsWith('pt') ? 'abrir' : 'open'}
                    </a>`
            : nothing}
                    <a href="#" @click=${(e) => { e.preventDefault(); this.clickDetails(step); }}>
                        details
                    </a>
                    <a style="display:none" href="#"
                        @click=${(e) => {
            e.preventDefault();
            this.selectedTraceStep = step;
        }}>
                        trace
                    </a>
                </span>
            </div>

            ${hasChildren && !collapsed
            ? children.map((s) => this.renderStep(s, depth + 1))
            : nothing}
        </div>
    `;
    }
    renderTaskRootDetails() {
        if (!this.task)
            return html ``;
        return html `
            <div class="row">
                <span class="icon">${this.getIconTask(this.task.status)}</span>
                <div>${this.task?.title}</div>
                ${this.renderActions()}
            </div>
            <hr></hr>

        `;
    }
    renderActions() {
        const task = this.task;
        if (!task)
            return nothing;
        const queue = task.iaCompressed?.queueFrontEnd;
        const showRestart = task.status === 'in progress' && !queue?.length;
        const showPause = task.status === 'in progress';
        const showContinue = task.status === 'paused';
        // ${showRestart ? html`<span class="icon" @click=${this.restartPoolingTask} >${collab_play} </span>` : nothing}
        return html `
        <div class="actions">
            ${showContinue ? html `<span class="paused-label">Paused</span>` : nothing}
            ${showPause || showContinue ? html `<span class="icon" @click=${() => { this.pauseOrContinueTask(showPause ? 'paused' : 'continue'); }} >${showPause ? collab_pause : collab_play} </span>` : nothing}


        </div>
    `;
    }
    clickDetails(step) {
        //this.selectedStep = step;
        if (!this.father)
            return;
        this.father.currentStepId = step.stepId;
    }
    pauseOrContinueTask(action) {
        if (!this.task || !this.message)
            return;
        const context = { message: this.message, task: this.task, isTest: false };
        pauseOrContinueTask('user request', context, action);
    }
    restartPoolingTask() {
        if (!this.task || !this.message)
            return;
        const context = { message: this.message, task: this.task, isTest: false };
        continuePoolingTask(context);
    }
    renderTaskProgress() {
        if (!this.task)
            return html ``;
        if (this.task.status !== 'in progress')
            return html ``;
        const root = this.task.iaCompressed?.nextSteps[0];
        if (!root?.progress)
            return html ``;
        const { completed, failed, total } = root.progress;
        const percent = total ? Math.round((completed / total) * 100) : 0;
        const stateClass = failed > 0
            ? 'failed'
            : percent === 100
                ? 'done'
                : 'running';
        return html `
            <div class="progress">
                <div class="progress-info">
                    <span>Progress</span>
                    <span>
                        ${completed}/${total}
                        ${failed > 0 ? html ` • ❌ ${failed}` : nothing}
                    </span>
                </div>

                <div class="bar">
                    <div
                        class="fill ${stateClass}"
                        style="width:${percent}%"
                    ></div>
                </div>
            </div>
        `;
    }
    renderTree() {
        this.rowIndex = 0;
        const steps = this.task?.iaCompressed?.nextSteps ?? [];
        return html `
        <section class="tree">
                ${this.renderTaskRootDetails()}
                ${this.isAgentParallelMode ? this.renderTaskProgress() : ''}
                ${steps.map((s) => this.renderStep(s))}
        </section>
            `;
    }
    renderDetails() {
        const step = JSON.parse(JSON.stringify(this.selectedStep));
        if (step && step.nextSteps)
            step.nextSteps = [];
        if (step && step.interaction && step.interaction.payload) {
            step.interaction.payload.forEach((pay) => {
                pay.nextSteps = [];
            });
        }
        return html `
            <section class="details">
                <a 
                    class="back"
                    href = "#"
                    @click=${(e) => { e.preventDefault(); this.selectedStep = null; }}>
                    ← back
                </a>
                <h3> ${this.getTitle(step)} </h3>
                <pre> ${JSON.stringify(step, null, 2)} </pre>
            </section>
                        `;
    }
    renderTrace() {
        const step = this.selectedTraceStep;
        if (!step)
            return nothing;
        const logs = step.interaction?.trace ?? [];
        return html `
            <section class="trace">
                <a 
                    class="back"
                    href = "#"
                    @click=${(e) => {
            e.preventDefault();
            this.selectedTraceStep = null;
        }}>
                ← back
            </a>

            <h3> Trace • ${this.getTitle(step)} </h3>

            ${logs.length === 0
            ? html `<div>No logs</div>`
            : html `
                    <ul class="log-list">
                        ${logs.map((l) => html `
                        <li class="log-item">
                            ${this.renderLogItem(l)}
                        </li>
                    `)}
                    </ul>
                `}
        </section>
            `;
    }
    renderLogItem(raw) {
        const data = this.tryParseJSON(raw);
        if (typeof data === 'object' && data !== null) {
            const obj = data;
            return html `
            <div class="log-card">
                ${obj.title ?
                html `<div> ${this.getIconStep(obj.ok ? 'completed' : 'failed')} <strong>${obj.title}</strong></div>`
                : nothing}
                <pre>${JSON.stringify(obj, null, 2)}</pre>
            </div>
        `;
        }
        return html `<pre>${String(data)}</pre>`;
    }
    tryParseJSON(value) {
        if (typeof value !== 'string')
            return value;
        try {
            return JSON.parse(value);
        }
        catch {
            return value; // continua string normal
        }
    }
    render() {
        if (!this.task)
            return html `No find task`;
        if (!this.task.iaCompressed)
            return html `No find Ai interaction in task`;
        return html `
            <section class="feedback-section">
                ${this.openedView
            ? this.renderOpenedView()
            : this.selectedTraceStep
                ? this.renderTrace()
                : this.selectedStep
                    ? this.renderDetails()
                    : this.renderTree()}
        </section>
            `;
    }
};
__decorate([
    property()
], AiAgentDefaultFeedback102025.prototype, "father", void 0);
__decorate([
    state()
], AiAgentDefaultFeedback102025.prototype, "task", void 0);
__decorate([
    state()
], AiAgentDefaultFeedback102025.prototype, "message", void 0);
__decorate([
    state()
], AiAgentDefaultFeedback102025.prototype, "selectedStep", void 0);
__decorate([
    state()
], AiAgentDefaultFeedback102025.prototype, "selectedTraceStep", void 0);
__decorate([
    state()
], AiAgentDefaultFeedback102025.prototype, "isAgentParallelMode", void 0);
__decorate([
    state()
], AiAgentDefaultFeedback102025.prototype, "openCapableAgents", void 0);
__decorate([
    state()
], AiAgentDefaultFeedback102025.prototype, "openedView", void 0);
__decorate([
    state()
], AiAgentDefaultFeedback102025.prototype, "userExpanded", void 0);
__decorate([
    state()
], AiAgentDefaultFeedback102025.prototype, "userCollapsed", void 0);
__decorate([
    state()
], AiAgentDefaultFeedback102025.prototype, "localTitles", void 0);
AiAgentDefaultFeedback102025 = __decorate([
    customElement('ai-agent-default-feedback-102025')
], AiAgentDefaultFeedback102025);
export { AiAgentDefaultFeedback102025 };
