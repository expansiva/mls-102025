/// <mls fileReference="_102025_/l2/collabTasksThemePicker.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    themesTitle: 'Tema',
    imagePickerLabel: 'Imagem de fundo',
};
const message_en = {
    themesTitle: 'Theme',
    imagePickerLabel: 'Background image',
};
/// **collab_i18n_end**
/**
 * Reusable theme picker.
 *
 * Renders the theme cards grid + (when applicable) the background-image
 * picker. Persists the selection via the shared helpers in collabTasksTheme,
 * and dispatches two events on the top window so any open tasks screen can
 * react and stay in sync:
 *   - 'tasks-theme-changed'  detail: { theme }
 *   - 'tasks-bg-changed'     detail: { theme, url }
 *
 * Usage:
 *   <collab-tasks-theme-picker-102025
 *       variant="compact"     // or "panel" (default)
 *       hideTitle              // optional
 *   ></collab-tasks-theme-picker-102025>
 */
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { THEME_BG_OPTIONS, THEME_LIST, getThemeMeta, themePreview, loadTasksTheme, loadThemeBgUrl, saveThemeBgUrl, } from '/_102025_/l2/collabTasksTheme.js';
// Side-effect import: ensures the design tokens stylesheet is loaded.
import '/_102025_/l2/collabTasksDesignTokens.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
let CollabTasksThemePicker = class CollabTasksThemePicker extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-tasks-theme-picker-102025 {
  display: block;
  font-family: inherit;
}
collab-tasks-theme-picker-102025 .ctp-title {
  font-size: var(--ct-text-11);
  font-weight: var(--ct-weight-semibold);
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--ct-text-tertiary);
  margin-bottom: var(--ct-space-5);
}
collab-tasks-theme-picker-102025 .ctp-grid {
  display: grid;
  gap: var(--ct-space-3);
}
collab-tasks-theme-picker-102025 .ctp-card {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: var(--ct-space-3);
  padding: var(--ct-space-4);
  border: 0.5px solid var(--ct-card-border);
  border-radius: var(--ct-radius-lg);
  cursor: pointer;
  background: var(--ct-surface-bg-alt);
  font-family: inherit;
  text-align: left;
  transition: border-color var(--ct-duration-normal) var(--ct-ease-out), box-shadow var(--ct-duration-normal) var(--ct-ease-out), transform var(--ct-duration-fast) var(--ct-ease-out);
}
collab-tasks-theme-picker-102025 .ctp-card:hover {
  border-color: var(--ct-surface-border-strong);
  box-shadow: var(--ct-shadow-md);
  transform: translateY(-1px);
}
collab-tasks-theme-picker-102025 .ctp-card:focus-visible {
  outline: 2px solid var(--ct-status-todo);
  outline-offset: 2px;
}
collab-tasks-theme-picker-102025 .ctp-card.is-selected {
  border-color: var(--ct-status-todo);
  box-shadow: var(--ct-shadow-glow);
}
collab-tasks-theme-picker-102025 .ctp-preview {
  border-radius: var(--ct-radius-sm);
  overflow: hidden;
  border: 0.5px solid var(--ct-ink-50);
}
collab-tasks-theme-picker-102025 .ctp-card-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--ct-space-2);
}
collab-tasks-theme-picker-102025 .ctp-card-name {
  font-size: var(--ct-text-12);
  font-weight: var(--ct-weight-medium);
  color: var(--ct-text-primary);
}
collab-tasks-theme-picker-102025 .ctp-check {
  color: var(--ct-status-todo);
  flex-shrink: 0;
}
collab-tasks-theme-picker-102025 .ctp-card-desc {
  font-size: var(--ct-text-10);
  color: var(--ct-text-tertiary);
  line-height: var(--ct-leading-normal);
}
collab-tasks-theme-picker-102025 .ctp-img-badge {
  position: absolute;
  top: var(--ct-space-3);
  right: var(--ct-space-3);
  font-size: var(--ct-text-9);
  opacity: 0.65;
}
collab-tasks-theme-picker-102025 .ctp-img-section {
  margin-top: var(--ct-space-6);
  padding-top: var(--ct-space-6);
  border-top: 0.5px solid var(--ct-surface-border);
}
collab-tasks-theme-picker-102025 .ctp-img-label {
  font-size: var(--ct-text-10);
  font-weight: var(--ct-weight-semibold);
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--ct-text-tertiary);
  margin-bottom: var(--ct-space-4);
}
collab-tasks-theme-picker-102025 .ctp-img-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: var(--ct-space-3);
}
collab-tasks-theme-picker-102025 .ctp-img-thumb {
  aspect-ratio: 16 / 9;
  border-radius: var(--ct-radius-sm);
  border: 2px solid transparent;
  background-size: cover;
  background-position: center;
  background-color: var(--ct-surface-bg-alt);
  cursor: pointer;
  position: relative;
  overflow: hidden;
  padding: 0;
  transition: border-color var(--ct-duration-normal) var(--ct-ease-out), transform var(--ct-duration-fast) var(--ct-ease-out), box-shadow var(--ct-duration-normal) var(--ct-ease-out);
}
collab-tasks-theme-picker-102025 .ctp-img-thumb:hover {
  transform: scale(1.03);
  box-shadow: var(--ct-shadow-md);
}
collab-tasks-theme-picker-102025 .ctp-img-thumb.is-selected {
  border-color: var(--ct-status-todo);
  box-shadow: 0 0 0 1px var(--ct-status-todo), var(--ct-shadow-md);
}
collab-tasks-theme-picker-102025 .ctp-img-thumb:focus-visible {
  outline: 2px solid var(--ct-status-todo);
  outline-offset: 2px;
}
collab-tasks-theme-picker-102025 .ctp-img-check {
  position: absolute;
  top: var(--ct-space-2);
  right: var(--ct-space-2);
  display: flex;
}
collab-tasks-theme-picker-102025[data-variant="compact"] .ctp-grid {
  grid-template-columns: repeat(5, 1fr);
  gap: var(--ct-space-2);
}
collab-tasks-theme-picker-102025[data-variant="compact"] .ctp-card {
  padding: var(--ct-space-3);
  gap: var(--ct-space-2);
}
collab-tasks-theme-picker-102025[data-variant="compact"] .ctp-card-name {
  font-size: var(--ct-text-11);
}
collab-tasks-theme-picker-102025[data-variant="compact"] .ctp-card-desc {
  font-size: var(--ct-text-9);
}
@media (max-width: 720px) {
  collab-tasks-theme-picker-102025[data-variant="compact"] .ctp-grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
@media (max-width: 420px) {
  collab-tasks-theme-picker-102025[data-variant="compact"] .ctp-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}
collab-tasks-theme-picker-102025[data-variant="panel"] .ctp-grid {
  grid-template-columns: repeat(5, 1fr);
  gap: var(--ct-space-4);
}
@media (max-width: 720px) {
  collab-tasks-theme-picker-102025[data-variant="panel"] .ctp-grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
@media (max-width: 420px) {
  collab-tasks-theme-picker-102025[data-variant="panel"] .ctp-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}
@media (prefers-reduced-motion: reduce) {
  collab-tasks-theme-picker-102025 .ctp-card,
  collab-tasks-theme-picker-102025 .ctp-img-thumb {
    transition: none;
  }
  collab-tasks-theme-picker-102025 .ctp-card:hover,
  collab-tasks-theme-picker-102025 .ctp-img-thumb:hover {
    transform: none;
  }
}
`);
        /** Visual density. 'compact' for inline popovers, 'panel' for standalone screens. */
        this.variant = 'panel';
        /** Hide the section title when the host already provides one. */
        this.hideTitle = false;
        this._theme = 'clean';
        this._bgUrl = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this._theme = loadTasksTheme();
        this._bgUrl = loadThemeBgUrl(this._theme);
        this.setAttribute('data-variant', this.variant);
        // Stay in sync if another picker (or another component) changes the theme.
        this._onThemeChanged = (e) => {
            const detail = e.detail;
            if (detail?.theme && detail.theme !== this._theme) {
                this._theme = detail.theme;
                this._bgUrl = loadThemeBgUrl(detail.theme);
            }
        };
        this._onBgChanged = (e) => {
            const detail = e.detail;
            if (detail?.theme === this._theme)
                this._bgUrl = detail.url;
        };
        const w = window?.top ?? window;
        w.addEventListener('tasks-theme-changed', this._onThemeChanged);
        w.addEventListener('tasks-bg-changed', this._onBgChanged);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        const w = window?.top ?? window;
        w.removeEventListener('tasks-theme-changed', this._onThemeChanged);
        w.removeEventListener('tasks-bg-changed', this._onBgChanged);
    }
    updated(changed) {
        super.updated(changed);
        if (changed.has('variant'))
            this.setAttribute('data-variant', this.variant);
    }
    _onSelectTheme(theme) {
        if (theme === this._theme)
            return;
        this._theme = theme;
        this._bgUrl = loadThemeBgUrl(theme);
        // saveTasksTheme persists + applies to a host element. We don't want this
        // picker to claim ownership of the theme class — that belongs to the
        // top-level screen host. So we persist directly and dispatch the event.
        localStorage.setItem('collab-board-theme', theme);
        const w = window?.top ?? window;
        w.dispatchEvent(new CustomEvent('tasks-theme-changed', {
            detail: { theme },
            bubbles: true, composed: true,
        }));
    }
    _onSelectBg(url) {
        if (url === this._bgUrl)
            return;
        this._bgUrl = url;
        saveThemeBgUrl(this._theme, url);
        const w = window?.top ?? window;
        w.dispatchEvent(new CustomEvent('tasks-bg-changed', {
            detail: { theme: this._theme, url },
            bubbles: true, composed: true,
        }));
    }
    render() {
        const m = getMsg();
        const lang = document.documentElement.lang ?? 'en';
        const opts = THEME_BG_OPTIONS[this._theme];
        const effectiveCurrent = this._bgUrl ?? opts?.[0]?.url ?? null;
        return html `
      ${this.hideTitle ? nothing : html `
        <div class="ctp-title">${m.themesTitle}</div>
      `}

      <div class="ctp-grid">
        ${THEME_LIST.map(meta => {
            const { label, desc } = getThemeMeta(meta.id, lang);
            const active = this._theme === meta.id;
            return html `
            <button
              type="button"
              class="ctp-card ${active ? 'is-selected' : ''} ctp-theme-${meta.id}"
              aria-pressed=${active ? 'true' : 'false'}
              @click=${() => this._onSelectTheme(meta.id)}
            >
              <div class="ctp-preview">${themePreview(meta.id)}</div>
              <div class="ctp-card-row">
                <span class="ctp-card-name">${label}</span>
                ${active ? html `
                  <svg class="ctp-check" width="13" height="13" viewBox="0 0 13 13" fill="none" aria-hidden="true">
                    <circle cx="6.5" cy="6.5" r="6.5" fill="currentColor"/>
                    <path d="M3.5 6.5l2 2 3.5-3.5" stroke="white" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                ` : nothing}
              </div>
              <span class="ctp-card-desc">${desc}</span>
              ${meta.hasImage ? html `<span class="ctp-img-badge" aria-hidden="true">🖼</span>` : nothing}
            </button>
          `;
        })}
      </div>

      ${opts ? html `
        <div class="ctp-img-section">
          <div class="ctp-img-label">${m.imagePickerLabel}</div>
          <div class="ctp-img-grid">
            ${opts.map(opt => html `
              <button
                type="button"
                class="ctp-img-thumb ${effectiveCurrent === opt.url ? 'is-selected' : ''}"
                title=${opt.label}
                aria-label=${opt.label}
                aria-pressed=${effectiveCurrent === opt.url ? 'true' : 'false'}
                @click=${() => this._onSelectBg(opt.url)}
                style="background-image: url('${opt.thumbUrl}')"
              >
                ${effectiveCurrent === opt.url ? html `
                  <span class="ctp-img-check" aria-hidden="true">
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                      <circle cx="6" cy="6" r="6" fill="rgba(255,255,255,0.92)"/>
                      <path d="M3.5 6l1.8 1.8 3-3" stroke="#185fa5" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                  </span>
                ` : nothing}
              </button>
            `)}
          </div>
        </div>
      ` : nothing}
    `;
    }
};
__decorate([
    property({ type: String })
], CollabTasksThemePicker.prototype, "variant", void 0);
__decorate([
    property({ type: Boolean })
], CollabTasksThemePicker.prototype, "hideTitle", void 0);
__decorate([
    state()
], CollabTasksThemePicker.prototype, "_theme", void 0);
__decorate([
    state()
], CollabTasksThemePicker.prototype, "_bgUrl", void 0);
CollabTasksThemePicker = __decorate([
    customElement('collab-tasks-theme-picker-102025')
], CollabTasksThemePicker);
export { CollabTasksThemePicker };
