declare module "_102025_/l2/collabMessages.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessages" {
    import * as msg from '_102025_/l2/shared/interfaces';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import '/_102025_/l2/collabMessagesAdd.js';
    import '/_102025_/l2/collabMessagesChat.js';
    import '/_102025_/l2/collabMessagesTasks.js';
    import '/_102025_/l2/collabMessagesApps.js';
    import '/_102025_/l2/collabMessagesMoments.js';
    import '/_102025_/l2/collabMessagesSettings.js';
    import '/_102025_/l2/collabMessagesFindtask.js';
    import '/_102025_/l2/collabMessagesTabMenu.js';
    export class CollabMessages extends CollabLitElement {
        private msg;
        dataLocal: IDataLocal;
        activeTab: ITabType;
        activeScenerie: IScenery;
        isLoadingThread: boolean;
        userPerfil: msg.User | undefined;
        userThreads: IThreadData;
        showNotificationAlert: boolean;
        threadToOpen: string;
        taskToOpen: string;
        lastLevel: number;
        modeMenu: string;
        private groupSelected;
        private menuItems;
        connectedCallback(): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private checkNotificationPermission;
        private startPendentsPoolingsIfNeeded;
        private onThreadChange;
        private onThreadOpen;
        private setEvents;
        private removeEvents;
        renderHeader(): any;
        renderTabs(): any;
        renderAlert(): any;
        private onAlertClose;
        renderCRM(): any;
        renderTasks(): any;
        renderMoments(): any;
        renderApps(): any;
        renderSettings(): any;
        renderConnect(): any;
        private getUser;
        private updateThreads;
        private searchForDeletedThreadsPending;
        private updateUsersThread;
        private getThreadFromLocalDB;
        private getThreadInfo;
        private onThreadCreate;
        private checkNotificationPending;
        private onTabChange;
        private onButtonClick;
    }
    interface IDataLocal {
        lastTab: ITabType;
    }
    type IThreadData = {
        [key: string]: IThreadInfo;
    };
    interface IThreadInfo {
        thread: msg.Thread;
        users: msg.User[];
    }
    type ITabType = 'CRM' | 'TASK' | 'MOMENTS' | 'CONNECT' | 'APPS' | 'SETTINGS' | 'Add' | 'Loading';
    type IScenery = 'tabs' | 'settings' | 'findTask';
}
declare module "_102025_/l2/collabMessagesAdd.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesAdd.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesAdd" {
    import { CollabMessagesInputTag } from '_102025_/l2/collabMessagesInputTag';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102025_/l2/collabMessagesInputTag.js';
    export class CollabMessagesAdd extends StateLitElement {
        private msg;
        private threadType;
        private threadName;
        private visibility;
        private group;
        private languages;
        private isLoading;
        private dmUser;
        private users;
        agentsBots: IAgentsBots[];
        _selectedAgent: string;
        _initialMessage: string;
        _topics: string[];
        _agentConfig: string;
        _promptToAvatar: string;
        labelOk: string;
        labelError: string;
        userId: string | undefined;
        languageInput?: CollabMessagesInputTag;
        onAddSuccess: Function | undefined;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private loadUsersAvaliables;
        private loadAgentsBotsAvaliables;
        private _renderAdd;
        private _handleChange;
        private renderBotsConfig;
        private renderInitialMessageConfig;
        private renderIconConfig;
        private validateForm;
        private addNewThread;
        private addBot;
        private generateAvatar;
        private extractSvgFromContext;
    }
    interface IAgentsBots {
        id: string;
        name: string;
        description: string;
        avatar_url: string;
        info?: {
            project: number;
            shortName: string;
            folder: string;
        };
    }
}
declare module "_102025_/l2/collabMessagesAddParticipant.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesAddParticipant.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesAddParticipant" {
    import * as msg from '_102025_/l2/shared/interfaces';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesAddParticipant extends StateLitElement {
        private msg;
        userId: string | undefined;
        labelOkAddParticipant: string;
        labelErrorAddParticipant: string;
        userIdOrName: string;
        auth: msg.UserAuth;
        isAddParticipant: boolean;
        actualThread: IThreadActual | undefined;
        highlightedIndex: number;
        suggestions: string[];
        allUsers: string[];
        private users;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private onInput;
        private onBlur;
        private selectSuggestion;
        private onKeyDown;
        private onFocus;
        private onSubmitAddParticipant;
        private loadUsersAvaliables;
    }
    interface IThreadActual {
        thread: msg.ThreadPerformanceCache;
        users: msg.User[];
    }
}
declare module "_102025_/l2/collabMessagesApps.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesApps.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesApps" { }
declare module "_102025_/l2/collabMessagesAppsMenu.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesAppsMenu.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesAppsMenu" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export interface IMenu {
        name: string;
        icon: string;
        project: number;
        path: string;
        menu: IMenuItem[];
    }
    export interface IMenuItem {
        title: string;
        icon: string;
        url: string;
        pageName: string;
        target?: string;
        children?: IMenuItem[];
    }
    export class CollabMessagesAppsMenu extends StateLitElement {
        keyFavoritesLocalStorage: string;
        identifier: string;
        menuTitle: string;
        menuModules: IMenu[];
        favorites: string[];
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        private loadFavorites;
        private getItemPath;
        private toggleFavorite;
        private isFavorite;
        private handleMenuClick;
        private renderMenuItem;
        render(): any;
        private findItemByPath;
    }
}
declare module "_102025_/l2/collabMessagesAvatar.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesAvatar.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesAvatar" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesAvatar extends StateLitElement {
        avatar: string;
        width: string;
        height: string;
        updated(changedProperties: Map<string, any>): void;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesChangeAvatar.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesChangeAvatar.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesChangeAvatar" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabChangeAvatar extends StateLitElement {
        private msg;
        value?: string;
        nameValue?: string;
        userId: string;
        threadId: string;
        private avatarPrompt;
        private avatarFile?;
        private isOpen;
        private generating;
        private preview?;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private onFileSelect;
        private triggerFileInput;
        private generateAvatarFromPrompt;
        private emitValueChanged;
        private safeSvg;
    }
}
declare module "_102025_/l2/collabMessagesChat.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesChat.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesChat" {
    import '/_102025_/l2/collabMessagesTask.js';
    import '/_102025_/l2/collabMessagesTopics.js';
    import '/_102025_/l2/collabMessagesPrompt.js';
    import '/_102025_/l2/collabMessagesAvatar.js';
    import '/_102025_/l2/collabMessagesThreadDetails.js';
    import '/_102025_/l2/collabMessagesUserModal.js';
    import '/_102025_/l2/collabMessagesThreadModal.js';
    import '/_102025_/l2/collabMessagesFilter.js';
    import '/_102025_/l2/collabMessagesAdd.js';
    import '/_102025_/l2/collabMessagesChatMessage.js';
    import '/_102025_/l2/collabMessagesRichPreviewText.js';
    import * as msg from '_102025_/l2/shared/interfaces';
    import { IMessage, IThreadInfo } from '_102025_/l2/collabMessagesHelper';
    import { CollabMessagesPrompt } from '_102025_/l2/collabMessagesPrompt';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesChat extends StateLitElement {
        private msg;
        collabMessagesPrompt: CollabMessagesPrompt | undefined;
        private unreadEl;
        private messageContainer;
        private isLoadingThread;
        private filteredThreads;
        private isThreadError;
        private threadErrorMsg;
        private lastTopicFilter;
        private welcomeMessage;
        private usersAvaliables;
        private elementTaskDetails;
        group: 'CONNECT' | 'APPS' | 'DOCS' | 'CRM';
        userId: string | undefined;
        threadToOpen: string | undefined;
        taskToOpen: string | undefined;
        userDeviceId: string | undefined;
        activeScenerie: IScenery;
        actualThread: IThreadInfo | undefined;
        actualTask: msg.TaskData | undefined;
        actualMessage: IMessage | undefined;
        actualMessages: IMessage[];
        actualMessagesParsed: IMessageGrouped;
        isLoadingMessages: boolean;
        searchTerm: string;
        userThreads: IThread;
        allThreads: msg.Thread[];
        lastMessageReaded: string | undefined;
        unreadCountInSelectedThread: number;
        private isSystemChangeScroll;
        private savedScrollTop;
        private hasMoreMessagesLocalDB;
        private hasMoreMessagesBefore;
        private messagesLimit;
        private messagesOffset;
        private isLoadingMoreMessages;
        private isChangeTopics;
        private wasMessagesAtBottom;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderHeader;
        private renderContent;
        private renderChatMessages;
        private renderWelcomeMessage;
        private renderTopics;
        private onTopicClick;
        private removeAllModal;
        private renderPrompt;
        private renderListThreads;
        private getThreadAvatar;
        private getThreadName;
        private isDirectMessage;
        private renderThreadsByStatus2;
        private renderThreadItemLi;
        private renderTaskPendingsCount;
        private formatMessageDate;
        private renderArchivedThreads;
        private renderDeletingThreads;
        private renderDeletedThreads;
        private renderThreadSearch;
        private renderTaskDetails;
        private renderThreadDetails;
        private renderThreadAdd;
        private onSearchInput;
        private updateMessagesAfterScrollMore;
        private getBeforeMessagesInServer;
        private onCopyChat;
        private onChatScroll;
        private groupThreadsByPrefix;
        private getOrdenedThreadsByStatus;
        private getFilteredThreads;
        private getMessagesAfter;
        private getMessagesBefore;
        private parseMessages;
        private groupMessages;
        private parseLocalDate;
        private mergeMessages;
        private onThreadClick;
        private updateThreadPendingsInBackground;
        private openTask;
        private checkWelcomeMessage;
        private checkNotificationsUnreadMessages;
        private alreadyCheckForRegisterToken;
        private checkForRegisterNotification;
        private loadAllMessages;
        private updateMessagesOnDb;
        private clearUnreadMessageFromThread;
        private updateLastMessage;
        private onTitleClick;
        private onThreadDetailsClick;
        private onThreadAddClick;
        private handleSend;
        private handlePromptResize;
        private addMessage;
        private addMessageIA;
        private updateMessageAI;
        private createTempMessage;
        private updateMessage2;
        private onTaskClick;
        private onReplyPreviewClick;
        private onReplyMessageClick;
        private getTaskUpdate;
        private getThreadInfo;
        private saveScrollPosition;
        private restoreScrollPosition;
        private onTaskChange;
        private onThreadChange;
        private onMessageChange;
        private onMessageSend;
        private onVisibilityChange;
        private onDocumentClick;
        private verifyChatScroll;
        private delay;
        private nextFrame;
        private waitingForRenderCodesWebComponents;
    }
    type IMessageGrouped = {
        [key: string]: IMessage[];
    };
    type IThread = {
        [key: string]: IThreadInfo[];
    };
    type IScenery = 'list' | 'details' | 'loading' | 'task' | 'threadDetails' | 'threadAdd';
}
declare module "_102025_/l2/collabMessagesChatMessage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesChatMessage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesChatMessage" {
    import * as msg from '_102025_/l2/shared/interfaces';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { IChatPreferences, IMessage, IThreadInfo } from '_102025_/l2/collabMessagesHelper';
    export class CollabMessagesChatMessage102025 extends StateLitElement {
        message?: IMessage;
        messageId?: string;
        allThreads: msg.Thread[];
        actualThread: IThreadInfo | undefined;
        usersAvaliables: msg.User[];
        userId: string | undefined;
        openedReactionMessageId?: string;
        reactionPickerTarget?: HTMLElement;
        openedMenuFor?: string;
        messageMenuTarget?: HTMLElement;
        openedReactionListMessageId?: string;
        reactionListTarget?: HTMLElement;
        userPreferenceChat?: IChatPreferences;
        private messageMenuPlacement;
        private reactionListPlacement;
        onTaskClick?: Function;
        private msg;
        private readonly reactionEmojis;
        updated(): void;
        render(): any;
        private renderMessage;
        private renderMessageByLanguage;
        private replyCache;
        private renderReplyPreview;
        private loadReplyPreview;
        private onReplyPreviewClick;
        private renderMessageResultByLanguage;
        private renderMessageFooterResult;
        private renderCollabMessagesRichPreview;
        private onMentionHover;
        private onChannelHover;
        private removeAllUserModal;
        private removeAllChannelModal;
        private getTitleMessageTranslated;
        private renderReactions;
        private renderReactionListPopup;
        private findUser;
        private openReactionList;
        private updateReactionListPlacement;
        private removeReactionFromList;
        private closeReactionList;
        private renderReactionButtonAdd;
        private renderReactionPicker;
        private onPickerEmojiSelect;
        private openReactionPicker;
        private closeReactionPicker;
        private toggleReaction;
        private updateReactionOnDb;
        private animateReactionPicker;
        private positionReactionPicker;
        private renderSubMenuButton;
        private openMessageMenu;
        private positionMessageMenu;
        private closeMessageMenu;
        private renderMessageMenu;
        private onReplyClick;
        private closeAllPopups;
        private updateMessageMenuPlacement;
    }
}
declare module "_102025_/l2/collabMessagesEmojis.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesEmojis.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesEmojis" {
    export interface IEmoji {
        unicode: string;
        shortname: string;
        aliases: string[];
    }
    export const emojiList: {
        text: string;
        value: string;
        description: string;
        alias: string[];
    }[];
}
declare module "_102025_/l2/collabMessagesEvents.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesEvents" {
    import * as msg from '_102025_/l2/shared/interfaces';
    export function notifyMessageSendChange(context: msg.ExecutionContext): void;
    export function notifyTaskChange(context: msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: msg.Thread): void;
    export function notifyMessageChange(message: msg.Message): void;
    export function notifyThreadNotification(show: boolean): void;
    export function notifyThreadCreate(thread: msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function dispatchDetailsTaskClick(messageId: string, taskId: string, task: msg.TaskData, message: msg.MessagePerformanceCache): void;
    export function dispatchThreadOpen(threadId: string, taskId?: string): void;
    export interface ICollabMessageEvent {
        threadId: string;
        taskId?: string;
    }
}
declare module "_102025_/l2/collabMessagesFilter.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesFilter.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesFilter" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesFilter extends StateLitElement {
        private expanded;
        private query;
        placeholder: string;
        private toggleExpand;
        private handleKey;
        private handleInput;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesHelper.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesHelper.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesHelper" {
    import * as msg from '_102025_/l2/shared/interfaces';
    export const AGENTDEFAULT = "agentPlanner1";
    export function registerToken(): Promise<any>;
    export function addMessage(threadId: string, messageContent: string, contextToBot?: msg.ToolsBeforeSendMessage): Promise<msg.ExecutionContext>;
    export function getArgsToBots(): Promise<Record<string, any>>;
    export function getBotsContext(thread: msg.Thread, prompt: string, context: msg.ExecutionContext): Promise<Record<string, any>>;
    export function saveNotificationDeviceId(deviceId: string): void;
    export function loadNotificationDeviceId(): string | null;
    export function saveNotificationToken(tokenFCM: string): void;
    export function loadNotificationToken(): string | null;
    export function saveNotificationPreferences(notificationPreference: NotificationPermission): void;
    export function loadNotificationPreferences(): NotificationPermission | null;
    export function saveNotificationPreferencesAudio(enable: boolean): void;
    export function loadNotificationPreferencesAudio(): boolean;
    export function saveLastAlertTime(time: number): void;
    export function loadLastAlertTime(): number | undefined;
    export function saveLastTab(lastTab: string): void;
    export function loadLastTab(): string;
    export function saveUserId(userId: string): void;
    export function getUserId(): string | null;
    export function loadChatPreferences(): IChatPreferences;
    export function saveChatPreferences(chatPreferences: IChatPreferences): void;
    export function loadOpenClawIntegrations(): Promise<msg.IOpenClawIntegration[]>;
    export function saveOpenClawIntegrations(integrations: msg.IOpenClawIntegration[]): Promise<any>;
    export function checkThreadAlreadyExist(threadName: string): Promise<void>;
    export function getDmThreadByUsers(userId1: string, userId2: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThread(threadName: string, languages: string[], visibility: msg.ThreadVisibility, avatar_url?: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThreadDM(threadName: string, dmUser: string, group: msg.ThreadGroup): Promise<any>;
    export function formatTimestamp(timestamp: string): {
        dateFull: string;
        date: string;
        time: string;
        timeShort: string;
    };
    export function getDateFormated(dt: string): string;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => msg.ExecutionContext;
    export function generateUUIDv7(): string;
    export function generateAgentAvatar(name: string): string;
    export function changeFavIcon(notification: boolean): Promise<void>;
    export function generateDefaultAvatar(name: string): string;
    export type TranslateMode = "none" | "icon" | "text" | "iconText" | "trace";
    export interface IChatPreferences {
        translationMode: TranslateMode;
        language: string;
        threadMaintenance: string;
    }
    export interface CollabMessagesLS {
        lastTab?: string;
        chatPreferences?: IChatPreferences;
        userId?: string;
        tokenFCM?: string;
        deviceId?: string;
        notificationPreference?: NotificationPermission;
        notificationAudio?: boolean;
        lastNotificationAlertTime?: number;
    }
    export interface IMessage extends msg.MessagePerformanceCache {
        context?: msg.ExecutionContext;
        lastChanged?: number;
        isSame?: boolean;
        isLoading?: boolean;
        isFailed?: boolean;
        isFailedError?: string;
    }
    export interface IThreadInfo {
        thread: msg.ThreadPerformanceCache;
        threadsPending?: string[];
        users: msg.User[];
        hasMore?: boolean | undefined;
        messages?: msg.Message[] | undefined;
    }
}
declare module "_102025_/l2/collabMessagesIcons.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesIcons.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesIcons" {
    export const collab_message: any;
    export const collab_reply: any;
    export const collab_copy: any;
    export const collab_edit: any;
    export const collab_delete: any;
    export const collab_smile: any;
    export const collab_chevron_down: any;
    export const collab_chevron_right: any;
    export const collab_clock_static: any;
    export const collab_users: any;
    export const collab_user: any;
    export const collab_magnifying_glass: any;
    export const collab_arrow_up_long: any;
    export const collab_minus: any;
    export const collab_ban: any;
    export const collab_dot: any;
    export const collab_bell: any;
    export const collab_money: any;
    export const collab_pause: any;
    export const collab_clock: any;
    export const collab_check: any;
    export const collab_bug_x12: any;
    export const collab_play: any;
    export const collab_bug: any;
    export const collab_chevron_left: any;
    export const collab_gear: any;
    export const collab_translate: any;
    export const collab_circle_exclamation: any;
    export const collab_plus: any;
    export const collab_folder_tree: any;
    export const collab_triangle_exclamation: any;
    export const collab_bell_slash: any;
    export const collab_xmark: any;
    export const collab_spinner_clock: any;
    export const collab_trash: any;
    export const collab_link: any;
    export const collab_plug: any;
    export const collab_robot: any;
    export const collab_refresh: any;
    export const collab_floppy_disk: any;
    export const collab_crm: any;
    export const collab_tasks: any;
    export const collab_connect: any;
    export const collab_moments: any;
    export const collab_apps: any;
}
declare module "_102025_/l2/collabMessagesIndexedDB.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesIndexedDB.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesIndexedDB" {
    export * from '_102036_/l2/collabMessagesIndexedDB';
}
declare module "_102025_/l2/collabMessagesInputTag.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesInputTag.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesInputTag" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesInputTag extends StateLitElement {
        tags: string[];
        input: HTMLInputElement | undefined;
        pattern: string | null;
        placeholder: string | null;
        allowDelete: boolean;
        hasError: boolean;
        get value(): string;
        set value(val: string);
        onValueChanged: Function | undefined;
        addTag(tag: string): void;
        deleteTag(index: number): void;
        empty(): void;
        private _addTag;
        private _deleteTag;
        private _empty;
        private onInputLeave;
        private onInputKeyDown;
        private isValidTag;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesMoments.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesMoments.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesMoments" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesMoments102025 extends StateLitElement {
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesPrompt.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesPrompt.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesPrompt" {
    import * as msg from '_102025_/l2/shared/interfaces';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102025_/l2/collabMessagesAvatar.js';
    export class CollabMessagesPrompt extends StateLitElement {
        private msg;
        textArea: HTMLTextAreaElement | undefined;
        mentionSuggestionsElement?: HTMLElement;
        wrapper?: HTMLElement;
        text: string;
        actualMention?: IMentions;
        mentionActive: boolean;
        mentionQuery: string;
        mentionSuggestions: IMentions[];
        mentionIndex: number;
        allUsers: msg.User[];
        allAgents: IMentionAgent[];
        alreadyLoadingAgents: boolean;
        lastScopeLoaded: string | undefined;
        replyingTo?: {
            messageId: string;
            senderId: string;
            preview: string;
        };
        onSend: Function | undefined;
        threadId?: string;
        placeholder?: string;
        scope?: string;
        acceptAutoCompleteUser?: boolean;
        acceptAutoCompleteAgents?: boolean;
        connectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        setReply(message: {
            messageId: string;
            senderId: string;
            preview: string;
        }): void;
        clearReply(): void;
        private getUsers;
        private getAgents;
        private getCaretCoordinates;
        private calculatePosition;
        private adjustTextAreaHeight;
        render(): any;
        private renderReply;
        handleFocus(): Promise<void>;
        handleInput(e: MouseEvent): Promise<void>;
        private getUserSuggestions;
        private getAgentSuggestions;
        private getEmojiSuggestions;
        private handleKeyDown;
        private scrollToActiveMention;
        private selectMention;
        private extractAgentName;
        handleSend(): Promise<void>;
    }
    interface IMentionAgent {
        name: string;
        description: string;
        alias: string;
        avatar_url?: string;
    }
    interface IMentions {
        text: string;
        value: string;
        description: string;
        avatar_url?: string | undefined;
        type: 'user' | 'agent' | 'emoji';
    }
}
declare module "_102025_/l2/collabMessagesRichPreviewText.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesRichPreviewText.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesRichPreviewText" {
    import * as msg from '_102025_/l2/shared/interfaces';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102025_/l2/collabMessagesTextCode.js';
    export type SlackToken = {
        type: 'text';
        value: string;
    } | {
        type: 'inline-code';
        value: string;
    } | {
        type: 'code-block';
        language: string;
        value: string;
    } | {
        type: 'bold';
        value: string;
    } | {
        type: 'italic';
        value: string;
    } | {
        type: 'strike';
        value: string;
    } | {
        type: 'mention';
        value: string;
        userId: string;
    } | {
        type: 'channel';
        value: string;
    } | {
        type: 'agent';
        value: string;
    } | {
        type: 'command';
        value: string;
    } | {
        type: 'help';
        value: string;
    } | {
        type: 'link';
        text: string;
        url: string;
    } | {
        type: 'raw-link';
        url: string;
    } | {
        type: 'blockquote';
        children: SlackToken[];
    } | {
        type: 'list';
        ordered: boolean;
        items: SlackToken[][];
    };
    export class CollabMessagesRichPreviewText102025 extends StateLitElement {
        private msg;
        allHelpers: string[];
        allCommands: string[];
        allThreads: msg.Thread[];
        allUsers: msg.User[];
        text: string;
        render(): any;
        private renderSlackTokens;
        private renderToken;
        private renderText;
        private renderBold;
        private renderItalic;
        private renderStrike;
        private renderInlineCode;
        private renderCodeBlock;
        private renderAgent;
        private renderMention;
        private renderChannel;
        private renderCommand;
        private renderHelp;
        private renderLink;
        private renderRawLink;
        private renderBlockquote;
        private renderList;
        private copyToClipboard;
        private parseSlackMarkdown;
        private parseInlineSlackMarkdown;
    }
}
declare module "_102025_/l2/collabMessagesSettings.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesSettings.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesSettings" {
    import * as msg from '_102025_/l2/shared/interfaces';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    type ViewMode = 'main' | 'integrationDetails' | 'editAvatar';
    export class CollabMessagesSettings extends StateLitElement {
        private msg;
        private list;
        userPerfil: msg.User | undefined;
        private chatPreferences;
        notificationPreferences?: NotificationPermission | null;
        audioEnabled: boolean;
        tempAvatarUrl: string;
        avatarUrlValid: boolean;
        avatarLoading: boolean;
        integrations: IOpenClawIntegrationLocal[];
        viewMode: ViewMode;
        currentIntegrationId: string;
        newAgentName: string;
        newAgentAvatarUrl: string;
        tokenCopiedId: string;
        addAgentDetailsOpen: boolean;
        showDeleteConfirmation: boolean;
        deleteConfirmationInput: string;
        deleteConfirmationError: string;
        labelOk: string;
        labelError: string;
        labelOkPref: string;
        labelErrorPref: string;
        labelOkNotification: string;
        labelErrorNotification: string;
        labelOkIntegration: string;
        labelErrorIntegration: string;
        labelOkAgent: string;
        labelErrorAgent: string;
        isSavingUser: boolean;
        isSavingChat: boolean;
        isSavingAgent: boolean;
        isSavingNotification: boolean;
        isSavingIntegration: boolean;
        userAvatarEl: HTMLImageElement | undefined;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        updated(): void;
        render(): any;
        private renderUser;
        private renderEditAvatarView;
        private renderChatPreferences;
        private renderPreferencesNotifications;
        private renderOpenClawIntegrations;
        private renderIntegrationDetailsView;
        private renderAddAgentForm;
        private renderDeleteConfirmation;
        private renderAgent;
        private getNotificationStatus;
        private renderReadMore;
        private handleOpenEditAvatar;
        private handleCancelEditAvatar;
        private handleAvatarUrlInput;
        private handleAvatarError;
        private handleSaveAvatar;
        private handleToggleDeleteConfirmation;
        private handleDeleteConfirmationInput;
        private handleCancelDelete;
        private handleConfirmDelete;
        private handleAddIntegration;
        private handleOpenIntegrationDetails;
        private handleCancelIntegration;
        private handleSaveIntegration;
        private handleIntegrationNameChange;
        private handleIntegrationUrlChange;
        private handleGenerateToken;
        private handleCopyToken;
        private handleAddAgentToggle;
        private handleBackToMain;
        private handleNewAgentNameInput;
        private handleNewAgentAvatarInput;
        private handleGenerateAgentAvatar;
        private handleSaveAgent;
        private handleRemoveAgent;
        private handleAudioToggle;
        private onEnabledNotifications;
        private getUserPerfil;
        private handleSave;
        private handleSaveChatPref;
        private handleTranslationModeChange;
        private handleLanguageInput;
        private handleNameInput;
    }
    interface IOpenClawIntegrationLocal extends msg.IOpenClawIntegration {
        isLocal?: boolean;
    }
}
declare module "_102025_/l2/collabMessagesSyncNotifications.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesSyncNotifications.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesSyncNotifications" {
    export const threadSyncMap: Map<string, boolean>;
    export function removeThreadFromSync(threadId: string): void;
    export function checkIfNotificationUnread(): Promise<boolean>;
    export function listenToThreadEvents(): Promise<void>;
    export function getThreadUpdateInBackground(reference: string): Promise<void>;
}
declare module "_102025_/l2/collabMessagesTabMenu.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTabMenu" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export interface TabMenuItem {
        id: string;
        icon: TemplateResult;
        label: string;
        activeColor?: string;
        type: 'tab' | 'button';
    }
    export class CollabMessagesTabMenu extends StateLitElement {
        items: TabMenuItem[];
        activeId: string;
        private get _tabs();
        private get _buttons();
        private _handleItemClick;
        private _renderItem;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesTask.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTask.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTask" {
    import * as msg from '_102025_/l2/shared/interfaces';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesTask extends StateLitElement {
        private msg;
        taskid: string;
        threadId: string;
        userId: string;
        messageid: string;
        lastChanged: string;
        status: string;
        task: msg.TaskData | undefined;
        context: msg.ExecutionContext | undefined;
        private secondsPassed;
        private lastStep;
        private timerId;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        renderIconTask(): any;
        private resetTimer;
        private formatTime;
        private getTaskLocal;
        private onCardClick;
        private getAllSteps;
        private getNextPendentStep;
        private getTotalCost;
    }
}
declare module "_102025_/l2/collabMessagesTasks.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTasks.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTasks" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesTasks extends StateLitElement {
        private view;
        private selectedTask;
        private _backToList;
        render(): any;
        private _renderTaskDetails;
        _renderTaskList(): any;
        private _openTaskDetails;
    }
}
declare module "_102025_/l2/collabMessagesTextCode.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTextCode.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTextCode" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesTextCode extends StateLitElement {
        config: string | undefined;
        language: string;
        languages: any[];
        text: string;
        codeBlock: HTMLElement | undefined;
        select: HTMLSelectElement | undefined;
        private _resolveRendered;
        private markRendered;
        whenRendered: Promise<void>;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        private unescapeHtml;
        setCode(): void;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesThreadDetails.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesThreadDetails.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesThreadDetails" {
    import * as msg from '_102025_/l2/shared/interfaces';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102025_/l2/collabMessagesInputTag.js';
    import '/_102025_/l2/collabMessagesAddParticipant.js';
    import '/_102025_/l2/collabMessagesChangeAvatar.js';
    export class CollabMessagesThreadDetails extends StateLitElement {
        private msg;
        userId: string | undefined;
        threadDetails?: IThreadDetails;
        avatarEl?: HTMLElement;
        labelOk: string;
        labelError: string;
        labelErrorRemoveUser: string;
        labelErrorRemoveBoot: string;
        labelErrorAgent: string;
        labelOkAgent: string;
        private isLoading;
        private editedThreadDetails?;
        private isDirectMessage?;
        private isChannel?;
        private isFileChannel?;
        private isEditingDetails;
        private showAgentForm;
        private integrations;
        private selectedIntegrationId;
        private selectedAgentId;
        private isLoadingAgents;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        private loadIntegrations;
        updated(changedProperties: Map<string, any>): Promise<void>;
        private getAddedAgentIds;
        private getAvailableAgents;
        private getVisibilityLabel;
        private getStatusLabel;
        private enterEditMode;
        private cancelEditMode;
        render(): any;
        private renderDetailsViewMode;
        private renderDetailsEditMode;
        private renderUsers;
        private renderAgents;
        private renderAgentFormContent;
        private findAgentInfo;
        private generateAgentAvatar;
        private openAgentForm;
        private closeAgentForm;
        private saveAgent;
        private updateStatusAgent;
        private renderBots;
        private removeUser;
        private removeBot;
        private disableBot;
        private getChangedFields;
        private onAddParticipant;
        private saveChanges;
        private removeUserFromThread;
        private getThreadInfo;
    }
    interface IThreadDetails {
        thread: msg.ThreadPerformanceCache;
        users: msg.User[];
    }
}
declare module "_102025_/l2/collabMessagesThreadModal.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesThreadModal.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesThreadModal" {
    import * as msg from '_102025_/l2/shared/interfaces';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102025_/l2/collabMessagesAvatar.js';
    export class CollabMessagesThreadModal extends StateLitElement {
        private msg;
        open: boolean;
        thread?: msg.ThreadPerformanceCache;
        private isLoading;
        private errorMessage;
        private handleGlobalMouseMove;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        disconnectedCallback(): void;
        private destroy;
        render(): any;
        private onClickThreadAction;
    }
}
declare module "_102025_/l2/collabMessagesTopics.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTopics.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTopics" {
    import * as msg from '_102025_/l2/shared/interfaces';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesTopics extends StateLitElement {
        messages: IMessage[];
        topics: string[];
        expanded: boolean;
        selectedTopic: string | null;
        threadTopics: string[];
        render(): any;
        private emitTopic;
        private extractTopics;
        private groupTopics;
        private getHeadersTopicsFromMessages;
        private getTopicsFromMessagesOrdered;
    }
    interface IMessage extends msg.MessagePerformanceCache {
        context?: msg.ExecutionContext;
    }
}
declare module "_102025_/l2/collabMessagesUserModal.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesUserModal.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesUserModal" {
    import * as msg from '_102025_/l2/shared/interfaces';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesUserModal extends StateLitElement {
        private msg;
        open: boolean;
        user?: msg.User;
        actualUserId?: string;
        private isLoading;
        private errorMessage;
        private close;
        private handleGlobalMouseMove;
        firstUpdated(): void;
        disconnectedCallback(): void;
        private destroy;
        render(): any;
        private onClickUserAction;
    }
}
declare module "_102025_/l2/designSystem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/designSystem" {
    import { IDesignSystemTokens } from '/_102027_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102025_/l2/project.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/project.test" {
    import { ICANTest, ICANIntegration } from './_100554_tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102025_/l2/shared/api.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/shared/api" {
    import * as msg from '_102025_/l2/shared/interfaces';
    export function post<T = msg.ResponseBase>(args: msg.RequestBase): Promise<T>;
    export function getPostError(response: Response, args: msg.RequestBase): Promise<Error>;
    export function msgGetUsers(args: Omit<msg.RequestGetUsers, "action">): Promise<ApiResult<msg.ResponseGetUsers>>;
    export function msgGetUserUpdate(args: Omit<msg.RequestGetUserUpdate, "action">): Promise<ApiResult<msg.ResponseGetUserUpdate>>;
    export function msgUpdateUserDetails(args: Omit<msg.RequestUpdateUserDetails, "action">): Promise<ApiResult<msg.ResponseUpdateUserDetails>>;
    export function msgAddThread(args: Omit<msg.RequestAddThread, "action">): Promise<ApiResult<msg.ResponseAddThread>>;
    export function msgUpdateThread(args: Omit<msg.RequestUpdateThread, "action">): Promise<ApiResult<msg.ResponseUpdateThread>>;
    export function msgRemoveParticipantFromThread(args: Omit<msg.RequestRemoveUserInThread, "action">): Promise<ApiResult<msg.ResponseRemoveUserInThread>>;
    export function msgAddParticipantToThread(args: Omit<msg.RequestAddUserInThread, "action">): Promise<ApiResult<msg.ResponseAddUserInThread>>;
    export function msgGetThreadUpdates(args: Omit<msg.RequestGetThreadUpdate, "action">): Promise<ApiResult<msg.ResponseGetThreadUpdate>>;
    export function msgGetTaskUpdate(args: Omit<msg.RequestGetTaskUpdate, "action">): Promise<ApiResult<msg.ResponseGetTaskUpdate>>;
    export function msgAddMessage(args: Omit<msg.RequestAddMessage, "action">): Promise<ApiResult<msg.ResponseAddMessage>>;
    export function msgAddMessageAI(args: Omit<msg.RequestAddMessageAI, "action">): Promise<ApiResult<msg.ResponseAddMessageAI>>;
    export function msgAddOrUpdateThreadBot(args: Omit<msg.RequestAddOrUpdateThreadBot, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadBot>>;
    export function msgAddOrUpdateThreadIntegration(args: Omit<msg.RequestAddOrUpdateThreadIntegration, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadIntegration>>;
    export function msgGetMessagesAfter(args: Omit<msg.RequestGetMessagesAfter, "action">): Promise<ApiResult<msg.ResponseGetMessagesAfter>>;
    export function msgGetMessagesBefore(args: Omit<msg.RequestGetMessagesBefore, "action">): Promise<ApiResult<msg.ResponseGetMessagesBefore>>;
    export function msgGetMessage(args: Omit<msg.RequestGetMessage, "action">): Promise<ApiResult<msg.ResponseGetMessage>>;
    export function msgUpdateMessage(args: Omit<msg.RequestUpdateMessage, "action">): Promise<ApiResult<msg.ResponseUpdateMessage>>;
    export type ApiResult<T> = {
        success: boolean;
        response?: T;
        error?: string;
        statusCode: number;
    };
}
declare module "_102025_/l2/shared/interfaces.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/shared/interfaces" {
    export * from '_102036_/l2/shared/interfaces';
}
