declare module "_102025_/l2/aiAgentDefaultFeedback.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102036_/l2/shared/interfaces" {
    export enum HttpStatus {
        OK = 200,
        NOT_MODIFIED = 304,
        BAD_REQUEST = 400,
        UNAUTHORIZED = 401,
        NOT_FOUND = 404,
        FORBIDDEN = 403,
        CONFLICT = 409,
        SERVER_ERROR = 500,
        NOT_IMPLEMENTED = 501
    }
    export interface RequestBase {
        action: string;
    }
    export interface ResponseBase {
        statusCode: HttpStatus;
        msg?: string;
    }
    export interface RequestAddMessage extends RequestBase {
        action: "addMessage";
        userId: string;
        threadId: string;
        content: string;
        contextToBot?: Record<string, any>;
        replyTo?: string;
        senderDeviceId?: string;
    }
    export interface ResponseAddMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
        botOutputs?: BotOutput[];
        integrationOutputs?: IntegrationOutput[];
    }
    export interface RequestCreateAttachmentUpload extends RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends ResponseBase {
        message: Message;
    }
    export interface RequestDeleteAttachment extends RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends ResponseBase {
        message: Message;
    }
    export interface RequestGetAttachmentUrl extends RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends ResponseBase {
        url: string;
        expiresAt: string;
    }
    export interface RequestUpdateMessage extends RequestBase {
        action: "updateMessage";
        userId: string;
        threadId: string;
        messageId: string;
        reaction?: string;
        messageAction?: "delete" | "moderate" | "createTask";
        editContent?: string;
        taskTitle?: string;
    }
    export interface ResponseUpdateMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
    }
    export interface RequestAddMessageAI extends RequestBase {
        action: "addMessageAI";
        userId: string;
        threadId: string;
        taskTitle: string;
        userMessage: string;
        agentName: string;
        inputAI: IAMessageInputType[];
        longTermMemory?: Record<string, string>;
        replyTo?: string;
    }
    export interface ResponseAddMessageAI extends ResponseBase {
        message: Message;
        task: TaskData;
    }
    export interface RequestApplyIntents extends RequestBase {
        action: "applyIntents";
        userId: string;
        intents: AgentIntent[];
    }
    export interface ResponseApplyIntents extends ResponseBase {
        message?: Message;
        task: TaskData;
    }
    export interface RequestAddUser extends RequestBase {
        action: "addUser";
        name: string;
        avatar_url?: string;
    }
    export interface ResponseAddUser extends ResponseBase {
        user: User;
    }
    export interface RequestUpdateUserDetails extends RequestBase {
        action: "updateUserDetails";
        userId: string;
        name?: string;
        status?: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        deviceId?: string;
        subscription?: PushSubscriptionData;
    }
    export interface ResponseUpdateUserDetails extends ResponseBase {
        user: User;
    }
    export interface RequestAddThread extends RequestBase {
        action: "addThread";
        userId: string;
        name: string;
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        languages: string[];
        avatar_url: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
    }
    export interface ResponseAddThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestDeleteThread extends RequestBase {
        action: "deleteThread";
        userId: string;
        threadId: string;
    }
    export interface ResponseDeleteThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestUpdateThread extends RequestBase {
        action: "updateThread";
        userId: string;
        threadId: string;
        newOwnerId?: string;
        name?: string;
        visibility?: ThreadVisibility;
        status?: ThreadStatus;
        group?: ThreadGroup;
        languages?: string[];
        avatar_url?: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
        notification?: ThreadNotification;
    }
    export interface ResponseUpdateThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetTaskUpdate extends RequestBase {
        action: "getTaskUpdate";
        userId: string;
        messageId: string;
        taskId: string;
    }
    export interface ResponseGetTaskUpdate extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddTaskAISteps extends RequestBase {
        action: "addTaskAISteps";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        stepdIdToChangeStatus: number | null;
        newStatus: AIStepStatus;
        traceMsg: string | null;
        newTaskTitle: string;
        steps: AIPayload[];
    }
    export interface ResponseAddTaskAISteps extends ResponseBase {
        task: TaskData;
    }
    /**
     * add new prompts to a existing interaction,
     * change status of stepIdToChangeStatus to newStatus
     * change status of interactionStepId to 'in_progress'
     * start LLM
     */
    export interface RequestAppendPromptToInteraction extends RequestBase {
        action: "appendPromptToInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        interactionStepId: number;
        inputAI: IAMessageInputType[];
        stepdIdToChangeStatus: number;
        newStatus: AIStepStatus;
        traceMsg?: string;
    }
    export interface ResponseAppendPromptToInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateStepStatus extends RequestBase {
        action: "updateStepStatus";
        userId: string;
        messageId: string;
        taskId: string;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        newTaskTitle?: string;
        newTaskStatus?: TaskStatus;
    }
    export interface ResponseUpdateStepStatus extends ResponseBase {
        task: TaskData;
        message?: Message;
    }
    export interface RequestAddTaskAIInteraction extends RequestBase {
        action: "addTaskAIInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        inputAI: IAMessageInputType[];
    }
    export interface ResponseAddTaskAIInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateTaskTitle extends RequestBase {
        action: "updateTaskTitle";
        userId: string;
        messageId: string;
        taskId: string;
        newTitle: string;
    }
    export interface ResponseUpdateTaskTitle extends ResponseBase {
        task: TaskData;
    }
    export interface RequestEnsureTaskRoom extends RequestBase {
        action: "ensureTaskRoom";
        userId: string;
        taskId: string;
        parentThreadId?: string;
    }
    export interface ResponseEnsureTaskRoom extends ResponseBase {
        task: TaskData;
        thread: Thread;
    }
    export interface TagVocabularyEntry {
        tag: string;
        label?: {
            pt: string;
            en: string;
        };
        color: 'bug' | 'feature' | 'business' | 'process' | 'neutral';
    }
    export interface RequestListTasks extends RequestBase {
        action: "listTasks";
        userId: string;
        view: 'active' | 'closed';
        cursor?: string;
        pageSize?: number;
    }
    export interface ResponseListTasks extends ResponseBase {
        tasks: TaskData[];
        nextCursor?: string;
    }
    export interface RequestGetOrgPreferences extends RequestBase {
        action: "getOrgPreferences";
        userId: string;
        organizationId: string;
    }
    export interface ResponseGetOrgPreferences extends ResponseBase {
        tagVocabulary: TagVocabularyEntry[];
    }
    export interface RequestGetMessagesAfter extends RequestBase {
        action: "getMessagesAfter";
        threadId: string;
        lastOrderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesAfter extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessagesBefore extends RequestBase {
        action: "getMessagesBefore";
        threadId: string;
        orderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesBefore extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessage extends RequestBase {
        action: "getMessage";
        threadId: string;
        messageId: string;
        userId: string;
    }
    export interface ResponseGetMessage extends ResponseBase {
        message: Message;
    }
    export interface RequestAddUserInThread extends RequestBase {
        action: "addUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        auth: UserAuth;
    }
    export interface ResponseAddUserInThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveUserInThread extends RequestBase {
        action: "removeUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        eventVisibility?: "all" | "admin";
    }
    export interface ResponseRemoveUserInThread extends ResponseBase {
        thread: Thread;
        messages?: Message[];
    }
    export interface RequestGetThreadUpdate extends RequestBase {
        action: "getThreadUpdate";
        userId: string;
        threadId: string;
        deviceId?: string;
        lastOrderAt?: string;
    }
    export interface ResponseGetThreadUpdate extends ResponseBase {
        thread: Thread;
        users: User[];
        messages?: Message[];
        threadsPending: string[];
        hasMore?: boolean;
    }
    export interface RequestGetUserUpdate extends RequestBase {
        action: "getUserUpdate";
        userId?: string;
        name?: string;
        avatar_url?: string;
    }
    export interface ResponseGetUserUpdate extends ResponseBase {
        user: User;
    }
    export interface RequestGetUsers extends RequestBase {
        action: "getUsers";
        userId: string;
        status: "active" | "blocked";
        prefixName: string;
    }
    export interface ResponseGetUsers extends ResponseBase {
        users: {
            userId: string;
            name: string;
        }[];
    }
    export interface RequestAppendLongTermMemory extends RequestBase {
        action: "appendLongTermMemory";
        userId: string;
        messageId: string;
        taskId: string;
        longTermMemory: Record<string, string>;
    }
    export interface ResponseAppendLongTermMemory extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddOrUpdateThreadBot extends RequestBase {
        action: "addOrUpdateThreadBot";
        userId: string;
        threadId: string;
        botId: string;
        llmPrompt: string;
        status: "active" | "disabled";
        config?: Record<string, any>;
    }
    export interface ResponseAddOrUpdateThreadBot extends ResponseBase {
        thread: Thread;
    }
    export interface BotFlexibleResultBase {
        ref?: string;
        output?: string;
        [key: string]: any;
    }
    export interface BotOutput {
        botId: string;
        cost: number;
        output: string;
    }
    export type IntegrationType = "openclaw";
    export interface ThreadIntegration {
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
        lastExecutionAt?: string;
    }
    export interface ThreadIntegrationConfig {
        url: string;
        bearerToken: string;
        inboundToken: string;
        agentId?: string;
        sessionId?: string;
    }
    export interface IntegrationOutput {
        integrationId: string;
        type: IntegrationType;
        responseMessageId?: string;
        error?: string;
    }
    export interface RequestAddOrUpdateThreadIntegration extends RequestBase {
        action: "addOrUpdateThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
    }
    export interface ResponseAddOrUpdateThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadIntegration extends RequestBase {
        action: "removeThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
    }
    export interface ResponseRemoveThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestWebhookInbound {
        threadId: string;
        integrationId: string;
        content: string;
        type?: Message['type'];
        replyTo?: string;
    }
    export interface ResponseWebhookInbound extends ResponseBase {
        message: Message;
    }
    export interface User {
        userId: string;
        name: string;
        status: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        kind?: UserKind;
        metadata?: UserMetadata;
        threads: string[];
        notifications?: UserNotifications[];
    }
    export interface PushSubscriptionData {
        endpoint: string;
        keys: {
            p256dh: string;
            auth: string;
        };
        expirationTime?: number | null;
    }
    export interface UserNotifications {
        deviceId: string;
        subscription: PushSubscriptionData;
    }
    export type UserKind = "human" | "synthetic_agent" | "pma";
    export interface UserMetadata {
        source?: "collab" | "openclaw" | "external";
        agentType?: "pma" | "agent" | "external_agent";
        definitionRef?: string;
        definitionVersion?: string;
        modelType?: string;
        connectorId?: string;
        agentId?: string;
        [key: string]: any;
    }
    export interface UserPerformanceCache extends User {
        lastSync?: string;
    }
    export type UserAuth = "admin" | "moderator" | "read" | "write" | "none";
    export interface ThreadUsers {
        userId: string;
        auth: UserAuth;
        notification?: ThreadNotification;
    }
    export type ThreadGroup = "CRM" | "TASK" | "DOCS" | "CONNECT" | "APPS";
    export type ThreadVisibility = "public" | "private" | "company" | "team";
    export type ThreadStatus = "active" | "archived" | "deleting" | "deleted";
    export type ThreadNotification = "all" | "mentions" | "never";
    export interface Thread {
        threadId: string;
        name: string;
        users: ThreadUsers[];
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        history: ThreadHistoryEntry[];
        languages: string[];
        defaultTopics?: string[];
        welcomeMessage?: string;
        avatar_url: string;
        bots?: ThreadBot[];
        integrations?: ThreadIntegration[];
        openClawAgents?: OpenClawAgentBinding[];
        kind?: 'thread' | 'task-room';
        taskRoom?: {
            taskId: string;
            parentThreadId: string;
            workflowType: WorkflowType;
        };
        archivedAt?: string;
        archivedBy?: string;
        deletedAt?: string;
        createdAt: string;
    }
    export interface ThreadHistoryEntry {
        action: string;
        userId: string;
        timestamp: string;
    }
    export interface ThreadBot {
        botId: string;
        llmPrompt: string;
        threadFeature: ThreadFeature;
        threadPermissionLevel: ThreadPermissionLevel;
        triggers: ThreadBotTrigger[];
        status: "idle" | "running" | "disabled";
        lastExecutionAt?: string;
        memoryRef?: string;
        config?: Record<string, any>;
    }
    export enum ThreadFeature {
        Summary = "summary",
        CustomPlugin = "custom_plugin",
        Tasks = "tasks",
        Workflow = "workflow",
        Notifications = "notifications",
        Voting = "voting",
        Moderation = "moderation",
        Feedback = "feedback"
    }
    export type ThreadPermissionLevel = "all" | "members" | "admin";
    export interface ThreadBotTrigger {
        type: BotTriggerType;
        match?: "any" | "all";
        conditions?: BotTriggerCondition[];
        args?: BotTriggerArgs;
    }
    export enum BotTriggerType {
        OnNewMessage = "onNewMessage",
        OnMention = "onMention",
        OnTaskCompleted = "onTaskCompleted",
        Schedule = "schedule",
        Manual = "manual"
    }
    export interface BotTriggerCondition {
        type: "hasTag" | "mention" | "startsWith" | "contains";
        value: string;
    }
    export type BotTriggerArgs = {
        cron: string;
    } | {
        taskType: string;
    } | Record<string, any>;
    export interface ThreadPerformanceCache extends Thread {
        lastMessage?: string;
        lastMessageTime?: string;
        unreadCount?: number;
        lastSync?: string;
    }
    export interface Message {
        threadId: string;
        orderAt: string;
        createAt: string;
        updatedAt?: string;
        senderId: string;
        content: string;
        language_detected?: string;
        externalPlatform?: string;
        translations?: Record<string, string>;
        reactions?: Record<string, string[]>;
        attachments?: MessageAttachment[];
        moderation?: MessageModeration;
        edits?: MessageEditVersion[];
        editedAt?: string;
        editedBy?: string;
        type?: 'text' | 'image' | 'video' | 'audio' | 'document' | 'location' | 'contact';
        pin?: boolean;
        taskId?: string;
        stepId?: number;
        taskRoomRole?: 'conversation' | 'system' | 'agent' | 'workflow';
        taskTitle?: string;
        taskStatus?: TaskStatus;
        taskResults?: string[];
        taskResultsTranslated?: Record<string, string>;
        taskTitleTranslated?: Record<string, string>;
        visibility?: "admin";
        url?: string;
        replyTo?: string;
    }
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export type MessageModerationStatus = "deleted" | "moderated";
    export interface MessageModeration {
        status: MessageModerationStatus;
        by: string;
        at: string;
    }
    export interface MessageEditVersion {
        content: string;
        editedBy: string;
        editedAt: string;
    }
    export interface MessagePerformanceCache extends Message {
        lastSync?: string;
        status?: 'read' | 'unread' | 'edited';
        footers: {
            title?: string;
            lines: string[];
            icon?: string;
            color?: string;
            backgroundColor?: string;
            timestamp?: string;
        }[];
    }
    export interface ProviderConfig {
        provider: string;
        alternateProvider: string;
        model: string;
        json: boolean;
        onlyImage?: boolean;
        inputValue: number;
        outputValue: number;
        extrabody?: Record<string, string>;
    }
    export interface Providers {
        [provider: string]: Record<string, ProviderConfig>;
    }
    export type TaskOperationType = "create" | "read" | "update" | "delete" | "query";
    export interface TaskOperation {
        operation: TaskOperationType;
        taskId?: string;
        data?: Partial<TaskData>;
        filters?: Record<string, any>;
        message?: string | null;
    }
    export interface TaskData {
        PK: string;
        SK: 'metadata';
        title: string;
        owner: string;
        team: 'unassigned' | string | null;
        assignees?: string[];
        dueDate?: string;
        status: TaskStatus;
        last_updated: 0 | number;
        last_update_log: string | null;
        source?: string;
        url?: string;
        description?: string;
        priority?: 'low' | 'normal' | 'high' | 'urgent';
        effort?: number;
        cost?: number;
        iaCompressed?: IACompressed;
        tags?: string[];
        attachmentsUrl?: string[];
        messageid_created?: string;
        messageid_refs?: string[];
        taskRoom?: {
            enabled: boolean;
            threadId?: string;
            workflowType?: WorkflowType;
            parentThreadId?: string;
            memoryRef?: string;
            status?: 'active' | 'archived' | 'deleted';
            pmaId?: string;
            pmaStatus?: "active" | "paused" | "disabled";
            pmaConfigRef?: string;
            lastDecisionLogRef?: string;
        };
    }
    export type TaskStatus = 'todo' | 'in progress' | 'paused' | 'done' | 'failed';
    export type WorkflowType = 'staticWorkflow' | 'dynamicWorkflow';
    export interface TaskDataToSave extends Omit<TaskData, 'iaCompressed'> {
        iaCompressed?: string;
    }
    export interface IACompressed {
        nextSteps: AIPayload[];
        longMemory: Record<string, string>;
        isTest?: boolean;
        queueBackEnd: AgentIntent[];
        queueFrontEnd: AgentHooks[];
    }
    export interface AIInteraction {
        input: IAMessageInputType[];
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
        cost: number;
        trace: string[];
        payload: AIPayload[] | null;
    }
    export interface LLMTool {
        type: 'function';
        function: {
            name: string;
            description?: string;
            parameters?: Record<string, unknown>;
        };
    }
    export type LLMToolChoice = 'auto' | 'none' | 'required' | {
        type: 'function';
        function: {
            name: string;
        };
    };
    export interface IAMessageInputType {
        type: 'system' | 'human' | 'ai';
        content: string;
    }
    export type AIStepStatus = 'waiting_dependency' | // not ready yet
    'waiting_human_input' | // for parallel steps waiting for human input
    'waiting_after_prompt' | // for parallel steps waiting for afterPrompt processing
    'waiting_after_prompt_with_error' | // for parallel steps waiting for afterPrompt processing
    'pending' | // already created, waiting to be processed
    'in_progress' | // being processed in LLM
    'completed' | // completed successfully
    'failed';
    export interface AIStepProgress {
        total: number;
        completed: number;
        failed: number;
        templateTitle: string;
    }
    export type AIStepPlanningExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export interface AIStepPlanningDynamicSource {
        sourcePlanId?: string;
        selectorField?: string;
        argsField?: string;
    }
    export interface AIStepPlanning {
        planId: string;
        dependsOn: string[];
        executionMode: AIStepPlanningExecutionMode;
        executionHost?: 'client' | 'server' | 'either';
        dynamicSource?: AIStepPlanningDynamicSource;
    }
    export interface AIStep {
        type: AIPayload['type'];
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
    }
    export type AIPayload = AIAgentStep | AIToolStep | AIClarificationStep | AIResultStep | AIFlexibleResultStep;
    export interface AIWorkflowStep {
        type: WorkflowType;
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
        workflowName?: string;
    }
    export interface AIAgentStep extends AIStep {
        type: 'agent';
        agentName: string;
        prompt?: string;
        rags: string[] | null;
    }
    export interface AIToolStep extends AIStep {
        type: 'tool';
        toolName: string;
        args: string;
    }
    export interface AIClarificationStep extends AIStep {
        type: 'clarification';
        json?: string;
    }
    export interface AIResultStep extends AIStep {
        type: 'result';
        result: string;
    }
    export interface AIFlexibleResultStep extends AIStep {
        type: 'flexible';
        result: any;
    }
    export interface ExecutionContext {
        message: Message;
        task: TaskData | undefined;
        isTest: boolean;
    }
    export type AgentIntentUpdateStatus = {
        type: 'update-status';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        cleaner?: 'input' | 'input_output';
    };
    export type AgentIntentAddStep = {
        type: 'add-step';
        messageId: string;
        threadId: string;
        taskId: string;
        parentStepId: number;
        step: AIPayload;
        stepTitle?: string;
        executionMode?: ExecutionMode;
    };
    export type AgentIntentPauseOrContinue = {
        type: 'pause-or-continue';
        messageId: string;
        threadId: string;
        taskId: string;
        reason: string;
    };
    export type AgentIntentAddMessageAI = {
        type: 'add-message-ai';
        stepTitle?: string;
        request: Omit<RequestAddMessageAI, 'userId'>;
        executionMode?: ExecutionMode;
        skipRootLLM?: boolean;
    };
    export type ExecutionMode = {
        type: 'parallel';
        args: string[];
        maxParallel?: number;
    };
    /**
     * Parallel steps execution mechanism.
     * Child steps inherit the system prompt from their parent step.
     * Human prompts are prepared client-side using compact args (via beforePrompt hook).
     * Keep args short, unique, and deterministic.
     *
     * Parallel execution flow:
     *
     * 1. Frontend requests creation of a parent step (via API) with system prompt only
     *    and one or more AgentIntentParallelSteps.
     *
     * 1.1 Frontend enforces max parallel items per request.
     *     Use pagination (offset/limit or batch markers) in args when more items exist.
     *
     * 2. Backend:
     *    - Creates parent step with status "in_progress"
     *    - Enqueues AgentIntentParallelSteps in queueBackEnd
     *    - Immediately creates a batch of "waiting_human_input" child steps (no human prompt yet)
     *
     * 2.1 Parent remains "in_progress" until all children reach terminal state ("completed" or "failed").
     *
     * 2.2 Child steps are pre-allocated and reused as prompts arrive.
     *
     * 3. Backend enqueues multiple AgentHookBeforePrompt (one per waiting_human_input child) for frontend.
     *
     * 4. Frontend prepares human prompts and returns AgentIntentContinueParallelStep items.
     *
     * 5. Backend:
     *    - Updates child steps with received human prompts
     *    - Applies strong deduplication (ignore duplicates by parentStepId + args)
     *    - Cleans queueBackEnd and queueFrontEnd
     *
     * 6. Backend executes child steps as they become ready.
     *
     * 6.1 After each child execution, backend sends feedback AgentHook to frontend
     *     (success or error). Frontend then requests child status update to "completed" or "failed".
     *
     * 7. When ALL children are in terminal state, backend finalizes the parent step.
     *
     * 7.1 Finished child steps are deleted to reduce task object size.
     *
     * Critical implementation notes:
     * - Uniqueness key: parentStepId + args (must be collision-resistant)
     * - Step 5 MUST implement strict idempotency and duplicate rejection
     * - Error handling, child retries, and stuck-state timeouts are responsibility of other system layers
     */
    export type AgentIntentParallelSteps = {
        type: 'parallel-steps';
        parentStepId: number;
        args: string;
    };
    export type AgentIntentPromptReady = {
        type: 'prompt_ready';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        args: string;
        humanPrompt: string;
        systemPrompt?: string;
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
    };
    export type AgentIntentRemoveHook = {
        type: 'remove-hook';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
    };
    export type AgentIntent = AgentIntentAddStep | AgentIntentPauseOrContinue | AgentIntentUpdateStatus | AgentIntentParallelSteps | AgentIntentPromptReady | AgentIntentAddMessageAI | AgentIntentRemoveHook;
    export type AgentHookBase = {
        hookSequential: number;
        stepId: number;
    };
    export type AgentHookBeforePromptStep = AgentHookBase & {
        type: 'beforePromptStep';
        parentStepId: number;
        args: string;
    };
    export type AgentHookBeforeTool = AgentHookBase & {
        type: 'beforeTool';
        parentStepId: number;
        args: string;
    };
    export type AgentHookAfterPromptStep = AgentHookBase & {
        type: 'afterPromptStep';
        parentStepId: number;
    };
    export type AgentHookPooling = AgentHookBase & {
        type: 'pooling';
        executionCount: number;
        afterMs: number;
    };
    export type AgentHooks = AgentHookBeforePromptStep | AgentHookAfterPromptStep | AgentHookPooling | AgentHookBeforeTool;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export interface IOpenClawAgent {
        id: string;
        name: string;
        avatarUrl: string;
        collabUserId: string;
        createdAt: string;
    }
    export interface IOpenClawIntegration {
        id: string;
        name: string;
        url: string;
        connectorId: string;
        bearerToken: string;
        agents: IOpenClawAgent[];
        createdAt: string;
    }
    export interface ToolsBeforeSendMessage {
        toolName: string;
        args: Record<string, any>;
    }
    export interface RequestAddOrUpdateOpenClawConnector extends RequestBase {
        action: "addOrUpdateOpenClawConnector";
        userId: string;
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs?: number;
        defaultOutputMode?: OpenClawOutputMode;
    }
    export interface ResponseAddOrUpdateOpenClawConnector extends ResponseBase {
        connector: OpenClawConnector;
    }
    export interface RequestRemoveOpenClawConnector extends RequestBase {
        action: "removeOpenClawConnector";
        userId: string;
        connectorId: string;
    }
    export interface ResponseRemoveOpenClawConnector extends ResponseBase {
        connectorId: string;
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export type OpenClawOutputMode = "final_only" | "status_and_final";
    export type OpenClawSessionMode = "thread" | "thread_user";
    export type OpenClawHandoffThreadRole = "handoff" | "collaboration";
    export interface OpenClawConnector {
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs: number;
        defaultOutputMode: OpenClawOutputMode;
        protocolVersion?: number;
        transport?: string;
    }
    export interface RequestAddOrUpdateThreadOpenClawAgent extends RequestBase {
        action: "addOrUpdateThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface ResponseAddOrUpdateThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadOpenClawAgent extends RequestBase {
        action: "removeThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
    }
    export interface ResponseRemoveThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestListThreadOpenClawAgents extends RequestBase {
        action: "listThreadOpenClawAgents";
        userId: string;
        threadId: string;
    }
    export interface ResponseListThreadOpenClawAgents extends ResponseBase {
        threadId: string;
        agents: OpenClawAgentBinding[];
    }
    export interface OpenClawAgentBinding {
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface OpenClawRemoteAgentSummary {
        id: string;
        name?: string;
        identity?: {
            name?: string;
            theme?: string;
            emoji?: string;
            avatar?: string;
            avatarUrl?: string;
        };
        workspace?: string;
        model?: {
            primary?: string;
            fallbacks?: string[];
        };
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export interface RequestListOpenClawAvailableAgents extends RequestBase {
        action: "listOpenClawAvailableAgents";
        userId: string;
        connectorId: string;
    }
    export interface ResponseListOpenClawAvailableAgents extends ResponseBase {
        connectorId: string;
        defaultId: string;
        mainKey: string;
        scope: "per-sender" | "global";
        agents: OpenClawRemoteAgentSummary[];
    }
    export interface RequestCreateOpenClawAgent extends RequestBase {
        action: "createOpenClawAgent";
        userId: string;
        connectorId: string;
        name: string;
        workspace: string;
        emoji?: string;
        avatar?: string;
        soulMd?: string;
        identityMd?: string;
    }
    export interface ResponseCreateOpenClawAgent extends ResponseBase {
        connectorId: string;
        agent: OpenClawRemoteAgentSummary;
        collabUserId: string;
    }
    export interface RequestDeleteOpenClawAgent extends RequestBase {
        action: "deleteOpenClawAgent";
        userId: string;
        connectorId: string;
        agentId: string;
        deleteFiles?: boolean;
    }
    export interface ResponseDeleteOpenClawAgent extends ResponseBase {
        connectorId: string;
        agentId: string;
        collabUserId?: string;
        updatedThreadIds: string[];
    }
}
declare module "_102036_/l2/environmentContract" {
    import { IAgentMeta, IOpenClawIntegration, Thread, ToolsBeforeSendMessage, ExecutionContext, TaskData, Message, PushSubscriptionData } from "_102036_/l2/shared/interfaces";
    export interface CollabProgramMenuItem {
        title: string;
        icon: string;
        url: string;
        pageName: string;
        target?: string;
        children?: CollabProgramMenuItem[];
    }
    export interface CollabProgramMenu {
        name: string;
        icon: string;
        project: number;
        path: string;
        menu: CollabProgramMenuItem[];
    }
    /**
     * CONTRACT
     */
    export interface CollabMessagesEnvironment {
        getAgents?(): Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw?(): Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw?(integrations: IOpenClawIntegration[]): Promise<void>;
        config?: {
            getMenuMode?(): 'default' | 'custom';
            generateSvgAvatarEnabled?(): boolean;
            getApiUrl?(): string;
            getApiCredentials?(): RequestCredentials;
            getDefaultUserName?(): string;
        };
        tasks?: {
            openTaskDetails?(messageId: string, taskId: string, task: TaskData, message: Message): Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps?: {
            getProgramMenu?(): Promise<CollabProgramMenu[]>;
            openProgram?(item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }): Promise<void>;
        };
        agents?: {
            loadAgent?(agentName: string): Promise<IAgentMeta | null>;
            executeAgent?(agentToCall: string, context: ExecutionContext): Promise<void>;
            generateSvgAvatar?(threadId: string, userId: string, promptToAvatar: string): Promise<string | null>;
        };
        notifications?: {
            getPushSubscriptionForBackend?(): Promise<PushSubscriptionData | null>;
            getNotifySoundUrl?(): Promise<string | null>;
            sendRequestMissed?(): Promise<void>;
            sendACK?(id: string): Promise<void>;
        };
        bots?: {
            getArgsToBots?(): Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend?(thread: Thread, messageText: string): Promise<string[]>;
            getBotContextVarsBeforeMessageSend2?(vars: string[], myArgs: Record<string, any>): Promise<ToolsBeforeSendMessage[]>;
        };
    }
    export function setEnvironment(env: CollabMessagesEnvironment): void;
    /**
     * FACADE FINAL
     */
    export const environment: {
        getAgents: () => Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw: () => Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw: (integrations: IOpenClawIntegration[]) => Promise<void>;
        notifications: {
            getPushSubscriptionForBackend: () => Promise<PushSubscriptionData>;
            getNotifySoundUrl: () => Promise<string>;
            sendRequestMissed: () => Promise<void>;
            sendACK: (id: string) => Promise<void>;
        };
        bots: {
            getArgsToBots: () => Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend: (thread: Thread, messageText: string) => Promise<string[]>;
            getBotContextVarsBeforeMessageSend2: (vars: string[], myArgs: Record<string, any>) => Promise<ToolsBeforeSendMessage[]>;
        };
        agents: {
            generateSvgAvatar: (threadId: string, userId: string, promptToAvatar: string) => Promise<string>;
            executeAgent: (agentToCall: string, context: ExecutionContext) => Promise<void>;
            loadAgent: (agentName: string) => Promise<IAgentMeta>;
        };
        tasks: {
            openTaskDetails: (messageId: string, taskId: string, task: TaskData, message: Message) => Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps: {
            getProgramMenu: () => Promise<CollabProgramMenu[]>;
            openProgram: (item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }) => Promise<void>;
        };
        config: {
            getMenuMode: () => "default" | "custom";
            generateSvgAvatarEnabled: () => boolean;
            getApiUrl: () => string;
            getApiCredentials: () => RequestCredentials;
            getDefaultUserName: () => string;
        };
    };
}
declare module "_102036_/l2/shared/api" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function post<T = msg.ResponseBase>(args: msg.RequestBase): Promise<T>;
    export function getPostError(response: Response, args: msg.RequestBase): Promise<Error>;
    export function msgGetUsers(args: Omit<msg.RequestGetUsers, "action">): Promise<ApiResult<msg.ResponseGetUsers>>;
    export function msgGetUserUpdate(args: Omit<msg.RequestGetUserUpdate, "action">): Promise<ApiResult<msg.ResponseGetUserUpdate>>;
    export function msgUpdateUserDetails(args: Omit<msg.RequestUpdateUserDetails, "action">): Promise<ApiResult<msg.ResponseUpdateUserDetails>>;
    export function msgAddThread(args: Omit<msg.RequestAddThread, "action">): Promise<ApiResult<msg.ResponseAddThread>>;
    export function msgUpdateThread(args: Omit<msg.RequestUpdateThread, "action">): Promise<ApiResult<msg.ResponseUpdateThread>>;
    export function msgRemoveParticipantFromThread(args: Omit<msg.RequestRemoveUserInThread, "action">): Promise<ApiResult<msg.ResponseRemoveUserInThread>>;
    export function msgAddParticipantToThread(args: Omit<msg.RequestAddUserInThread, "action">): Promise<ApiResult<msg.ResponseAddUserInThread>>;
    export function msgGetThreadUpdates(args: Omit<msg.RequestGetThreadUpdate, "action">): Promise<ApiResult<msg.ResponseGetThreadUpdate>>;
    export function msgGetTaskUpdate(args: Omit<msg.RequestGetTaskUpdate, "action">): Promise<ApiResult<msg.ResponseGetTaskUpdate>>;
    export function msgAddMessage(args: Omit<msg.RequestAddMessage, "action">): Promise<ApiResult<msg.ResponseAddMessage>>;
    export function msgCreateAttachmentUpload(args: Omit<msg.RequestCreateAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCreateAttachmentUpload>>;
    export function msgCompleteAttachmentUpload(args: Omit<msg.RequestCompleteAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCompleteAttachmentUpload>>;
    export function msgDeleteAttachment(args: Omit<msg.RequestDeleteAttachment, "action">): Promise<ApiResult<msg.ResponseDeleteAttachment>>;
    export function msgGetAttachmentUrl(args: Omit<msg.RequestGetAttachmentUrl, "action">): Promise<ApiResult<msg.ResponseGetAttachmentUrl>>;
    export function msgEnsureTaskRoom(args: Omit<msg.RequestEnsureTaskRoom, "action">): Promise<ApiResult<msg.ResponseEnsureTaskRoom>>;
    export function msgAddMessageAI(args: Omit<msg.RequestAddMessageAI, "action">): Promise<ApiResult<msg.ResponseAddMessageAI>>;
    export function msgAddOrUpdateThreadBot(args: Omit<msg.RequestAddOrUpdateThreadBot, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadBot>>;
    export function msgAddOrUpdateThreadIntegration(args: Omit<msg.RequestAddOrUpdateThreadIntegration, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadIntegration>>;
    export function msgGetMessagesAfter(args: Omit<msg.RequestGetMessagesAfter, "action">): Promise<ApiResult<msg.ResponseGetMessagesAfter>>;
    export function msgGetMessagesBefore(args: Omit<msg.RequestGetMessagesBefore, "action">): Promise<ApiResult<msg.ResponseGetMessagesBefore>>;
    export function msgGetMessage(args: Omit<msg.RequestGetMessage, "action">): Promise<ApiResult<msg.ResponseGetMessage>>;
    export function msgUpdateMessage(args: Omit<msg.RequestUpdateMessage, "action">): Promise<ApiResult<msg.ResponseUpdateMessage>>;
    export function msgAddOrUpdateOpenClawConnector(args: Omit<msg.RequestAddOrUpdateOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateOpenClawConnector>>;
    export function msgRemoveOpenClawConnector(args: Omit<msg.RequestRemoveOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseRemoveOpenClawConnector>>;
    export function msgListOpenClawConnectors(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListOpenClawConnectorAgents(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListThreadOpenClawAgents(args: Omit<msg.RequestListThreadOpenClawAgents, "action">): Promise<ApiResult<msg.ResponseListThreadOpenClawAgents>>;
    export function msgAddOrUpdateThreadOpenClawAgent(args: Omit<msg.RequestAddOrUpdateThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadOpenClawAgent>>;
    export function msgRemoveThreadOpenClawAgent(args: Omit<msg.RequestRemoveThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseRemoveThreadOpenClawAgent>>;
    export function msgCreateOpenClawAgent(args: Omit<msg.RequestCreateOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseCreateOpenClawAgent>>;
    export function msgDeleteOpenClawAgent(args: Omit<msg.RequestDeleteOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseDeleteOpenClawAgent>>;
    export function msgListOpenClawAvailableAgents(args: Omit<msg.RequestListOpenClawAvailableAgents, "action">): Promise<ApiResult<msg.ResponseListOpenClawAvailableAgents>>;
    export function msgListTasks(args: Omit<msg.RequestListTasks, "action">): Promise<ApiResult<msg.ResponseListTasks>>;
    export function msgGetOrgPreferences(args: Omit<msg.RequestGetOrgPreferences, "action">): Promise<ApiResult<msg.ResponseGetOrgPreferences>>;
    export type ApiResult<T> = {
        success: boolean;
        response?: T;
        error?: string;
        statusCode: number;
    };
    export function msgApplyIntents(args: Omit<msg.RequestApplyIntents, "action">): Promise<msg.ResponseApplyIntents>;
    export function msgAppendLongTermMemory(args: Omit<msg.RequestAppendLongTermMemory, "action">): Promise<msg.ResponseAppendLongTermMemory>;
}
declare module "_102027_/l2/aiAgentHelper" {
    /**
     * Helper function to collect all steps from a task in a flat array
     */
    export const getAllSteps: (firstStep: mls.msg.AIPayload[] | undefined) => mls.msg.AIPayload[];
    export const getAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload | null;
    export const getAllAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload[] | null;
    export const getAgentsStepByAgentName: (task: mls.msg.TaskData, agentName: string, status?: mls.msg.AIStepStatus) => mls.msg.AIPayload[];
    export const getStepById: (task: mls.msg.TaskData, stepId: number) => mls.msg.AIPayload | null;
    export const getNextPendentStep: (task: mls.msg.TaskData) => mls.msg.AIPayload | null;
    export const getNextResultStep: (task: mls.msg.TaskData) => mls.msg.AIResultStep | null;
    export const getNextClarificationStep: (task: mls.msg.TaskData) => mls.msg.AIClarificationStep | null;
    export const getNextPendingStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getNextFlexiblePendingStep: (task: mls.msg.TaskData) => mls.msg.AIFlexibleResultStep | null;
    export const getNextInProgressStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getRootAgent: (task: mls.msg.TaskData) => mls.msg.AIAgentStep | null;
    export const getInteractionStepId: (task: mls.msg.TaskData, stepId: number) => number | null;
    export type StatisticsAITask = {
        agents: number;
        tools: number;
        clarification: number;
        result: number;
        flexible: number;
        totalCost: number;
        totalSteps: number;
    };
    export const calculateStepsStatistics: (steps: mls.msg.AIPayload[], removeFirstStep: boolean) => StatisticsAITask;
    export const calculateStepsByFilter: (task: mls.msg.TaskData, filter: Record<string, any>) => number;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => mls.msg.ExecutionContext;
    export function notifyMessageSendChange(context: mls.msg.ExecutionContext): void;
    export function notifyTaskChange(context: mls.msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: mls.msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: mls.msg.Thread): void;
    export function notifyMessageChange(message: mls.msg.Message): void;
    export function notifyThreadCreate(thread: mls.msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function getTotalCost(task: mls.msg.TaskData): string;
    export function appendLongTermMemory(context: mls.msg.ExecutionContext, longTermMemory: Record<string, string>): Promise<mls.msg.TaskData>;
    export function getNextStepIdAvaliable(task: mls.msg.TaskData): number;
    export function findPreviousAgentStep(data: mls.msg.TaskData, baseStep: number): mls.msg.AIAgentStep | null;
}
declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102036_/l2/collabMessagesIndexedDB" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function openDB(): Promise<IDBDatabase>;
    export function addMessages(messages: msg.MessagePerformanceCache[]): Promise<void>;
    export function addMessage(message: msg.MessagePerformanceCache): Promise<void>;
    export function updateMessage(message: msg.Message): Promise<void>;
    export function deleteAllMessagesFromThread(threadId: string): Promise<void>;
    export function getMessage(messageId: string): Promise<msg.MessagePerformanceCache | undefined>;
    export function getMessagesByThreadId(threadId: string, limit?: number, offset?: number): Promise<msg.MessagePerformanceCache[]>;
    export function getAllMessagesByThreadId(threadId: string): Promise<msg.MessagePerformanceCache[]>;
    export function addOrUpdateTask(task: msg.TaskData): Promise<void>;
    export function getTask(taskId: string): Promise<msg.TaskData | undefined>;
    export function deleteTask(taskId: string): Promise<void>;
    export function listThreads(): Promise<msg.ThreadPerformanceCache[]>;
    export function addThread(thread: msg.Thread): Promise<msg.ThreadPerformanceCache>;
    export function updateLastMessageReadTime(threadId: string, lastMessageReadTime: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreadPendingTasks(threadId: string, taskId?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThread(threadId: string, thread: msg.Thread, lastMessage?: string, lastMessageTime?: string, unreadCount?: number, lastSync?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreads(threadsFromServer: msg.Thread[]): Promise<void>;
    export function getThread(threadId: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getThreadByName(threadName: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getAllThreads(): Promise<IDBThreadPerformanceCache[]>;
    export function cleanupThreads(validThreadIds: string[]): Promise<void>;
    export function listUsers(): Promise<msg.User[]>;
    export function addUser(user: msg.User): Promise<void>;
    export function updateUsers(usersFromServer: msg.User[]): Promise<void>;
    export function getUser(userId: string): Promise<msg.User | undefined>;
    export function addPooling(pooling: PoolingTask): Promise<void>;
    export function deletePooling(taskId: string): Promise<void>;
    export function getPooling(taskId: string): Promise<PoolingTask | undefined>;
    export function listPoolings(): Promise<PoolingTask[]>;
    export function getCompactUTC(): string;
    export interface IDBThreadPerformanceCache extends msg.ThreadPerformanceCache {
        pendingTasks?: string;
    }
    export interface PoolingTask {
        taskId: string;
        userId: string;
        startAt: string;
    }
}
declare module "_102027_/l2/aiAgentOrchestration" {
    import { msgApplyIntents } from "_102036_/l2/shared/api";
    import { IAgent, IAgentAsync } from "_102027_/l2/aiAgentBase";
    /** Browser keeps IndexedDB. CLI calls setOrchestrationStorage before loadAgent/pooling. */
    export type OrchestrationStorage = {
        addOrUpdateTask(task: mls.msg.TaskData): Promise<void>;
        getTask(taskId: string): Promise<mls.msg.TaskData | undefined>;
        getMessage(messageId: string): Promise<mls.msg.Message | undefined>;
        addPooling(pooling: {
            taskId: string;
            userId: string;
            startAt: string;
        }): Promise<void>;
        deletePooling(taskId: string): Promise<void>;
        /**
         * The browser (IndexedDB) returns the updated thread; a host with no thread cache returns
         * nothing. Declared as the type the consumer actually needs — `unknown` compiled here and
         * broke at the two call sites that hand the result to `notifyThreadChange`.
         */
        updateThreadPendingTasks(threadId: string, taskId?: string): Promise<mls.msg.Thread | undefined>;
    };
    export function setOrchestrationStorage(next: OrchestrationStorage | null): void;
    type ApplyIntentsFn = typeof msgApplyIntents;
    /** CLI injects Bearer POST /msg. Browser never calls this. */
    export function setApplyIntents(fn: ApplyIntentsFn | null): void;
    export type OrchestrationEvent = {
        type: 'task-created';
        taskId: string;
        task: mls.msg.TaskData;
        message?: mls.msg.Message;
    } | {
        type: 'intents-applied';
        task: mls.msg.TaskData;
        message: mls.msg.Message;
    } | {
        type: 'hook-start';
        hookType: string;
        stepId: number;
    } | {
        type: 'hook-done';
        hookType: string;
        intents: mls.msg.AgentIntent[];
    } | {
        type: 'pooling-start';
        taskId: string;
    } | {
        type: 'pooling-end';
        taskId: string;
    } | {
        type: 'cycle-done';
        remaining: number;
    } | {
        type: 'error';
        error: string;
        stepId?: number;
    } | {
        type: 'done';
    };
    type OrchestrationListener = (event: OrchestrationEvent) => void;
    /** CLI / tests. Browser never subscribes — executeBeforePrompt still swallows the stream. */
    export function subscribeOrchestrationEvents(listener: OrchestrationListener): () => void;
    export function executeBeforePromptStream(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): AsyncGenerator<OrchestrationEvent, void, unknown>;
    /**
     * Backward-compatible wrapper: consome o generator inteiro e retorna void.
     * Quem não precisa de streaming continua usando essa.
     */
    export function executeBeforePrompt(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): Promise<void>;
    export function continuePoolingTask(context: mls.msg.ExecutionContext): Promise<void>;
    export function pauseOrContinueTask(reason: string, context: mls.msg.ExecutionContext, action: "paused" | "continue"): Promise<void>;
    export function restartStep(context: mls.msg.ExecutionContext, stepId: number, cleaner?: 'input' | 'input_output'): Promise<void>;
    export function executeTool(toolName: string, args: string): Promise<IExecuteToolReturn>;
    export function finishClarification(agent: IAgent | IAgentAsync, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], context: mls.msg.ExecutionContext, value: string, action: "continue" | "cancel"): Promise<void>;
    export function getClarificationElement(context: mls.msg.ExecutionContext): Promise<HTMLElement>;
    export function getAgentContext(taskId: string): Promise<{
        context: mls.msg.ExecutionContext;
        interaction: mls.msg.AIAgentStep;
        step: mls.msg.AIPayload;
    }>;
    export function loadAgent(agentName: string): Promise<IAgent | IAgentAsync | undefined>;
    export function loadTool(toolName: string): Promise<any | undefined>;
    type InstanceMode = 'agent' | 'tool';
    /**
     * agentName, ex: 'agentXX1' or '_100554_/l2/agents/agentXX1'
     */
    export function getInstanceByName(nameOrPath: string, mode: InstanceMode): Promise<IAgent | IAgentAsync | undefined>;
    export interface IExecuteToolReturn {
        status: boolean;
        error: string;
        result: any;
    }
    export interface ClarificationValue {
        taskId: string;
        stepId: number;
        title: string;
        userLanguage: string;
        questions: ClarificationQuestions;
        legends: string[];
    }
    export interface ClarificationQuestions {
        [key: string]: Question;
    }
    export interface Question {
        type: 'open' | 'select' | 'boolean' | 'MoSCoW' | 'range';
        question: string;
        answer?: string | boolean;
        options?: QuestionOption[];
    }
    export interface QuestionOption {
        id: string;
        label: string;
    }
}
declare module "_102025_/l2/aiAgentDefaultFeedbackTree" {
    export function isTransparentCompletedStep(step: mls.msg.AIPayload): boolean;
    /** True only when a visible branch and every descendant have completed. */
    export function isBranchCompleted(step: mls.msg.AIPayload): boolean;
    /** Counts visible descendant rows, traversing completed transparent nodes. */
    export function countCollapsedRows(step: mls.msg.AIPayload): number;
}
declare module "_102025_/l2/shared/interfaces" {
    import type * as base from "_102036_/l2/shared/interfaces";
    export * from "_102036_/l2/shared/interfaces";
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export interface RequestCreateAttachmentUpload extends base.RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends base.ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends base.RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestDeleteAttachment extends base.RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestGetAttachmentUrl extends base.RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends base.ResponseBase {
        url: string;
        expiresAt: string;
    }
    module "_102036_/l2/shared/interfaces" {
        interface RequestUpdateMessage {
            pin?: boolean;
            favorite?: boolean;
            readConfirmation?: 'request' | 'confirm' | 'cancel' | 'requestExecution' | 'reviewExecution';
            messageAction?: 'delete' | 'moderate' | 'createTask';
            editContent?: string;
            taskTitle?: string;
        }
        interface ResponseUpdateMessage {
            thread?: Thread;
            messages?: Message[];
            user?: User;
            users?: User[];
            task?: TaskData;
            taskRoomThread?: Thread;
        }
        interface RequestRemoveUserInThread {
            eventVisibility?: "all" | "admin";
        }
        interface ResponseRemoveUserInThread {
            messages?: Message[];
        }
        interface User {
            favorites?: string[];
            readConfirmations?: UserReadConfirmations;
        }
        interface UserReadConfirmations {
            pending?: string[];
            requested?: string[];
        }
        interface Message {
            readConfirmations?: MessageReadConfirmation[];
            attachments?: MessageAttachment[];
            moderation?: MessageModeration;
            edits?: MessageEditVersion[];
            editedAt?: string;
            editedBy?: string;
        }
        interface MessageModeration {
            status: "deleted" | "moderated";
            by: string;
            at: string;
        }
        interface MessageEditVersion {
            content: string;
            editedBy: string;
            editedAt: string;
        }
        interface MessageReadConfirmation {
            kind?: 'read' | 'execution';
            requestedBy: string;
            requestedAt: string;
            targetUserIds: string[];
            confirmedBy?: Record<string, string>;
            canceledAt?: string;
            canceledBy?: string;
            followupHistory?: MessageFollowupHistoryEntry[];
        }
        interface MessageFollowupHistoryEntry {
            userId: string;
            reaction: string;
            at: string;
        }
        interface Thread {
            pinnedMessages?: PinnedMessage[];
        }
        interface PinnedMessage {
            messageId: string;
            pinnedBy: string;
            pinnedAt: string;
            excerpt?: string;
        }
    }
}
declare module "_102025_/l2/collabMessagesEvents" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export function notifyMessageSendChange(context: msg.ExecutionContext): void;
    export function notifyTaskChange(context: msg.ExecutionContext, oldContextCreateAt?: string): void;
    /** Ephemeral step title on the client. No server, store, or intents. */
    export const STEP_TITLE_LOCAL_EVENT = "step-title-local";
    export const LOCAL_STEP_TITLE_MIN_MS = 500;
    export interface LocalStepTitleDetail {
        taskPK: string;
        stepId: number;
        title: string;
    }
    type LocalStepTitleThrottle = {
        at: number;
        title: string;
    };
    /** Pure tick decision: at most one event per step per ~500ms, drop a repeated same title. */
    export function shouldEmitLocalStepTitle(last: LocalStepTitleThrottle | undefined, now: number, title: string, minIntervalMs?: number): boolean;
    export function getLocalStepTitleEventScope(): Window | undefined;
    /**
     * Paint a step title in the open task UI. Fail-soft: no window (headless/CLI) is a silent no-op;
     * any throw is swallowed — an ornament must never kill a run.
     */
    export function changeLocalStepTitle(taskPK: string, stepId: number, title: string): void;
    /** Main-thread tick while a worker/await holds. No-op (and no timer) without window. */
    export function startLocalStepTitleTick(taskPK: string, stepId: number, makeTitle: (elapsedSec: number) => string, intervalMs?: number): () => void;
    export function notifyTaskCompleted(context: msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: msg.Thread): void;
    export function notifyMessageChange(message: msg.Message): void;
    export function notifyThreadNotification(show: boolean): void;
    export function notifyThreadCreate(thread: msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function dispatchDetailsTaskClick(messageId: string, taskId: string, task: msg.TaskData, message: msg.MessagePerformanceCache): void;
    export function dispatchThreadOpen(threadId: string, taskId?: string): void;
    /** Existing share-link format from createMessageLink: `#message/{threadId}` or `#message/{threadId}/{messageId}`. */
    export function threadOpenFromHash(hash: string): {
        threadId: string;
        messageId?: string;
    } | undefined;
    export function notifyTaskMetaChanged(payload: {
        taskId: string;
        taskTitle: string;
        threadId: string;
    }): void;
    export interface ICollabMessageEvent {
        threadId: string;
        taskId?: string;
    }
}
declare module "_102025_/l2/aiAgentDefaultFeedbackLocalTitle" {
    export interface LocalStepTitleEntry {
        title: string;
        status?: string;
    }
    export type LocalStepTitles = Map<number, LocalStepTitleEntry>;
    export function applyLocalStepTitle(current: LocalStepTitles, shownTaskPK: string | undefined, event: {
        taskPK?: string;
        stepId?: number;
        title?: string;
    }, stepStatus?: string): LocalStepTitles;
    export function dropLocalTitlesOnTaskChange(current: LocalStepTitles, shownTaskPK: string | undefined, eventTaskPK: string | undefined): LocalStepTitles;
    export function dropLocalTitleIfStatusChanged(current: LocalStepTitles, stepId: number, status: string | undefined): LocalStepTitles;
    export function displayedStepTitle(step: {
        stepId: number;
        stepTitle?: string;
        status?: string;
        type?: string;
        agentName?: string;
        toolName?: string;
    }, local: LocalStepTitles): string;
}
declare module "_102025_/l2/aiAgentDefaultFeedback" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class AiAgentDefaultFeedback102025 extends StateLitElement {
        father: HTMLElement | undefined;
        task?: mls.msg.TaskData;
        message?: mls.msg.Message;
        selectedStep: mls.msg.AIPayload | null;
        selectedTraceStep: mls.msg.AIPayload | null;
        isAgentParallelMode: boolean;
        private openCapableAgents;
        private openedView;
        private userExpanded;
        private userCollapsed;
        private localTitles;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private onLocalStepTitle;
        private onDurableTaskChange;
        private statusOf;
        firstUpdated(): Promise<void>;
        updated(_changedProperties: Map<PropertyKey, unknown>): void;
        private resolveOpenCapableAgents;
        private clickOpen;
        private renderOpenedView;
        private getTitle;
        private getIconStep;
        private getIconTask;
        private rowIndex;
        private getChildren;
        private toggleBranch;
        private renderStep;
        private renderTaskRootDetails;
        private renderActions;
        private clickDetails;
        private pauseOrContinueTask;
        private restartPoolingTask;
        private renderTaskProgress;
        private renderTree;
        private renderDetails;
        private renderTrace;
        private renderLogItem;
        private tryParseJSON;
        render(): any;
        private iconError;
        private iconPending;
        private iconTaskPaused;
        private iconOk;
        private iconWaitingHumam;
        private iconWaitingAfter;
    }
}
declare module "_102025_/l2/collabMessages.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesIndexedDB" {
    export * from "_102036_/l2/collabMessagesIndexedDB";
}
declare module "_102025_/l2/shared/api" {
    export * from "_102036_/l2/shared/api";
}
declare module "_102025_/l2/notificationsRuntime" {
    import type { CollabMessagesEnvironment } from "_102036_/l2/environmentContract";
    /** Bounded poll matching the runtime shell mls-lib load window (~20s at 300ms). */
    export const MLS_LIB_RETRY_MS = 300;
    export const MLS_LIB_RETRIES = 67;
    export function hasPushSubscriptionCapability(): boolean;
    export function isNotificationPermissionDenied(): boolean;
    export const notificationsRuntime: NonNullable<CollabMessagesEnvironment["notifications"]>;
}
declare module "_102029_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export type StudioRunMode = 'studio' | 'studioClient';
    /**
     * Where the studio chrome is running:
     * - 'studio'       — on.collab.codes: the full IDE, every org/project.
     * - 'studioClient' — the client server's app page: the studio runs embedded and is
     *                    scoped to the single project that app belongs to.
     *
     * The client server (startServer, mls-102034) injects window.collabBoot on every app
     * page; the studio page never has it. Do NOT use window.mls or #collabNav1 as the
     * signal — cbeMiniCfe boots the lib and creates that marker on the client app too.
     */
    export function getStudioRunMode(): StudioRunMode;
    export function isStudioClient(): boolean;
    /**
     * The single project the studio-client is pinned to; undefined in 'studio' mode.
     *
     * `clientProjectId` first: it is the workspace's client project, which is what the studio edits.
     * `projectId` is the owner of the SERVED MODULE, so entering through a platform module
     * (monitor/mdm/audit, owned by the master backend) pinned the studio to the master and the client's
     * services never appeared — measured on 102047.collabcodes.com, 23/09/2026.
     * `projectId` stays as the fallback for a server that does not send the new field yet;
     * mls.actualProject is the last resort when the payload carries no usable id.
     */
    export function getStudioScopeProject(): number | undefined;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102029_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 44 color ROLES. Each role carries 4 keys: the base plus
     *  `-hover`, `-focus` and `-disabled` — and a `_dark-` twin for every one of them. */
    export const MANDATORY_COLOR_ROLES: readonly ["page-bg", "surface-bg", "surface-alt-bg", "input-bg", "text-strong", "text-default", "text-muted", "border-default", "border-subtle", "button-primary-bg", "button-primary-text", "button-secondary-bg", "button-secondary-text", "button-secondary-border", "button-danger-bg", "button-danger-text", "link-text", "focus-ring", "selected-bg", "selected-text", "selected-border", "status-success-bg", "status-success-text", "status-error-bg", "status-error-text", "status-warning-bg", "status-warning-text", "status-info-bg", "status-info-text", "status-neutral-bg", "status-neutral-text", "nav-bg", "nav-text", "nav-active-bg", "nav-active-text", "overlay-backdrop-bg", "tooltip-bg", "tooltip-text", "chart-series-1", "chart-series-2", "chart-series-3", "chart-series-4", "chart-series-5", "chart-series-6"];
    export type MandatoryColorRole = typeof MANDATORY_COLOR_ROLES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102029_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102029_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102029_/l2/designSystemEditorBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102029_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102029_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102025_/l2/collabMessagesHelper" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export const AGENTDEFAULT = "agentPlanner1";
    export function registerToken(): Promise<msg.PushSubscriptionData>;
    export function addMessage(threadId: string, messageContent: string, contextToBot?: msg.ToolsBeforeSendMessage): Promise<msg.ExecutionContext>;
    export function getArgsToBots(): Promise<Record<string, any>>;
    export function getBotsContext(thread: msg.Thread, prompt: string, context: msg.ExecutionContext): Promise<Record<string, any>>;
    export function saveNotificationDeviceId(deviceId: string): void;
    export function loadNotificationDeviceId(): string | null;
    export function saveNotificationToken(tokenFCM: string): void;
    export function loadNotificationToken(): string | null;
    export function saveNotificationPreferences(notificationPreference: NotificationPermission): void;
    export function loadNotificationPreferences(): NotificationPermission | null;
    export function saveNotificationPreferencesAudio(enable: boolean): void;
    export function loadNotificationPreferencesAudio(): boolean;
    export function saveLastAlertTime(time: number): void;
    export function loadLastAlertTime(): number | undefined;
    export function saveLastTab(lastTab: string): void;
    export function loadLastTab(): string;
    export function saveUserId(userId: string): void;
    export function getUserId(): string | null;
    export function loadChatPreferences(): IChatPreferences;
    export function saveChatPreferences(chatPreferences: IChatPreferences): void;
    export function loadOpenClawIntegrations(): Promise<msg.IOpenClawIntegration[]>;
    export function saveOpenClawIntegrations(integrations: msg.IOpenClawIntegration[]): Promise<void>;
    export function checkThreadAlreadyExist(threadName: string): Promise<void>;
    export function getDmThreadByUsers(userId1: string, userId2: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThread(threadName: string, languages: string[], visibility: msg.ThreadVisibility, avatar_url?: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThreadDM(threadName: string, dmUser: string, group: msg.ThreadGroup): Promise<msg.Thread>;
    export function formatTimestamp(timestamp: string): {
        dateFull: string;
        date: string;
        time: string;
        timeShort: string;
    };
    export function getDateFormated(dt: string): string;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => msg.ExecutionContext;
    export function findAgentInIntegrationsByUserId(collabUserId: string): Promise<{
        name: string;
        agentId: string;
        connectorId: string;
    }>;
    export function generateUUIDv7(): string;
    export function generateAgentAvatar(name: string): string;
    export function changeFavIcon(notification: boolean): Promise<void>;
    export type TranslateMode = "none" | "icon" | "text" | "iconText" | "trace";
    export interface IChatPreferences {
        translationMode: TranslateMode;
        language: string;
        threadMaintenance: string;
    }
    export interface CollabMessagesLS {
        lastTab?: string;
        chatPreferences?: IChatPreferences;
        userId?: string;
        tokenFCM?: string;
        deviceId?: string;
        notificationPreference?: NotificationPermission;
        notificationAudio?: boolean;
        lastNotificationAlertTime?: number;
    }
    export interface IMessage extends msg.MessagePerformanceCache {
        context?: msg.ExecutionContext;
        lastChanged?: number;
        isSame?: boolean;
        isLoading?: boolean;
        isFailed?: boolean;
        isFailedError?: string;
    }
    export interface IThreadInfo {
        thread: msg.ThreadPerformanceCache;
        threadsPending?: string[];
        users: msg.User[];
        hasMore?: boolean | undefined;
        messages?: msg.Message[] | undefined;
    }
}
declare module "_102025_/l2/collabMessagesSyncNotifications" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export function isNotificationTraceEnabled(): boolean;
    export function traceNotification(event: string, fields?: {
        reference?: string;
        [key: string]: unknown;
    }): void;
    /** Boot: localStorage.collabTraceNotification === 'true' liga o trace sem rebuild. */
    export function applyNotificationTraceFromStorage(): boolean;
    export const threadSyncMap: Map<string, boolean>;
    type NotificationTarget = {
        threadId: string;
        sourceThreadId: string;
        taskId?: string;
    };
    export function removeThreadFromSync(threadId: string): void;
    export function clearThreadNotification(threadId: string): void;
    export function clearTaskNotification(taskId: string): void;
    export function refreshNotificationIndicator(): Promise<void>;
    export function markThreadReadLocally(threadId: string, lastMessageReadTime?: string, notificationTarget?: NotificationTarget): Promise<msg.ThreadPerformanceCache | undefined>;
    export function hasThreadNotificationPending(threadId: string): boolean;
    export function hasTaskNotificationPending(taskId: string): boolean;
    export function getPendingTaskNotificationsForThread(threadId: string): string[];
    export function checkIfNotificationUnread(): Promise<boolean>;
    export type NotificationOffer = 'none' | 'offer';
    export function getNotificationOffer(): NotificationOffer;
    export function resetNotificationSession(): void;
    /** Idempotent. Binds click/keydown/touchstart once so later programmatic play() is allowed. */
    export function unlockNotificationSound(): void;
    export function setNotificationSoundForTests(el: HTMLAudioElement | null): void;
    export function isTestplayCommand(value: string): boolean;
    export function isHelpCommand(value: string): boolean;
    export function isNotificationSoundUnlocked(): boolean;
    /** Local diagnostic: sound + badge + OS notification, no network, no addMessage. */
    export function runNotificationTestplay(): Promise<string>;
    export function startPageNotificationSound(threadId: string, reference: string): void;
    /** The page is the only sound source: the OS notification never silences it. */
    export function shouldPlayPageNotificationSound(opts: {
        audioEnabled: boolean;
        hasSound: boolean;
    }): boolean;
    /** Idempotent. Called by the collab-messages root once the user is known (post-login). */
    export function initNotifications(): Promise<void>;
    export function acceptNotificationOffer(): Promise<void>;
    export function dismissNotificationOffer(): void;
    export function listenToThreadEvents(): Promise<void>;
    export function getThreadUpdateInBackground(reference: string): Promise<void>;
}
declare module "_102025_/l2/collabMessagesIcons" {
    export const collab_message: any;
    export const collab_reply: any;
    export const collab_copy: any;
    export const collab_pin: any;
    export const collab_star: any;
    export const collab_paperclip: any;
    export const collab_edit: any;
    export const collab_delete: any;
    export const collab_smile: any;
    export const collab_chevron_down: any;
    export const collab_chevron_right: any;
    export const collab_clock_static: any;
    export const collab_users: any;
    export const collab_user: any;
    export const collab_magnifying_glass: any;
    export const collab_arrow_up_long: any;
    export const collab_minus: any;
    export const collab_ban: any;
    export const collab_dot: any;
    export const collab_bell: any;
    export const collab_money: any;
    export const collab_pause: any;
    export const collab_clock: any;
    export const collab_check: any;
    export const collab_bug_x12: any;
    export const collab_play: any;
    export const collab_bug: any;
    export const collab_chevron_left: any;
    export const collab_gear: any;
    export const collab_translate: any;
    export const collab_circle_exclamation: any;
    export const collab_circle_check: any;
    export const collab_plus: any;
    export const collab_folder_tree: any;
    export const collab_triangle_exclamation: any;
    export const collab_bell_slash: any;
    export const collab_xmark: any;
    export const collab_spinner_clock: any;
    export const collab_trash: any;
    export const collab_link: any;
    export const collab_plug: any;
    export const collab_robot: any;
    export const collab_refresh: any;
    export const collab_floppy_disk: any;
    export const collab_crm: any;
    export const collab_tasks: any;
    export const collab_connect: any;
    export const collab_moments: any;
    export const collab_apps: any;
    export const collab_warning: any;
    export const collab_signal: any;
    export const collab_eye: any;
    export const collab_eye_slash: any;
}
declare module "_102025_/l2/collabMessagesInputTag" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesInputTag extends StateLitElement {
        tags: string[];
        input: HTMLInputElement | undefined;
        pattern: string | null;
        placeholder: string | null;
        allowDelete: boolean;
        hasError: boolean;
        get value(): string;
        set value(val: string);
        onValueChanged: Function | undefined;
        addTag(tag: string): void;
        deleteTag(index: number): void;
        empty(): void;
        private _addTag;
        private _deleteTag;
        private _empty;
        private onInputLeave;
        private onInputKeyDown;
        private isValidTag;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesAdd" {
    import { CollabMessagesInputTag } from "_102025_/l2/collabMessagesInputTag";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesInputTag";
    export class CollabMessagesAdd extends StateLitElement {
        private msg;
        private threadType;
        private threadName;
        private visibility;
        private group;
        private languages;
        private isLoading;
        private dmUser;
        private users;
        agentsBots: IAgentsBots[];
        _selectedAgent: string;
        _initialMessage: string;
        _topics: string[];
        _agentConfig: string;
        _promptToAvatar: string;
        labelOk: string;
        labelError: string;
        userId: string | undefined;
        languageInput?: CollabMessagesInputTag;
        onAddSuccess: Function | undefined;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private loadUsersAvaliables;
        private loadAgentsBotsAvaliables;
        private _renderAdd;
        private _handleChange;
        private renderBotsConfig;
        private renderInitialMessageConfig;
        private renderIconConfig;
        private validateForm;
        private addNewThread;
        private addBot;
        private generateAvatar;
        private extractSvgFromContext;
    }
    interface IAgentsBots {
        id: string;
        name: string;
        description: string;
        avatar_url: string;
        info?: {
            project: number;
            shortName: string;
            folder: string;
        };
    }
}
declare module "_102025_/l2/collabMessagesJohnSendError" {
    export function johnSendErrorMessage(error: string, language: string): string;
}
declare module "_102025_/l2/collabMessagesTask" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesTask extends StateLitElement {
        private msg;
        taskid: string;
        threadId: string;
        userId: string;
        messageid: string;
        lastChanged: string;
        status: string;
        notificationPending: boolean;
        task: msg.TaskData | undefined;
        context: msg.ExecutionContext | undefined;
        private secondsPassed;
        private lastStep;
        private timerId;
        private finalSnapshotSyncedKey;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        renderIconTask(): any;
        private resetTimer;
        private resetTimerState;
        private formatTime;
        private getTaskLocal;
        private shouldSyncFailedSnapshot;
        private getTaskSnapshotKey;
        private syncTaskFromServer;
        private onCardClick;
        private normalizeMessageId;
        private getAllSteps;
        private getNextPendentStep;
        private getTotalCost;
    }
}
declare module "_102025_/l2/collabMessagesTaskDetails" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesTaskDetails extends StateLitElement {
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        stepid: string;
        seen: Set<string>;
        interactionClarification: mls.msg.AIAgentStep | undefined;
        directClarification: HTMLElement | undefined;
        directClarificationContent: HTMLElement | undefined;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderTaskModeJson;
        private renderTaskModeDetails;
        private renderDirectResult;
        private renderDirectClarification;
        private hasPendingClarification;
        private renderlLongMemory;
        private renderTaskInfo;
        private renderTaskInteractions;
        private renderPayload;
        private renderPayloadAgent;
        private renderInteration;
        private renderAgent;
        private renderTool;
        private renderClarificationDetails;
        private renderFlexible;
        private renderClarification;
        private renderResult;
        private setClarification;
        private executeHTMLClarificationScript;
        private syntaxHighlight;
        private onTaskChange;
    }
}
declare module "_102025_/l2/requestMonacoLoad" {
    type Fire = (levels: mls.Level[] | mls.Level, types: mls.events.TypeEvent[] | mls.events.TypeEvent, desc?: string, timeout?: number) => Promise<void>;
    /**
     * Ask the host to load Monaco. Does **not** create `window.monacoReady`.
     *
     * If the requester creates that promise first, the host
     * (`ensureMonacoReady` in 102041 / `loadMonacoScript` in 102033) sees it
     * already exists, never captures its resolver, and `script.onload` resolves
     * nothing — the tab hangs forever. Only the host creates and resolves it.
     *
     * `fire(..., 0)` delivers now (`await fireEvents`), so the listener has
     * already run when this returns. Then we await the host's promise.
     */
    export function requestMonacoLoad(mls: {
        events?: {
            fire?: Fire;
        };
    }, timeoutMs?: number): Promise<void>;
}
declare module "_102025_/l2/collabMessagesTaskPreviewAgent" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewAgent extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIAgentStep | null;
        agentDescription: string;
        private prompts;
        private mode;
        private monacoLoadError;
        elEditor: IHTMLEditorElement | undefined;
        private lastKey;
        private get sharedEditor();
        private get sharedMonaco();
        firstUpdated(): void;
        update(changedProperties: any): void;
        updated(changedProperties: Map<string, any>): void;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderInputs(): any;
        renderTools(tools: any[], toolChoice: any): any;
        private toolName;
        private renderJsonCard;
        renderPayload(): any;
        renderPrompt(prompt: mls.msg.IAMessageInputType, idx: number): any;
        renderResults(): any;
        private init;
        private getDescription;
        private getPrompts;
        private selectTabInput;
        private selectTabInfo;
        private selectTabResult;
        private selectTabPayload;
        private ensureEditorCreated;
        private mountEditor;
        /**
         * Monaco is no longer guaranteed to be loaded outside the Studio dev environment
         * (Ctrl+Alt+S) — this preview (the Payload tab) is a normal end-user feature, so it asks
         * the host via LoadMonaco instead of importing the shell that hosts it.
         */
        private loadMonacoThenMount;
        private createModel;
        private updateEditorContent;
        private getPayloadTabValue;
        private hasPayloadTabValue;
        private getTracePayload;
        private parseTracePayloadItem;
        private isTracePayloadItem;
        private readonly editorConf;
        private canRestartStep;
        private isParallelChild;
        private restartStep;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewClarification" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewClarification extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIClarificationStep | null;
        private mode;
        private tag;
        clarificationid: HTMLDivElement | undefined;
        private elClarification;
        firstUpdated(): void;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderClarification(): any;
        renderResults(): any;
        private selectTabClarification;
        private selectTabInfo;
        private getFile;
        private getAgentBeforeStep;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewFlexible" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewFlexible extends CollabLitElement {
        private mode;
        private monacoLoadError;
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIFlexibleResultStep | null;
        msize: string;
        elEditor: IHTMLEditorElement | undefined;
        private get sharedEditor();
        private get sharedMonaco();
        firstUpdated(): Promise<void>;
        updated(changedProps: Map<string, any>): void;
        private ensureEditorCreated;
        /**
         * Called every time the flexible tab becomes visible.
         * Creates the shared editor once, then re-appends it to the fresh #elEditor node.
         */
        private mountEditor;
        /**
         * Monaco is no longer guaranteed to be loaded outside the Studio dev environment
         * (Ctrl+Alt+S) — this preview is a normal end-user feature, so it asks the host via
         * LoadMonaco instead of importing the shell that hosts it.
         */
        private loadMonacoThenMount;
        private createModel;
        private updateEditorContent;
        render(): any;
        private setMode;
        private renderMode;
        private renderInfo;
        private renderSummary;
        private renderFlexible;
        private renderResults;
        private readonly editorConf;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewTools" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewTools extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIToolStep | null;
        private mode;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderTools(): any;
        renderResults(): any;
        private selectTabTools;
        private selectTabInfo;
        private selectTabResult;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewResult" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewResult extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIResultStep | null;
        private mode;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderResults(): any;
        private selectTabInfo;
        private selectTabResult;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewRaw" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewRaw extends CollabLitElement {
        private mode;
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIFlexibleResultStep | null;
        msize: string;
        elEditor: IHTMLEditorElement | undefined;
        private resizeObserver;
        private get sharedEditor();
        private get sharedMonaco();
        firstUpdated(): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProps: Map<string, any>): void;
        private ensureEditorCreated;
        /**
         * Called every time the flexible tab becomes visible.
         * Creates the shared editor once, then re-appends it to the fresh #elEditor node.
         */
        private mountEditor;
        private observeEditorHost;
        private createModel;
        private updateEditorContent;
        private layoutEditor;
        render(): any;
        private setMode;
        private renderMode;
        private renderInfo;
        private renderTaskModeDetails;
        private renderTaskInfo;
        private renderlLongMemory;
        private renderSummary;
        private renderFlexible;
        private renderResults;
        private readonly editorConf;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreview" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_102025_/l2/collabMessagesTaskPreviewAgent";
    import "_102025_/l2/collabMessagesTaskPreviewClarification";
    import "_102025_/l2/collabMessagesTaskPreviewFlexible";
    import "_102025_/l2/collabMessagesTaskPreviewTools";
    import "_102025_/l2/collabMessagesTaskPreviewResult";
    import "_102025_/l2/collabMessagesTaskPreviewRaw";
    export class CollabMessagesTaskPreview extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        modeTest: boolean;
        father: HTMLElement | undefined;
        initialStep: string;
        private stepMap;
        private navigationStack;
        private currentStepId;
        private allSteps;
        private lastStepId;
        private payloadStepIds;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderStep(): any;
        renderNavigation(stepId: number): any;
        private navigableStepIds;
        private setCurrentStep;
        private goFirst;
        private goPrev;
        private goNext;
        private goLast;
        renderStepDetails(step: any | undefined): any;
        renderBreadcrumb(): any;
        renderRaw(): any;
        renderAgent(step: mls.msg.AIAgentStep): any;
        renderClarification(step: mls.msg.AIClarificationStep): any;
        renderFlexible(step: mls.msg.AIFlexibleResultStep): any;
        renderTools(step: mls.msg.AIToolStep): any;
        renderResult(step: mls.msg.AIResultStep): any;
        renderWorkflow(step: {
            stepId: number;
            type: string;
            workflowName?: string;
            status?: string;
            nextSteps?: any[];
        }): any;
        private init;
        private onTaskChange;
        private buildStepMap;
        private tryNext;
        private navigateToStep;
        private goBack;
    }
}
declare module "_102025_/l2/collabMessagesTaskLogPreview" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/aiAgentDefaultFeedback";
    export class PluginTaskLogPreview102025 extends StateLitElement {
        currentStepId: number;
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        father: HTMLElement | undefined;
        template?: TemplateResult;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProperties: any): void;
        render(): any;
        private onTaskChange;
        private createFeedBack;
    }
}
declare module "_102025_/l2/collabMessagesEmojis" {
    export interface IEmoji {
        unicode: string;
        shortname: string;
        aliases: string[];
    }
    export const emojiList: {
        text: string;
        value: string;
        description: string;
        alias: string[];
    }[];
}
declare module "_102025_/l2/collabMessagesAvatar" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesAvatar extends StateLitElement {
        avatar: string;
        alt: string;
        width: string;
        height: string;
        updated(changedProperties: Map<string, any>): void;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesRichTextParser" {
    export type RichToken = {
        type: 'text';
        value: string;
    } | {
        type: 'bold';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'italic';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'strike';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'inline-code';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'code-block';
        language: string;
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'mention';
        value: string;
        userId: string;
    } | {
        type: 'agent';
        value: string;
    } | {
        type: 'channel';
        value: string;
    } | {
        type: 'command';
        value: string;
    } | {
        type: 'help';
        value: string;
    } | {
        type: 'link';
        text: string;
        url: string;
    } | {
        type: 'raw-link';
        url: string;
    } | {
        type: 'heading';
        level: number;
        children: RichToken[];
    } | {
        type: 'horizontal-rule';
    } | {
        type: 'blockquote';
        children: RichToken[];
        lines: RichToken[][];
    } | {
        type: 'list';
        ordered: boolean;
        items: RichListItem[];
    };
    export interface RichListItem {
        marker: string;
        children: RichToken[];
    }
    export function parseRichText(input: string): RichToken[];
    export function parseInlineRichText(input: string, skipCodeBlock?: boolean): RichToken[];
}
declare module "_102025_/l2/collabMessagesPromptOverlay" {
    export type OverlaySegmentKind = 'text' | 'newline' | 'marker' | 'bold' | 'italic' | 'strike' | 'inline-code' | 'code-block' | 'mention' | 'agent' | 'channel' | 'command' | 'help' | 'link';
    export interface OverlaySegment {
        kind: OverlaySegmentKind;
        text: string;
    }
    export const OVERLAY_TRAILING_SENTINEL = "\u200B";
    export function buildOverlaySegments(text: string): OverlaySegment[];
    export function needsTrailingSentinel(text: string): boolean;
    export function normalizeLineBreaks(text: string): string;
    export function overlayText(segments: OverlaySegment[]): string;
}
declare module "_102025_/l2/collabMessagesPromptEditing" {
    export interface EditResult {
        text: string;
        selectionStart: number;
        selectionEnd: number;
    }
    interface LineInfo {
        start: number;
        end: number;
        text: string;
    }
    interface ListMarker {
        indent: string;
        marker: string;
        spacing: string;
        content: string;
        ordered: boolean;
    }
    export function getLineInfo(text: string, cursor: number): LineInfo;
    export function replaceRange(text: string, start: number, end: number, value: string, cursorOffset?: number): EditResult;
    export function insertText(text: string, selectionStart: number, selectionEnd: number, value: string, cursorOffset?: number): EditResult;
    export function getListMarker(line: string): ListMarker | undefined;
    export function getNextListPrefix(marker: ListMarker): string;
    export function applySmartNewline(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function indentSelection(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function outdentSelection(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function wrapSelection(text: string, selectionStart: number, selectionEnd: number, before: string, after: string, placeholder?: string): EditResult;
    export function makeCodeBlock(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function makeLinePrefix(text: string, selectionStart: number, selectionEnd: number, prefix: string): EditResult;
}
declare module "_102025_/l2/collabMessagesPrompt" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesAvatar";
    export function serializeUserMentions(text: string, users: msg.User[]): string;
    export function deserializeUserMentions(text: string, users?: msg.User[]): string;
    export class CollabMessagesPrompt extends StateLitElement {
        private msg;
        textArea: HTMLTextAreaElement | undefined;
        overlayElement?: HTMLElement;
        mentionSuggestionsElement?: HTMLElement;
        wrapper?: HTMLElement;
        text: string;
        actualMention?: IMentions;
        mentionActive: boolean;
        mentionQuery: string;
        mentionSuggestions: IMentions[];
        mentionIndex: number;
        allUsers: msg.User[];
        allUsersValids: msg.User[];
        hasSelection: boolean;
        selectedFiles: File[];
        sendError: string;
        isSending: boolean;
        allAgents: IMentionAgent[];
        alreadyLoadingAgents: boolean;
        lastScopeLoaded: string | undefined;
        replyingTo?: {
            messageId: string;
            senderId: string;
            preview: string;
        };
        onSend: Function | undefined;
        threadId?: string;
        placeholder?: string;
        scope?: string;
        allowAttachments: boolean;
        showSubmitButton: boolean;
        submitOnEnter: boolean;
        acceptAutoCompleteUser?: boolean;
        acceptAutoCompleteAgents?: boolean;
        enableRichPreview?: boolean;
        connectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        setReply(message: {
            messageId: string;
            senderId: string;
            preview: string;
        }): void;
        clearReply(): void;
        private getUsers;
        private getAgents;
        private getCaretCoordinates;
        private calculatePosition;
        private adjustTextAreaHeight;
        private handleScroll;
        private renderOverlaySegment;
        private renderRichOverlay;
        render(): any;
        private renderToolbar;
        private renderReply;
        private renderSelectedAttachments;
        handleFocus(): Promise<void>;
        handleInput(e: MouseEvent): Promise<void>;
        private preventToolbarFocus;
        private updateSelectionState;
        private clearSelectionState;
        private applyEditResult;
        private syncTextAreaEdit;
        private applyInlineFormat;
        private applyCodeBlock;
        private applyLinePrefix;
        private applyLink;
        private openAttachmentPicker;
        private handleAttachmentInput;
        private removeSelectedAttachment;
        private emitTextChange;
        private formatFileSize;
        private getUserSuggestions;
        private getAgentSuggestions;
        private getEmojiSuggestions;
        private handleKeyDown;
        private handlePaste;
        private scrollToActiveMention;
        private selectMention;
        private extractAgentName;
        handleSend(): Promise<void>;
    }
    interface IMentionAgent {
        name: string;
        description: string;
        alias: string;
        avatar_url?: string;
    }
    interface IMentions {
        text: string;
        value: string;
        description: string;
        avatar_url?: string | undefined;
        type: 'user' | 'agent' | 'emoji';
    }
}
declare module "_102025_/l2/collabMessagesE01Context" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesE01Context extends StateLitElement {
        userId: string;
        threadId: string;
        sourceMessageId: string;
        sessionKey: string;
        variant: 'source' | 'response';
        private open;
        private phase;
        private execution?;
        private error;
        private feedback;
        private identity;
        updated(changed: Map<PropertyKey, unknown>): void;
        render(): any;
        private renderPanel;
        private renderSources;
        private toggle;
        private load;
        private cancel;
        private openSource;
        private statusLabel;
        private reasonLabel;
        private clearPrivateState;
        private identityToken;
        private copy;
    }
}
declare module "_102025_/l2/e02AudioPolling" {
    export interface E02AudioPollScheduler {
        schedule(callback: () => void, delayMs: number): unknown;
        cancel(token: unknown): void;
    }
    /** One bounded polling chain. Calling start twice never replenishes its budget. */
    export class E02AudioPollingSession {
        private readonly delayMs;
        private readonly poll;
        private readonly scheduler;
        private timer?;
        private running;
        private generation;
        private remaining;
        constructor(maxPolls: number, delayMs: number, poll: () => Promise<boolean>, scheduler?: E02AudioPollScheduler);
        get active(): boolean;
        get pollsRemaining(): number;
        start(): void;
        stop(): void;
        private scheduleNext;
        private tick;
    }
}
declare module "_102025_/l2/e02AudioPrivacy" {
    export interface E02PrivateViewCache<T> {
        audioUrl: string;
        processingId: string;
        processing: T | undefined;
        correctionDraft: string;
        interpretationRequest: string;
        selectedVersion: number | null;
        feedback: string;
    }
    export function e02ErrorStatus(error: unknown): number | null;
    export function isE02AccessRevokedError(error: unknown): boolean;
    /** Pure fail-closed reducer used by the UI and its privacy regression tests. */
    export function clearE02PrivateCacheOnAccessError<T>(error: unknown, current: E02PrivateViewCache<T>): {
        revoked: boolean;
        cache: E02PrivateViewCache<T>;
    };
}
declare module "_102025_/l2/collabMessagesE02Audio" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export const E02_AUDIO_UI_LIMITS: Readonly<{
        maxFileBytes: 524288;
        maxDurationSeconds: 60;
        maxCorrectionChars: 12000;
        maxInterpretationRequestChars: 2000;
    }>;
    export type E02PhaseState = 'not_requested' | 'validated' | 'admitted' | 'sent' | 'uncertain' | 'completed' | 'failed' | 'cancelled' | 'obsolete';
    export type E02TranscriptStatus = 'speech' | 'no_speech' | 'unintelligible';
    export interface E02AudioReceipt {
        localRequests: 0 | 1;
        providerAttempts: number | null;
        costChargedUsd: number | null;
        resolvedModel: string | null;
        reconciliationPending: boolean;
    }
    export interface E02TranscriptVersion {
        version: number;
        origin: 'model' | 'human' | 'deterministic';
        detectorVersion?: 'wav-pcm16-zero.v1';
        text: string;
        createdAt: string;
        status?: E02TranscriptStatus;
        uncertainties?: Array<{
            excerpt: string;
            reason: string;
        }>;
    }
    export interface E02AudioProcessingProjection {
        contractVersion: 'john-audio.v1';
        processingId: string;
        sourceAvailable: boolean;
        transcription: {
            state: E02PhaseState;
            receipt: E02AudioReceipt | null;
            result?: {
                status: E02TranscriptStatus;
                text: string;
                uncertainties: Array<{
                    excerpt: string;
                    reason: string;
                }>;
                origin?: 'model' | 'deterministic';
                detectorVersion?: 'wav-pcm16-zero.v1';
            };
        };
        review: {
            state: 'not_available' | 'awaiting_review' | 'reviewed';
            selectedVersion: number | null;
            versions: E02TranscriptVersion[];
        };
        interpretation: {
            state: E02PhaseState;
            transcriptVersion: number | null;
            contextVersion: string | null;
            contextSourceIds: string[];
            receipt: E02AudioReceipt | null;
            request?: string;
            result?: {
                answer: string;
                inferences: Array<{
                    statement: string;
                    basis: 'transcript' | 'confirmed_context' | 'both';
                }>;
            };
        };
        error: {
            code: string;
            phase: 'validation' | 'transcription' | 'interpretation';
            retryable: boolean;
        } | null;
    }
    export type E02GetAudioProcessingRequest = {
        action: 'getAudioProcessing';
        userId: string;
        processingId: string;
        source?: never;
    } | {
        action: 'getAudioProcessing';
        userId: string;
        source: {
            threadId: string;
            messageId: string;
            attachmentId: string;
        };
        processingId?: never;
    };
    export class CollabMessagesE02Audio extends StateLitElement {
        private readonly controlId;
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
        fileName: string;
        sizeBytes: number;
        contentType: string;
        sessionKey: string;
        processingId: string;
        fixture?: E02AudioProcessingProjection;
        private audioUrl;
        private durationSeconds;
        private durationInvalid;
        private processing?;
        private busy;
        private error;
        private feedback;
        private noProcessing;
        private correctionDraft;
        private interpretationRequest;
        private selectedVersion;
        private correctionInput?;
        private identity;
        private pollingSession?;
        private loadGeneration;
        private readGeneration;
        private discovering;
        private readonly idempotencyKeys;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changed: Map<PropertyKey, unknown>): void;
        render(): any;
        private renderProcessing;
        private renderTranscript;
        private renderTranscriptVersion;
        private renderInterpretation;
        private renderReceipt;
        private loadAudio;
        private openAudio;
        private onMetadata;
        private onAudioError;
        private requestTranscription;
        private saveCorrection;
        private requestInterpretation;
        private cancelProcessing;
        private perform;
        private loadProcessing;
        private applyProcessing;
        private selectVersion;
        private startPolling;
        private stopPolling;
        private hasActivePhase;
        private isActive;
        private statusLabel;
        private isFormatEligible;
        private operationKey;
        private identityToken;
        private copy;
        private safeError;
        private formatFileSize;
        private revokeAudioUrl;
        private clearRevokedAccess;
        private clearPrivateState;
    }
}
declare module "_102025_/l2/collabMessagesChatMessage" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IChatPreferences, IMessage, IThreadInfo } from "_102025_/l2/collabMessagesHelper";
    import "_102025_/l2/collabMessagesE01Context";
    import "_102025_/l2/collabMessagesE02Audio";
    export class CollabMessagesChatMessage102025 extends StateLitElement {
        message?: IMessage;
        messageId?: string;
        allThreads: msg.Thread[];
        actualThread: IThreadInfo | undefined;
        usersAvaliables: msg.User[];
        currentUser: msg.User | undefined;
        userId: string | undefined;
        e01SessionKey: string;
        toolbarHighlighted: boolean;
        openedReactionMessageId?: string;
        reactionPickerTarget?: HTMLElement;
        openedMenuFor?: string;
        messageMenuTarget?: HTMLElement;
        openedReactionListMessageId?: string;
        reactionListTarget?: HTMLElement;
        openedFollowupActionsMessageId?: string;
        followupActionTarget?: HTMLElement;
        followupActionAnchor?: DOMRect;
        userPreferenceChat?: IChatPreferences;
        private messageMenuPlacement;
        private reactionListPlacement;
        private isEditingMessage;
        private editContent;
        private showEditHistory;
        private showFullContent;
        private showFullTaskError;
        onTaskClick?: Function;
        private msg;
        private readonly documentClickHandler;
        private readonly documentScrollHandler;
        private readonly reactionEmojis;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(): void;
        render(): any;
        private renderMessage;
        private renderE01Context;
        private renderMessageByLanguage;
        private renderMessageContentByLanguage;
        private renderModerationNotice;
        private renderEditMessageForm;
        private renderEditHistory;
        private renderHistoryToggle;
        private hasMessageHistory;
        private hasReadConfirmationHistory;
        private renderAttachments;
        private renderAttachment;
        private isJohnAudioThread;
        private renderDeleteAttachmentButton;
        private openAttachment;
        private refreshAttachmentImage;
        private loadAttachmentUrl;
        private onDeleteAttachmentClick;
        private canDeleteAttachment;
        private canWriteThread;
        private canModerateThread;
        private isMessageContentHidden;
        private canDeleteMessage;
        private canModerateMessage;
        private canEditMessage;
        private parseCompactDate;
        private getUserName;
        private formatFileSize;
        private replyCache;
        private renderReplyPreview;
        private loadReplyPreview;
        private onReplyPreviewClick;
        private renderMessageResultByLanguage;
        private renderReadConfirmations;
        private renderExecutionFollowup;
        private getReadConfirmationStatusByUser;
        private getReadConfirmationKind;
        private getActiveExecutionFollowup;
        private getFollowupStatusItems;
        private hasExecutionFollowup;
        private isFollowupReaction;
        private getFollowupReactionForUser;
        private renderFollowupIcon;
        private getFollowupLabel;
        private renderUserLabel;
        private formatLocalDateTime;
        private renderMessageFooterResult;
        private renderCollabMessagesRichPreview;
        private renderSeeMoreButton;
        private onMentionClick;
        private positionModalByTarget;
        private isCurrentThreadDirectMessage;
        private onChannelHover;
        private removeAllUserModal;
        private removeAllChannelModal;
        private getTitleMessageTranslated;
        private renderReactions;
        private renderReactionListPopup;
        private findUser;
        private getEmojiReactionListItems;
        private getFollowupReactionListItems;
        private getReactionListItems;
        private getReactionSummaryItems;
        private getReadConfirmationSummaryItems;
        private getReadConfirmationReactionListItems;
        private getActiveReadConfirmationStatuses;
        private getReactionIcon;
        private getReactionLabel;
        private openReactionList;
        private updateReactionListPlacement;
        private removeReactionFromList;
        private closeReactionList;
        private renderSideAction;
        private renderFollowupQuickActions;
        private getFollowupActions;
        private renderReactionButtonAdd;
        private renderReactionPicker;
        private onPickerEmojiSelect;
        private onReadConfirmationPickerClick;
        private onFollowupActionClick;
        private openFollowupActionMenu;
        private closeFollowupActionMenu;
        private onDocumentClick;
        private isPopupInteractionTarget;
        private closeLocalPopups;
        private openReactionPicker;
        private closeReactionPicker;
        private toggleReaction;
        private updateReactionOnDb;
        private animateReactionPicker;
        private positionReactionPicker;
        private positionFollowupActionMenu;
        private renderSubMenuButton;
        private openMessageMenu;
        private positionMessageMenu;
        private closeMessageMenu;
        private renderMessageMenu;
        private onReplyClick;
        private onCopyTextClick;
        private onCopyLinkClick;
        private getMessageLink;
        private onMarkUnreadClick;
        private onForwardClick;
        private onEditClick;
        private onEditCancelClick;
        private onEditSaveClick;
        private onViewHistoryClick;
        private onHistoryToggleClick;
        private onPinClick;
        private onFavoriteClick;
        private onReadConfirmationClick;
        private onFollowupActionsMenuClick;
        private onMessageActionClick;
        private isPinned;
        private isFavorite;
        private getMentionedUserIds;
        private hasReadConfirmation;
        private hasPendingReadConfirmation;
        private hasAllReadConfirmationsConfirmed;
        private canCancelReadConfirmation;
        private closeAllPopups;
        private updateMessageMenuPlacement;
        private getMessageOrderAt;
        private normalizeMessageId;
    }
}
declare module "_102025_/l2/collabMessagesTaskRoom" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import * as msg from "_102025_/l2/shared/interfaces";
    import "_102025_/l2/collabMessagesChatMessage";
    import "_102025_/l2/collabMessagesPrompt";
    export class CollabMessagesTaskRoom extends StateLitElement {
        task: msg.TaskData | undefined;
        message: msg.Message | undefined;
        userId: string | undefined;
        private roomThread;
        private roomUsers;
        private messages;
        private loading;
        private error;
        private showScrollToBottom;
        private messagesContainer?;
        private ensuredKey;
        private lastRenderedMessageCount;
        private didInitialScroll;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private onMessagesScroll;
        private scrollToBottom;
        private scrollMessagesToBottom;
        private ensureRoom;
        private ensureRoomOnServer;
        private openKnownRoom;
        private syncMessages;
        private loadLocalMessages;
        private markRoomReadLocally;
        private sendMessage;
        private cacheRoomThread;
        private getLastOrderAt;
        private getResponseLastOrderAt;
        private onThreadChange;
        private onMessageChange;
        private getUserId;
        private getParentThreadId;
        private getEnsureKey;
        private canUseTaskRoom;
        private toMessageView;
    }
}
declare module "_102025_/l2/collabMessagesTaskInfo" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesTaskDetails";
    import "_102025_/l2/collabMessagesTaskPreview";
    import "_102025_/l2/collabMessagesTaskLogPreview";
    import "_102025_/l2/collabMessagesTaskRoom";
    type TaskInfoTab = 'workflow' | 'step' | 'raw' | 'todo' | 'chat' | 'statistics';
    export type TaskLLMCall = {
        stepId: number;
        title: string;
        provider: string;
        model: string;
        alias: string;
        stage: string;
        inputTokens: number;
        outputTokens: number;
        cost: number;
        llmMs: number;
    };
    export type TaskModelStatistic = {
        key: string;
        provider: string;
        model: string;
        alias: string;
        stage: string;
        calls: number;
        inputTokens: number;
        outputTokens: number;
        cost: number;
        llmMs: number;
        tps: number;
    };
    export type TaskExecutionStatistics = {
        totalSteps: number;
        interactions: number;
        totalCost: number;
        interactionCost: number;
        traceCost: number;
        llmCalls: number;
        inputTokens: number;
        outputTokens: number;
        totalLlmMs: number;
        totalExecutionMs: number;
        errorCount: number;
        failedSteps: number;
        fallbackCount: number;
        traceRecords: number;
        jsonTraceRecords: number;
        byStatus: Record<string, number>;
        byType: Record<string, number>;
        models: TaskModelStatistic[];
        slowestCalls: TaskLLMCall[];
        errorLines: string[];
    };
    export function roundMoneyUpToCents(value: number): number;
    export function buildTaskStatistics(task: mls.msg.TaskData | undefined): TaskExecutionStatistics;
    export class CollabMessagesTaskInfo extends StateLitElement {
        private elParent;
        private contentPluginStyle;
        private forceViewRaw;
        private hasTodo;
        private currentStepId;
        private msg;
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        restartPooling: boolean;
        isTest: boolean;
        stepid: string;
        seen: Set<string>;
        interactionClarification: mls.msg.AIAgentStep | undefined;
        directClarification: HTMLElement | undefined;
        directClarificationContent: HTMLElement | undefined;
        private activeTab;
        isClarificationPending: boolean;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        renderTab(isClarificationPending?: boolean): any;
        renderTabContent(activeTab: TaskInfoTab): any;
        renderRaw(): any;
        renderStep(): any;
        renderTodo(): any;
        renderChat(): any;
        renderStatistics(): any;
        renderDirectClarification(): any;
        private hasPendingClarification;
        renderClarification(payload: mls.msg.AIClarificationStep): any;
        private clickForceViewRaw;
        private setClarification;
        private executeHTMLClarificationScript;
        private setTab;
        private renderStatKpi;
        private renderModelsTable;
        private renderStatsBars;
        private renderSlowCalls;
        private formatMoney;
        private formatInteger;
        private formatTps;
        private getNumberLocale;
        private formatDuration;
        private canUseTaskRoom;
        private onTaskChange;
        private normalizeServiceDetailContainer;
        private restoreServiceDetailContainer;
    }
}
declare module "_102025_/l2/collabMessagesTopics" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesTopics extends StateLitElement {
        messages: IMessage[];
        topics: string[];
        expanded: boolean;
        selectedTopic: string | null;
        threadTopics: string[];
        render(): any;
        private emitTopic;
        private extractTopics;
        private groupTopics;
        private getHeadersTopicsFromMessages;
        private getTopicsFromMessagesOrdered;
    }
    interface IMessage extends msg.MessagePerformanceCache {
        context?: msg.ExecutionContext;
    }
}
declare module "_102025_/l2/collabMessagesAddParticipant" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesAddParticipant extends StateLitElement {
        private msg;
        userId: string | undefined;
        labelOkAddParticipant: string;
        labelErrorAddParticipant: string;
        userIdOrName: string;
        auth: msg.UserAuth;
        isAddParticipant: boolean;
        actualThread: IThreadActual | undefined;
        highlightedIndex: number;
        suggestions: string[];
        allUsers: string[];
        private users;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private onInput;
        private onBlur;
        private selectSuggestion;
        private onKeyDown;
        private onFocus;
        private onSubmitAddParticipant;
        private loadUsersAvaliables;
    }
    interface IThreadActual {
        thread: msg.ThreadPerformanceCache;
        users: msg.User[];
    }
}
declare module "_102025_/l2/collabMessagesChangeAvatar" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabChangeAvatar extends StateLitElement {
        private msg;
        value?: string;
        nameValue?: string;
        userId: string;
        threadId: string;
        private avatarPrompt;
        private avatarFile?;
        private isOpen;
        private generating;
        private preview?;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private onFileSelect;
        private triggerFileInput;
        private generateAvatarFromPrompt;
        private emitValueChanged;
        private safeSvg;
    }
}
declare module "_102025_/l2/collabMessagesThreadDetails" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesInputTag";
    import "_102025_/l2/collabMessagesAddParticipant";
    import "_102025_/l2/collabMessagesChangeAvatar";
    export class CollabMessagesThreadDetails extends StateLitElement {
        private msg;
        userId: string | undefined;
        threadDetails?: IThreadDetails;
        avatarEl?: HTMLElement;
        labelOk: string;
        labelError: string;
        labelErrorRemoveUser: string;
        labelErrorRemoveBoot: string;
        labelErrorAgent: string;
        labelOkAgent: string;
        private isLoading;
        private editedThreadDetails?;
        private isDirectMessage?;
        private isChannel?;
        private isFileChannel?;
        private isEditingDetails;
        private showAgentForm;
        private integrations;
        private selectedIntegrationId;
        private selectedAgentId;
        private isLoadingAgents;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        private loadIntegrations;
        updated(changedProperties: Map<string, any>): Promise<void>;
        private getAddedAgentIds;
        private getAvailableAgents;
        private getVisibilityLabel;
        private getCurrentUserNotification;
        private setCurrentUserNotification;
        private getStatusLabel;
        private getCurrentUserThreadAuth;
        private canManageThread;
        private canModerateThread;
        private isLastAdmin;
        private enterEditMode;
        private cancelEditMode;
        render(): any;
        private renderDetailsViewMode;
        private renderDetailsEditMode;
        private renderUsers;
        private renderAvatar;
        private isUrl;
        private renderAgents;
        private renderAgentFormContent;
        private findAgentInfo;
        private openAgentForm;
        private closeAgentForm;
        private addAgentOpenClawInThread;
        private addIntegrationOpenClawInThread;
        private saveAgentOpenClaw;
        private removeAgentOpenClaw;
        private updateStatusAgent;
        private renderBots;
        private removeUser;
        private removeBot;
        private disableBot;
        private getChangedFields;
        private onAddParticipant;
        private saveChanges;
        private removeUserFromThread;
        private getThreadInfo;
    }
    interface IThreadDetails {
        thread: msg.ThreadPerformanceCache;
        users: msg.User[];
    }
}
declare module "_102025_/l2/collabMessagesUserModal" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesUserModal extends StateLitElement {
        private msg;
        open: boolean;
        user?: msg.User;
        actualUserId?: string;
        isDirectMessage: boolean;
        private isLoading;
        private errorMessage;
        private close;
        private handleGlobalClick;
        firstUpdated(): void;
        disconnectedCallback(): void;
        private destroy;
        render(): any;
        private onClickUserAction;
    }
}
declare module "_102025_/l2/collabMessagesThreadModal" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesAvatar";
    export class CollabMessagesThreadModal extends StateLitElement {
        private msg;
        open: boolean;
        thread?: msg.ThreadPerformanceCache;
        private isLoading;
        private errorMessage;
        private handleGlobalMouseMove;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        disconnectedCallback(): void;
        private destroy;
        render(): any;
        private onClickThreadAction;
    }
}
declare module "_102025_/l2/collabMessagesFilter" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesFilter extends StateLitElement {
        private expanded;
        private query;
        placeholder: string;
        private toggleExpand;
        private handleKey;
        private handleInput;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesTextCode" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesTextCode extends StateLitElement {
        config: string | undefined;
        language: string;
        languages: any[];
        text: string;
        codeBlock: HTMLElement | undefined;
        select: HTMLSelectElement | undefined;
        private _resolveRendered;
        private markRendered;
        whenRendered: Promise<void>;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        private unescapeHtml;
        private getHighlightLanguage;
        private markRenderedAfterPaint;
        setCode(): void;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesRichPreviewText" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesTextCode";
    export class CollabMessagesRichPreviewText102025 extends StateLitElement {
        private msg;
        allHelpers: string[];
        allCommands: string[];
        allThreads: msg.Thread[];
        allUsers: msg.User[];
        text: string;
        showMarkers: boolean;
        private expandedCodeBlocks;
        render(): any;
        private renderTokens;
        private renderMarker;
        private renderToken;
        private renderText;
        private renderBold;
        private renderItalic;
        private renderStrike;
        private renderInlineCode;
        private renderCodeBlock;
        private openBugReport;
        private toggleCodeBlock;
        private renderAgent;
        private renderMention;
        private renderChannel;
        private renderCommand;
        private renderHelp;
        private renderLink;
        private renderRawLink;
        private renderHeading;
        private renderBlockquote;
        private renderList;
        private normalizeLinkHref;
        private copyToClipboard;
    }
}
declare module "_102025_/l2/collabMessagesE01Memory" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesE01Memory extends StateLitElement {
        userId: string;
        threadId: string;
        sessionKey: string;
        private view?;
        private phase;
        private busy;
        private notice;
        private editing?;
        private editValue;
        private identity;
        private operationKeys;
        connectedCallback(): void;
        updated(changed: Map<PropertyKey, unknown>): void;
        render(): any;
        private renderLegacy;
        private renderSection;
        private renderProposals;
        private renderSources;
        private reload;
        private decide;
        private correct;
        private invalidate;
        private mutate;
        private openSource;
        private startEditing;
        private stopEditing;
        private clearPrivateState;
        private identityToken;
        private newKey;
        private copy;
    }
}
declare module "_102025_/l2/collabMessagesChat" {
    import "_102025_/l2/collabMessagesTask";
    import "_102025_/l2/collabMessagesTaskInfo";
    import "_102025_/l2/collabMessagesTopics";
    import "_102025_/l2/collabMessagesPrompt";
    import "_102025_/l2/collabMessagesAvatar";
    import "_102025_/l2/collabMessagesThreadDetails";
    import "_102025_/l2/collabMessagesUserModal";
    import "_102025_/l2/collabMessagesThreadModal";
    import "_102025_/l2/collabMessagesFilter";
    import "_102025_/l2/collabMessagesAdd";
    import "_102025_/l2/collabMessagesChatMessage";
    import "_102025_/l2/collabMessagesRichPreviewText";
    import "_102025_/l2/collabMessagesE01Memory";
    import * as msg from "_102025_/l2/shared/interfaces";
    import { IMessage, IThreadInfo } from "_102025_/l2/collabMessagesHelper";
    import { CollabMessagesPrompt } from "_102025_/l2/collabMessagesPrompt";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesChat extends StateLitElement {
        private msg;
        collabMessagesPrompt: CollabMessagesPrompt | undefined;
        private unreadEl;
        private messageContainer;
        private isLoadingThread;
        private filteredThreads;
        private isThreadError;
        private threadErrorMsg;
        private lastTopicFilter;
        private welcomeMessage;
        private usersAvaliables;
        private elementTaskDetails;
        private taskNotificationNavDirection;
        private toolbarView;
        group: 'CONNECT' | 'APPS' | 'DOCS' | 'CRM';
        userId: string | undefined;
        threadToOpen: string | undefined;
        taskToOpen: string | undefined;
        userDeviceId: string | undefined;
        e01RootSessionKey: string;
        activeScenerie: IScenery;
        actualThread: IThreadInfo | undefined;
        actualTask: msg.TaskData | undefined;
        actualMessage: IMessage | undefined;
        actualMessages: IMessage[];
        actualMessagesParsed: IMessageGrouped;
        isLoadingMessages: boolean;
        searchTerm: string;
        userThreads: IThread;
        allThreads: msg.Thread[];
        lastMessageReaded: string | undefined;
        unreadCountInSelectedThread: number;
        private forwardMessageSource?;
        private forwardDestinationQuery;
        private forwardDestinationThreadId;
        private forwardError;
        private isForwardingMessage;
        private highlightedMessageId;
        private toolbarHelpKind?;
        private toolbarNavigationKind?;
        private toolbarNavigationFailedKind?;
        private toolbarNavigationError;
        private cachedToolbarMessages;
        private showPersonalMemory;
        private e01SessionEpoch;
        private isSystemChangeScroll;
        private savedScrollTop;
        private hasMoreMessagesLocalDB;
        private hasMoreMessagesBefore;
        private messagesLimit;
        private isLoadingMoreMessages;
        private isChangeTopics;
        private wasMessagesAtBottom;
        private ignoreToolbarScrollClearUntil;
        private isToolbarAutoScroll;
        private toolbarAutoScrollTimer?;
        private personalMemoryTrigger?;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderHeader;
        private renderContent;
        private renderChatMessages;
        private renderTaskNotificationNav;
        private renderForwardMessage;
        private renderForwardDestination;
        private renderToolbarHelp;
        private getToolbarHelpContent;
        private closeToolbarHelp;
        private renderTaskNotificationNavIcon;
        private renderWelcomeMessage;
        private renderTopics;
        private renderThreadToolbar;
        private renderToolbarCounter;
        private navigateToolbarItem;
        private getToolbarTitle;
        private clearToolbarSelection;
        private getNextToolbarIndex;
        private getAttachmentMessages;
        private getAgentMessages;
        private getMessagesKnownToToolbar;
        private openToolbarHelp;
        private getFavoriteMessageIdsForThread;
        private getReadConfirmationMessageIdsForThread;
        private hasPendingReadConfirmationsForThread;
        private getLoadedMessageById;
        private getReadConfirmationMessageIdsFromLoadedMessages;
        private isReadConfirmationRelevantForCurrentUser;
        private isReadConfirmationPendingForCurrentUser;
        private isReadConfirmationRequestedByCurrentUser;
        private getReadConfirmationKind;
        private getFollowupReactionForUser;
        private getCurrentUser;
        private navigateToMessageId;
        private normalizeToolbarMessageId;
        private getLocalMessageById;
        private renderMessageWindowFromLocalCache;
        private renderMessageWindowFromServer;
        private buildMessageWindowFromTarget;
        private applyToolbarMessageWindow;
        private parseMessageId;
        private getMessageCacheKey;
        private isSameMessageId;
        private scrollToMessageId;
        private deferToolbarAutoScrollEnd;
        private isMessageHighlightedByToolbar;
        private onTopicClick;
        private removeAllModal;
        private renderPrompt;
        private getCurrentThreadUserAuth;
        private canWriteCurrentThread;
        private showReadOnlyThreadError;
        private renderListThreads;
        private getThreadAvatar;
        private getThreadName;
        private isDirectMessage;
        private renderThreadsByStatus2;
        private renderThreadItemLi;
        private renderTaskPendingsCount;
        private formatMessageDate;
        private renderArchivedThreads;
        private renderDeletingThreads;
        private renderDeletedThreads;
        private renderThreadSearch;
        private renderTaskDetails;
        private renderThreadDetails;
        private renderThreadAdd;
        private onSearchInput;
        private getScrollAnchor;
        private restoreScrollAnchor;
        private updateMessagesAfterScrollMore;
        private getBeforeMessagesInServer;
        private getBeforeMessagesInLocalDb;
        private onCopyChat;
        private onChatScroll;
        private getFirstPendingTaskNotificationInView;
        private getTaskNotificationElement;
        private updateTaskNotificationNavDirection;
        private scrollToTaskNotification;
        private groupThreadsByPrefix;
        private getOrdenedThreadsByStatus;
        private getFilteredThreads;
        private getMessagesAfter;
        private getMessagesBefore;
        private parseMessages;
        private groupMessages;
        private parseLocalDate;
        private mergeMessages;
        private onThreadClick;
        private updateThreadPendingsInBackground;
        private markActualThreadRead;
        private clearUnreadMarkerForActualThread;
        private getLastKnownMessageCreateAt;
        private openTask;
        private checkWelcomeMessage;
        private refreshCachedToolbarMessages;
        private checkNotificationsUnreadMessages;
        private loadAllMessages;
        private updateMessagesOnDb;
        private clearUnreadMessageFromThread;
        private shouldPreserveUnreadMarker;
        private getFirstUnreadMessageCreateAt;
        private getUnreadMessagesCount;
        private updateLastMessage;
        private onTitleClick;
        private onThreadDetailsClick;
        private openPersonalMemory;
        private isJohnE01Thread;
        private onE01OpenSource;
        private closePersonalMemory;
        private getE01SessionKey;
        private onThreadAddClick;
        private showLocalSystemMessage;
        private handleSend;
        private handlePromptResize;
        private scrollMessagesToBottom;
        private addMessage;
        private addAttachmentMessage;
        private addMessageIA;
        private updateMessageAI;
        private createTempMessage;
        private updateMessage2;
        private onTaskClick;
        private openTaskDetailsPanel;
        private hasStudioTaskDetailHost;
        private createLocalTaskDetails;
        private onReplyPreviewClick;
        private onReplyMessageClick;
        private onPinMessageClick;
        private onFavoriteMessageClick;
        private onReadConfirmationMessageClick;
        private onMessageActionMessageClick;
        private onEditMessageClick;
        private applyMessageUpdateResponse;
        private onMarkUnreadMessageClick;
        private onForwardMessageClick;
        private onForwardDestinationInput;
        private selectForwardDestination;
        private cancelForwardMessage;
        private confirmForwardMessage;
        private getForwardDestinationSuggestions;
        private isForwardDestinationAllowed;
        private getForwardThreadSortTime;
        private isDirectMessageThread;
        private getForwardThreadName;
        private renderForwardDestinationAvatar;
        private createTaskTitleFromMessage;
        private createMessageLink;
        private onDeleteAttachmentMessage;
        private updateCurrentUser;
        private updateUsersInState;
        private replaceUser;
        private getTaskUpdate;
        private clearMissingTaskReference;
        private normalizeTaskMessageId;
        private normalizeMessageId;
        private getThreadInfo;
        private saveScrollPosition;
        private restoreScrollPosition;
        private onTaskChange;
        private openCreatedTaskDetails;
        private onThreadChange;
        private onMessageChange;
        private onMessageSend;
        private onVisibilityChange;
        private onDocumentClick;
        private scrollLock;
        private verifyChatScroll;
        private delay;
        private nextFrame;
        private waitingForRenderCodesWebComponents;
    }
    type IMessageGrouped = {
        [key: string]: IMessage[];
    };
    type IThread = {
        [key: string]: IThreadInfo[];
    };
    type IScenery = 'list' | 'details' | 'loading' | 'task' | 'threadDetails' | 'threadAdd' | 'forwardMessage' | 'toolbarHelp';
}
declare module "_102027_/l2/libCommom" {
    export * from "_102029_/l2/libCommom";
}
declare module "_102025_/l2/collabTasksSidebar" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    type ScreenId = 'board' | 'mytasks' | 'workflows' | 'simulator' | 'approvals' | 'analytics' | 'settings';
    export class CollabTasksSidebar extends StateLitElement {
        activeScreen: ScreenId;
        private _emit;
        render(): any;
    }
}
declare module "_102025_/l2/collabTasksTheme" {
    /**
     * Shared theme utilities for the Tasks tab.
     * Board and My Tasks share the same localStorage key so theme changes
     * are reflected everywhere immediately.
     */
    import { TemplateResult } from 'lit';
    export type TasksTheme = 'clean' | 'amber' | 'forest' | 'trello' | 'clickup';
    export const TASKS_THEME_KEY = "collab-board-theme";
    export const TASKS_BG_KEY_PREFIX = "collab-tasks-bg-";
    export const TASKS_VALID_THEMES: TasksTheme[];
    export const THEME_BG_OPTIONS: Partial<Record<TasksTheme, {
        url: string;
        thumbUrl: string;
        label: string;
    }[]>>;
    export function loadTasksTheme(): TasksTheme;
    export function loadThemeBgUrl(theme: TasksTheme): string | null;
    export function saveThemeBgUrl(theme: TasksTheme, url: string): void;
    export function applyThemeToHost(theme: TasksTheme, host: HTMLElement): void;
    /**
     * Persist the theme, apply it to the given host, and broadcast the change
     * to any other open tasks screen so the picker / board / my-tasks stay in
     * sync without a reload. Listeners can re-apply the theme to their own host
     * with applyThemeToHost(theme, this).
     */
    export function saveTasksTheme(theme: TasksTheme, host: HTMLElement): void;
    export interface ThemeMeta {
        id: TasksTheme;
        labelPt: string;
        labelEn: string;
        descPt: string;
        descEn: string;
        hasImage: boolean;
    }
    export const THEME_LIST: ThemeMeta[];
    export function getThemeMeta(id: TasksTheme, lang: string): {
        label: string;
        desc: string;
    };
    export function themePreview(id: TasksTheme): TemplateResult;
    export function renderThemeCards(currentTheme: TasksTheme, lang: string, onSelect: (t: TasksTheme) => void): TemplateResult;
    export function renderImagePicker(theme: TasksTheme, currentUrl: string | null, lang: string, onSelect: (url: string) => void): TemplateResult;
}
declare module "_102025_/l2/collabTasksCard" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import * as msg from "_102025_/l2/shared/interfaces";
    export class CollabTasksCard extends StateLitElement {
        task: msg.TaskData | undefined;
        tagVocabulary: msg.TagVocabularyEntry[];
        boardStatus: string;
        connectedCallback(): void;
        updated(changed: Map<string, unknown>): void;
        private _applyStatusClass;
        render(): any;
        private _onClick;
        private _onKeyDown;
    }
}
declare module "_102025_/l2/collabTasksEmptyState" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabTasksEmptyState extends StateLitElement {
        title: string;
        subtitle: string;
        render(): any;
    }
}
declare module "_102025_/l2/collabTasksDesignTokens" {
    /**
     * Tasks design tokens.
     *
     * This is a TypeScript barrel for the companion `collabTasksDesignTokens.less`
     * file, which exposes a shared set of CSS variables (`--ct-*`) consumed by all
     * tasks components: board, my-tasks, card, settings, theme picker, etc.
     *
     * The tokens are declared at `:root` so they cascade everywhere — making them
     * available to other mls-102025 components that wish to adopt them later
     * without forcing a refactor today.
     *
     * Import this module from any tasks component to ensure the stylesheet is
     * pulled in by the enhancement loader.
     */
    export const CT_STATUS_ACCENT: {
        readonly todo: "#185fa5";
        readonly 'in progress': "#854f0b";
        readonly paused: "#6b7280";
        readonly done: "#3b6d11";
        readonly failed: "#a32d2d";
    };
    export const CT_TAG_ACCENT: {
        readonly bug: "#a32d2d";
        readonly feature: "#185fa5";
        readonly business: "#854f0b";
        readonly process: "#085041";
        readonly neutral: "#5f5e5a";
    };
    export type CtStatusKey = keyof typeof CT_STATUS_ACCENT;
    export type CtTagKey = keyof typeof CT_TAG_ACCENT;
}
declare module "_102025_/l2/collabTasksThemePicker" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabTasksDesignTokens";
    export class CollabTasksThemePicker extends StateLitElement {
        /** Visual density. 'compact' for inline popovers, 'panel' for standalone screens. */
        variant: 'compact' | 'panel';
        /** Hide the section title when the host already provides one. */
        hideTitle: boolean;
        private _theme;
        private _bgUrl;
        private _onThemeChanged;
        private _onBgChanged;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changed: Map<string, unknown>): void;
        private _onSelectTheme;
        private _onSelectBg;
        render(): any;
    }
}
declare module "_102025_/l2/collabTasksBoard" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabTasksCard";
    import "_102025_/l2/collabTasksEmptyState";
    import "_102025_/l2/collabTasksThemePicker";
    import "_102025_/l2/collabTasksDesignTokens";
    export class CollabTasksBoard extends StateLitElement {
        reloadKey: number;
        userId: string;
        organizationId: string;
        initialPmaFilter: string;
        private activeTasks;
        private closedTasks;
        private tagVocabulary;
        private loadingActive;
        private loadingClosed;
        private error;
        private _theme;
        private _showSettings;
        private _filterTags;
        private _filterPmaIds;
        private _initialFetchDone;
        private _refetchTimer;
        private _onTaskChange;
        private _onThreadChange;
        private _onTaskMetaChanged;
        private _onThemeChanged;
        private _onBgChanged;
        connectedCallback(): void;
        private _applyThemeClass;
        private _getFilterOptions;
        private _applyFilters;
        private _toggleTag;
        private _togglePmaId;
        private _clearFilters;
        disconnectedCallback(): void;
        updated(changed: Map<string, unknown>): void;
        private _fetchAll;
        private _fetchClosed;
        private _filterWorkflow;
        private _scheduleRefetch;
        private _handleTaskChange;
        private _handleThreadChange;
        private _handleTaskMetaChanged;
        private _bucket;
        render(): any;
        private _renderFilterBar;
        private _renderSettings;
        private _renderColumn;
        private _renderCard;
        private _renderSkeletons;
    }
}
declare module "_102025_/l2/collabTasksMyTasks" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabTasksThemePicker";
    import "_102025_/l2/collabTasksDesignTokens";
    export class CollabTasksMyTasks extends StateLitElement {
        userId: string;
        private activeTasks;
        private closedTasks;
        private loadingActive;
        private loadingClosed;
        private error;
        private showClosed;
        private _theme;
        private _showSettings;
        private _refetchTimer;
        private _onTaskChange;
        private _onTaskMetaChanged;
        private _onThemeChanged;
        private _onBgChanged;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private _applyThemeClass;
        private _fetchAll;
        private _fetchClosed;
        private _scheduleRefetch;
        private _handleTaskChange;
        private _handleTaskMetaChanged;
        private _openTask;
        render(): any;
        private _renderHeader;
        private _renderSettings;
        private _renderBody;
        private _renderTaskRow;
        private _renderSkeletons;
    }
}
declare module "_102025_/l2/collabTasksWorkflows" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabTasksWorkflows extends StateLitElement {
        userId: string;
        private groups;
        private loading;
        private error;
        connectedCallback(): void;
        private _fetchAll;
        render(): any;
        private _openInBoard;
        private _renderGroup;
        private _renderSkeletons;
    }
}
declare module "_102025_/l2/collabTasksApprovals" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabTasksApprovals extends StateLitElement {
        userId: string;
        private pending;
        private paused;
        private loading;
        private error;
        connectedCallback(): void;
        private _fetchAll;
        private _openTask;
        render(): any;
        private _renderRow;
        private _renderSkeletons;
    }
}
declare module "_102025_/l2/collabTasksAnalytics" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabTasksAnalytics extends StateLitElement {
        userId: string;
        private analytics;
        private loading;
        private error;
        connectedCallback(): void;
        private _fetchAll;
        render(): any;
        private _renderDashboard;
        private _tile;
        private _renderLoadingTiles;
    }
}
declare module "_102025_/l2/collabTasksSettings" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabTasksDesignTokens";
    export class CollabTasksSettings extends StateLitElement {
        userId: string;
        organizationId: string;
        private tagVocabulary;
        private loadingTags;
        private errorTags;
        private _onThemeChanged;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private _loadTags;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesTasks" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabTasksSidebar";
    export class CollabMessagesTasks extends StateLitElement {
        private screen;
        private _onBoardFilter;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private _openBoardWithFilter;
        render(): any;
        private _onScreenChange;
        private _openScreen;
    }
}
declare module "_102025_/l2/collabMessagesAppsMenu" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export interface IMenu {
        name: string;
        icon: string;
        project: number;
        path: string;
        menu: IMenuItem[];
    }
    export interface IMenuItem {
        title: string;
        icon: string;
        url: string;
        pageName: string;
        target?: string;
        children?: IMenuItem[];
    }
    type IFilter = 'all' | 'favorites' | 'history';
    export class CollabMessagesAppsMenu extends StateLitElement {
        private msg;
        keyFavoritesLocalStorage: string;
        keyHistoryLocalStorage: string;
        identifier: string;
        menuTitle: string;
        menuModules: IMenu[];
        favorites: string[];
        history: string[];
        searchTerm: string;
        activeFilter: IFilter;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        private getScope;
        private readStore;
        private loadFavorites;
        private loadHistory;
        private loadFilter;
        private setFilter;
        private getItemPath;
        private toggleFavorite;
        private isFavorite;
        private recordHistory;
        private handleMenuClick;
        private onSearch;
        private matchesSearch;
        private filterItems;
        private renderMenuItem;
        render(): any;
        private renderToolbar;
        private renderContent;
        private renderKeyList;
        private renderModules;
        private findItemByPath;
    }
}
declare module "_102025_/l2/collabMessagesApps" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import { type CollabProgramMenu } from "_102036_/l2/environmentContract";
    import "_102025_/l2/collabMessagesAppsMenu";
    export class CollabMessagesApps extends CollabLitElement {
        menuModules: CollabProgramMenu[];
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private handleMenuClick;
    }
}
declare module "_102025_/l2/collabMessagesMoments" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesMoments102025 extends StateLitElement {
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesSettingsOpenClaw" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import * as msg from "_102025_/l2/shared/interfaces";
    type ViewMode = 'main' | 'connectorDetails' | 'editAgent';
    interface IOpenClawConnectorLocal extends msg.OpenClawConnector {
        isNew?: boolean;
        gatewayTokenChanged?: boolean;
        inboundTokenChanged?: boolean;
    }
    export class CollabMessagesSettingsOpenClaw extends StateLitElement {
        private msg;
        userId: string;
        actualIntegration: msg.IOpenClawIntegration | undefined;
        integrations: msg.IOpenClawIntegration[];
        connectors: IOpenClawConnectorLocal[];
        viewMode: ViewMode;
        currentConnectorId: string;
        editingConnector: IOpenClawConnectorLocal | null;
        isTestingConnection: boolean;
        connectionTestResult: 'none' | 'success' | 'error' | 'warning';
        connectionTestMessage: string;
        connectionTestLatency: number;
        showGatewayToken: boolean;
        showInboundToken: boolean;
        copiedToken: 'gateway' | 'inbound' | null;
        showDeleteConfirmation: boolean;
        deleteConfirmationInput: string;
        newAgentName: string;
        newAgentAvatarUrl: string;
        editingAgent: msg.IOpenClawAgent | null;
        isNewAgent: boolean;
        newAgentWorkspace: string;
        newAgentEmoji: string;
        newAgentSoulMd: string;
        newAgentIdentityMd: string;
        showDeleteAgentConfirmation: boolean;
        agentToDelete: msg.IOpenClawAgent | null;
        deleteAgentFiles: boolean;
        isDeletingAgent: boolean;
        labelOkConnector: string;
        labelErrorConnector: string;
        labelOkAgent: string;
        labelErrorAgent: string;
        isSavingConnector: boolean;
        isSavingAgent: boolean;
        firstUpdated(): Promise<void>;
        render(): any;
        private renderOpenClawConnectors;
        private renderConnectorCard;
        private renderToggleIcon;
        private renderConnectorDetailsView;
        private renderConfigurationSection;
        private renderTestConnectionSection;
        private renderAgentSection;
        private renderDeleteSection;
        private renderDeleteConfirmation;
        private renderAgentCard;
        private renderDeleteAgentModal;
        private renderAvatar;
        private isUrl;
        private renderEditAgentView;
        private navigateTo;
        private handleAddConnector;
        private clearErrors;
        private clearStates;
        private getIntegration;
        private handleOpenConnectorDetails;
        private handleBackToMain;
        private handleCancelConnector;
        private handleConnectorNameChange;
        private handleConnectorUrlChange;
        private handleGatewayTokenChange;
        private handleInboundTokenChange;
        private handleChangeToken;
        private handleTimeoutChange;
        private handleOutputModeChange;
        private handleConnectorEnabledToggle;
        private handleGenerateToken;
        private handleSaveConnector;
        private saveIntegration;
        private removeIntegration;
        private saveOrUpdateOpenClawConnector;
        private handleTestConnection;
        private checkDomainExists;
        private handleToggleDeleteConfirmation;
        private handleDeleteConfirmationInput;
        private handleCancelDelete;
        private handleConfirmDelete;
        private handleOpenAddAgent;
        private handleOpenEditAgent;
        private handleBackToConnectorDetails;
        private handleNewAgentNameInput;
        private handleNewAgentAvatarInput;
        private handleNewAgentWorkspaceInput;
        private handleNewAgentEmojiInput;
        private handleNewAgentSoulMdInput;
        private handleNewAgentIdentityMdInput;
        private handleGenerateAgentAvatar;
        private handleSaveAgent;
        private handleOpenDeleteAgentConfirmation;
        private handleCloseDeleteAgentConfirmation;
        private handleDeleteAgentFilesChange;
        private handleConfirmDeleteAgent;
        private handleDisableAgent;
        private handleToggleTokenVisibility;
        private handleCopyToken;
    }
}
declare module "_102025_/l2/collabMessagesSettingsChatPreferences" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesSettingsChatPreferences extends StateLitElement {
        private msg;
        private chatPreferences;
        private isSaving;
        private labelOk;
        private labelError;
        firstUpdated(): Promise<void>;
        render(): any;
        private handleTranslationModeChange;
        private handleLanguageInput;
        private handleSave;
    }
}
declare module "_102025_/l2/collabMessagesSettingsUser" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesSettingsUser extends StateLitElement {
        private msg;
        private userPerfil;
        private viewMode;
        private isSaving;
        private labelOk;
        private labelError;
        private tempAvatarUrl;
        private avatarUrlValid;
        private avatarLoading;
        firstUpdated(): Promise<void>;
        render(): any;
        private renderUserSection;
        private renderEditAvatarView;
        private getUserPerfil;
        private handleNameInput;
        private handleSave;
        private handleOpenEditAvatar;
        private handleCancelEditAvatar;
        private handleAvatarUrlInput;
        private handleAvatarError;
        private handleSaveAvatar;
    }
}
declare module "_102025_/l2/collabMessagesSettingsNotificationPreferences" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesSettingsNotificationPreferences extends StateLitElement {
        private msg;
        private notificationPreferences;
        private audioEnabled;
        private isSaving;
        private labelOk;
        private labelError;
        firstUpdated(): Promise<void>;
        render(): any;
        private renderEnabled;
        private renderDisabled;
        private renderReadMore;
        private getNotificationStatus;
        private handleAudioToggle;
        private handleEnableNotifications;
    }
}
declare module "_102025_/l2/collabMessagesSettingsGeral" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesSettingsOpenClaw";
    import "_102025_/l2/collabMessagesSettingsChatPreferences";
    import "_102025_/l2/collabMessagesSettingsUser";
    import "_102025_/l2/collabMessagesSettingsNotificationPreferences";
    import * as msg from "_102025_/l2/shared/interfaces";
    type ViewMode = 'all' | 'user' | 'chat' | 'notification' | 'openclaw';
    export class CollabMessagesSettingsGeral102025 extends StateLitElement {
        private msg;
        viewMode: ViewMode;
        userPerfil: msg.User | undefined;
        private scrollPositions;
        private show;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderUser;
        private renderChatPreferences;
        private renderPreferencesNotifications;
        private renderOpenClawConnectors;
        private onSettingsChange;
        private getUserPerfil;
        private saveScrollPosition;
        private restoreScrollPosition;
        private navigateTo;
    }
}
declare module "_102025_/l2/collabMessagesTabMenu" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export interface TabMenuItem {
        id: string;
        icon: TemplateResult;
        label: string;
        activeColor?: string;
        type: 'tab' | 'button';
    }
    export class CollabMessagesTabMenu extends StateLitElement {
        items: TabMenuItem[];
        activeId: string;
        private get _tabs();
        private get _buttons();
        private _handleItemClick;
        private _renderItem;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessages" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_102025_/l2/collabMessagesAdd";
    import "_102025_/l2/collabMessagesChat";
    import "_102025_/l2/collabMessagesTasks";
    import "_102025_/l2/collabMessagesApps";
    import "_102025_/l2/collabMessagesMoments";
    import "_102025_/l2/collabMessagesSettingsGeral";
    import "_102025_/l2/collabMessagesTabMenu";
    export class CollabMessages extends CollabLitElement {
        private msg;
        dataLocal: IDataLocal;
        activeTab: ITabType;
        activeScenerie: IScenery;
        isLoadingThread: boolean;
        userPerfil: msg.User | undefined;
        userThreads: IThreadData;
        showNotificationAlert: boolean;
        notificationAlertKind: 'offer' | 'blocked';
        threadToOpen: string;
        taskToOpen: string;
        lastLevel: number;
        modeMenu: string;
        private e01RootSessionKey;
        private groupSelected;
        private hashOpenConsumed;
        private menuItems;
        connectedCallback(): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private checkNotificationPermission;
        private startPendentsPoolingsIfNeeded;
        private onThreadChange;
        private onThreadOpen;
        private setEvents;
        private removeEvents;
        renderHeader(): any;
        renderTabs(): any;
        renderAlert(): any;
        private onAlertEnable;
        private onAlertClose;
        renderCRM(): any;
        renderTasks(): any;
        renderMoments(): any;
        renderApps(): any;
        renderSettings(): any;
        renderConnect(): any;
        private newE01RootSessionKey;
        private getUser;
        private updateThreads;
        private searchForDeletedThreadsPending;
        private updateUsersThread;
        private getThreadFromLocalDB;
        private getThreadInfo;
        private onThreadCreate;
        private checkNotificationPending;
        private tryOpenFromHash;
        private onTabChange;
        private onButtonClick;
    }
    interface IDataLocal {
        lastTab: ITabType;
    }
    type IThreadData = {
        [key: string]: IThreadInfo;
    };
    interface IThreadInfo {
        thread: msg.Thread;
        users: msg.User[];
    }
    type ITabType = 'CRM' | 'TASK' | 'MOMENTS' | 'CONNECT' | 'APPS' | 'SETTINGS' | 'Add' | 'Loading';
    type IScenery = 'tabs' | 'settings' | 'findTask';
}
declare module "_102025_/l2/collabMessagesAdd.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesAddParticipant.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesApps.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesAppsMenu.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesAvatar.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesChangeAvatar.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesChat.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesChatMessage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesE02AudioFixtures" {
    import type { E02AudioProcessingProjection, E02GetAudioProcessingRequest } from "_102025_/l2/collabMessagesE02Audio";
    export const E02_GET_AUDIO_FIXTURES: readonly E02GetAudioProcessingRequest[];
    /** Visual-proof fixtures only. Nothing imports or activates these in the normal product path. */
    export const E02_AUDIO_VISUAL_FIXTURES: Readonly<{
        pending: {
            transcription: {
                state: "sent";
                receipt: any;
            };
            review: {
                state: "not_available";
                selectedVersion: any;
                versions: any[];
            };
            contractVersion: "john-audio.v1";
            processingId: string;
            sourceAvailable: boolean;
            interpretation: {
                state: import("/_102025_/l2/collabMessagesE02Audio.js").E02PhaseState;
                transcriptVersion: number | null;
                contextVersion: string | null;
                contextSourceIds: string[];
                receipt: import("/_102025_/l2/collabMessagesE02Audio.js").E02AudioReceipt | null;
                request?: string;
                result?: {
                    answer: string;
                    inferences: Array<{
                        statement: string;
                        basis: "transcript" | "confirmed_context" | "both";
                    }>;
                };
            };
            error: {
                code: string;
                phase: "validation" | "transcription" | "interpretation";
                retryable: boolean;
            } | null;
        };
        transcript: E02AudioProcessingProjection;
        corrected: {
            review: {
                state: "reviewed";
                selectedVersion: number;
                versions: import("/_102025_/l2/collabMessagesE02Audio.js").E02TranscriptVersion[];
            };
            contractVersion: "john-audio.v1";
            processingId: string;
            sourceAvailable: boolean;
            transcription: {
                state: import("/_102025_/l2/collabMessagesE02Audio.js").E02PhaseState;
                receipt: import("/_102025_/l2/collabMessagesE02Audio.js").E02AudioReceipt | null;
                result?: {
                    status: import("/_102025_/l2/collabMessagesE02Audio.js").E02TranscriptStatus;
                    text: string;
                    uncertainties: Array<{
                        excerpt: string;
                        reason: string;
                    }>;
                    origin?: "model" | "deterministic";
                    detectorVersion?: "wav-pcm16-zero.v1";
                };
            };
            interpretation: {
                state: import("/_102025_/l2/collabMessagesE02Audio.js").E02PhaseState;
                transcriptVersion: number | null;
                contextVersion: string | null;
                contextSourceIds: string[];
                receipt: import("/_102025_/l2/collabMessagesE02Audio.js").E02AudioReceipt | null;
                request?: string;
                result?: {
                    answer: string;
                    inferences: Array<{
                        statement: string;
                        basis: "transcript" | "confirmed_context" | "both";
                    }>;
                };
            };
            error: {
                code: string;
                phase: "validation" | "transcription" | "interpretation";
                retryable: boolean;
            } | null;
        };
        noSpeech: {
            transcription: {
                state: "completed";
                receipt: {
                    localRequests: 1;
                    providerAttempts: number;
                    costChargedUsd: number;
                    resolvedModel: string;
                    reconciliationPending: boolean;
                };
                result: {
                    status: "no_speech";
                    text: string;
                    uncertainties: any[];
                };
            };
            review: {
                state: "awaiting_review";
                selectedVersion: number;
                versions: {
                    version: number;
                    origin: "model";
                    text: string;
                    createdAt: string;
                    status: "no_speech";
                }[];
            };
            contractVersion: "john-audio.v1";
            processingId: string;
            sourceAvailable: boolean;
            interpretation: {
                state: import("/_102025_/l2/collabMessagesE02Audio.js").E02PhaseState;
                transcriptVersion: number | null;
                contextVersion: string | null;
                contextSourceIds: string[];
                receipt: import("/_102025_/l2/collabMessagesE02Audio.js").E02AudioReceipt | null;
                request?: string;
                result?: {
                    answer: string;
                    inferences: Array<{
                        statement: string;
                        basis: "transcript" | "confirmed_context" | "both";
                    }>;
                };
            };
            error: {
                code: string;
                phase: "validation" | "transcription" | "interpretation";
                retryable: boolean;
            } | null;
        };
        digitalSilence: {
            transcription: {
                state: "completed";
                receipt: {
                    localRequests: 0;
                    providerAttempts: number;
                    costChargedUsd: number;
                    resolvedModel: any;
                    reconciliationPending: boolean;
                };
                result: {
                    status: "no_speech";
                    text: string;
                    uncertainties: any[];
                    origin: "deterministic";
                    detectorVersion: "wav-pcm16-zero.v1";
                };
            };
            review: {
                state: "awaiting_review";
                selectedVersion: number;
                versions: {
                    version: number;
                    origin: "deterministic";
                    detectorVersion: "wav-pcm16-zero.v1";
                    text: string;
                    createdAt: string;
                    status: "no_speech";
                }[];
            };
            contractVersion: "john-audio.v1";
            processingId: string;
            sourceAvailable: boolean;
            interpretation: {
                state: import("/_102025_/l2/collabMessagesE02Audio.js").E02PhaseState;
                transcriptVersion: number | null;
                contextVersion: string | null;
                contextSourceIds: string[];
                receipt: import("/_102025_/l2/collabMessagesE02Audio.js").E02AudioReceipt | null;
                request?: string;
                result?: {
                    answer: string;
                    inferences: Array<{
                        statement: string;
                        basis: "transcript" | "confirmed_context" | "both";
                    }>;
                };
            };
            error: {
                code: string;
                phase: "validation" | "transcription" | "interpretation";
                retryable: boolean;
            } | null;
        };
        unintelligible: {
            transcription: {
                state: "completed";
                receipt: {
                    localRequests: 1;
                    providerAttempts: number;
                    costChargedUsd: number;
                    resolvedModel: string;
                    reconciliationPending: boolean;
                };
                result: {
                    status: "unintelligible";
                    text: string;
                    uncertainties: {
                        excerpt: string;
                        reason: string;
                    }[];
                };
            };
            review: {
                state: "awaiting_review";
                selectedVersion: number;
                versions: {
                    version: number;
                    origin: "model";
                    text: string;
                    createdAt: string;
                    status: "unintelligible";
                    uncertainties: {
                        excerpt: string;
                        reason: string;
                    }[];
                }[];
            };
            contractVersion: "john-audio.v1";
            processingId: string;
            sourceAvailable: boolean;
            interpretation: {
                state: import("/_102025_/l2/collabMessagesE02Audio.js").E02PhaseState;
                transcriptVersion: number | null;
                contextVersion: string | null;
                contextSourceIds: string[];
                receipt: import("/_102025_/l2/collabMessagesE02Audio.js").E02AudioReceipt | null;
                request?: string;
                result?: {
                    answer: string;
                    inferences: Array<{
                        statement: string;
                        basis: "transcript" | "confirmed_context" | "both";
                    }>;
                };
            };
            error: {
                code: string;
                phase: "validation" | "transcription" | "interpretation";
                retryable: boolean;
            } | null;
        };
        failed: {
            transcription: {
                state: "failed";
                receipt: {
                    localRequests: 1;
                    providerAttempts: number;
                    costChargedUsd: number;
                    resolvedModel: string;
                    reconciliationPending: boolean;
                };
            };
            review: {
                state: "not_available";
                selectedVersion: any;
                versions: any[];
            };
            error: {
                code: string;
                phase: "transcription";
                retryable: boolean;
            };
            contractVersion: "john-audio.v1";
            processingId: string;
            sourceAvailable: boolean;
            interpretation: {
                state: import("/_102025_/l2/collabMessagesE02Audio.js").E02PhaseState;
                transcriptVersion: number | null;
                contextVersion: string | null;
                contextSourceIds: string[];
                receipt: import("/_102025_/l2/collabMessagesE02Audio.js").E02AudioReceipt | null;
                request?: string;
                result?: {
                    answer: string;
                    inferences: Array<{
                        statement: string;
                        basis: "transcript" | "confirmed_context" | "both";
                    }>;
                };
            };
        };
        costUncertain: {
            transcription: {
                state: "uncertain";
                receipt: {
                    localRequests: 1;
                    providerAttempts: any;
                    costChargedUsd: any;
                    resolvedModel: any;
                    reconciliationPending: boolean;
                };
            };
            contractVersion: "john-audio.v1";
            processingId: string;
            sourceAvailable: boolean;
            review: {
                state: "not_available" | "awaiting_review" | "reviewed";
                selectedVersion: number | null;
                versions: import("/_102025_/l2/collabMessagesE02Audio.js").E02TranscriptVersion[];
            };
            interpretation: {
                state: import("/_102025_/l2/collabMessagesE02Audio.js").E02PhaseState;
                transcriptVersion: number | null;
                contextVersion: string | null;
                contextSourceIds: string[];
                receipt: import("/_102025_/l2/collabMessagesE02Audio.js").E02AudioReceipt | null;
                request?: string;
                result?: {
                    answer: string;
                    inferences: Array<{
                        statement: string;
                        basis: "transcript" | "confirmed_context" | "both";
                    }>;
                };
            };
            error: {
                code: string;
                phase: "validation" | "transcription" | "interpretation";
                retryable: boolean;
            } | null;
        };
        interpreted: {
            interpretation: {
                state: "completed";
                transcriptVersion: number;
                contextVersion: string;
                contextSourceIds: string[];
                request: string;
                receipt: {
                    localRequests: 1;
                    providerAttempts: number;
                    costChargedUsd: number;
                    resolvedModel: string;
                    reconciliationPending: boolean;
                };
                result: {
                    answer: string;
                    inferences: {
                        statement: string;
                        basis: "transcript";
                    }[];
                };
            };
            contractVersion: "john-audio.v1";
            processingId: string;
            sourceAvailable: boolean;
            transcription: {
                state: import("/_102025_/l2/collabMessagesE02Audio.js").E02PhaseState;
                receipt: import("/_102025_/l2/collabMessagesE02Audio.js").E02AudioReceipt | null;
                result?: {
                    status: import("/_102025_/l2/collabMessagesE02Audio.js").E02TranscriptStatus;
                    text: string;
                    uncertainties: Array<{
                        excerpt: string;
                        reason: string;
                    }>;
                    origin?: "model" | "deterministic";
                    detectorVersion?: "wav-pcm16-zero.v1";
                };
            };
            review: {
                state: "not_available" | "awaiting_review" | "reviewed";
                selectedVersion: number | null;
                versions: import("/_102025_/l2/collabMessagesE02Audio.js").E02TranscriptVersion[];
            };
            error: {
                code: string;
                phase: "validation" | "transcription" | "interpretation";
                retryable: boolean;
            } | null;
        };
        obsolete: {
            interpretation: {
                state: "obsolete";
                transcriptVersion: number;
                contextVersion: string;
                contextSourceIds: string[];
                receipt: {
                    localRequests: 1;
                    providerAttempts: number;
                    costChargedUsd: number;
                    resolvedModel: string;
                    reconciliationPending: boolean;
                };
            };
            error: {
                code: string;
                phase: "interpretation";
                retryable: boolean;
            };
            contractVersion: "john-audio.v1";
            processingId: string;
            sourceAvailable: boolean;
            transcription: {
                state: import("/_102025_/l2/collabMessagesE02Audio.js").E02PhaseState;
                receipt: import("/_102025_/l2/collabMessagesE02Audio.js").E02AudioReceipt | null;
                result?: {
                    status: import("/_102025_/l2/collabMessagesE02Audio.js").E02TranscriptStatus;
                    text: string;
                    uncertainties: Array<{
                        excerpt: string;
                        reason: string;
                    }>;
                    origin?: "model" | "deterministic";
                    detectorVersion?: "wav-pcm16-zero.v1";
                };
            };
            review: {
                state: "not_available" | "awaiting_review" | "reviewed";
                selectedVersion: number | null;
                versions: import("/_102025_/l2/collabMessagesE02Audio.js").E02TranscriptVersion[];
            };
        };
        unavailable: {
            sourceAvailable: boolean;
            contractVersion: "john-audio.v1";
            processingId: string;
            transcription: {
                state: import("/_102025_/l2/collabMessagesE02Audio.js").E02PhaseState;
                receipt: import("/_102025_/l2/collabMessagesE02Audio.js").E02AudioReceipt | null;
                result?: {
                    status: import("/_102025_/l2/collabMessagesE02Audio.js").E02TranscriptStatus;
                    text: string;
                    uncertainties: Array<{
                        excerpt: string;
                        reason: string;
                    }>;
                    origin?: "model" | "deterministic";
                    detectorVersion?: "wav-pcm16-zero.v1";
                };
            };
            review: {
                state: "not_available" | "awaiting_review" | "reviewed";
                selectedVersion: number | null;
                versions: import("/_102025_/l2/collabMessagesE02Audio.js").E02TranscriptVersion[];
            };
            interpretation: {
                state: import("/_102025_/l2/collabMessagesE02Audio.js").E02PhaseState;
                transcriptVersion: number | null;
                contextVersion: string | null;
                contextSourceIds: string[];
                receipt: import("/_102025_/l2/collabMessagesE02Audio.js").E02AudioReceipt | null;
                request?: string;
                result?: {
                    answer: string;
                    inferences: Array<{
                        statement: string;
                        basis: "transcript" | "confirmed_context" | "both";
                    }>;
                };
            };
            error: {
                code: string;
                phase: "validation" | "transcription" | "interpretation";
                retryable: boolean;
            } | null;
        };
        xssLiteral: {
            review: {
                state: "awaiting_review";
                selectedVersion: number;
                versions: {
                    version: number;
                    origin: "model";
                    text: string;
                    createdAt: string;
                    status: "speech";
                }[];
            };
            contractVersion: "john-audio.v1";
            processingId: string;
            sourceAvailable: boolean;
            transcription: {
                state: import("/_102025_/l2/collabMessagesE02Audio.js").E02PhaseState;
                receipt: import("/_102025_/l2/collabMessagesE02Audio.js").E02AudioReceipt | null;
                result?: {
                    status: import("/_102025_/l2/collabMessagesE02Audio.js").E02TranscriptStatus;
                    text: string;
                    uncertainties: Array<{
                        excerpt: string;
                        reason: string;
                    }>;
                    origin?: "model" | "deterministic";
                    detectorVersion?: "wav-pcm16-zero.v1";
                };
            };
            interpretation: {
                state: import("/_102025_/l2/collabMessagesE02Audio.js").E02PhaseState;
                transcriptVersion: number | null;
                contextVersion: string | null;
                contextSourceIds: string[];
                receipt: import("/_102025_/l2/collabMessagesE02Audio.js").E02AudioReceipt | null;
                request?: string;
                result?: {
                    answer: string;
                    inferences: Array<{
                        statement: string;
                        basis: "transcript" | "confirmed_context" | "both";
                    }>;
                };
            };
            error: {
                code: string;
                phase: "validation" | "transcription" | "interpretation";
                retryable: boolean;
            } | null;
        };
    }>;
}
declare module "_102025_/l2/collabMessagesEmojis.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesEnvironmentBase" {
    import type { CollabMessagesEnvironment } from "_102036_/l2/environmentContract";
    export const collabMessagesEnvironmentBase: Pick<CollabMessagesEnvironment, 'getAgents' | 'getIntegrationsOpenClaw' | 'setIntegrationsOpenClaw' | 'bots'>;
}
declare module "_102025_/l2/collabMessagesEvents.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesFilter.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesHelper.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesIcons.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesIndexedDB.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesInputTag.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesMoments.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesPrompt.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesRichPreviewText.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesRichTextParser.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesSettingsChatPreferences.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesSettingsGeral.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesSettingsNotificationPreferences.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesSettingsOpenClaw.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesSettingsUser.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesSyncNotifications.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTabMenu.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTask.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskLogPreview.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreview.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreviewAgent.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreviewClarification.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreviewFlexible.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreviewResult.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreviewTools.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTasks.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTextCode.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesThreadDetails.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesThreadModal.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTopics.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesUserModal.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabTasksTopbar" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabTasksTopbar extends StateLitElement {
        title: string;
        subtitle: string;
        render(): any;
        private _reload;
    }
}
declare module "_102025_/l2/designSystem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    /**
     * Project design system — ROLE-BASED token vocabulary.
     * Migrated from the old family-based model (text-primary-color, bg-secondary-color,
     * grey-color) to the canonical vocabulary of _102029_/l2/designSystemBase.ts
     * (DEFAULT_TOKENS_TEMPLATE). See TASK-102025-ds-tokens-por-papel.md.
     *
     * Naming rules (color):
     *  - The name says WHERE the token is used; never infer it from the value.
     *  - Pairs travel together: whoever paints with button-primary-bg writes the
     *    label with button-primary-text; status-error-bg goes with status-error-text;
     *    nav-bg with nav-text; tooltip-bg with tooltip-text. Holds for every
     *    <role>-bg / <role>-text pair.
     *  - Surfaces: page-bg (page background) > surface-bg (cards, panels, modals) >
     *    surface-alt-bg (zebra rows, row hover, skeleton, section headers). Text on
     *    surfaces: text-strong (titles), text-default (body), text-muted
     *    (secondary/placeholder).
     *  - Navigation (sidebar/topbar): nav-bg + nav-text; the active item uses
     *    nav-active-bg + nav-active-text.
     *  - Modal overlay: overlay-backdrop-bg behind, surface-bg on the modal.
     *  - Charts: series use chart-series-1..6 ALWAYS in this fixed order (the order
     *    IS the colour-blindness safeguard — never shuffle, never generate new
     *    colours); labels and axes use the text-* tokens, never the series colour;
     *    status-* are reserved for state and never become a chart series.
     *  - Every base colour token has -hover, -focus and -disabled variants (on
     *    chart-series, -disabled is the series dimmed by the legend).
     *  - Night mode: every key has a _dark- twin (same name). The compiler emits the
     *    dark block automatically; pages only ever use the base name.
     *
     * Where the values came from:
     *  - Roles with an origin in the old DS inherited the 102025 value (text greys,
     *    surfaces, the grey-* border scale, the #1890FF brand accent, state colours).
     *  - button-primary-bg comes from the old info-color (#0a6dc9): that is what
     *    painted .btn-save / button.activate / button.edit, not active-color.
     *    active-color (#1890FF) was selection and focus, so it feeds selected-text,
     *    selected-border, focus-ring and nav-active-text.
     *  - In dark, text-strong comes from _dark-text-primary-color-LIGHTER and
     *    text-muted from _dark-text-primary-color-DARKER: in the dark the lightest
     *    tone is the title and the darkest is the secondary text — an inversion the
     *    family-based model could not express.
     *  - status-*-bg did not exist: it is the `fade(<state colour>, 10%)` the .less
     *    files applied inline, now resolved as a token (and therefore theme-reactive).
     *  - Roles with no origin (page-bg, input-bg, button-secondary-*, selected-bg,
     *    status-neutral-*, nav-* other than nav-active-text, overlay-backdrop-bg,
     *    tooltip-*, chart-series-*) kept the template defaults.
     */
    export const tokens: IDesignSystemTokens[];
}
declare module "_102025_/l2/project.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102025_/l2/testLlmClient" {
    export interface CollabLlmConfig {
        baseUrl: string;
        token: string;
        org?: string;
    }
    export interface ToolProviderResult {
        modelType: string;
        status: number;
        text: string;
        args: unknown;
        schemaReject: boolean;
    }
    export function liveTestsEnabled(): boolean;
    export function liveRuns(): number;
    export function parseEnvFile(content: string): CollabLlmConfig;
    export function callToolProvider(cfg: CollabLlmConfig, opts: {
        modelType: string;
        system: string;
        human: string;
        tool: unknown;
        maxTokens?: number;
        timeoutMs?: number;
    }): Promise<ToolProviderResult>;
    export function callBothModelTypes(cfg: CollabLlmConfig, opts: {
        system: string;
        human: string;
        tool: unknown;
        maxTokens?: number;
    }): Promise<ToolProviderResult[]>;
}
declare module "_102025_/l2/toolSchemaLint" {
    export function lintToolSchema(parametersJson: string): string[] | null;
}
declare module "_102025_/l2/tsTestAST" {
    export interface ICANTest {
        functionName: string;
        params: Record<string, any>[];
    }
    export interface ICANIntegration {
        enabled: boolean;
        description: string;
        page: string;
        functionName: string;
        schema: Record<string, ICANSchema>;
    }
    export interface ICANSchema {
        type: string;
        optional?: boolean;
        description?: string;
    }
}
declare module "_102025_/l2/widgetQuestionsForClarification.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/widgetQuestionsForClarification" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { ClarificationValue } from "_102027_/l2/aiAgentOrchestration";
    export class WidgetQuestionsForClarification102025 extends StateLitElement {
        value: ClarificationValue | null;
        readonly: boolean;
        mode: 'new' | 'old';
        private localAnswers;
        private autoAcceptRemainingSeconds;
        private autoAcceptTimer;
        private autoAcceptTimerKey;
        private autoAcceptCancelledFor;
        disconnectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        updated(changedProps: Map<string, any>): void;
        private onInputChange;
        private onCancel;
        private onContinue;
        private syncAutoAcceptTimer;
        private cancelAutoAccept;
        private clearAutoAcceptTimer;
        private getAutoAcceptSeconds;
        private getAutoAcceptKey;
        private renderAutoAcceptCounter;
        render(): any;
    }
}
declare module "_102025_/l2/shared/api.defs" {
    export const asis: mls.defs.AsIs;
}
