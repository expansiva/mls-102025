declare module "_102025_/l2/collabMessages.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102036_/l2/shared/interfaces" {
    export enum HttpStatus {
        OK = 200,
        NOT_MODIFIED = 304,
        BAD_REQUEST = 400,
        UNAUTHORIZED = 401,
        NOT_FOUND = 404,
        FORBIDDEN = 403,
        CONFLICT = 409,
        SERVER_ERROR = 500,
        NOT_IMPLEMENTED = 501
    }
    export interface RequestBase {
        action: string;
    }
    export interface ResponseBase {
        statusCode: HttpStatus;
        msg?: string;
    }
    export interface RequestAddMessage extends RequestBase {
        action: "addMessage";
        userId: string;
        threadId: string;
        content: string;
        contextToBot?: Record<string, any>;
        replyTo?: string;
    }
    export interface ResponseAddMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
        botOutputs?: BotOutput[];
        integrationOutputs?: IntegrationOutput[];
    }
    export interface RequestUpdateMessage extends RequestBase {
        action: "updateMessage";
        userId: string;
        threadId: string;
        messageId: string;
        reaction?: string;
    }
    export interface ResponseUpdateMessage extends ResponseBase {
        message: Message;
    }
    export interface RequestAddMessageAI extends RequestBase {
        action: "addMessageAI";
        userId: string;
        threadId: string;
        taskTitle: string;
        userMessage: string;
        agentName: string;
        inputAI: IAMessageInputType[];
        longTermMemory?: Record<string, string>;
        replyTo?: string;
    }
    export interface ResponseAddMessageAI extends ResponseBase {
        message: Message;
        task: TaskData;
    }
    export interface RequestApplyIntents extends RequestBase {
        action: "applyIntents";
        userId: string;
        intents: AgentIntent[];
    }
    export interface ResponseApplyIntents extends ResponseBase {
        message?: Message;
        task: TaskData;
    }
    export interface RequestAddUser extends RequestBase {
        action: "addUser";
        name: string;
        avatar_url?: string;
    }
    export interface ResponseAddUser extends ResponseBase {
        user: User;
    }
    export interface RequestUpdateUserDetails extends RequestBase {
        action: "updateUserDetails";
        userId: string;
        name?: string;
        status?: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        deviceId?: string;
        notificationToken?: string;
    }
    export interface ResponseUpdateUserDetails extends ResponseBase {
        user: User;
    }
    export interface RequestAddThread extends RequestBase {
        action: "addThread";
        userId: string;
        name: string;
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        languages: string[];
        avatar_url: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
    }
    export interface ResponseAddThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestDeleteThread extends RequestBase {
        action: "deleteThread";
        userId: string;
        threadId: string;
    }
    export interface ResponseDeleteThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestUpdateThread extends RequestBase {
        action: "updateThread";
        userId: string;
        threadId: string;
        newOwnerId?: string;
        name?: string;
        visibility?: ThreadVisibility;
        status?: ThreadStatus;
        group?: ThreadGroup;
        languages?: string[];
        avatar_url?: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
    }
    export interface ResponseUpdateThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetTaskUpdate extends RequestBase {
        action: "getTaskUpdate";
        userId: string;
        messageId: string;
        taskId: string;
    }
    export interface ResponseGetTaskUpdate extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddTaskAISteps extends RequestBase {
        action: "addTaskAISteps";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        stepdIdToChangeStatus: number | null;
        newStatus: AIStepStatus;
        traceMsg: string | null;
        newTaskTitle: string;
        steps: AIPayload[];
    }
    export interface ResponseAddTaskAISteps extends ResponseBase {
        task: TaskData;
    }
    /**
     * add new prompts to a existing interaction,
     * change status of stepIdToChangeStatus to newStatus
     * change status of interactionStepId to 'in_progress'
     * start LLM
     */
    export interface RequestAppendPromptToInteraction extends RequestBase {
        action: "appendPromptToInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        interactionStepId: number;
        inputAI: IAMessageInputType[];
        stepdIdToChangeStatus: number;
        newStatus: AIStepStatus;
        traceMsg?: string;
    }
    export interface ResponseAppendPromptToInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateStepStatus extends RequestBase {
        action: "updateStepStatus";
        userId: string;
        messageId: string;
        taskId: string;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        newTaskTitle?: string;
        newTaskStatus?: TaskStatus;
    }
    export interface ResponseUpdateStepStatus extends ResponseBase {
        task: TaskData;
        message?: Message;
    }
    export interface RequestAddTaskAIInteraction extends RequestBase {
        action: "addTaskAIInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        inputAI: IAMessageInputType[];
    }
    export interface ResponseAddTaskAIInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateTaskTitle extends RequestBase {
        action: "updateTaskTitle";
        userId: string;
        messageId: string;
        taskId: string;
        newTitle: string;
    }
    export interface ResponseUpdateTaskTitle extends ResponseBase {
        task: TaskData;
    }
    export interface RequestEnsureTaskRoom extends RequestBase {
        action: "ensureTaskRoom";
        userId: string;
        taskId: string;
        parentThreadId?: string;
    }
    export interface ResponseEnsureTaskRoom extends ResponseBase {
        task: TaskData;
        thread: Thread;
    }
    export interface RequestGetMessagesAfter extends RequestBase {
        action: "getMessagesAfter";
        threadId: string;
        lastOrderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesAfter extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessagesBefore extends RequestBase {
        action: "getMessagesBefore";
        threadId: string;
        orderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesBefore extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessage extends RequestBase {
        action: "getMessage";
        threadId: string;
        messageId: string;
        userId: string;
    }
    export interface ResponseGetMessage extends ResponseBase {
        message: Message;
    }
    export interface RequestAddUserInThread extends RequestBase {
        action: "addUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        auth: UserAuth;
    }
    export interface ResponseAddUserInThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveUserInThread extends RequestBase {
        action: "removeUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
    }
    export interface ResponseRemoveUserInThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetThreadUpdate extends RequestBase {
        action: "getThreadUpdate";
        userId: string;
        threadId: string;
        deviceId?: string;
        lastOrderAt?: string;
    }
    export interface ResponseGetThreadUpdate extends ResponseBase {
        thread: Thread;
        users: User[];
        messages?: Message[];
        threadsPending: string[];
        hasMore?: boolean;
    }
    export interface RequestGetUserUpdate extends RequestBase {
        action: "getUserUpdate";
        userId?: string;
        name?: string;
        avatar_url?: string;
    }
    export interface ResponseGetUserUpdate extends ResponseBase {
        user: User;
    }
    export interface RequestGetUsers extends RequestBase {
        action: "getUsers";
        userId: string;
        status: "active" | "blocked";
        prefixName: string;
    }
    export interface ResponseGetUsers extends ResponseBase {
        users: {
            userId: string;
            name: string;
        }[];
    }
    export interface RequestAppendLongTermMemory extends RequestBase {
        action: "appendLongTermMemory";
        userId: string;
        messageId: string;
        taskId: string;
        longTermMemory: Record<string, string>;
    }
    export interface ResponseAppendLongTermMemory extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddOrUpdateThreadBot extends RequestBase {
        action: "addOrUpdateThreadBot";
        userId: string;
        threadId: string;
        botId: string;
        llmPrompt: string;
        status: "active" | "disabled";
        config?: Record<string, any>;
    }
    export interface ResponseAddOrUpdateThreadBot extends ResponseBase {
        thread: Thread;
    }
    export interface BotFlexibleResultBase {
        ref?: string;
        output?: string;
        [key: string]: any;
    }
    export interface BotOutput {
        botId: string;
        cost: number;
        output: string;
    }
    export type IntegrationType = "openclaw";
    export interface ThreadIntegration {
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
        lastExecutionAt?: string;
    }
    export interface ThreadIntegrationConfig {
        url: string;
        bearerToken: string;
        inboundToken: string;
        agentId?: string;
        sessionId?: string;
    }
    export interface IntegrationOutput {
        integrationId: string;
        type: IntegrationType;
        responseMessageId?: string;
        error?: string;
    }
    export interface RequestAddOrUpdateThreadIntegration extends RequestBase {
        action: "addOrUpdateThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
    }
    export interface ResponseAddOrUpdateThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadIntegration extends RequestBase {
        action: "removeThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
    }
    export interface ResponseRemoveThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestWebhookInbound {
        threadId: string;
        integrationId: string;
        content: string;
        type?: Message['type'];
        replyTo?: string;
    }
    export interface ResponseWebhookInbound extends ResponseBase {
        message: Message;
    }
    export interface User {
        userId: string;
        name: string;
        status: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        kind?: UserKind;
        metadata?: UserMetadata;
        threads: string[];
        notifications?: UserNotifications[];
    }
    export interface UserNotifications {
        deviceId: string;
        notificationToken: string;
    }
    export type UserKind = "human" | "synthetic_agent" | "pma";
    export interface UserMetadata {
        source?: "collab" | "openclaw" | "external";
        agentType?: "pma" | "agent" | "external_agent";
        definitionRef?: string;
        definitionVersion?: string;
        modelType?: string;
        connectorId?: string;
        agentId?: string;
        [key: string]: any;
    }
    export interface UserPerformanceCache extends User {
        lastSync?: string;
    }
    export type UserAuth = "admin" | "moderator" | "read" | "write" | "none";
    export interface ThreadUsers {
        userId: string;
        auth: UserAuth;
    }
    export type ThreadGroup = "CRM" | "TASK" | "DOCS" | "CONNECT" | "APPS";
    export type ThreadVisibility = "public" | "private" | "company" | "team";
    export type ThreadStatus = "active" | "archived" | "deleting" | "deleted";
    export interface Thread {
        threadId: string;
        name: string;
        users: ThreadUsers[];
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        history: ThreadHistoryEntry[];
        languages: string[];
        defaultTopics?: string[];
        welcomeMessage?: string;
        avatar_url: string;
        bots?: ThreadBot[];
        integrations?: ThreadIntegration[];
        openClawAgents?: OpenClawAgentBinding[];
        kind?: 'thread' | 'task-room';
        taskRoom?: {
            taskId: string;
            parentThreadId: string;
            workflowType: WorkflowType;
        };
        archivedAt?: string;
        archivedBy?: string;
        deletedAt?: string;
        createdAt: string;
    }
    export interface ThreadHistoryEntry {
        action: string;
        userId: string;
        timestamp: string;
    }
    export interface ThreadBot {
        botId: string;
        llmPrompt: string;
        threadFeature: ThreadFeature;
        threadPermissionLevel: ThreadPermissionLevel;
        triggers: ThreadBotTrigger[];
        status: "idle" | "running" | "disabled";
        lastExecutionAt?: string;
        memoryRef?: string;
        config?: Record<string, any>;
    }
    export enum ThreadFeature {
        Summary = "summary",
        CustomPlugin = "custom_plugin",
        Tasks = "tasks",
        Workflow = "workflow",
        Notifications = "notifications",
        Voting = "voting",
        Moderation = "moderation",
        Feedback = "feedback"
    }
    export type ThreadPermissionLevel = "all" | "members" | "admin";
    export interface ThreadBotTrigger {
        type: BotTriggerType;
        match?: "any" | "all";
        conditions?: BotTriggerCondition[];
        args?: BotTriggerArgs;
    }
    export enum BotTriggerType {
        OnNewMessage = "onNewMessage",
        OnMention = "onMention",
        OnTaskCompleted = "onTaskCompleted",
        Schedule = "schedule",
        Manual = "manual"
    }
    export interface BotTriggerCondition {
        type: "hasTag" | "mention" | "startsWith" | "contains";
        value: string;
    }
    export type BotTriggerArgs = {
        cron: string;
    } | {
        taskType: string;
    } | Record<string, any>;
    export interface ThreadPerformanceCache extends Thread {
        lastMessage?: string;
        lastMessageTime?: string;
        unreadCount?: number;
        lastSync?: string;
    }
    export interface Message {
        threadId: string;
        orderAt: string;
        createAt: string;
        updatedAt?: string;
        senderId: string;
        content: string;
        language_detected?: string;
        externalPlatform?: string;
        translations?: Record<string, string>;
        reactions?: Record<string, string[]>;
        type?: 'text' | 'image' | 'video' | 'audio' | 'document' | 'location' | 'contact';
        pin?: boolean;
        taskId?: string;
        stepId?: number;
        taskRoomRole?: 'conversation' | 'system' | 'agent' | 'workflow';
        taskTitle?: string;
        taskStatus?: TaskStatus;
        taskResults?: string[];
        taskResultsTranslated?: Record<string, string>;
        taskTitleTranslated?: Record<string, string>;
        visibility?: "admin";
        url?: string;
        replyTo?: string;
    }
    export interface MessagePerformanceCache extends Message {
        lastSync?: string;
        status?: 'read' | 'unread' | 'edited';
        footers: {
            title?: string;
            lines: string[];
            icon?: string;
            color?: string;
            backgroundColor?: string;
            timestamp?: string;
        }[];
    }
    export interface ProviderConfig {
        provider: string;
        alternateProvider: string;
        model: string;
        json: boolean;
        onlyImage?: boolean;
        inputValue: number;
        outputValue: number;
        extrabody?: Record<string, string>;
    }
    export interface Providers {
        [provider: string]: Record<string, ProviderConfig>;
    }
    export type TaskOperationType = "create" | "read" | "update" | "delete" | "query";
    export interface TaskOperation {
        operation: TaskOperationType;
        taskId?: string;
        data?: Partial<TaskData>;
        filters?: Record<string, any>;
        message?: string | null;
    }
    export interface TaskData {
        PK: string;
        SK: 'metadata';
        title: string;
        owner: string;
        team: 'unassigned' | string | null;
        assigness?: string[];
        status: TaskStatus;
        last_updated: 0 | number;
        last_update_log: string | null;
        source?: string;
        url?: string;
        description?: string;
        priority?: 'low' | 'normal' | 'high' | 'urgent';
        effort?: number;
        cost?: number;
        iaCompressed?: IACompressed;
        tags?: string[];
        attachmentsUrl?: string[];
        messageid_created?: string;
        messageid_refs?: string[];
        taskRoom?: {
            enabled: boolean;
            threadId?: string;
            workflowType?: WorkflowType;
            parentThreadId?: string;
            memoryRef?: string;
            status?: 'active' | 'archived' | 'deleted';
        };
    }
    export type TaskStatus = 'todo' | 'in progress' | 'paused' | 'done' | 'failed';
    export type WorkflowType = 'staticWorkflow' | 'dynamicWorkflow';
    export interface TaskDataToSave extends Omit<TaskData, 'iaCompressed'> {
        iaCompressed?: string;
    }
    export interface IACompressed {
        nextSteps: AIPayload[];
        longMemory: Record<string, string>;
        isTest?: boolean;
        queueBackEnd: AgentIntent[];
        queueFrontEnd: AgentHooks[];
    }
    export interface AIInteraction {
        input: IAMessageInputType[];
        cost: number;
        trace: string[];
        payload: AIPayload[] | null;
    }
    export interface IAMessageInputType {
        type: 'system' | 'human' | 'ai';
        content: string;
    }
    export type AIStepStatus = 'waiting_human_input' | // for parallel steps waiting for human input
    'waiting_after_prompt' | // for parallel steps waiting for afterPrompt processing
    'pending' | // already created, waiting to be processed
    'in_progress' | // being processed in LLM
    'completed' | // completed successfully
    'failed';
    export interface AIStepProgress {
        total: number;
        completed: number;
        failed: number;
        templateTitle: string;
    }
    export interface AIStep {
        type: AIPayload['type'];
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
    }
    export type AIPayload = AIAgentStep | AIToolStep | AIClarificationStep | AIResultStep | AIFlexibleResultStep;
    export interface AIWorkflowStep {
        type: WorkflowType;
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
        workflowName?: string;
    }
    export interface AIAgentStep extends AIStep {
        type: 'agent';
        agentName: string;
        prompt?: string;
        rags: string[] | null;
    }
    export interface AIToolStep extends AIStep {
        type: 'tool';
        toolName: string;
        args: string;
    }
    export interface AIClarificationStep extends AIStep {
        type: 'clarification';
        json?: string;
    }
    export interface AIResultStep extends AIStep {
        type: 'result';
        result: string;
    }
    export interface AIFlexibleResultStep extends AIStep {
        type: 'flexible';
        result: any;
    }
    export interface ExecutionContext {
        message: Message;
        task: TaskData | undefined;
        isTest: boolean;
    }
    export type AgentIntentUpdateStatus = {
        type: 'update-status';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        stepId: number;
        status: AIStepStatus;
        cleaner?: 'input' | 'input_output';
    };
    export type AgentIntentAddStep = {
        type: 'add-step';
        messageId: string;
        threadId: string;
        taskId: string;
        parentStepId: number;
        step: AIPayload;
        stepTitle?: string;
        executionMode?: ExecutionMode;
    };
    export type AgentIntentPauseOrContinue = {
        type: 'pause-or-continue';
        messageId: string;
        threadId: string;
        taskId: string;
        reason: string;
    };
    export type AgentIntentAddMessageAI = {
        type: 'add-message-ai';
        stepTitle?: string;
        request: Omit<RequestAddMessageAI, 'userId'>;
        executionMode?: ExecutionMode;
    };
    export type ExecutionMode = {
        type: 'parallel';
        args: string[];
        maxParallel?: number;
    };
    /**
     * Parallel steps execution mechanism.
     * Child steps inherit the system prompt from their parent step.
     * Human prompts are prepared client-side using compact args (via beforePrompt hook).
     * Keep args short, unique, and deterministic.
     *
     * Parallel execution flow:
     *
     * 1. Frontend requests creation of a parent step (via API) with system prompt only
     *    and one or more AgentIntentParallelSteps.
     *
     * 1.1 Frontend enforces max parallel items per request.
     *     Use pagination (offset/limit or batch markers) in args when more items exist.
     *
     * 2. Backend:
     *    - Creates parent step with status "in_progress"
     *    - Enqueues AgentIntentParallelSteps in queueBackEnd
     *    - Immediately creates a batch of "waiting_human_input" child steps (no human prompt yet)
     *
     * 2.1 Parent remains "in_progress" until all children reach terminal state ("completed" or "failed").
     *
     * 2.2 Child steps are pre-allocated and reused as prompts arrive.
     *
     * 3. Backend enqueues multiple AgentHookBeforePrompt (one per waiting_human_input child) for frontend.
     *
     * 4. Frontend prepares human prompts and returns AgentIntentContinueParallelStep items.
     *
     * 5. Backend:
     *    - Updates child steps with received human prompts
     *    - Applies strong deduplication (ignore duplicates by parentStepId + args)
     *    - Cleans queueBackEnd and queueFrontEnd
     *
     * 6. Backend executes child steps as they become ready.
     *
     * 6.1 After each child execution, backend sends feedback AgentHook to frontend
     *     (success or error). Frontend then requests child status update to "completed" or "failed".
     *
     * 7. When ALL children are in terminal state, backend finalizes the parent step.
     *
     * 7.1 Finished child steps are deleted to reduce task object size.
     *
     * Critical implementation notes:
     * - Uniqueness key: parentStepId + args (must be collision-resistant)
     * - Step 5 MUST implement strict idempotency and duplicate rejection
     * - Error handling, child retries, and stuck-state timeouts are responsibility of other system layers
     */
    export type AgentIntentParallelSteps = {
        type: 'parallel-steps';
        parentStepId: number;
        args: string;
    };
    export type AgentIntentPromptReady = {
        type: 'prompt_ready';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        args: string;
        humanPrompt: string;
        systemPrompt?: string;
    };
    export type AgentIntentRemoveHook = {
        type: 'remove-hook';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
    };
    export type AgentIntent = AgentIntentAddStep | AgentIntentPauseOrContinue | AgentIntentUpdateStatus | AgentIntentParallelSteps | AgentIntentPromptReady | AgentIntentAddMessageAI | AgentIntentRemoveHook;
    export type AgentHookBase = {
        hookSequential: number;
        stepId: number;
    };
    export type AgentHookBeforePromptStep = AgentHookBase & {
        type: 'beforePromptStep';
        parentStepId: number;
        args: string;
    };
    export type AgentHookBeforeTool = AgentHookBase & {
        type: 'beforeTool';
        parentStepId: number;
        args: string;
    };
    export type AgentHookAfterPromptStep = AgentHookBase & {
        type: 'afterPromptStep';
        parentStepId: number;
    };
    export type AgentHookPooling = AgentHookBase & {
        type: 'pooling';
        executionCount: number;
        afterMs: number;
    };
    export type AgentHooks = AgentHookBeforePromptStep | AgentHookAfterPromptStep | AgentHookPooling | AgentHookBeforeTool;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export interface IOpenClawAgent {
        id: string;
        name: string;
        avatarUrl: string;
        collabUserId: string;
        createdAt: string;
    }
    export interface IOpenClawIntegration {
        id: string;
        name: string;
        url: string;
        connectorId: string;
        bearerToken: string;
        agents: IOpenClawAgent[];
        createdAt: string;
    }
    export interface ToolsBeforeSendMessage {
        toolName: string;
        args: Record<string, any>;
    }
    export interface RequestAddOrUpdateOpenClawConnector extends RequestBase {
        action: "addOrUpdateOpenClawConnector";
        userId: string;
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs?: number;
        defaultOutputMode?: OpenClawOutputMode;
    }
    export interface ResponseAddOrUpdateOpenClawConnector extends ResponseBase {
        connector: OpenClawConnector;
    }
    export interface RequestRemoveOpenClawConnector extends RequestBase {
        action: "removeOpenClawConnector";
        userId: string;
        connectorId: string;
    }
    export interface ResponseRemoveOpenClawConnector extends ResponseBase {
        connectorId: string;
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export type OpenClawOutputMode = "final_only" | "status_and_final";
    export type OpenClawSessionMode = "thread" | "thread_user";
    export type OpenClawHandoffThreadRole = "handoff" | "collaboration";
    export interface OpenClawConnector {
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs: number;
        defaultOutputMode: OpenClawOutputMode;
        protocolVersion?: number;
        transport?: string;
    }
    export interface RequestAddOrUpdateThreadOpenClawAgent extends RequestBase {
        action: "addOrUpdateThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface ResponseAddOrUpdateThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadOpenClawAgent extends RequestBase {
        action: "removeThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
    }
    export interface ResponseRemoveThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestListThreadOpenClawAgents extends RequestBase {
        action: "listThreadOpenClawAgents";
        userId: string;
        threadId: string;
    }
    export interface ResponseListThreadOpenClawAgents extends ResponseBase {
        threadId: string;
        agents: OpenClawAgentBinding[];
    }
    export interface OpenClawAgentBinding {
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface OpenClawRemoteAgentSummary {
        id: string;
        name?: string;
        identity?: {
            name?: string;
            theme?: string;
            emoji?: string;
            avatar?: string;
            avatarUrl?: string;
        };
        workspace?: string;
        model?: {
            primary?: string;
            fallbacks?: string[];
        };
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export interface RequestListOpenClawAvailableAgents extends RequestBase {
        action: "listOpenClawAvailableAgents";
        userId: string;
        connectorId: string;
    }
    export interface ResponseListOpenClawAvailableAgents extends ResponseBase {
        connectorId: string;
        defaultId: string;
        mainKey: string;
        scope: "per-sender" | "global";
        agents: OpenClawRemoteAgentSummary[];
    }
    export interface RequestCreateOpenClawAgent extends RequestBase {
        action: "createOpenClawAgent";
        userId: string;
        connectorId: string;
        name: string;
        workspace: string;
        emoji?: string;
        avatar?: string;
        soulMd?: string;
        identityMd?: string;
    }
    export interface ResponseCreateOpenClawAgent extends ResponseBase {
        connectorId: string;
        agent: OpenClawRemoteAgentSummary;
        collabUserId: string;
    }
    export interface RequestDeleteOpenClawAgent extends RequestBase {
        action: "deleteOpenClawAgent";
        userId: string;
        connectorId: string;
        agentId: string;
        deleteFiles?: boolean;
    }
    export interface ResponseDeleteOpenClawAgent extends ResponseBase {
        connectorId: string;
        agentId: string;
        collabUserId?: string;
        updatedThreadIds: string[];
    }
}
declare module "_102036_/l2/environmentContract" {
    import { IAgentMeta, IOpenClawIntegration, Thread, ToolsBeforeSendMessage, ExecutionContext, TaskData, Message } from "_102036_/l2/shared/interfaces";
    /**
     * CONTRACT
     */
    export interface CollabMessagesEnvironment {
        getAgents?(): Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw?(): Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw?(integrations: IOpenClawIntegration[]): Promise<void>;
        config?: {
            getMenuMode?(): 'default' | 'custom';
            generateSvgAvatarEnabled?(): boolean;
        };
        tasks?: {
            openTaskDetails?(messageId: string, taskId: string, task: TaskData, message: Message): Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        agents?: {
            loadAgent?(agentName: string): Promise<IAgentMeta | null>;
            executeAgent?(agentToCall: string, context: ExecutionContext): Promise<void>;
            generateSvgAvatar?(threadId: string, userId: string, promptToAvatar: string): Promise<string | null>;
        };
        notifications?: {
            getFCMTokenForBackend?(): Promise<string | null>;
            getNotifySoundUrl?(): Promise<string | null>;
            sendRequestMissed?(): Promise<void>;
            sendACK?(id: string): Promise<void>;
        };
        bots?: {
            getArgsToBots?(): Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend?(thread: Thread, messageText: string): Promise<string[]>;
            getBotContextVarsBeforeMessageSend2?(vars: string[], myArgs: Record<string, any>): Promise<ToolsBeforeSendMessage[]>;
        };
    }
    export function setEnvironment(env: CollabMessagesEnvironment): void;
    /**
     * FACADE FINAL
     */
    export const environment: {
        getAgents: () => Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw: () => Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw: (integrations: IOpenClawIntegration[]) => Promise<void>;
        notifications: {
            getFCMTokenForBackend: () => Promise<string>;
            getNotifySoundUrl: () => Promise<string>;
            sendRequestMissed: () => Promise<void>;
            sendACK: (id: string) => Promise<void>;
        };
        bots: {
            getArgsToBots: () => Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend: (thread: Thread, messageText: string) => Promise<string[]>;
            getBotContextVarsBeforeMessageSend2: (vars: string[], myArgs: Record<string, any>) => Promise<ToolsBeforeSendMessage[]>;
        };
        agents: {
            generateSvgAvatar: (threadId: string, userId: string, promptToAvatar: string) => Promise<string>;
            executeAgent: (agentToCall: string, context: ExecutionContext) => Promise<void>;
            loadAgent: (agentName: string) => Promise<IAgentMeta>;
        };
        tasks: {
            openTaskDetails: (messageId: string, taskId: string, task: TaskData, message: Message) => Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        config: {
            getMenuMode: () => "default" | "custom";
            generateSvgAvatarEnabled: () => boolean;
        };
    };
}
declare module "_102025_/l2/shared/interfaces" {
    export * from "_102036_/l2/shared/interfaces";
}
declare module "_102036_/l2/collabMessagesIndexedDB" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function openDB(): Promise<IDBDatabase>;
    export function addMessages(messages: msg.MessagePerformanceCache[]): Promise<void>;
    export function addMessage(message: msg.MessagePerformanceCache): Promise<void>;
    export function updateMessage(message: msg.Message): Promise<void>;
    export function deleteAllMessagesFromThread(threadId: string): Promise<void>;
    export function getMessage(messageId: string): Promise<msg.MessagePerformanceCache | undefined>;
    export function getMessagesByThreadId(threadId: string, limit?: number, offset?: number): Promise<msg.MessagePerformanceCache[]>;
    export function getAllMessagesByThreadId(threadId: string): Promise<msg.MessagePerformanceCache[]>;
    export function addOrUpdateTask(task: msg.TaskData): Promise<void>;
    export function getTask(taskId: string): Promise<msg.TaskData | undefined>;
    export function deleteTask(taskId: string): Promise<void>;
    export function listThreads(): Promise<msg.ThreadPerformanceCache[]>;
    export function addThread(thread: msg.Thread): Promise<msg.ThreadPerformanceCache>;
    export function updateLastMessageReadTime(threadId: string, lastMessageReadTime: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreadPendingTasks(threadId: string, taskId?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThread(threadId: string, thread: msg.Thread, lastMessage?: string, lastMessageTime?: string, unreadCount?: number, lastSync?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreads(threadsFromServer: msg.Thread[]): Promise<void>;
    export function getThread(threadId: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getThreadByName(threadName: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getAllThreads(): Promise<IDBThreadPerformanceCache[]>;
    export function cleanupThreads(validThreadIds: string[]): Promise<void>;
    export function listUsers(): Promise<msg.User[]>;
    export function addUser(user: msg.User): Promise<void>;
    export function updateUsers(usersFromServer: msg.User[]): Promise<void>;
    export function getUser(userId: string): Promise<msg.User | undefined>;
    export function addPooling(pooling: PoolingTask): Promise<void>;
    export function deletePooling(taskId: string): Promise<void>;
    export function getPooling(taskId: string): Promise<PoolingTask | undefined>;
    export function listPoolings(): Promise<PoolingTask[]>;
    export function getCompactUTC(): string;
    export interface IDBThreadPerformanceCache extends msg.ThreadPerformanceCache {
        pendingTasks?: string;
    }
    export interface PoolingTask {
        taskId: string;
        userId: string;
        startAt: string;
    }
}
declare module "_102025_/l2/collabMessagesIndexedDB" {
    export * from "_102036_/l2/collabMessagesIndexedDB";
}
declare module "_102025_/l2/shared/api" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export function post<T = msg.ResponseBase>(args: msg.RequestBase): Promise<T>;
    export function getPostError(response: Response, args: msg.RequestBase): Promise<Error>;
    export function msgGetUsers(args: Omit<msg.RequestGetUsers, "action">): Promise<ApiResult<msg.ResponseGetUsers>>;
    export function msgGetUserUpdate(args: Omit<msg.RequestGetUserUpdate, "action">): Promise<ApiResult<msg.ResponseGetUserUpdate>>;
    export function msgUpdateUserDetails(args: Omit<msg.RequestUpdateUserDetails, "action">): Promise<ApiResult<msg.ResponseUpdateUserDetails>>;
    export function msgAddThread(args: Omit<msg.RequestAddThread, "action">): Promise<ApiResult<msg.ResponseAddThread>>;
    export function msgUpdateThread(args: Omit<msg.RequestUpdateThread, "action">): Promise<ApiResult<msg.ResponseUpdateThread>>;
    export function msgRemoveParticipantFromThread(args: Omit<msg.RequestRemoveUserInThread, "action">): Promise<ApiResult<msg.ResponseRemoveUserInThread>>;
    export function msgAddParticipantToThread(args: Omit<msg.RequestAddUserInThread, "action">): Promise<ApiResult<msg.ResponseAddUserInThread>>;
    export function msgGetThreadUpdates(args: Omit<msg.RequestGetThreadUpdate, "action">): Promise<ApiResult<msg.ResponseGetThreadUpdate>>;
    export function msgGetTaskUpdate(args: Omit<msg.RequestGetTaskUpdate, "action">): Promise<ApiResult<msg.ResponseGetTaskUpdate>>;
    export function msgAddMessage(args: Omit<msg.RequestAddMessage, "action">): Promise<ApiResult<msg.ResponseAddMessage>>;
    export function msgEnsureTaskRoom(args: Omit<msg.RequestEnsureTaskRoom, "action">): Promise<ApiResult<msg.ResponseEnsureTaskRoom>>;
    export function msgAddMessageAI(args: Omit<msg.RequestAddMessageAI, "action">): Promise<ApiResult<msg.ResponseAddMessageAI>>;
    export function msgAddOrUpdateThreadBot(args: Omit<msg.RequestAddOrUpdateThreadBot, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadBot>>;
    export function msgAddOrUpdateThreadIntegration(args: Omit<msg.RequestAddOrUpdateThreadIntegration, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadIntegration>>;
    export function msgGetMessagesAfter(args: Omit<msg.RequestGetMessagesAfter, "action">): Promise<ApiResult<msg.ResponseGetMessagesAfter>>;
    export function msgGetMessagesBefore(args: Omit<msg.RequestGetMessagesBefore, "action">): Promise<ApiResult<msg.ResponseGetMessagesBefore>>;
    export function msgGetMessage(args: Omit<msg.RequestGetMessage, "action">): Promise<ApiResult<msg.ResponseGetMessage>>;
    export function msgUpdateMessage(args: Omit<msg.RequestUpdateMessage, "action">): Promise<ApiResult<msg.ResponseUpdateMessage>>;
    export function msgAddOrUpdateOpenClawConnector(args: Omit<msg.RequestAddOrUpdateOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateOpenClawConnector>>;
    export function msgRemoveOpenClawConnector(args: Omit<msg.RequestRemoveOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseRemoveOpenClawConnector>>;
    export function msgListOpenClawConnectors(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListOpenClawConnectorAgents(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListThreadOpenClawAgents(args: Omit<msg.RequestListThreadOpenClawAgents, "action">): Promise<ApiResult<msg.ResponseListThreadOpenClawAgents>>;
    export function msgAddOrUpdateThreadOpenClawAgent(args: Omit<msg.RequestAddOrUpdateThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadOpenClawAgent>>;
    export function msgRemoveThreadOpenClawAgent(args: Omit<msg.RequestRemoveThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseRemoveThreadOpenClawAgent>>;
    export function msgCreateOpenClawAgent(args: Omit<msg.RequestCreateOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseCreateOpenClawAgent>>;
    export function msgDeleteOpenClawAgent(args: Omit<msg.RequestDeleteOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseDeleteOpenClawAgent>>;
    export function msgListOpenClawAvailableAgents(args: Omit<msg.RequestListOpenClawAvailableAgents, "action">): Promise<ApiResult<msg.ResponseListOpenClawAvailableAgents>>;
    export function msgListTasks(args: Omit<msg.RequestListTasks, "action">): Promise<ApiResult<msg.ResponseListTasks>>;
    export function msgGetOrgPreferences(args: Omit<msg.RequestGetOrgPreferences, "action">): Promise<ApiResult<msg.ResponseGetOrgPreferences>>;
    export type ApiResult<T> = {
        success: boolean;
        response?: T;
        error?: string;
        statusCode: number;
    };
}
declare module "_102025_/l2/collabMessagesEvents" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export function notifyMessageSendChange(context: msg.ExecutionContext): void;
    export function notifyTaskChange(context: msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: msg.Thread): void;
    export function notifyMessageChange(message: msg.Message): void;
    export function notifyThreadNotification(show: boolean): void;
    export function notifyThreadCreate(thread: msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function dispatchDetailsTaskClick(messageId: string, taskId: string, task: msg.TaskData, message: msg.MessagePerformanceCache): void;
    export function dispatchThreadOpen(threadId: string, taskId?: string): void;
    export function notifyTaskMetaChanged(payload: {
        taskId: string;
        taskTitle: string;
        threadId: string;
    }): void;
    export interface ICollabMessageEvent {
        threadId: string;
        taskId?: string;
    }
}
declare module "_102025_/l2/collabMessagesHelper" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export const AGENTDEFAULT = "agentPlanner1";
    export function registerToken(): Promise<string>;
    export function addMessage(threadId: string, messageContent: string, contextToBot?: msg.ToolsBeforeSendMessage): Promise<msg.ExecutionContext>;
    export function getArgsToBots(): Promise<Record<string, any>>;
    export function getBotsContext(thread: msg.Thread, prompt: string, context: msg.ExecutionContext): Promise<Record<string, any>>;
    export function saveNotificationDeviceId(deviceId: string): void;
    export function loadNotificationDeviceId(): string | null;
    export function saveNotificationToken(tokenFCM: string): void;
    export function loadNotificationToken(): string | null;
    export function saveNotificationPreferences(notificationPreference: NotificationPermission): void;
    export function loadNotificationPreferences(): NotificationPermission | null;
    export function saveNotificationPreferencesAudio(enable: boolean): void;
    export function loadNotificationPreferencesAudio(): boolean;
    export function saveLastAlertTime(time: number): void;
    export function loadLastAlertTime(): number | undefined;
    export function saveLastTab(lastTab: string): void;
    export function loadLastTab(): string;
    export function saveUserId(userId: string): void;
    export function getUserId(): string | null;
    export function loadChatPreferences(): IChatPreferences;
    export function saveChatPreferences(chatPreferences: IChatPreferences): void;
    export function loadOpenClawIntegrations(): Promise<msg.IOpenClawIntegration[]>;
    export function saveOpenClawIntegrations(integrations: msg.IOpenClawIntegration[]): Promise<void>;
    export function checkThreadAlreadyExist(threadName: string): Promise<void>;
    export function getDmThreadByUsers(userId1: string, userId2: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThread(threadName: string, languages: string[], visibility: msg.ThreadVisibility, avatar_url?: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThreadDM(threadName: string, dmUser: string, group: msg.ThreadGroup): Promise<msg.Thread>;
    export function formatTimestamp(timestamp: string): {
        dateFull: string;
        date: string;
        time: string;
        timeShort: string;
    };
    export function getDateFormated(dt: string): string;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => msg.ExecutionContext;
    export function findAgentInIntegrationsByUserId(collabUserId: string): Promise<{
        name: string;
        agentId: string;
        connectorId: string;
    }>;
    export function generateUUIDv7(): string;
    export function generateAgentAvatar(name: string): string;
    export function changeFavIcon(notification: boolean): Promise<void>;
    export type TranslateMode = "none" | "icon" | "text" | "iconText" | "trace";
    export interface IChatPreferences {
        translationMode: TranslateMode;
        language: string;
        threadMaintenance: string;
    }
    export interface CollabMessagesLS {
        lastTab?: string;
        chatPreferences?: IChatPreferences;
        userId?: string;
        tokenFCM?: string;
        deviceId?: string;
        notificationPreference?: NotificationPermission;
        notificationAudio?: boolean;
        lastNotificationAlertTime?: number;
    }
    export interface IMessage extends msg.MessagePerformanceCache {
        context?: msg.ExecutionContext;
        lastChanged?: number;
        isSame?: boolean;
        isLoading?: boolean;
        isFailed?: boolean;
        isFailedError?: string;
    }
    export interface IThreadInfo {
        thread: msg.ThreadPerformanceCache;
        threadsPending?: string[];
        users: msg.User[];
        hasMore?: boolean | undefined;
        messages?: msg.Message[] | undefined;
    }
}
declare module "_102025_/l2/collabMessagesSyncNotifications" {
    export const threadSyncMap: Map<string, boolean>;
    export function removeThreadFromSync(threadId: string): void;
    export function clearThreadNotification(threadId: string): void;
    export function clearTaskNotification(taskId: string): void;
    export function hasThreadNotificationPending(threadId: string): boolean;
    export function hasTaskNotificationPending(taskId: string): boolean;
    export function getPendingTaskNotificationsForThread(threadId: string): string[];
    export function checkIfNotificationUnread(): Promise<boolean>;
    export function listenToThreadEvents(): Promise<void>;
    export function getThreadUpdateInBackground(reference: string): Promise<void>;
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102025_/l2/collabMessagesIcons" {
    export const collab_message: any;
    export const collab_reply: any;
    export const collab_copy: any;
    export const collab_edit: any;
    export const collab_delete: any;
    export const collab_smile: any;
    export const collab_chevron_down: any;
    export const collab_chevron_right: any;
    export const collab_clock_static: any;
    export const collab_users: any;
    export const collab_user: any;
    export const collab_magnifying_glass: any;
    export const collab_arrow_up_long: any;
    export const collab_minus: any;
    export const collab_ban: any;
    export const collab_dot: any;
    export const collab_bell: any;
    export const collab_money: any;
    export const collab_pause: any;
    export const collab_clock: any;
    export const collab_check: any;
    export const collab_bug_x12: any;
    export const collab_play: any;
    export const collab_bug: any;
    export const collab_chevron_left: any;
    export const collab_gear: any;
    export const collab_translate: any;
    export const collab_circle_exclamation: any;
    export const collab_plus: any;
    export const collab_folder_tree: any;
    export const collab_triangle_exclamation: any;
    export const collab_bell_slash: any;
    export const collab_xmark: any;
    export const collab_spinner_clock: any;
    export const collab_trash: any;
    export const collab_link: any;
    export const collab_plug: any;
    export const collab_robot: any;
    export const collab_refresh: any;
    export const collab_floppy_disk: any;
    export const collab_crm: any;
    export const collab_tasks: any;
    export const collab_connect: any;
    export const collab_moments: any;
    export const collab_apps: any;
    export const collab_warning: any;
    export const collab_signal: any;
    export const collab_eye: any;
    export const collab_eye_slash: any;
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102025_/l2/collabMessagesInputTag" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesInputTag extends StateLitElement {
        tags: string[];
        input: HTMLInputElement | undefined;
        pattern: string | null;
        placeholder: string | null;
        allowDelete: boolean;
        hasError: boolean;
        get value(): string;
        set value(val: string);
        onValueChanged: Function | undefined;
        addTag(tag: string): void;
        deleteTag(index: number): void;
        empty(): void;
        private _addTag;
        private _deleteTag;
        private _empty;
        private onInputLeave;
        private onInputKeyDown;
        private isValidTag;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesAdd" {
    import { CollabMessagesInputTag } from "_102025_/l2/collabMessagesInputTag";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesInputTag";
    export class CollabMessagesAdd extends StateLitElement {
        private msg;
        private threadType;
        private threadName;
        private visibility;
        private group;
        private languages;
        private isLoading;
        private dmUser;
        private users;
        agentsBots: IAgentsBots[];
        _selectedAgent: string;
        _initialMessage: string;
        _topics: string[];
        _agentConfig: string;
        _promptToAvatar: string;
        labelOk: string;
        labelError: string;
        userId: string | undefined;
        languageInput?: CollabMessagesInputTag;
        onAddSuccess: Function | undefined;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private loadUsersAvaliables;
        private loadAgentsBotsAvaliables;
        private _renderAdd;
        private _handleChange;
        private renderBotsConfig;
        private renderInitialMessageConfig;
        private renderIconConfig;
        private validateForm;
        private addNewThread;
        private addBot;
        private generateAvatar;
        private extractSvgFromContext;
    }
    interface IAgentsBots {
        id: string;
        name: string;
        description: string;
        avatar_url: string;
        info?: {
            project: number;
            shortName: string;
            folder: string;
        };
    }
}
declare module "_102025_/l2/collabMessagesTask" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesTask extends StateLitElement {
        private msg;
        taskid: string;
        threadId: string;
        userId: string;
        messageid: string;
        lastChanged: string;
        status: string;
        notificationPending: boolean;
        task: msg.TaskData | undefined;
        context: msg.ExecutionContext | undefined;
        private secondsPassed;
        private lastStep;
        private timerId;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        renderIconTask(): any;
        private resetTimer;
        private resetTimerState;
        private formatTime;
        private getTaskLocal;
        private onCardClick;
        private normalizeMessageId;
        private getAllSteps;
        private getNextPendentStep;
        private getTotalCost;
    }
}
declare module "_102027_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102027_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102027_/l2/stateLitElement" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    import { PropertyValueMap } from 'lit';
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102027_/l2/aiAgentHelper" {
    /**
     * Helper function to collect all steps from a task in a flat array
     */
    export const getAllSteps: (firstStep: mls.msg.AIPayload[] | undefined) => mls.msg.AIPayload[];
    export const getAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload | null;
    export const getAllAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload[] | null;
    export const getAgentsStepByAgentName: (task: mls.msg.TaskData, agentName: string, status?: mls.msg.AIStepStatus) => mls.msg.AIPayload[];
    export const getStepById: (task: mls.msg.TaskData, stepId: number) => mls.msg.AIPayload | null;
    export const getNextPendentStep: (task: mls.msg.TaskData) => mls.msg.AIPayload | null;
    export const getNextResultStep: (task: mls.msg.TaskData) => mls.msg.AIResultStep | null;
    export const getNextClarificationStep: (task: mls.msg.TaskData) => mls.msg.AIClarificationStep | null;
    export const getNextPendingStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getNextFlexiblePendingStep: (task: mls.msg.TaskData) => mls.msg.AIFlexibleResultStep | null;
    export const getNextInProgressStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getRootAgent: (task: mls.msg.TaskData) => mls.msg.AIAgentStep | null;
    export const getInteractionStepId: (task: mls.msg.TaskData, stepId: number) => number | null;
    export type StatisticsAITask = {
        agents: number;
        tools: number;
        clarification: number;
        result: number;
        flexible: number;
        totalCost: number;
        totalSteps: number;
    };
    export const calculateStepsStatistics: (steps: mls.msg.AIPayload[], removeFirstStep: boolean) => StatisticsAITask;
    export const calculateStepsByFilter: (task: mls.msg.TaskData, filter: Record<string, any>) => number;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => mls.msg.ExecutionContext;
    export function notifyMessageSendChange(context: mls.msg.ExecutionContext): void;
    export function notifyTaskChange(context: mls.msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: mls.msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: mls.msg.Thread): void;
    export function notifyMessageChange(message: mls.msg.Message): void;
    export function notifyThreadCreate(thread: mls.msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function getTotalCost(task: mls.msg.TaskData): string;
    export function appendLongTermMemory(context: mls.msg.ExecutionContext, longTermMemory: Record<string, string>): Promise<mls.msg.TaskData>;
    export function getNextStepIdAvaliable(task: mls.msg.TaskData): number;
    export function findPreviousAgentStep(data: mls.msg.TaskData, baseStep: number): mls.msg.AIAgentStep | null;
}
declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102027_/l2/aiAgentOrchestration" {
    import { IAgent, IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function executeBeforePrompt(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): Promise<void>;
    export function continuePoolingTask(context: mls.msg.ExecutionContext): Promise<void>;
    export function pauseOrContinueTask(reason: string, context: mls.msg.ExecutionContext, action: "paused" | "continue"): Promise<void>;
    export function executeTool(toolName: string, args: string): Promise<IExecuteToolReturn>;
    export function finishClarification(agent: IAgent | IAgentAsync, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], context: mls.msg.ExecutionContext, value: string, action: "continue" | "cancel"): Promise<void>;
    export function prepareClarificationElement(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], clarification: ClarificationValue | Object | string): Promise<HTMLElement>;
    export function getClarificationElement(context: mls.msg.ExecutionContext): Promise<HTMLElement>;
    export function getAgentContext(taskId: string): Promise<{
        context: mls.msg.ExecutionContext;
        interaction: mls.msg.AIAgentStep;
        step: mls.msg.AIPayload;
    }>;
    export function loadAgent(agentName: string): Promise<IAgent | IAgentAsync | undefined>;
    export function loadTool(toolName: string): Promise<any | undefined>;
    type InstanceMode = 'agent' | 'tool';
    /**
     * agentName, ex: 'agentXX1' or '_100554_/l2/agents/agentXX1'
     */
    export function getInstanceByName(nameOrPath: string, mode: InstanceMode): Promise<IAgent | IAgentAsync | undefined>;
    export interface IExecuteToolReturn {
        status: boolean;
        error: string;
        result: any;
    }
    export interface ClarificationValue {
        taskId: string;
        stepId: number;
        title: string;
        userLanguage: string;
        questions: ClarificationQuestions;
        legends: string[];
    }
    export interface ClarificationQuestions {
        [key: string]: Question;
    }
    export interface Question {
        type: 'open' | 'select' | 'boolean' | 'MoSCoW' | 'range';
        question: string;
        answer?: string | boolean;
        options?: QuestionOption[];
    }
    export interface QuestionOption {
        id: string;
        label: string;
    }
}
declare module "_102025_/l2/collabMessagesTaskDetails" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class CollabMessagesTaskDetails extends StateLitElement {
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        stepid: string;
        seen: Set<string>;
        interactionClarification: mls.msg.AIAgentStep | undefined;
        directClarification: HTMLElement | undefined;
        directClarificationContent: HTMLElement | undefined;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderTaskModeJson;
        private renderTaskModeDetails;
        private renderDirectResult;
        private renderDirectClarification;
        private renderlLongMemory;
        private renderTaskInfo;
        private renderTaskInteractions;
        private renderPayload;
        private renderPayloadAgent;
        private renderInteration;
        private renderAgent;
        private renderTool;
        private renderClarificationDetails;
        private renderFlexible;
        private renderClarification;
        private renderResult;
        private setClarification;
        private executeHTMLClarificationScript;
        private syntaxHighlight;
        private onTaskChange;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewAgent" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewAgent extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIAgentStep | null;
        agentDescription: string;
        private prompts;
        private mode;
        private lastKey;
        firstUpdated(): void;
        update(changedProperties: any): void;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderInputs(): any;
        renderPrompt(prompt: mls.msg.IAMessageInputType, idx: number): any;
        renderResults(): any;
        private init;
        private getDescription;
        private getPrompts;
        private selectTabInput;
        private selectTabInfo;
        private selectTabResult;
        private replayForSupport;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewClarification" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewClarification extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIClarificationStep | null;
        private mode;
        private tag;
        clarificationid: HTMLDivElement | undefined;
        private elClarification;
        firstUpdated(): void;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderClarification(): any;
        renderResults(): any;
        private selectTabClarification;
        private selectTabInfo;
        private getFile;
        private getAgentBeforeStep;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewFlexible" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewFlexible extends CollabLitElement {
        private mode;
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIFlexibleResultStep | null;
        msize: string;
        elEditor: IHTMLEditorElement | undefined;
        private get sharedEditor();
        private get sharedMonaco();
        firstUpdated(): Promise<void>;
        updated(changedProps: Map<string, any>): void;
        private ensureEditorCreated;
        /**
         * Called every time the flexible tab becomes visible.
         * Creates the shared editor once, then re-appends it to the fresh #elEditor node.
         */
        private mountEditor;
        private createModel;
        private updateEditorContent;
        render(): any;
        private setMode;
        private renderMode;
        private renderInfo;
        private renderSummary;
        private renderFlexible;
        private renderResults;
        private readonly editorConf;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewTools" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewTools extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIToolStep | null;
        private mode;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderTools(): any;
        renderResults(): any;
        private selectTabTools;
        private selectTabInfo;
        private selectTabResult;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewResult" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewResult extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIResultStep | null;
        private mode;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderResults(): any;
        private selectTabInfo;
        private selectTabResult;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewRaw" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class CollabMessagesTaskPreviewRaw extends CollabLitElement {
        private mode;
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIFlexibleResultStep | null;
        msize: string;
        elEditor: IHTMLEditorElement | undefined;
        private resizeObserver;
        private get sharedEditor();
        private get sharedMonaco();
        firstUpdated(): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProps: Map<string, any>): void;
        private ensureEditorCreated;
        /**
         * Called every time the flexible tab becomes visible.
         * Creates the shared editor once, then re-appends it to the fresh #elEditor node.
         */
        private mountEditor;
        private observeEditorHost;
        private createModel;
        private updateEditorContent;
        private layoutEditor;
        render(): any;
        private setMode;
        private renderMode;
        private renderInfo;
        private renderTaskModeDetails;
        private renderTaskInfo;
        private renderlLongMemory;
        private renderSummary;
        private renderFlexible;
        private renderResults;
        private readonly editorConf;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreview" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    import "_102025_/l2/collabMessagesTaskPreviewAgent";
    import "_102025_/l2/collabMessagesTaskPreviewClarification";
    import "_102025_/l2/collabMessagesTaskPreviewFlexible";
    import "_102025_/l2/collabMessagesTaskPreviewTools";
    import "_102025_/l2/collabMessagesTaskPreviewResult";
    import "_102025_/l2/collabMessagesTaskPreviewRaw";
    export class CollabMessagesTaskPreview extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        modeTest: boolean;
        father: HTMLElement | undefined;
        initialStep: string;
        private stepMap;
        private navigationStack;
        private currentStepId;
        private allSteps;
        private lastStepId;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderStep(): any;
        renderNavigation(stepId: number): any;
        renderStepDetails(step: any | undefined): any;
        renderBreadcrumb(): any;
        renderRaw(): any;
        renderAgent(step: mls.msg.AIAgentStep): any;
        renderClarification(step: mls.msg.AIClarificationStep): any;
        renderFlexible(step: mls.msg.AIFlexibleResultStep): any;
        renderTools(step: mls.msg.AIToolStep): any;
        renderResult(step: mls.msg.AIResultStep): any;
        renderWorkflow(step: {
            stepId: number;
            type: string;
            workflowName?: string;
            status?: string;
            nextSteps?: any[];
        }): any;
        private init;
        private onTaskChange;
        private buildStepMap;
        private tryNext;
        private navigateToStep;
        private goBack;
    }
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102025_/l2/collabMessagesTaskLogPreview" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    export class PluginTaskLogPreview100554 extends StateLitElement {
        currentStepId: number;
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        father: HTMLElement | undefined;
        template?: TemplateResult;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProperties: any): void;
        render(): any;
        private onTaskChange;
        private createFeedBack;
    }
}
declare module "_102025_/l2/collabMessagesChatMessage" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IChatPreferences, IMessage, IThreadInfo } from "_102025_/l2/collabMessagesHelper";
    export class CollabMessagesChatMessage102025 extends StateLitElement {
        message?: IMessage;
        messageId?: string;
        allThreads: msg.Thread[];
        actualThread: IThreadInfo | undefined;
        usersAvaliables: msg.User[];
        userId: string | undefined;
        openedReactionMessageId?: string;
        reactionPickerTarget?: HTMLElement;
        openedMenuFor?: string;
        messageMenuTarget?: HTMLElement;
        openedReactionListMessageId?: string;
        reactionListTarget?: HTMLElement;
        userPreferenceChat?: IChatPreferences;
        private messageMenuPlacement;
        private reactionListPlacement;
        onTaskClick?: Function;
        private msg;
        private readonly reactionEmojis;
        updated(): void;
        render(): any;
        private renderMessage;
        private renderMessageByLanguage;
        private replyCache;
        private renderReplyPreview;
        private loadReplyPreview;
        private onReplyPreviewClick;
        private renderMessageResultByLanguage;
        private renderMessageFooterResult;
        private renderCollabMessagesRichPreview;
        private onMentionHover;
        private onChannelHover;
        private removeAllUserModal;
        private removeAllChannelModal;
        private getTitleMessageTranslated;
        private renderReactions;
        private renderReactionListPopup;
        private findUser;
        private openReactionList;
        private updateReactionListPlacement;
        private removeReactionFromList;
        private closeReactionList;
        private renderReactionButtonAdd;
        private renderReactionPicker;
        private onPickerEmojiSelect;
        private openReactionPicker;
        private closeReactionPicker;
        private toggleReaction;
        private updateReactionOnDb;
        private animateReactionPicker;
        private positionReactionPicker;
        private renderSubMenuButton;
        private openMessageMenu;
        private positionMessageMenu;
        private closeMessageMenu;
        private renderMessageMenu;
        private onReplyClick;
        private closeAllPopups;
        private updateMessageMenuPlacement;
        private getMessageOrderAt;
        private normalizeMessageId;
    }
}
declare module "_102025_/l2/collabMessagesEmojis" {
    export interface IEmoji {
        unicode: string;
        shortname: string;
        aliases: string[];
    }
    export const emojiList: {
        text: string;
        value: string;
        description: string;
        alias: string[];
    }[];
}
declare module "_102025_/l2/collabMessagesAvatar" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesAvatar extends StateLitElement {
        avatar: string;
        alt: string;
        width: string;
        height: string;
        updated(changedProperties: Map<string, any>): void;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesRichTextParser" {
    export type RichToken = {
        type: 'text';
        value: string;
    } | {
        type: 'bold';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'italic';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'strike';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'inline-code';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'code-block';
        language: string;
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'mention';
        value: string;
        userId: string;
    } | {
        type: 'agent';
        value: string;
    } | {
        type: 'channel';
        value: string;
    } | {
        type: 'command';
        value: string;
    } | {
        type: 'help';
        value: string;
    } | {
        type: 'link';
        text: string;
        url: string;
    } | {
        type: 'raw-link';
        url: string;
    } | {
        type: 'blockquote';
        children: RichToken[];
    } | {
        type: 'list';
        ordered: boolean;
        items: RichToken[][];
    };
    export function parseRichText(input: string): RichToken[];
    export function parseInlineRichText(input: string, skipCodeBlock?: boolean): RichToken[];
}
declare module "_102025_/l2/collabMessagesPrompt" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesAvatar";
    export class CollabMessagesPrompt extends StateLitElement {
        private msg;
        textArea: HTMLTextAreaElement | undefined;
        overlayElement?: HTMLElement;
        mentionSuggestionsElement?: HTMLElement;
        wrapper?: HTMLElement;
        text: string;
        actualMention?: IMentions;
        mentionActive: boolean;
        mentionQuery: string;
        mentionSuggestions: IMentions[];
        mentionIndex: number;
        allUsers: msg.User[];
        allUsersValids: msg.User[];
        allAgents: IMentionAgent[];
        alreadyLoadingAgents: boolean;
        lastScopeLoaded: string | undefined;
        replyingTo?: {
            messageId: string;
            senderId: string;
            preview: string;
        };
        onSend: Function | undefined;
        threadId?: string;
        placeholder?: string;
        scope?: string;
        acceptAutoCompleteUser?: boolean;
        acceptAutoCompleteAgents?: boolean;
        enableRichPreview?: boolean;
        connectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        setReply(message: {
            messageId: string;
            senderId: string;
            preview: string;
        }): void;
        clearReply(): void;
        private getUsers;
        private getAgents;
        private getCaretCoordinates;
        private calculatePosition;
        private adjustTextAreaHeight;
        private handleScroll;
        private renderRichToken;
        private renderRichOverlay;
        render(): any;
        private renderReply;
        handleFocus(): Promise<void>;
        handleInput(e: MouseEvent): Promise<void>;
        private getUserSuggestions;
        private getAgentSuggestions;
        private getEmojiSuggestions;
        private handleKeyDown;
        private scrollToActiveMention;
        private selectMention;
        private extractAgentName;
        handleSend(): Promise<void>;
    }
    interface IMentionAgent {
        name: string;
        description: string;
        alias: string;
        avatar_url?: string;
    }
    interface IMentions {
        text: string;
        value: string;
        description: string;
        avatar_url?: string | undefined;
        type: 'user' | 'agent' | 'emoji';
    }
}
declare module "_102025_/l2/collabMessagesTaskRoom" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import * as msg from "_102025_/l2/shared/interfaces";
    import "_102025_/l2/collabMessagesChatMessage";
    import "_102025_/l2/collabMessagesPrompt";
    export class CollabMessagesTaskRoom extends StateLitElement {
        task: msg.TaskData | undefined;
        message: msg.Message | undefined;
        userId: string | undefined;
        private roomThread;
        private roomUsers;
        private messages;
        private loading;
        private error;
        private showScrollToBottom;
        private messagesContainer?;
        private ensuredKey;
        private lastRenderedMessageCount;
        private didInitialScroll;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private onMessagesScroll;
        private scrollToBottom;
        private scrollMessagesToBottom;
        private ensureRoom;
        private ensureRoomOnServer;
        private openKnownRoom;
        private syncMessages;
        private loadLocalMessages;
        private sendMessage;
        private cacheRoomThread;
        private getLastOrderAt;
        private getResponseLastOrderAt;
        private onThreadChange;
        private onMessageChange;
        private getUserId;
        private getParentThreadId;
        private getEnsureKey;
        private canUseTaskRoom;
        private toMessageView;
    }
}
declare module "_102025_/l2/collabMessagesTaskInfo" {
    import { StateLitElement } from "_102027_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesTaskDetails";
    import "_102025_/l2/collabMessagesTaskPreview";
    import "_102025_/l2/collabMessagesTaskLogPreview";
    import "_102025_/l2/collabMessagesTaskRoom";
    export class CollabMessagesTaskInfo extends StateLitElement {
        private elParent;
        private contentPluginStyle;
        private forceViewRaw;
        private hasTodo;
        private currentStepId;
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        restartPooling: boolean;
        isTest: boolean;
        stepid: string;
        seen: Set<string>;
        interactionClarification: mls.msg.AIAgentStep | undefined;
        directClarification: HTMLElement | undefined;
        directClarificationContent: HTMLElement | undefined;
        private activeTab;
        isClarificationPending: boolean;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        renderTab(): any;
        renderTabContent(activeTab: 'workflow' | 'step' | 'raw' | 'todo' | 'chat'): any;
        renderRaw(): any;
        renderStep(): any;
        renderTodo(): any;
        renderChat(): any;
        renderDirectClarification(): any;
        renderClarification(payload: mls.msg.AIClarificationStep): any;
        private clickForceViewRaw;
        private setClarification;
        private executeHTMLClarificationScript;
        private setTab;
        private canUseTaskRoom;
        private onTaskChange;
        private normalizeServiceDetailContainer;
        private restoreServiceDetailContainer;
    }
}
declare module "_102025_/l2/collabMessagesTopics" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesTopics extends StateLitElement {
        messages: IMessage[];
        topics: string[];
        expanded: boolean;
        selectedTopic: string | null;
        threadTopics: string[];
        render(): any;
        private emitTopic;
        private extractTopics;
        private groupTopics;
        private getHeadersTopicsFromMessages;
        private getTopicsFromMessagesOrdered;
    }
    interface IMessage extends msg.MessagePerformanceCache {
        context?: msg.ExecutionContext;
    }
}
declare module "_102025_/l2/collabMessagesAddParticipant" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesAddParticipant extends StateLitElement {
        private msg;
        userId: string | undefined;
        labelOkAddParticipant: string;
        labelErrorAddParticipant: string;
        userIdOrName: string;
        auth: msg.UserAuth;
        isAddParticipant: boolean;
        actualThread: IThreadActual | undefined;
        highlightedIndex: number;
        suggestions: string[];
        allUsers: string[];
        private users;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private onInput;
        private onBlur;
        private selectSuggestion;
        private onKeyDown;
        private onFocus;
        private onSubmitAddParticipant;
        private loadUsersAvaliables;
    }
    interface IThreadActual {
        thread: msg.ThreadPerformanceCache;
        users: msg.User[];
    }
}
declare module "_102025_/l2/collabMessagesChangeAvatar" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabChangeAvatar extends StateLitElement {
        private msg;
        value?: string;
        nameValue?: string;
        userId: string;
        threadId: string;
        private avatarPrompt;
        private avatarFile?;
        private isOpen;
        private generating;
        private preview?;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private onFileSelect;
        private triggerFileInput;
        private generateAvatarFromPrompt;
        private emitValueChanged;
        private safeSvg;
    }
}
declare module "_102025_/l2/collabMessagesThreadDetails" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesInputTag";
    import "_102025_/l2/collabMessagesAddParticipant";
    import "_102025_/l2/collabMessagesChangeAvatar";
    export class CollabMessagesThreadDetails extends StateLitElement {
        private msg;
        userId: string | undefined;
        threadDetails?: IThreadDetails;
        avatarEl?: HTMLElement;
        labelOk: string;
        labelError: string;
        labelErrorRemoveUser: string;
        labelErrorRemoveBoot: string;
        labelErrorAgent: string;
        labelOkAgent: string;
        private isLoading;
        private editedThreadDetails?;
        private isDirectMessage?;
        private isChannel?;
        private isFileChannel?;
        private isEditingDetails;
        private showAgentForm;
        private integrations;
        private selectedIntegrationId;
        private selectedAgentId;
        private isLoadingAgents;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        private loadIntegrations;
        updated(changedProperties: Map<string, any>): Promise<void>;
        private getAddedAgentIds;
        private getAvailableAgents;
        private getVisibilityLabel;
        private getCurrentUserNotification;
        private setCurrentUserNotification;
        private getStatusLabel;
        private enterEditMode;
        private cancelEditMode;
        render(): any;
        private renderDetailsViewMode;
        private renderDetailsEditMode;
        private renderUsers;
        private renderAvatar;
        private isUrl;
        private renderAgents;
        private renderAgentFormContent;
        private findAgentInfo;
        private openAgentForm;
        private closeAgentForm;
        private addAgentOpenClawInThread;
        private addIntegrationOpenClawInThread;
        private saveAgentOpenClaw;
        private removeAgentOpenClaw;
        private updateStatusAgent;
        private renderBots;
        private removeUser;
        private removeBot;
        private disableBot;
        private getChangedFields;
        private onAddParticipant;
        private saveChanges;
        private removeUserFromThread;
        private getThreadInfo;
    }
    interface IThreadDetails {
        thread: msg.ThreadPerformanceCache;
        users: msg.User[];
    }
}
declare module "_102025_/l2/collabMessagesUserModal" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesUserModal extends StateLitElement {
        private msg;
        open: boolean;
        user?: msg.User;
        actualUserId?: string;
        private isLoading;
        private errorMessage;
        private close;
        private handleGlobalMouseMove;
        firstUpdated(): void;
        disconnectedCallback(): void;
        private destroy;
        render(): any;
        private onClickUserAction;
    }
}
declare module "_102025_/l2/collabMessagesThreadModal" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesAvatar";
    export class CollabMessagesThreadModal extends StateLitElement {
        private msg;
        open: boolean;
        thread?: msg.ThreadPerformanceCache;
        private isLoading;
        private errorMessage;
        private handleGlobalMouseMove;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        disconnectedCallback(): void;
        private destroy;
        render(): any;
        private onClickThreadAction;
    }
}
declare module "_102025_/l2/collabMessagesFilter" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesFilter extends StateLitElement {
        private expanded;
        private query;
        placeholder: string;
        private toggleExpand;
        private handleKey;
        private handleInput;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesTextCode" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesTextCode extends StateLitElement {
        config: string | undefined;
        language: string;
        languages: any[];
        text: string;
        codeBlock: HTMLElement | undefined;
        select: HTMLSelectElement | undefined;
        private _resolveRendered;
        private markRendered;
        whenRendered: Promise<void>;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        private unescapeHtml;
        setCode(): void;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesRichPreviewText" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesTextCode";
    export class CollabMessagesRichPreviewText102025 extends StateLitElement {
        private msg;
        allHelpers: string[];
        allCommands: string[];
        allThreads: msg.Thread[];
        allUsers: msg.User[];
        text: string;
        showMarkers: boolean;
        render(): any;
        private renderTokens;
        private renderMarker;
        private renderToken;
        private renderText;
        private renderBold;
        private renderItalic;
        private renderStrike;
        private renderInlineCode;
        private renderCodeBlock;
        private renderAgent;
        private renderMention;
        private renderChannel;
        private renderCommand;
        private renderHelp;
        private renderLink;
        private renderRawLink;
        private renderBlockquote;
        private renderList;
        private copyToClipboard;
    }
}
declare module "_102025_/l2/collabMessagesChat" {
    import "_102025_/l2/collabMessagesTask";
    import "_102025_/l2/collabMessagesTaskInfo";
    import "_102025_/l2/collabMessagesTopics";
    import "_102025_/l2/collabMessagesPrompt";
    import "_102025_/l2/collabMessagesAvatar";
    import "_102025_/l2/collabMessagesThreadDetails";
    import "_102025_/l2/collabMessagesUserModal";
    import "_102025_/l2/collabMessagesThreadModal";
    import "_102025_/l2/collabMessagesFilter";
    import "_102025_/l2/collabMessagesAdd";
    import "_102025_/l2/collabMessagesChatMessage";
    import "_102025_/l2/collabMessagesRichPreviewText";
    import * as msg from "_102025_/l2/shared/interfaces";
    import { IMessage, IThreadInfo } from "_102025_/l2/collabMessagesHelper";
    import { CollabMessagesPrompt } from "_102025_/l2/collabMessagesPrompt";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesChat extends StateLitElement {
        private msg;
        collabMessagesPrompt: CollabMessagesPrompt | undefined;
        private unreadEl;
        private messageContainer;
        private isLoadingThread;
        private filteredThreads;
        private isThreadError;
        private threadErrorMsg;
        private lastTopicFilter;
        private welcomeMessage;
        private usersAvaliables;
        private elementTaskDetails;
        private taskNotificationNavDirection;
        group: 'CONNECT' | 'APPS' | 'DOCS' | 'CRM';
        userId: string | undefined;
        threadToOpen: string | undefined;
        taskToOpen: string | undefined;
        userDeviceId: string | undefined;
        activeScenerie: IScenery;
        actualThread: IThreadInfo | undefined;
        actualTask: msg.TaskData | undefined;
        actualMessage: IMessage | undefined;
        actualMessages: IMessage[];
        actualMessagesParsed: IMessageGrouped;
        isLoadingMessages: boolean;
        searchTerm: string;
        userThreads: IThread;
        allThreads: msg.Thread[];
        lastMessageReaded: string | undefined;
        unreadCountInSelectedThread: number;
        private isSystemChangeScroll;
        private savedScrollTop;
        private hasMoreMessagesLocalDB;
        private hasMoreMessagesBefore;
        private messagesLimit;
        private messagesOffset;
        private isLoadingMoreMessages;
        private isChangeTopics;
        private wasMessagesAtBottom;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderHeader;
        private renderContent;
        private renderChatMessages;
        private renderTaskNotificationNav;
        private renderTaskNotificationNavIcon;
        private renderWelcomeMessage;
        private renderTopics;
        private onTopicClick;
        private removeAllModal;
        private renderPrompt;
        private renderListThreads;
        private getThreadAvatar;
        private getThreadName;
        private isDirectMessage;
        private renderThreadsByStatus2;
        private renderThreadItemLi;
        private renderTaskPendingsCount;
        private formatMessageDate;
        private renderArchivedThreads;
        private renderDeletingThreads;
        private renderDeletedThreads;
        private renderThreadSearch;
        private renderTaskDetails;
        private renderThreadDetails;
        private renderThreadAdd;
        private onSearchInput;
        private getScrollAnchor;
        private restoreScrollAnchor;
        private updateMessagesAfterScrollMore;
        private getBeforeMessagesInServer;
        private onCopyChat;
        private onChatScroll;
        private getFirstPendingTaskNotificationInView;
        private getTaskNotificationElement;
        private updateTaskNotificationNavDirection;
        private scrollToTaskNotification;
        private groupThreadsByPrefix;
        private getOrdenedThreadsByStatus;
        private getFilteredThreads;
        private getMessagesAfter;
        private getMessagesBefore;
        private parseMessages;
        private groupMessages;
        private parseLocalDate;
        private mergeMessages;
        private onThreadClick;
        private updateThreadPendingsInBackground;
        private openTask;
        private checkWelcomeMessage;
        private checkNotificationsUnreadMessages;
        private alreadyCheckForRegisterToken;
        private checkForRegisterNotification;
        private loadAllMessages;
        private updateMessagesOnDb;
        private clearUnreadMessageFromThread;
        private updateLastMessage;
        private onTitleClick;
        private onThreadDetailsClick;
        private onThreadAddClick;
        private handleSend;
        private handlePromptResize;
        private scrollMessagesToBottom;
        private addMessage;
        private addMessageIA;
        private updateMessageAI;
        private createTempMessage;
        private updateMessage2;
        private onTaskClick;
        private hasStudioTaskDetailHost;
        private createLocalTaskDetails;
        private onReplyPreviewClick;
        private onReplyMessageClick;
        private getTaskUpdate;
        private clearMissingTaskReference;
        private normalizeTaskMessageId;
        private normalizeMessageId;
        private getThreadInfo;
        private saveScrollPosition;
        private restoreScrollPosition;
        private onTaskChange;
        private onThreadChange;
        private onMessageChange;
        private onMessageSend;
        private onVisibilityChange;
        private onDocumentClick;
        private scrollLock;
        private verifyChatScroll;
        private delay;
        private nextFrame;
        private waitingForRenderCodesWebComponents;
    }
    type IMessageGrouped = {
        [key: string]: IMessage[];
    };
    type IThread = {
        [key: string]: IThreadInfo[];
    };
    type IScenery = 'list' | 'details' | 'loading' | 'task' | 'threadDetails' | 'threadAdd';
}
declare module "_102025_/l2/collabTasksSidebar" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    type ScreenId = 'board' | 'mytasks' | 'workflows' | 'simulator' | 'approvals' | 'analytics' | 'settings';
    export class CollabTasksSidebar extends StateLitElement {
        activeScreen: ScreenId;
        private collapsed;
        static styles: any;
        private _emit;
        render(): any;
    }
}
declare module "_102025_/l2/collabTasksTopbar" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabTasksTopbar extends StateLitElement {
        title: string;
        subtitle: string;
        static styles: any;
        render(): any;
        private _reload;
    }
}
declare module "_102025_/l2/collabTasksEmptyState" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabTasksEmptyState extends StateLitElement {
        title: string;
        subtitle: string;
        static styles: any;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesTasks" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabTasksSidebar";
    import "_102025_/l2/collabTasksTopbar";
    import '/_102025_/l2/collabTasksBoard.js';
    import '/_102025_/l2/collabTasksMyTasks.js';
    import "_102025_/l2/collabTasksEmptyState";
    export class CollabMessagesTasks extends StateLitElement {
        private screen;
        private reloadKey;
        static styles: any;
        render(): any;
        private _renderScreen;
        private _screenLabel;
    }
}
declare module "_102025_/l2/collabMessagesApps" { }
declare module "_102025_/l2/collabMessagesMoments" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesMoments102025 extends StateLitElement {
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesSettingsOpenClaw" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import * as msg from "_102025_/l2/shared/interfaces";
    type ViewMode = 'main' | 'connectorDetails' | 'editAgent';
    interface IOpenClawConnectorLocal extends msg.OpenClawConnector {
        isNew?: boolean;
        gatewayTokenChanged?: boolean;
        inboundTokenChanged?: boolean;
    }
    export class CollabMessagesSettingsOpenClaw extends StateLitElement {
        private msg;
        userId: string;
        actualIntegration: msg.IOpenClawIntegration | undefined;
        integrations: msg.IOpenClawIntegration[];
        connectors: IOpenClawConnectorLocal[];
        viewMode: ViewMode;
        currentConnectorId: string;
        editingConnector: IOpenClawConnectorLocal | null;
        isTestingConnection: boolean;
        connectionTestResult: 'none' | 'success' | 'error' | 'warning';
        connectionTestMessage: string;
        connectionTestLatency: number;
        showGatewayToken: boolean;
        showInboundToken: boolean;
        copiedToken: 'gateway' | 'inbound' | null;
        showDeleteConfirmation: boolean;
        deleteConfirmationInput: string;
        newAgentName: string;
        newAgentAvatarUrl: string;
        editingAgent: msg.IOpenClawAgent | null;
        isNewAgent: boolean;
        newAgentWorkspace: string;
        newAgentEmoji: string;
        newAgentSoulMd: string;
        newAgentIdentityMd: string;
        showDeleteAgentConfirmation: boolean;
        agentToDelete: msg.IOpenClawAgent | null;
        deleteAgentFiles: boolean;
        isDeletingAgent: boolean;
        labelOkConnector: string;
        labelErrorConnector: string;
        labelOkAgent: string;
        labelErrorAgent: string;
        isSavingConnector: boolean;
        isSavingAgent: boolean;
        firstUpdated(): Promise<void>;
        render(): any;
        private renderOpenClawConnectors;
        private renderConnectorCard;
        private renderToggleIcon;
        private renderConnectorDetailsView;
        private renderConfigurationSection;
        private renderTestConnectionSection;
        private renderAgentSection;
        private renderDeleteSection;
        private renderDeleteConfirmation;
        private renderAgentCard;
        private renderDeleteAgentModal;
        private renderAvatar;
        private isUrl;
        private renderEditAgentView;
        private navigateTo;
        private handleAddConnector;
        private clearErrors;
        private clearStates;
        private getIntegration;
        private handleOpenConnectorDetails;
        private handleBackToMain;
        private handleCancelConnector;
        private handleConnectorNameChange;
        private handleConnectorUrlChange;
        private handleGatewayTokenChange;
        private handleInboundTokenChange;
        private handleChangeToken;
        private handleTimeoutChange;
        private handleOutputModeChange;
        private handleConnectorEnabledToggle;
        private handleGenerateToken;
        private handleSaveConnector;
        private saveIntegration;
        private removeIntegration;
        private saveOrUpdateOpenClawConnector;
        private handleTestConnection;
        private checkDomainExists;
        private handleToggleDeleteConfirmation;
        private handleDeleteConfirmationInput;
        private handleCancelDelete;
        private handleConfirmDelete;
        private handleOpenAddAgent;
        private handleOpenEditAgent;
        private handleBackToConnectorDetails;
        private handleNewAgentNameInput;
        private handleNewAgentAvatarInput;
        private handleNewAgentWorkspaceInput;
        private handleNewAgentEmojiInput;
        private handleNewAgentSoulMdInput;
        private handleNewAgentIdentityMdInput;
        private handleGenerateAgentAvatar;
        private handleSaveAgent;
        private handleOpenDeleteAgentConfirmation;
        private handleCloseDeleteAgentConfirmation;
        private handleDeleteAgentFilesChange;
        private handleConfirmDeleteAgent;
        private handleDisableAgent;
        private handleToggleTokenVisibility;
        private handleCopyToken;
    }
}
declare module "_102025_/l2/collabMessagesSettingsChatPreferences" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesSettingsChatPreferences extends StateLitElement {
        private msg;
        private chatPreferences;
        private isSaving;
        private labelOk;
        private labelError;
        firstUpdated(): Promise<void>;
        render(): any;
        private handleTranslationModeChange;
        private handleLanguageInput;
        private handleSave;
    }
}
declare module "_102025_/l2/collabMessagesSettingsUser" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesSettingsUser extends StateLitElement {
        private msg;
        private userPerfil;
        private viewMode;
        private isSaving;
        private labelOk;
        private labelError;
        private tempAvatarUrl;
        private avatarUrlValid;
        private avatarLoading;
        firstUpdated(): Promise<void>;
        render(): any;
        private renderUserSection;
        private renderEditAvatarView;
        private getUserPerfil;
        private handleNameInput;
        private handleSave;
        private handleOpenEditAvatar;
        private handleCancelEditAvatar;
        private handleAvatarUrlInput;
        private handleAvatarError;
        private handleSaveAvatar;
    }
}
declare module "_102025_/l2/collabMessagesSettingsNotificationPreferences" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesSettingsNotificationPreferences extends StateLitElement {
        private msg;
        private notificationPreferences;
        private audioEnabled;
        private isSaving;
        private labelOk;
        private labelError;
        firstUpdated(): Promise<void>;
        render(): any;
        private renderEnabled;
        private renderDisabled;
        private renderReadMore;
        private getNotificationStatus;
        private handleAudioToggle;
        private handleEnableNotifications;
    }
}
declare module "_102025_/l2/collabMessagesSettingsGeral" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesSettingsOpenClaw";
    import "_102025_/l2/collabMessagesSettingsChatPreferences";
    import "_102025_/l2/collabMessagesSettingsUser";
    import "_102025_/l2/collabMessagesSettingsNotificationPreferences";
    import * as msg from "_102025_/l2/shared/interfaces";
    type ViewMode = 'all' | 'user' | 'chat' | 'notification' | 'openclaw';
    export class CollabMessagesSettingsGeral102025 extends StateLitElement {
        private msg;
        viewMode: ViewMode;
        userPerfil: msg.User | undefined;
        private scrollPositions;
        private show;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderUser;
        private renderChatPreferences;
        private renderPreferencesNotifications;
        private renderOpenClawConnectors;
        private onSettingsChange;
        private getUserPerfil;
        private saveScrollPosition;
        private restoreScrollPosition;
        private navigateTo;
    }
}
declare module "_102025_/l2/collabMessagesTabMenu" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export interface TabMenuItem {
        id: string;
        icon: TemplateResult;
        label: string;
        activeColor?: string;
        type: 'tab' | 'button';
    }
    export class CollabMessagesTabMenu extends StateLitElement {
        items: TabMenuItem[];
        activeId: string;
        private get _tabs();
        private get _buttons();
        private _handleItemClick;
        private _renderItem;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessages" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_102025_/l2/collabMessagesAdd";
    import "_102025_/l2/collabMessagesChat";
    import "_102025_/l2/collabMessagesTasks";
    import "_102025_/l2/collabMessagesApps";
    import "_102025_/l2/collabMessagesMoments";
    import "_102025_/l2/collabMessagesSettingsGeral";
    import "_102025_/l2/collabMessagesTabMenu";
    export class CollabMessages extends CollabLitElement {
        private msg;
        dataLocal: IDataLocal;
        activeTab: ITabType;
        activeScenerie: IScenery;
        isLoadingThread: boolean;
        userPerfil: msg.User | undefined;
        userThreads: IThreadData;
        showNotificationAlert: boolean;
        threadToOpen: string;
        taskToOpen: string;
        lastLevel: number;
        modeMenu: string;
        private groupSelected;
        private menuItems;
        connectedCallback(): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private checkNotificationPermission;
        private startPendentsPoolingsIfNeeded;
        private onThreadChange;
        private onThreadOpen;
        private setEvents;
        private removeEvents;
        renderHeader(): any;
        renderTabs(): any;
        renderAlert(): any;
        private onAlertClose;
        renderCRM(): any;
        renderTasks(): any;
        renderMoments(): any;
        renderApps(): any;
        renderSettings(): any;
        renderConnect(): any;
        private getUser;
        private updateThreads;
        private searchForDeletedThreadsPending;
        private updateUsersThread;
        private getThreadFromLocalDB;
        private getThreadInfo;
        private onThreadCreate;
        private checkNotificationPending;
        private onTabChange;
        private onButtonClick;
    }
    interface IDataLocal {
        lastTab: ITabType;
    }
    type IThreadData = {
        [key: string]: IThreadInfo;
    };
    interface IThreadInfo {
        thread: msg.Thread;
        users: msg.User[];
    }
    type ITabType = 'CRM' | 'TASK' | 'MOMENTS' | 'CONNECT' | 'APPS' | 'SETTINGS' | 'Add' | 'Loading';
    type IScenery = 'tabs' | 'settings' | 'findTask';
}
declare module "_102025_/l2/collabMessagesAdd.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesAddParticipant.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesApps.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesAppsMenu.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesAppsMenu" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export interface IMenu {
        name: string;
        icon: string;
        project: number;
        path: string;
        menu: IMenuItem[];
    }
    export interface IMenuItem {
        title: string;
        icon: string;
        url: string;
        pageName: string;
        target?: string;
        children?: IMenuItem[];
    }
    export class CollabMessagesAppsMenu extends StateLitElement {
        keyFavoritesLocalStorage: string;
        identifier: string;
        menuTitle: string;
        menuModules: IMenu[];
        favorites: string[];
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        private loadFavorites;
        private getItemPath;
        private toggleFavorite;
        private isFavorite;
        private handleMenuClick;
        private renderMenuItem;
        render(): any;
        private findItemByPath;
    }
}
declare module "_102025_/l2/collabMessagesAvatar.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesChangeAvatar.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesChat.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesChatMessage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesEmojis.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesEvents.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesFilter.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesHelper.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesIcons.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesIndexedDB.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesInputTag.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesMoments.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesPrompt.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesRichPreviewText.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesRichTextParser.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesSettingsChatPreferences.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesSettingsGeral.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesSettingsNotificationPreferences.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesSettingsOpenClaw.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesSettingsUser.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesSyncNotifications.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTabMenu.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTask.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/tsTestAST" {
    export interface ICANTest {
        functionName: string;
        params: Record<string, any>[];
    }
    export interface ICANIntegration {
        enabled: boolean;
        description: string;
        page: string;
        functionName: string;
        schema: Record<string, ICANSchema>;
    }
    export interface ICANSchema {
        type: string;
        optional?: boolean;
        description?: string;
    }
}
declare module "_102025_/l2/collabMessagesTaskDetails.test" {
    import { ICANTest, ICANIntegration } from "_102025_/l2/tsTestAST";
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskInfo.test" {
    import { ICANTest, ICANIntegration } from "_102025_/l2/tsTestAST";
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskLogPreview.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskLogPreview.test" {
    import { ICANTest, ICANIntegration } from "_102025_/l2/tsTestAST";
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskPreview.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreview.test" {
    import { ICANTest, ICANIntegration } from "_102025_/l2/tsTestAST";
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskPreviewAgent.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreviewAgent.test" {
    import { ICANTest, ICANIntegration } from "_102025_/l2/tsTestAST";
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskPreviewClarification.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreviewClarification.test" {
    import { ICANTest, ICANIntegration } from "_102025_/l2/tsTestAST";
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskPreviewFlexible.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreviewFlexible.test" {
    import { ICANTest, ICANIntegration } from "_102025_/l2/tsTestAST";
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskPreviewRaw.test" {
    import { ICANTest, ICANIntegration } from "_102025_/l2/tsTestAST";
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskPreviewResult.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreviewResult.test" {
    import { ICANTest, ICANIntegration } from "_102025_/l2/tsTestAST";
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTaskPreviewTools.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTaskPreviewTools.test" {
    import { ICANTest, ICANIntegration } from "_102025_/l2/tsTestAST";
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102025_/l2/collabMessagesTasks.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTextCode.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesThreadDetails.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesThreadModal.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesTopics.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabMessagesUserModal.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/collabTasksCard" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import * as msg from "_102025_/l2/shared/interfaces";
    export class CollabTasksCard extends StateLitElement {
        task: msg.TaskData | undefined;
        tagVocabulary: msg.TagVocabularyEntry[];
        static styles: any;
        render(): any;
        connectedCallback(): void;
        private _onClick;
    }
}
declare module "_102025_/l2/designSystem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102025_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102025_/l2/project.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102025_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102025_/l2/shared/api.defs" {
    export const asis: mls.defs.AsIs;
}
