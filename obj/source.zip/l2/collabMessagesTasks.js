/// <mls fileReference="_102025_/l2/collabMessagesTasks.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    myTasks: 'Minhas tasks',
    workflows: 'Workflows',
    simulator: 'Simulador',
    approvals: 'Aprovações',
    analytics: 'Analytics',
    settings: 'Configurações',
    board: 'Board',
    comingSoon: 'Em desenvolvimento',
};
const message_en = {
    myTasks: 'My tasks',
    workflows: 'Workflows',
    simulator: 'Simulator',
    approvals: 'Approvals',
    analytics: 'Analytics',
    settings: 'Settings',
    board: 'Board',
    comingSoon: 'In development',
};
/// **collab_i18n_end**
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { getUserId } from '/_102025_/l2/collabMessagesHelper.js';
import { openElementInServiceDetails } from '/_102027_/l2/libCommom.js';
import '/_102025_/l2/collabTasksSidebar.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
let CollabMessagesTasks = class CollabMessagesTasks extends StateLitElement {
    constructor() {
        super(...arguments);
        this.screen = 'board';
    }
    connectedCallback() {
        super.connectedCallback();
        this._onBoardFilter = (e) => {
            const { pmaId } = e.detail;
            this.screen = 'board';
            this._openBoardWithFilter(pmaId);
        };
        const w = window?.top ?? window;
        w.addEventListener('tasks-open-board-filter', this._onBoardFilter);
        this._openScreen('board');
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        const w = window?.top ?? window;
        w.removeEventListener('tasks-open-board-filter', this._onBoardFilter);
    }
    async _openBoardWithFilter(pmaId) {
        const userId = getUserId() || '';
        await import('/_102025_/l2/collabTasksBoard.js');
        const board = document.createElement('collab-tasks-board-102025');
        board.userId = userId;
        board.organizationId = 'collabcodes';
        board.reloadKey = Date.now();
        board.initialPmaFilter = pmaId;
        openElementInServiceDetails(board);
    }
    render() {
        return html `
      <collab-tasks-sidebar-102025
        .activeScreen=${this.screen}
        @screen-change=${(e) => this._onScreenChange(e.detail)}
      ></collab-tasks-sidebar-102025>
    `;
    }
    _onScreenChange(screen) {
        this.screen = screen;
        this._openScreen(screen);
    }
    async _openScreen(screen) {
        const msg = getMsg();
        const userId = getUserId() || '';
        let el;
        if (screen === 'board') {
            await import('/_102025_/l2/collabTasksBoard.js');
            const board = document.createElement('collab-tasks-board-102025');
            board.userId = userId;
            board.organizationId = 'collabcodes';
            board.reloadKey = Date.now();
            el = board;
        }
        else if (screen === 'mytasks') {
            await import('/_102025_/l2/collabTasksMyTasks.js');
            const myTasks = document.createElement('collab-tasks-my-tasks-102025');
            myTasks.userId = userId;
            el = myTasks;
        }
        else if (screen === 'workflows') {
            await import('/_102025_/l2/collabTasksWorkflows.js');
            const wf = document.createElement('collab-tasks-workflows-102025');
            wf.userId = userId;
            el = wf;
        }
        else if (screen === 'approvals') {
            await import('/_102025_/l2/collabTasksApprovals.js');
            const ap = document.createElement('collab-tasks-approvals-102025');
            ap.userId = userId;
            el = ap;
        }
        else if (screen === 'analytics') {
            await import('/_102025_/l2/collabTasksAnalytics.js');
            const an = document.createElement('collab-tasks-analytics-102025');
            an.userId = userId;
            el = an;
        }
        else if (screen === 'settings') {
            await import('/_102025_/l2/collabTasksSettings.js');
            const st = document.createElement('collab-tasks-settings-102025');
            st.userId = userId;
            st.organizationId = 'collabcodes';
            el = st;
        }
        else {
            await import('/_102025_/l2/collabTasksEmptyState.js');
            const empty = document.createElement('collab-tasks-empty-state-102025');
            const label = msg[screen] ?? screen;
            empty.setAttribute('title', label);
            empty.setAttribute('subtitle', msg.comingSoon);
            el = empty;
        }
        openElementInServiceDetails(el);
    }
};
__decorate([
    state()
], CollabMessagesTasks.prototype, "screen", void 0);
CollabMessagesTasks = __decorate([
    customElement('collab-messages-tasks-102025')
], CollabMessagesTasks);
export { CollabMessagesTasks };
