/// <mls fileReference="_102025_/l2/collabMessagesThreadModal.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { collab_clock_static, collab_users } from '/_102025_/l2/collabMessagesIcons.js';
import { getDateFormated, formatTimestamp } from '/_102025_/l2/collabMessagesHelper.js';
import { dispatchThreadOpen } from '/_102025_/l2/collabMessagesEvents.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102025_/l2/collabMessagesAvatar.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    userInThread: 'pessoas nesse canal',
    seeChannel: 'Ver canal',
};
const message_en = {
    loading: 'Loading...',
    userInThread: ' people in this channel',
    seeChannel: 'See channel',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesThreadModal = class CollabMessagesThreadModal extends StateLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.open = true;
        this.isLoading = false;
        this.errorMessage = '';
        this.handleGlobalMouseMove = (e) => {
            const modal = this.querySelector('collab-messages-thread-modal-102025');
            if (modal && !modal.contains(e.target)) {
                this.destroy();
            }
        };
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        document.addEventListener('mousemove', this.handleGlobalMouseMove);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        document.removeEventListener('mousemove', this.handleGlobalMouseMove);
    }
    destroy() {
        this.remove();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.open)
            return null;
        return html `
        <div class="collab-messages-thread-modal-box"
            @mouseover=${(e) => e.stopPropagation()}
            @mouseleave=${(e) => { e.stopPropagation(); this.destroy(); }}
            @click=${(e) => e.stopPropagation()}
        >
            <div class="collab-messages-thread-modal-header">
            <collab-messages-avatar-102025 avatar=${this.thread?.avatar_url} alt=${this.thread?.name} ></collab-messages-avatar-102025>
                <div>
                    <div class="collab-messages-thread-modal-title">${this.thread?.name}</div>
                    <div class="collab-messages-thread-modal-subtitle">${collab_users}${this.thread?.users.length || '0'} ${this.msg.userInThread}</div>
                    <div class="collab-messages-thread-modal-subtitle">${collab_clock_static} ${getDateFormated(formatTimestamp(this.thread?.lastMessageTime || '')?.dateFull || '')}</div>
                    <div class="collab-messages-thread-modal-userStatus ${this.thread?.status}"> ● ${this.thread?.status}</div>
                </div>
            </div>

            ${this.errorMessage ? html `<small class="user-message-error">${this.errorMessage}<small>` : ''}

      
            <div class="collab-messages-thread-modal-actions">
                <button
                    @click=${this.onClickThreadAction} 
                    class="collab-messages-thread-modal-message-btn"
                    ?disabled=${this.isLoading}
                >
                    ${this.isLoading ? html `<span class="loader"></span>` : html `${this.msg.seeChannel}`}
                </button>
            </div>
            
        
        </div>
    
    `;
    }
    async onClickThreadAction() {
        if (!this.thread)
            return;
        this.isLoading = true;
        try {
            dispatchThreadOpen(this.thread?.threadId);
        }
        catch (err) {
            this.errorMessage = err.message;
        }
        finally {
            this.isLoading = false;
        }
        ;
    }
};
__decorate([
    property({ type: Boolean })
], CollabMessagesThreadModal.prototype, "open", void 0);
__decorate([
    property()
], CollabMessagesThreadModal.prototype, "thread", void 0);
__decorate([
    state()
], CollabMessagesThreadModal.prototype, "isLoading", void 0);
__decorate([
    state()
], CollabMessagesThreadModal.prototype, "errorMessage", void 0);
CollabMessagesThreadModal = __decorate([
    customElement('collab-messages-thread-modal-102025')
], CollabMessagesThreadModal);
export { CollabMessagesThreadModal };
