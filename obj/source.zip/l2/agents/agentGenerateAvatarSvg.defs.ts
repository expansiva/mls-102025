/// <mls shortName="agentGenerateAvatarSvg" project="102025" enhancement="_blank" folder="agents" />

