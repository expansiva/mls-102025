/// <mls fileReference="_102025_/l2/collabMessagesTaskLogPreview.ts" enhancement="_102027_/l2/enhancementLit" />
import { html, TemplateResult } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { getRootAgent } from '/_102027_/l2/aiAgentHelper.js';
import { IAgent, IAgentAsync } from '/_102027_/l2/aiAgentBase.js';
import { loadAgent } from '/_102027_/l2/aiAgentOrchestration.js';
import '/_102025_/l2/aiAgentDefaultFeedback.js';
 

@customElement('collab-messages-task-log-preview-102025')  
export class PluginTaskLogPreview102025 extends StateLitElement {

  @state() currentStepId: number = 0;

  @property() task: mls.msg.TaskData | undefined = undefined;
  @property() message: mls.msg.Message | undefined = undefined;
  @property() father: HTMLElement | undefined;


  @state() template?: TemplateResult;

  async firstUpdated(changedProperties: Map<PropertyKey, unknown>) {
    window.addEventListener('task-change', this.onTaskChange);
    //this.task = await getTask('20250917143000.1001');
    this.createFeedBack();

  }

  disconnectedCallback() {
    super.disconnectedCallback();
    window.removeEventListener('task-change', this.onTaskChange);
  }

  updated(changedProperties: any) {
    if (changedProperties.has('currentStepId')) {
      const oldValue = changedProperties.get('currentStepId');
      const newValue = +this.currentStepId;

      if (!this.father || newValue === 0) return
      (this.father as any).currentStepId = newValue;
      (this.father as any).activeTab = 'step';
      
    }
  }

  render() {
    return html`
    <div>${this.template}</div>`;
  }

  private onTaskChange = async (e: Event) => {
    if (!this.task) return;
    const customEvent = e as CustomEvent;
    const context = customEvent.detail.context;
    const message: mls.msg.Message = context.message;
    const _task: mls.msg.TaskData = context.task;
    if (this.task.PK !== _task.PK) return;
    this.task = _task;
    this.createFeedBack();
  };

  private async createFeedBack() {
    if (!this.task) return;
    const firstAgent = getRootAgent(this.task);
    if (!firstAgent) return;
    const agentName = firstAgent.agentName;
    const agent: IAgent | IAgentAsync | undefined = await loadAgent(agentName);
    if (!agent || !agent.getFeedBack) {
      this.template = html`<ai-agent-default-feedback-102025 .task=${this.task} .message=${this.message} .father=${this}></ai-agent-default-feedback-102025>`

      return;
    }
    const html2 = await agent.getFeedBack(this.task);
    this.template = html2;
  }
}
