/// <mls fileReference="_102025_/l2/collabTasksSettings.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    title: 'Configurações',
    subtitle: 'Tasks',
    tags: 'Vocabulário de tags',
    tagsDesc: 'Tags configuradas para esta organização.',
    tagsEmpty: 'Nenhuma tag configurada.',
    future: 'Em breve',
    settingNotif: 'Notificações',
    settingNotifD: 'Quando e como notificar aprovadores e responsáveis.',
    settingExport: 'Exportação e auditoria',
    settingExportD: 'CSV, PDF e trilha completa de instâncias de processo.',
    settingPerms: 'Perfis e permissões',
    settingPermsD: 'Quem pode criar, editar e aprovar workflows.',
    themesHint: 'O tema do board pode ser alterado pelo ícone ⚙ no Board ou em Minhas tasks.',
    reload: 'Recarregar',
    loadError: 'Não consegui carregar.',
    retry: 'Tentar de novo',
};
const message_en = {
    title: 'Settings',
    subtitle: 'Tasks',
    tags: 'Tag vocabulary',
    tagsDesc: 'Tags configured for this organization.',
    tagsEmpty: 'No tags configured.',
    future: 'Coming soon',
    settingNotif: 'Notifications',
    settingNotifD: 'When and how to notify approvers and owners.',
    settingExport: 'Export & audit',
    settingExportD: 'CSV, PDF and full process instance trail.',
    settingPerms: 'Profiles & permissions',
    settingPermsD: 'Who can create, edit and approve workflows.',
    themesHint: 'The board theme can be changed from the ⚙ icon in Board or My tasks.',
    reload: 'Reload',
    loadError: 'Could not load.',
    retry: 'Retry',
};
/// **collab_i18n_end**
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { msgGetOrgPreferences } from '/_102025_/l2/shared/api.js';
import { getUserId } from '/_102025_/l2/collabMessagesHelper.js';
import { loadTasksTheme, applyThemeToHost, } from '/_102025_/l2/collabTasksTheme.js';
import '/_102025_/l2/collabTasksDesignTokens.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
const TAG_COLOR_LABEL = {
    bug: { bg: '#fcebeb', text: '#a32d2d' },
    feature: { bg: '#e6f1fb', text: '#185fa5' },
    business: { bg: '#faeeda', text: '#854f0b' },
    process: { bg: '#e1f5ee', text: '#085041' },
    neutral: { bg: '#f5f4f0', text: '#5f5e5a' },
};
let CollabTasksSettings = class CollabTasksSettings extends StateLitElement {
    constructor() {
        super(...arguments);
        this.userId = '';
        this.organizationId = 'collabcodes';
        this.tagVocabulary = [];
        this.loadingTags = true;
        this.errorTags = null;
    }
    connectedCallback() {
        super.connectedCallback();
        if (!this.userId)
            this.userId = getUserId() || '';
        // Apply the currently saved theme to this host so this screen visually
        // matches the rest of the tasks tab (header tone, etc.). Listen for
        // changes so it follows along if the user switches theme in Board.
        applyThemeToHost(loadTasksTheme(), this);
        this._onThemeChanged = () => applyThemeToHost(loadTasksTheme(), this);
        const w = window?.top ?? window;
        w.addEventListener('tasks-theme-changed', this._onThemeChanged);
        w.addEventListener('tasks-bg-changed', this._onThemeChanged);
        this._loadTags();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        const w = window?.top ?? window;
        w.removeEventListener('tasks-theme-changed', this._onThemeChanged);
        w.removeEventListener('tasks-bg-changed', this._onThemeChanged);
    }
    async _loadTags() {
        this.loadingTags = true;
        this.errorTags = null;
        try {
            const res = await msgGetOrgPreferences({ organizationId: this.organizationId, userId: this.userId });
            if (res.success)
                this.tagVocabulary = res.response?.tagVocabulary ?? [];
            else
                this.errorTags = res.error ?? 'error';
        }
        catch (err) {
            this.errorTags = err?.message ?? 'error';
        }
        this.loadingTags = false;
    }
    render() {
        const m = getMsg();
        const lang = document.documentElement.lang ?? 'en';
        return html `
      <div class="st-header">
        <div class="st-header-left">
          <span class="st-title">${m.title}</span>
          <span class="st-sep">·</span>
          <span class="st-sub">${m.subtitle}</span>
        </div>
        <button class="st-icon-btn" title="${m.reload}" @click=${() => this._loadTags()}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="23 4 23 10 17 10"></polyline>
            <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"></path>
          </svg>
        </button>
      </div>

      <div class="st-body">

        <!-- ── Theme hint (themes themselves now live in Board / My tasks gear) ── -->
        <div class="st-theme-hint" role="note">
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
            <circle cx="7" cy="7" r="5.5" stroke="currentColor" stroke-width="1.1"/>
            <path d="M7 6.2v3.4M7 4.4v.05" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/>
          </svg>
          <span>${m.themesHint}</span>
        </div>

        <!-- ── Tag vocabulary ── -->
        <section class="st-section">
          <div class="st-section-header">
            <div class="st-section-title">${m.tags}</div>
            <div class="st-section-desc">${m.tagsDesc}</div>
          </div>

          ${this.errorTags ? html `
            <div class="st-error">
              <span>${m.loadError}</span>
              <button @click=${() => this._loadTags()}>${m.retry}</button>
            </div>
          ` : this.loadingTags ? html `
            <div class="tag-chips">
              ${[60, 80, 55, 70, 45].map(w => html `
                <div class="skel" style="width:${w}px;height:22px;border-radius:12px"></div>
              `)}
            </div>
          ` : this.tagVocabulary.length === 0 ? html `
            <div class="st-empty">${m.tagsEmpty}</div>
          ` : html `
            <div class="tag-chips">
              ${this.tagVocabulary.map(entry => {
            const colors = TAG_COLOR_LABEL[entry.color] ?? TAG_COLOR_LABEL.neutral;
            const label = entry.label
                ? (lang === 'pt' ? entry.label.pt : entry.label.en) || entry.tag
                : entry.tag;
            return html `
                  <span class="tag-chip" style="background:${colors.bg};color:${colors.text}">
                    ${label}
                  </span>
                `;
        })}
            </div>
          `}
        </section>

        <!-- ── Coming soon ── -->
        <section class="st-section">
          <div class="st-section-header">
            <div class="st-section-title">${m.future}</div>
          </div>
          <div class="st-future-list">
            ${([
            { name: m.settingNotif, desc: m.settingNotifD, icon: '🔔' },
            { name: m.settingPerms, desc: m.settingPermsD, icon: '👥' },
            { name: m.settingExport, desc: m.settingExportD, icon: '📦' },
        ]).map(item => html `
              <div class="st-future-row">
                <div class="st-future-icon">${item.icon}</div>
                <div class="st-future-info">
                  <div class="st-future-name">${item.name}</div>
                  <div class="st-future-desc">${item.desc}</div>
                </div>
                <span class="st-soon-badge">soon</span>
              </div>
            `)}
          </div>
        </section>

      </div>
    `;
    }
};
__decorate([
    property({ type: String })
], CollabTasksSettings.prototype, "userId", void 0);
__decorate([
    property({ type: String })
], CollabTasksSettings.prototype, "organizationId", void 0);
__decorate([
    state()
], CollabTasksSettings.prototype, "tagVocabulary", void 0);
__decorate([
    state()
], CollabTasksSettings.prototype, "loadingTags", void 0);
__decorate([
    state()
], CollabTasksSettings.prototype, "errorTags", void 0);
CollabTasksSettings = __decorate([
    customElement('collab-tasks-settings-102025')
], CollabTasksSettings);
export { CollabTasksSettings };
