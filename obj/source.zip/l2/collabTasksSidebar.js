/// <mls fileReference="_102025_/l2/collabTasksSidebar.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// **collab_i18n_start**
const message_pt = {
    board: 'Board',
    myTasks: 'Minhas tasks',
    workflows: 'Workflows',
    simulator: 'Simulador',
    approvals: 'Aprovações',
    analytics: 'Analytics',
    settings: 'Configurações',
    tracking: 'Acompanhamento',
    manage: 'Gerenciar',
    workspace: 'Workspace',
};
const message_en = {
    board: 'Board',
    myTasks: 'My tasks',
    workflows: 'Workflows',
    simulator: 'Simulator',
    approvals: 'Approvals',
    analytics: 'Analytics',
    settings: 'Settings',
    tracking: 'Tracking',
    manage: 'Manage',
    workspace: 'Workspace',
};
/// **collab_i18n_end**
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { collab_tasks, collab_gear, } from '/_102025_/l2/collabMessagesIcons.js';
function getMsg() {
    return document.documentElement.lang === 'pt' ? message_pt : message_en;
}
let CollabTasksSidebar = class CollabTasksSidebar extends StateLitElement {
    constructor() {
        super(...arguments);
        this.activeScreen = 'board';
    }
    _emit(screen) {
        this.dispatchEvent(new CustomEvent('screen-change', { detail: screen, bubbles: true, composed: true }));
    }
    render() {
        const msg = getMsg();
        const item = (id, label, icon) => html `
      <div class="nav-item ${this.activeScreen === id ? 'active' : ''}" @click=${() => this._emit(id)}>
        ${icon ? html `<span class="nav-icon">${icon}</span>` : html `<span class="nav-icon" style="width:16px"></span>`}
        <span class="nav-label-text">${label}</span>
      </div>
    `;
        return html `
      <div class="sidebar-inner">
        <div class="nav-section">
          <div class="nav-label">${msg.tracking}</div>
          ${item('board', msg.board, collab_tasks)}
          ${item('mytasks', msg.myTasks, collab_tasks)}
        </div>

        <div class="nav-divider"></div>

        <div class="nav-section">
          <div class="nav-label">${msg.manage}</div>
          ${item('workflows', msg.workflows)}
          ${item('simulator', msg.simulator)}
          ${item('approvals', msg.approvals)}
          ${item('analytics', msg.analytics)}
        </div>

        <div class="nav-divider"></div>

        <div class="nav-section">
          <div class="nav-label">${msg.workspace}</div>
          ${item('settings', msg.settings, collab_gear)}
        </div>
      </div>
    `;
    }
};
__decorate([
    property({ type: String })
], CollabTasksSidebar.prototype, "activeScreen", void 0);
CollabTasksSidebar = __decorate([
    customElement('collab-tasks-sidebar-102025')
], CollabTasksSidebar);
export { CollabTasksSidebar };
