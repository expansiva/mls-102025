/// <mls fileReference="_102025_/l2/widgetQuestionsForClarification.test.ts" enhancement="_blank" />

 import { ICANTest, ICANIntegration, ICANSchema  } from '/_102025_/l2/tsTestAST.js';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];