/// <mls fileReference="_102025_/l2/collabMessagesAppsMenu.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    searchPlaceholder: 'Buscar...',
    filterAll: 'Todos',
    filterFavorites: 'Favoritos',
    filterHistory: 'Histórico',
    favoritesTitle: 'Favoritos',
    historyTitle: 'Histórico',
    emptyFavorites: 'Nenhum favorito.',
    emptyHistory: 'Nenhum acesso recente.',
    emptySearch: 'Nada encontrado.'
};
const message_en = {
    searchPlaceholder: 'Search...',
    filterAll: 'All',
    filterFavorites: 'Favorites',
    filterHistory: 'History',
    favoritesTitle: 'Favorites',
    historyTitle: 'History',
    emptyFavorites: 'No favorites.',
    emptyHistory: 'No recent access.',
    emptySearch: 'Nothing found.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const HISTORY_LIMIT = 20;
let CollabMessagesAppsMenu = class CollabMessagesAppsMenu extends StateLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.keyFavoritesLocalStorage = 'menuFavorites';
        this.keyHistoryLocalStorage = 'menuHistory';
        this.identifier = '';
        this.menuTitle = '';
        this.menuModules = [];
        this.favorites = [];
        this.history = [];
        this.searchTerm = '';
        this.activeFilter = 'all';
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        this.loadFavorites();
        this.loadHistory();
        this.loadFilter();
    }
    // Scope key isolates favorites/history per project. Falls back to identifier when
    // the menu has no modules loaded yet.
    getScope() {
        const project = this.menuModules[0]?.project;
        if (project !== undefined && project !== null)
            return String(project);
        return this.identifier?.toString() || 'default';
    }
    readStore(key) {
        try {
            const raw = localStorage.getItem(key);
            const parsed = raw ? JSON.parse(raw) : {};
            return parsed && typeof parsed === 'object' ? parsed : {};
        }
        catch {
            return {};
        }
    }
    loadFavorites() {
        this.favorites = this.readStore(this.keyFavoritesLocalStorage)[this.getScope()] ?? [];
    }
    loadHistory() {
        this.history = this.readStore(this.keyHistoryLocalStorage)[this.getScope()] ?? [];
    }
    loadFilter() {
        try {
            const raw = localStorage.getItem(this.keyFavoritesLocalStorage + 'Filter');
            const parsed = raw ? JSON.parse(raw) : {};
            const value = parsed?.[this.getScope()];
            if (value === 'all' || value === 'favorites' || value === 'history')
                this.activeFilter = value;
        }
        catch {
            // keep default
        }
    }
    setFilter(filter) {
        this.activeFilter = filter;
        try {
            const key = this.keyFavoritesLocalStorage + 'Filter';
            const stored = this.readStore(key);
            stored[this.getScope()] = filter;
            localStorage.setItem(key, JSON.stringify(stored));
        }
        catch {
            // persisting the filter preference is best-effort
        }
    }
    getItemPath(moduleItem, item) {
        const findPath = (menu, target, path) => {
            for (const m of menu) {
                const currentPath = [...path, m.title];
                if (m === target)
                    return currentPath;
                if (m.children) {
                    const found = findPath(m.children, target, currentPath);
                    if (found)
                        return found;
                }
            }
            return null;
        };
        const path = findPath(moduleItem.menu, item, [moduleItem.name]);
        return path ? path.join('/') : moduleItem.name;
    }
    toggleFavorite(moduleItem, item) {
        const key = this.getItemPath(moduleItem, item);
        const scope = this.getScope();
        const stored = this.readStore(this.keyFavoritesLocalStorage);
        if (!Array.isArray(stored[scope]))
            stored[scope] = [];
        const favorites = stored[scope];
        const index = favorites.indexOf(key);
        if (index >= 0)
            favorites.splice(index, 1);
        else
            favorites.push(key);
        stored[scope] = favorites;
        localStorage.setItem(this.keyFavoritesLocalStorage, JSON.stringify(stored));
        this.favorites = [...favorites];
        this.requestUpdate();
    }
    isFavorite(moduleItem, item) {
        const key = this.getItemPath(moduleItem, item);
        return this.favorites.includes(key);
    }
    // Records the opened item at the top of the history (most recent first, deduped, capped).
    recordHistory(moduleItem, item) {
        const key = this.getItemPath(moduleItem, item);
        const scope = this.getScope();
        const stored = this.readStore(this.keyHistoryLocalStorage);
        const current = Array.isArray(stored[scope]) ? stored[scope] : [];
        const next = [key, ...current.filter(k => k !== key)].slice(0, HISTORY_LIMIT);
        stored[scope] = next;
        localStorage.setItem(this.keyHistoryLocalStorage, JSON.stringify(stored));
        this.history = next;
    }
    handleMenuClick(moduleItem, item) {
        this.recordHistory(moduleItem, item);
        this.dispatchEvent(new CustomEvent('menu-selected', { detail: { ...item, project: moduleItem.project, module: moduleItem.name, path: moduleItem.path } }));
    }
    onSearch(e) {
        this.searchTerm = e.target.value ?? '';
    }
    // Case-insensitive title match used by search.
    matchesSearch(title) {
        const term = this.searchTerm.trim().toLowerCase();
        if (!term)
            return true;
        return title.toLowerCase().includes(term);
    }
    // Keeps items that match the search or have matching descendants.
    filterItems(items) {
        if (!this.searchTerm.trim())
            return items;
        const result = [];
        for (const item of items) {
            const children = item.children ? this.filterItems(item.children) : undefined;
            if (this.matchesSearch(item.title) || (children && children.length > 0)) {
                result.push({ ...item, children });
            }
        }
        return result;
    }
    renderMenuItem(moduleItem, item) {
        const hasChildren = item.children && item.children.length > 0;
        return html `
			<li class="menu-item">
				<div class="menu-item-header" @click=${() => this.handleMenuClick(moduleItem, item)}>
					<span class="icon" .innerHTML=${item.icon}></span>
					<span class="title">${item.title}</span>
					<span
						class="favorite ${this.isFavorite(moduleItem, item) ? 'active' : ''}"
						title="Favoritar"
						@click=${(e) => {
            e.stopPropagation();
            this.toggleFavorite(moduleItem, item);
        }}
					>★</span>
				</div>

				${hasChildren
            ? html `
						<ul class="submenu">
							${item.children.map(child => this.renderMenuItem(moduleItem, child))}
						</ul>
					`
            : null}
			</li>
		`;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
			<div class="menu-container">
                ${this.renderToolbar()}
                ${this.renderContent()}
			</div>
		`;
    }
    renderToolbar() {
        const filters = [
            { id: 'all', label: this.msg.filterAll },
            { id: 'favorites', label: this.msg.filterFavorites },
            { id: 'history', label: this.msg.filterHistory }
        ];
        return html `
            <div class="apps-toolbar">
                <input
                    class="apps-search"
                    type="search"
                    .value=${this.searchTerm}
                    placeholder=${this.msg.searchPlaceholder}
                    @input=${(e) => this.onSearch(e)}
                />
                <div class="apps-filters">
                    ${filters.map(f => html `
                        <button
                            class="apps-filter ${this.activeFilter === f.id ? 'active' : ''}"
                            @click=${() => this.setFilter(f.id)}
                        >${f.label}</button>
                    `)}
                </div>
            </div>
        `;
    }
    renderContent() {
        if (this.activeFilter === 'favorites')
            return this.renderKeyList(this.favorites, this.msg.emptyFavorites, this.msg.favoritesTitle);
        if (this.activeFilter === 'history')
            return this.renderKeyList(this.history, this.msg.emptyHistory, this.msg.historyTitle);
        return this.renderModules();
    }
    // Renders a flat list (favorites/history) resolved from stored path keys.
    renderKeyList(keys, emptyLabel, title) {
        const resolved = keys
            .map(key => ({ key, ...this.findItemByPath(key) }))
            .filter(r => r.menuItem && r.moduleItem)
            .filter(r => this.matchesSearch(r.menuItem.title) || this.matchesSearch(r.key.replace(/\//g, ' ')));
        return html `
            <h3>${title}</h3>
            ${resolved.length === 0
            ? html `<p class="empty">${this.searchTerm.trim() ? this.msg.emptySearch : emptyLabel}</p>`
            : html `
                    <ul class="favorites">
                        ${resolved.map(r => {
                const pathDisplay = r.key.replace(/\//g, ' / ');
                return html `
                                <li
                                    class="favorite-item"
                                    title=${pathDisplay}
                                    @click=${() => this.handleMenuClick(r.moduleItem, r.menuItem)}
                                >
                                    <span class="icon" .innerHTML=${r.menuItem.icon}></span>
                                    <span class="title">${pathDisplay}</span>
                                </li>
                            `;
            })}
                    </ul>
                `}
        `;
    }
    renderModules() {
        const searching = !!this.searchTerm.trim();
        const modules = this.menuModules
            .map(module => ({ module, items: this.filterItems(module.menu) }))
            .filter(m => !searching || m.items.length > 0);
        if (modules.length === 0) {
            return html `
                <h3>${this.menuTitle}</h3>
                <p class="empty">${this.msg.emptySearch}</p>
            `;
        }
        return html `
            <h3>${this.menuTitle}</h3>
            ${modules.map(({ module, items }) => html `
                <details class="menu-module" ?open=${searching}>
                    <summary>
                        <span class="icon" .innerHTML=${module.icon}></span>
                        <span class="name">${module.name}</span>
                    </summary>
                    <ul class="menu-list">
                        ${items.map(item => this.renderMenuItem(module, item))}
                    </ul>
                </details>
            `)}
        `;
    }
    findItemByPath(path) {
        const parts = path.split('/');
        const moduleName = parts.shift();
        const module = this.menuModules.find(m => m.name === moduleName);
        if (!module)
            return {
                menuItem: null,
                moduleItem: undefined
            };
        let currentItems = module.menu;
        let found = null;
        for (const part of parts) {
            found = currentItems.find(i => i.title === part) || null;
            if (!found) {
                return {
                    menuItem: null,
                    moduleItem: undefined
                };
            }
            currentItems = found.children || [];
        }
        return {
            menuItem: found,
            moduleItem: module
        };
    }
};
__decorate([
    property()
], CollabMessagesAppsMenu.prototype, "keyFavoritesLocalStorage", void 0);
__decorate([
    property()
], CollabMessagesAppsMenu.prototype, "keyHistoryLocalStorage", void 0);
__decorate([
    property()
], CollabMessagesAppsMenu.prototype, "identifier", void 0);
__decorate([
    property()
], CollabMessagesAppsMenu.prototype, "menuTitle", void 0);
__decorate([
    state()
], CollabMessagesAppsMenu.prototype, "menuModules", void 0);
__decorate([
    state()
], CollabMessagesAppsMenu.prototype, "favorites", void 0);
__decorate([
    state()
], CollabMessagesAppsMenu.prototype, "history", void 0);
__decorate([
    state()
], CollabMessagesAppsMenu.prototype, "searchTerm", void 0);
__decorate([
    state()
], CollabMessagesAppsMenu.prototype, "activeFilter", void 0);
CollabMessagesAppsMenu = __decorate([
    customElement('collab-messages-apps-menu-102025')
], CollabMessagesAppsMenu);
export { CollabMessagesAppsMenu };
