/// <mls fileReference="_102025_/l2/collabMessagesTask.ts" enhancement="_102027_/l2/enhancementLit" />

import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { getTask, getMessage } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { msgGetTaskUpdate } from '/_102025_/l2/shared/api.js';

import {
    collab_money,
    collab_pause,
    collab_bell,
    collab_chevron_right,
    collab_clock,
    collab_check,
    collab_bug,
    collab_play
} from '/_102025_/l2/collabMessagesIcons.js';

import * as msg from '/_102025_/l2/shared/interfaces.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';


/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
}

const message_en = {
    loading: 'Loading...',
}
type MessageType = typeof message_en;
const messages: { [key: string]: MessageType } = {
    'en': message_en,
    'pt': message_pt
}
/// **collab_i18n_end**

@customElement('collab-messages-task-102025')
export class CollabMessagesTask extends StateLitElement {

    private msg: MessageType = messages['en'];

    @property() taskid: string = '';
    @property() threadId: string = '';
    @property() userId: string = '';
    @property() messageid: string = '';
    @property() lastChanged: string = '';
    @property() status: string = '';
    @property({ type: Boolean }) notificationPending: boolean = false;

    @state() task: msg.TaskData | undefined;
    @state() context: msg.ExecutionContext | undefined;
    @state() private secondsPassed: number = 0;
    @state() private lastStep: number | undefined;

    private timerId: number | undefined;

    disconnectedCallback() {
        super.disconnectedCallback();
        if (this.timerId) {
            clearInterval(this.timerId);
            this.timerId = undefined;
        }
    }

    async updated(changedProperties: Map<PropertyKey, unknown>) {
        super.updated(changedProperties);

        if (changedProperties.has('lastChanged')) {
            if (this.context && this.context.task) {
                this.task = this.context.task;
                const nextStep = this.getNextPendentStep(this.task);
                if (!nextStep || nextStep.type === 'clarification') {
                    this.resetTimer();
                    this.lastStep = undefined;
                } else {
                    if (this.lastStep !== nextStep.stepId) {
                        this.resetTimer();
                        this.lastStep = nextStep.stepId
                    }
                }
            }
        }

        if (changedProperties.has('taskid') && changedProperties.get('taskid') !== '') {
            this.getTaskLocal(this.taskid);
        }
    }

    render() {

        const isOverMinute = this.secondsPassed >= 60;
        const timeClass = isOverMinute ? 'card-time over-minute' : 'card-time';

        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.task) {
            return html`<div @click=${this.onCardClick} class="card no-details"> 
            <div class="card-header">
                <span class="card-title">Task</span>
                ${collab_chevron_right}
            </div>
         </div>`
        }

        const price = this.task ? this.getTotalCost(this.task) || '0.00' : '';
        const title = this.task?.title || '';
        const timeDisplay = this.formatTime(this.secondsPassed);

        return html`<div @click=${this.onCardClick} class="card ${this.notificationPending ? 'has-notification' : ''}"> 
        <div class="card-header">
            ${this.renderIconTask()}
            <span class="card-title"> ${title}</span>
            ${this.notificationPending ? html`<span class="task-room-notification">${collab_bell}</span>` : ''}
            <span class="card-price"> ${price ? collab_money : ''}${price}</span>
            ${this.lastStep ? html`<span class="${timeClass}">${timeDisplay}</span>` : ''}
        </div>
     </div>`;
    }

    renderIconTask() {

        const taskObj: any = {
            '': html``,
            'pending': collab_clock,
            'paused': collab_pause,
            'todo': collab_clock,
            'in progress': collab_clock,
            'done': collab_check,
            'failed': collab_bug,
            'waitingforuser': html`
                    <span class="icon-wrapper">
                        ${collab_bell}
                        <span class="notification-badge">1</span>
                    </span>`,
        }
        let status = this.status;
        if (this.task) {
            status = this.task.status;
            const nextStepPending = this.getNextPendentStep(this.task);
            if (nextStepPending?.type === 'clarification') status = 'waitingforuser'
        }

        if (!status) return html`<span class="task-icon in progress ">${collab_clock}</span>`;
        return html`<span class="task-icon ${status.split(' ').join('-')} ">${taskObj[status]}</span>`;

    }

    private resetTimer() {
        this.secondsPassed = 0;
        if (this.timerId) {
            clearInterval(this.timerId);
        }
        this.timerId = window.setInterval(() => {
            this.secondsPassed++;
            this.requestUpdate();
        }, 1000);
    }

    private formatTime(seconds: number) {
        const min = Math.floor(seconds / 60).toString().padStart(2, '0');
        const sec = (seconds % 60).toString().padStart(2, '0');
        return `${min}:${sec}`;
    }

    private async getTaskLocal(taskId: string) {
        const task = await getTask(taskId);
        if (!task) return;

        this.task = task;

        const shouldSync =
            task.status === 'in progress' &&
            task.owner === this.userId &&
            !this.context;

        if (!shouldSync) return;

        const messageId = `${this.threadId}/${this.messageid}`;

        try {
            const result = await msgGetTaskUpdate({
                messageId,
                taskId,
                userId: this.userId
            });

            if (!result.success || !result.response?.task) return;

            const message = await getMessage(messageId);
            if (!message) return;

            this.context = {
                task: result.response.task,
                message,
                isTest: false
            };

            this.lastChanged = Date.now().toString();


        } catch (err: any) {
            console.error('Error fetching task update:', err);
        }
    }

    private onCardClick() {
        const event = new CustomEvent('taskclick', {
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(event);
    }

    private getAllSteps(firstStep: msg.AIPayload[] | undefined): msg.AIPayload[] {
        if (!firstStep || firstStep.length < 1) {
            return [];
        }
        const allSteps: msg.AIPayload[] = [];
        const queue: msg.AIPayload[] = [...firstStep];

        // BFS approach to collect all steps
        while (queue.length > 0) {
            const currentStep = queue.shift()!;
            allSteps.push(currentStep);

            // Add nextSteps to queue if they exist
            if (currentStep.nextSteps) {
                queue.push(...currentStep.nextSteps);
            }

            // Add steps from interaction.payload if they exist
            if (currentStep.interaction?.payload) {
                queue.push(...currentStep.interaction.payload);
            }
        }

        return allSteps;
    };

    private getNextPendentStep(task: msg.TaskData): msg.AIPayload | null {
        const allSteps = this.getAllSteps(task.iaCompressed?.nextSteps);
        return allSteps.find(step => step.status === 'pending') || null;
    };


    private getTotalCost(task: msg.TaskData): string {
        let tot = 0;
        const nextSteps = task.iaCompressed?.nextSteps;
        if (!nextSteps || nextSteps.length === 0) return "$ 0.01"; // garante saída mínima

        const sumCosts = (payload: msg.AIPayload[]) => {
            payload.forEach((pay) => {
                const { interaction, nextSteps } = pay;

                if (interaction) {
                    tot += interaction.cost ? interaction.cost : 0;
                    if (interaction.payload) sumCosts(interaction.payload);
                }

                if (nextSteps) {
                    nextSteps.forEach((next) => sumCosts([next]));
                }
            });
        };

        nextSteps.forEach((step) => sumCosts([step]));

        const rounded = Math.ceil(tot * 100) / 100;
        return `${rounded.toFixed(2)}`;
    }

}
