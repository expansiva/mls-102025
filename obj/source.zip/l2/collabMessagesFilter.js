/// <mls fileReference="_102025_/l2/collabMessagesFilter.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { classMap } from 'lit/directives/class-map.js';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { collab_magnifying_glass } from '/_102025_/l2/collabMessagesIcons.js';
let CollabMessagesFilter = class CollabMessagesFilter extends StateLitElement {
    constructor() {
        super(...arguments);
        this.expanded = false;
        this.query = '';
        this.placeholder = '';
    }
    toggleExpand(e) {
        if (e.target.closest('input'))
            return;
        if (this.expanded) {
            this.expanded = false;
            this.query = '';
        }
        else {
            this.expanded = true;
            setTimeout(() => {
                const input = this.querySelector('input');
                input?.focus();
            }, 100);
        }
    }
    handleKey(e) {
        if (e.key === 'Escape') {
            this.expanded = false;
            this.query = '';
        }
    }
    handleInput(e) {
        const target = e.target;
        this.query = target.value;
        this.dispatchEvent(new CustomEvent('search-change', {
            detail: this.query,
            bubbles: true,
            composed: true
        }));
    }
    render() {
        return html `
			<div @click=${this.toggleExpand} class=${classMap({ container: true, expanded: this.expanded })}>
				<button
					class="icon"
					
					title=${this.expanded ? 'Fechar pesquisa' : 'Buscar'}
				>
					<span>${collab_magnifying_glass}</span>
				</button>

				<input
					type="text"
					placeholder=${this.placeholder}
					.value=${this.query}
					@input=${this.handleInput}
	                @keydown=${this.handleKey}
				/>
			</div>
		`;
    }
};
__decorate([
    property({ reflect: true })
], CollabMessagesFilter.prototype, "expanded", void 0);
__decorate([
    property()
], CollabMessagesFilter.prototype, "query", void 0);
__decorate([
    property()
], CollabMessagesFilter.prototype, "placeholder", void 0);
CollabMessagesFilter = __decorate([
    customElement('collab-messages-filter-102025')
], CollabMessagesFilter);
export { CollabMessagesFilter };
