/// <mls fileReference="_102025_/l2/collabMessagesPrompt.ts" enhancement="_102027_/l2/enhancementLit" />

import { html, nothing } from 'lit';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, property, state, query, } from 'lit/decorators.js';
import { collab_arrow_up_long, collab_link, collab_plus } from '/_102025_/l2/collabMessagesIcons.js';
import { getThread, listUsers } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { emojiList } from '/_102025_/l2/collabMessagesEmojis.js'

import { environment } from '/_102036_/l2/environmentContract.js';
import * as msg from '/_102025_/l2/shared/interfaces.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';

import '/_102025_/l2/collabMessagesAvatar.js';
import { parseInlineRichText } from '/_102025_/l2/collabMessagesRichTextParser.js';
import type { RichToken } from '/_102025_/l2/collabMessagesRichTextParser.js';
import {
    applySmartNewline,
    indentSelection,
    insertText,
    makeCodeBlock,
    makeLinePrefix,
    outdentSelection,
    wrapSelection,
} from '/_102025_/l2/collabMessagesPromptEditing.js';
import type { EditResult } from '/_102025_/l2/collabMessagesPromptEditing.js';


/// **collab_i18n_start**
const message_pt = {
    replyingTo: 'Respondendo a',
    cancelReply: 'Cancelar resposta',
    attachFiles: 'Anexar arquivos',
    removeAttachment: 'Remover anexo',
    sendError: 'Erro ao enviar mensagem',
}

const message_en = {
    replyingTo: 'Responding to',
    cancelReply: 'Cancel reply',
    attachFiles: 'Attach files',
    removeAttachment: 'Remove attachment',
    sendError: 'Error sending message',
}

type MessageType = typeof message_en;
const messages: { [key: string]: MessageType } = {
    'en': message_en,
    'pt': message_pt
}
/// **collab_i18n_end**

function escapeRegExp(value: string): string {
    return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export function serializeUserMentions(text: string, users: msg.User[]): string {
    let finalText = text;
    const sortedUsers = [...users].sort((a, b) => b.name.length - a.name.length);

    sortedUsers.forEach(user => {
        const escapedName = escapeRegExp(user.name);
        const regex = new RegExp(`(^|\\s)@${escapedName}(?=$|\\s|[.,!?])`, 'g');
        finalText = finalText.replace(regex, `$1[@${user.name}](${user.userId})`);
    });

    return finalText;
}

export function deserializeUserMentions(text: string, users: msg.User[] = []): string {
    return text.replace(/\[@([^\]]+)\]\(([^)]+)\)/g, (_match, name, userId) => {
        const user = users.find(item => item.userId === userId);
        return `@${user?.name || name}`;
    });
}


@customElement('collab-messages-prompt-102025')
export class CollabMessagesPrompt extends StateLitElement {

    private msg: MessageType = messages['en'];

    @query('textarea') textArea: HTMLTextAreaElement | undefined;
    @query('.prompt-overlay') overlayElement?: HTMLElement;
    @query('.mention-suggestions') mentionSuggestionsElement?: HTMLElement;
    @query('.wrapper') wrapper?: HTMLElement;
    @property() text: string = '';
    @state() actualMention?: IMentions;
    @state() mentionActive: boolean = false;
    @state() mentionQuery: string = '';
    @state() mentionSuggestions: IMentions[] = [];
    @state() mentionIndex: number = 0;
    @state() allUsers: msg.User[] = [];
    @state() allUsersValids: msg.User[] = [];
    @state() hasSelection: boolean = false;
    @state() selectedFiles: File[] = [];
    @state() sendError: string = '';

    @state() allAgents: IMentionAgent[] = [];
    @state() alreadyLoadingAgents: boolean = false;
    @state() lastScopeLoaded: string | undefined;

    @state() replyingTo?: {
        messageId: string;
        senderId: string;
        preview: string;
    };

    @property({ type: Function }) onSend: Function | undefined;
    @property() threadId?: string;
    @property() placeholder?: string;
    @property() scope?: string;
    @property({
        type: Boolean,
        converter: (value: string | null) => value !== 'false'
    }) allowAttachments: boolean = true;
    @property({
        type: Boolean,
        converter: (value: string | null) => value !== 'false'
    }) showSubmitButton: boolean = true;
    @property({
        type: Boolean,
        converter: (value: string | null) => value !== 'false'
    }) submitOnEnter: boolean = true;

    @property({
        type: Boolean,
        converter: (value: string | null) => value === 'true'
    }) acceptAutoCompleteUser?: boolean = false;

    @property({
        type: Boolean,
        converter: (value: string | null) => value === 'true'
    }) acceptAutoCompleteAgents?: boolean = false;

    @property({
        type: Boolean,
        converter: (value: string | null) => value === 'true'
    }) enableRichPreview?: boolean = false;

    connectedCallback() {
        super.connectedCallback();
        window.visualViewport?.addEventListener("resize", () => {
            this.calculatePosition();
        });
    }


    firstUpdated(changedProperties: Map<PropertyKey, unknown>) {
        super.firstUpdated(changedProperties);
        this.adjustTextAreaHeight();
    }

    async updated(changedProperties: Map<PropertyKey, unknown>) {
        super.updated(changedProperties);
        if (changedProperties.has('threadId')
            && this.threadId !== ''
            && this.threadId !== changedProperties.get('threadId')
            && this.acceptAutoCompleteUser
        ) {
            this.getUsers();
        }
        if (changedProperties.has('text')) {
            await this.updateComplete;
            this.adjustTextAreaHeight();
            this.handleScroll();
        }
    }

    public setReply(message: {
        messageId: string;
        senderId: string;
        preview: string;
    }) {
        this.replyingTo = message;
        setTimeout(() => {
            this.textArea?.focus();
        });
    }

    public clearReply() {
        this.replyingTo = undefined;
    }

    private async getUsers() {
        const users: msg.User[] = await listUsers();
        this.allUsers = users;
        this.allUsersValids = users.filter((user) => !user.kind);
    }

    private async getAgents() {

        const thread = await getThread(this.threadId?.trim() || '');
        const agentsFiles = await environment.getAgents();
        const usersAgent = this.allUsers.filter((user) => user.kind === 'synthetic_agent' && thread?.openClawAgents?.some((item) => item.collabUserId === user.userId));

        const agentsPublic = agentsFiles.map((agent: msg.IAgentMeta) => {
            const { visibility, agentName, avatar_url, agentDescription, scope } = agent;
            if (visibility === 'public') {

                let inScope = this.scope ? false : true;
                if (this.scope === '*' || (scope && scope.includes('*'))) inScope = true;
                else if (this.scope && scope) inScope = scope.includes(this.scope);
                else if (!this.scope && scope) inScope = false;

                if (inScope) {
                    return {
                        name: agentName,
                        description: agentDescription,
                        avatar_url,
                        alias: agentName.replace('agent', '')
                    }
                }
            }
        }).filter((item) => !!item);

        const agentsAsUser = usersAgent.map((usersAgent) => {
            const mentionAgent: IMentionAgent = {
                alias: usersAgent.name,
                description: usersAgent?.metadata?.source || '',
                name: usersAgent.name,
                avatar_url: usersAgent.avatar_url
            }
            return mentionAgent;
        });

        this.allAgents = [...agentsPublic, ...agentsAsUser] as IMentionAgent[];

    }

    private getCaretCoordinates(): { x: number, y: number } | null {
        if (!this.textArea) return null;

        const div = document.createElement("div");
        const style = getComputedStyle(this.textArea);

        for (const prop of style) {
            div.style.setProperty(prop, style.getPropertyValue(prop));
        }

        div.style.position = "absolute";
        div.style.visibility = "hidden";
        div.style.whiteSpace = "pre-wrap";
        div.style.wordWrap = "break-word";
        div.style.overflow = "hidden";

        const text = this.textArea.value.substring(0, this.textArea.selectionStart);
        const span = document.createElement("span");
        span.textContent = "\u200b";
        div.textContent = text;
        div.appendChild(span);

        this.appendChild(div);
        const rect = span.getBoundingClientRect();
        const coords = { x: rect.left, y: rect.bottom };
        this.removeChild(div);

        return coords;
    }

    private calculatePosition() {
        if (!this.mentionSuggestionsElement || !this.wrapper || !this.textArea) return;

        const coords = this.getCaretCoordinates();
        if (!coords) return;

        const wrapperRect = this.wrapper.getBoundingClientRect();
        const suggestionsHeight = this.mentionSuggestionsElement.offsetHeight || 150;

        // Posiciona acima do textarea, alinhado com o cursor X
        const left = Math.max(wrapperRect.left, Math.min(coords.x, wrapperRect.right - 200));
        const top = wrapperRect.top - suggestionsHeight - 4;

        this.mentionSuggestionsElement.style.position = "fixed";
        this.mentionSuggestionsElement.style.left = `${left}px`;
        this.mentionSuggestionsElement.style.top = `${top}px`;
    }

    private adjustTextAreaHeight() {
        const maxHeight = 200;
        const minHeight = 42;
        if (this.textArea) {
            const prevHeight = this.textArea.offsetHeight;

            if (!this.text || this.text.trim() === '') {
                this.textArea.style.height = `${minHeight}px`;
            } else {
                this.textArea.style.height = 'auto';
                const newCalculatedHeight = Math.max(minHeight, Math.min(this.textArea.scrollHeight, maxHeight));
                this.textArea.style.height = `${newCalculatedHeight}px`;
            }

            this.textArea.style.height = 'auto';

            const newCalculatedHeight = Math.max(minHeight, Math.min(this.textArea.scrollHeight, maxHeight));
            this.textArea.style.height = `${newCalculatedHeight}px`;

            const newHeight = this.textArea.offsetHeight;
            if (newHeight !== prevHeight) {
                this.dispatchEvent(new CustomEvent('textarea-resize', {
                    detail: {
                        height: newHeight
                    },
                    bubbles: true,
                    composed: true
                }));
            }

            this.calculatePosition();
        }
    }

    private handleScroll() {
        if (this.overlayElement && this.textArea) {
            this.overlayElement.scrollTop = this.textArea.scrollTop;
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Rich preview rendering (usa parser compartilhado)
    // ─────────────────────────────────────────────────────────────

    private renderRichToken(token: RichToken) {
        const marker = (m?: string) => m ? html`<span class="marker">${m}</span>` : nothing;

        switch (token.type) {
            case 'text':
                return html`${token.value.split('\n').map((part, idx) =>
                    idx === 0 ? html`${part}` : html`<br />${part}`
                )}`;
            case 'bold':
                return html`${marker(token.markerStart)}<strong>${token.value}</strong>${marker(token.markerEnd)}`;
            case 'italic':
                return html`${marker(token.markerStart)}<em>${token.value}</em>${marker(token.markerEnd)}`;
            case 'strike':
                return html`${marker(token.markerStart)}<del>${token.value}</del>${marker(token.markerEnd)}`;
            case 'inline-code':
                return html`${marker(token.markerStart)}<code class="inline-code">${token.value}</code>${marker(token.markerEnd)}`;
            case 'mention':
                return html`<span class="mention-preview">@${token.value}</span>`;
            case 'agent':
                return html`<span class="agent-preview">@@${token.value}</span>`;
            case 'channel':
                return html`<span class="channel-preview">#${token.value}</span>`;
            case 'command':
                return html`<span class="command-preview">/${token.value}</span>`;
            case 'help':
                return html`<span class="help-preview">?${token.value}</span>`;
            case 'link':
                return html`<span class="link-preview">[${token.text}](${token.url})</span>`;
            case 'raw-link':
                return html`<span class="link-preview">${token.url}</span>`;
            case 'code-block':
                return html`${marker(token.markerStart)}<span class="code-block-preview">${token.value}</span>${marker(token.markerEnd)}`;
            case 'blockquote':
                return html`${token.lines.map((line, index) => html`${index > 0 ? html`<br />` : nothing}<span class="blockquote-marker-preview">&gt; </span>${line.map(child => this.renderRichToken(child))}`)}`;
            case 'list':
                return html`${token.items.map((item, index) => html`${index > 0 ? html`<br />` : nothing}<span class="list-marker-preview">${item.marker} </span>${item.children.map(child => this.renderRichToken(child))}`)}`;
            default:
                return html``;
        }
    }

    private renderRichOverlay() {
        const lines = this.text.split(/\r?\n/);

        return html`${lines.map((line, index) => html`${index > 0 ? html`<br />` : nothing}${parseInlineRichText(line, true).map(token => this.renderRichToken(token))}`)}`;
    }


    render() {

        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];

        return html`
            </div>
                ${this.renderReply()}
                ${this.renderToolbar()}

                <div class="wrapper">
                    ${this.allowAttachments ? html`
                        <input
                            class="attachment-input"
                            type="file"
                            multiple
                            @change=${this.handleAttachmentInput}
                        />
                        <button
                            class="attachment-button"
                            title=${this.msg.attachFiles}
                            aria-label=${this.msg.attachFiles}
                            @click=${this.openAttachmentPicker}
                        >
                            ${collab_plus}
                        </button>
                    ` : nothing}
                    <div class="textarea-container ${this.enableRichPreview ? 'rich-preview-enabled' : ''}">
                        ${this.enableRichPreview ? html`
                            <div class="prompt-overlay">${this.renderRichOverlay()}</div>
                        ` : ''}
                        <textarea
                            .value=${this.text}
                            @input=${this.handleInput}
                            @focus=${this.handleFocus}
                            @keydown=${this.handleKeyDown}
                            @keyup=${this.updateSelectionState}
                            @mouseup=${this.updateSelectionState}
                            @select=${this.updateSelectionState}
                            @blur=${this.clearSelectionState}
                            @paste=${this.handlePaste}
                            @scroll=${this.handleScroll}
                            id="prompt_input"
                            placeholder="${ifDefined(this.placeholder)}">
                        </textarea>
                    </div>
                    ${this.showSubmitButton ? html`<button @click=${this.handleSend}>${collab_arrow_up_long}</button>` : nothing}
                    ${this.mentionActive && this.mentionSuggestions.length > 0 ? html`
                        <ul class="mention-suggestions">
                            ${this.mentionSuggestions.map((s, i) => html`
                                <li
                                    class="${i === this.mentionIndex ? 'active' : ''}"
                                    title=${s.description}
                                    @click=${() => this.selectMention(s)}
                                >
                                    ${s.type === 'emoji' ? html`
                                    <span class="emoji-suggestion">${s.text}</span>
                                    <span class="emoji-code">:${s.value}:</span>
                                    ` : s.type === 'agent' ? html`
                                        <collab-messages-avatar-102025 width="20px" height="20px" avatar=${s.avatar_url} alt=${s.text}></collab-messages-avatar-102025>
                                        <span class="agent-suggestion">${s.text}</span>
                                    ` : s.type === 'user' ? html`<collab-messages-avatar-102025 width="20px" height="20px" avatar=${s.avatar_url} alt=${s.text}></collab-messages-avatar-102025>
                                    <span class="user-suggestion">${s.text}</span>
                                    ` : ''}
                                </li>
                                `)}
                        </ul>
                ` : ''}
        </div>
        ${this.sendError ? html`<div class="prompt-error">${this.sendError}</div>` : nothing}
        ${this.renderSelectedAttachments()}`
    }

    private renderToolbar() {
        if (!this.enableRichPreview || !this.hasSelection) return nothing;

        return html`
            <div class="prompt-toolbar" aria-label="Message formatting">
                <button title="Bold" @mousedown=${this.preventToolbarFocus} @click=${() => this.applyInlineFormat('**', '**', 'bold')}><strong>B</strong></button>
                <button title="Italic" @mousedown=${this.preventToolbarFocus} @click=${() => this.applyInlineFormat('_', '_', 'italic')}><em>I</em></button>
                <button title="Inline code" @mousedown=${this.preventToolbarFocus} @click=${() => this.applyInlineFormat('`', '`', 'code')}>&#96;</button>
                <button title="Code block" @mousedown=${this.preventToolbarFocus} @click=${() => this.applyCodeBlock()}>{}</button>
                <button title="Quote" @mousedown=${this.preventToolbarFocus} @click=${() => this.applyLinePrefix('> ')}>&gt;</button>
                <button title="Bulleted list" @mousedown=${this.preventToolbarFocus} @click=${() => this.applyLinePrefix('- ')}>-</button>
                <button title="Numbered list" @mousedown=${this.preventToolbarFocus} @click=${() => this.applyLinePrefix('1. ')}>1.</button>
                <button title="Link" @mousedown=${this.preventToolbarFocus} @click=${() => this.applyLink()}>${collab_link}</button>
            </div>
        `;
    }

    private renderReply() {

        const user = this.allUsersValids?.find(u => u.userId === this.replyingTo?.senderId)
        const name = user?.name || this.replyingTo?.senderId;

        return html`${this.replyingTo ? html`
                <div class="reply-preview">
                    <div class="reply-bar"></div>

                    <div class="reply-content">
                        <div class="reply-user">
                            ${this.msg.replyingTo} @${name}
                        </div>
                        <div class="reply-text">
                            ${this.replyingTo.preview}
                        </div>
                    </div>

                    <button
                        class="reply-cancel"
                        @click=${this.clearReply}
                        title="${this.msg.cancelReply}"
                    >
                        ✕
                    </button>
                </div>
            ` : nothing
            }`
    }

    private renderSelectedAttachments() {
        if (!this.allowAttachments) return nothing;
        if (this.selectedFiles.length === 0) return nothing;
        return html`
            <div class="attachment-preview-list">
                ${this.selectedFiles.map((file, index) => html`
                    <div class="attachment-preview-item">
                        <span>${file.name}</span>
                        <small>${this.formatFileSize(file.size)}</small>
                        <button
                            title=${this.msg.removeAttachment}
                            aria-label=${this.msg.removeAttachment}
                            @click=${() => this.removeSelectedAttachment(index)}
                        >×</button>
                    </div>
                `)}
            </div>
        `;
    }
    async handleFocus() {
        if (this.acceptAutoCompleteAgents &&
            (!this.alreadyLoadingAgents || this.scope !== this.lastScopeLoaded)
        ) {
            this.lastScopeLoaded = this.scope;
            this.alreadyLoadingAgents = true;
            this.getAgents();
        }
    }

    async handleInput(e: MouseEvent) {
        if (!e.target) return;
        const target = e.target as HTMLTextAreaElement;
        this.text = target.value;
        this.emitTextChange();
        this.sendError = '';
        this.updateSelectionState();
        this.adjustTextAreaHeight();
        this.handleScroll();

        const cursorPos = target.selectionStart;
        const beforeCursor = this.text.slice(0, cursorPos);

        let suggestions: IMentions[] = [];
        let query = '';

        const matchUser = beforeCursor.match(/(?:^|\s)@([a-zA-Z]*)$/);
        if (matchUser && this.acceptAutoCompleteUser) {
            query = matchUser[1];
            suggestions = this.getUserSuggestions(query);
        }

        const matchAgent = beforeCursor.match(/(?:^|\s)@@([a-zA-Z]*)$/);
        if (matchAgent && this.acceptAutoCompleteAgents) {
            query = matchAgent[1];
            suggestions = this.getAgentSuggestions(query);
        }

        const matchEmoji = beforeCursor.match(/::(\w+)$/);
        if (matchEmoji) {
            query = matchEmoji[1];
            suggestions = this.getEmojiSuggestions(query).slice(0, 10);
        }

        if (suggestions.length > 0) {
            this.mentionActive = true;
            this.mentionQuery = query;
            this.mentionSuggestions = suggestions;
            await this.updateComplete;
            this.calculatePosition();
        } else {
            this.mentionActive = false;
            this.mentionSuggestions = [];
            this.mentionQuery = '';
        }
    }

    private preventToolbarFocus(e: MouseEvent) {
        e.preventDefault();
    }

    private updateSelectionState() {
        this.hasSelection = Boolean(this.textArea && this.textArea.selectionStart !== this.textArea.selectionEnd);
    }

    private clearSelectionState() {
        this.hasSelection = false;
    }

    private async applyEditResult(result: EditResult) {
        this.text = result.text;
        this.emitTextChange();
        await this.updateComplete;

        if (!this.textArea) return;
        this.textArea.selectionStart = result.selectionStart;
        this.textArea.selectionEnd = result.selectionEnd;
        this.textArea.focus();
        this.updateSelectionState();
        this.adjustTextAreaHeight();
        this.handleScroll();
    }

    private applyInlineFormat(before: string, after: string, placeholder: string) {
        if (!this.textArea) return;
        const result = wrapSelection(
            this.text,
            this.textArea.selectionStart,
            this.textArea.selectionEnd,
            before,
            after,
            placeholder
        );
        this.applyEditResult(result);
    }

    private applyCodeBlock() {
        if (!this.textArea) return;
        const result = makeCodeBlock(this.text, this.textArea.selectionStart, this.textArea.selectionEnd);
        this.applyEditResult(result);
    }

    private applyLinePrefix(prefix: string) {
        if (!this.textArea) return;
        const result = makeLinePrefix(this.text, this.textArea.selectionStart, this.textArea.selectionEnd, prefix);
        this.applyEditResult(result);
    }

    private applyLink() {
        if (!this.textArea) return;

        const selectionStart = this.textArea.selectionStart;
        const selectionEnd = this.textArea.selectionEnd;
        const selected = this.text.slice(selectionStart, selectionEnd);
        const label = selected || 'link';
        const inserted = `[${label}](https://)`;
        const cursorOffset = selected ? inserted.length : 1 + label.length;
        const result = insertText(this.text, selectionStart, selectionEnd, inserted, cursorOffset);
        this.applyEditResult(result);
    }

    private openAttachmentPicker() {
        if (!this.allowAttachments) return;
        const input = this.querySelector('.attachment-input') as HTMLInputElement | null;
        input?.click();
    }

    private handleAttachmentInput(e: Event) {
        if (!this.allowAttachments) return;
        const input = e.target as HTMLInputElement;
        const files = Array.from(input.files || []);
        this.selectedFiles = [...this.selectedFiles, ...files].slice(0, 6);
        this.sendError = '';
        input.value = '';
    }

    private removeSelectedAttachment(index: number) {
        this.selectedFiles = this.selectedFiles.filter((_, itemIndex) => itemIndex !== index);
    }

    private emitTextChange() {
        this.dispatchEvent(new CustomEvent('text-change', {
            detail: { text: this.text },
            bubbles: true,
            composed: true
        }));
    }

    private formatFileSize(size: number): string {
        if (size < 1024) return `${size} B`;
        if (size < 1024 * 1024) return `${Math.round(size / 1024)} KB`;
        return `${(size / (1024 * 1024)).toFixed(1)} MB`;
    }

    private getUserSuggestions(query: string): IMentions[] {
        return this.allUsersValids
            .filter(user => user.name.toLowerCase().startsWith(query.toLowerCase()))
            .map(user => ({
                avatar_url: user.avatar_url,
                text: user.name,
                value: user.name,
                description: user.name,
                type: 'user'
            }));
    }

    private getAgentSuggestions(query: string): IMentions[] {
        return this.allAgents
            .filter(agent =>
                agent.name.toLowerCase().startsWith(query.toLowerCase()) ||
                agent.alias.toLowerCase().startsWith(query.toLowerCase())
            )
            .map(agent => ({
                text: agent.alias,
                value: agent.name,
                description: agent.description,
                avatar_url: agent.avatar_url,
                type: 'agent'
            }));
    }

    private getEmojiSuggestions(query: string): IMentions[] {
        // Remove :: caso o usuário tenha digitado junto e converte para lowercase
        const q = query.replace(/^::/, '').toLowerCase().trim();
        if (!q) return []; // se estiver vazio, retorna nada

        return emojiList
            .filter(e =>
                e.value.toLowerCase().startsWith(q) ||  // busca pelo value
                (Array.isArray(e.alias) && e.alias.some(a => a.toLowerCase().includes(q))) // busca pelos aliases
            )
            .map(e => ({
                text: e.text,
                value: e.value,
                description: e.description,
                type: 'emoji'
            }));
    }



    private async handleKeyDown(e: KeyboardEvent) {
        if (this.mentionActive) {
            const mention = this.mentionSuggestions[this.mentionIndex];
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                this.mentionIndex = (this.mentionIndex + 1) % this.mentionSuggestions.length;
                this.scrollToActiveMention();
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                this.mentionIndex =
                    (this.mentionIndex - 1 + this.mentionSuggestions.length) % this.mentionSuggestions.length;
                this.scrollToActiveMention();
            } else if (e.key === 'Tab') {
                e.preventDefault();
                this.selectMention(mention);
            } else if (e.key === 'Enter') {
                if (this.mentionSuggestions.length > 0) {
                    e.preventDefault();
                    this.selectMention(mention);
                }
            } else if (e.key === 'Escape') {
                e.preventDefault();
                this.mentionActive = false;
                this.mentionSuggestions = [];
                this.mentionQuery = '';
            }
            return;
        }

        if (e.key === 'Tab') {
            e.preventDefault();
            if (!this.textArea) return;

            const result = e.shiftKey
                ? outdentSelection(this.text, this.textArea.selectionStart, this.textArea.selectionEnd)
                : indentSelection(this.text, this.textArea.selectionStart, this.textArea.selectionEnd);

            await this.applyEditResult(result);
            return;
        }

        if (e.key === 'Enter' && e.shiftKey) {
            e.preventDefault();
            if (!this.textArea) return;
            await this.applyEditResult(applySmartNewline(this.text, this.textArea.selectionStart, this.textArea.selectionEnd));
            return;
        }

        if (this.submitOnEnter && e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            await this.handleSend();
        }
    }

    private async handlePaste(e: ClipboardEvent) {
        const value = e.clipboardData?.getData('text/plain');
        if (!value || !this.textArea || !value.includes('\n')) return;

        e.preventDefault();
        const normalized = value.replace(/\r\n?/g, '\n');
        await this.applyEditResult(insertText(
            this.text,
            this.textArea.selectionStart,
            this.textArea.selectionEnd,
            normalized
        ));
    }

    private async scrollToActiveMention() {
        if (!this.mentionSuggestionsElement) return;
        await this.updateComplete;

        const activeItem = this.mentionSuggestionsElement.querySelector('li.active') as HTMLElement;
        if (!activeItem) return;

        const containerTop = this.mentionSuggestionsElement.scrollTop;
        const containerBottom = containerTop + this.mentionSuggestionsElement.clientHeight;

        const itemTop = activeItem.offsetTop;
        const itemBottom = itemTop + activeItem.offsetHeight;

        if (itemBottom > containerBottom) {
            this.mentionSuggestionsElement.scrollTop += itemBottom - containerBottom;
        } else if (itemTop < containerTop) {
            this.mentionSuggestionsElement.scrollTop -= containerTop - itemTop;
        }
    }

    private selectMention(suggestion: IMentions) {
        if (!this.textArea || !suggestion) return;

        const cursorPos = this.textArea.selectionStart;
        const beforeCursor = this.text.slice(0, cursorPos);
        const afterCursor = this.text.slice(cursorPos);

        let newText = '';

        switch (suggestion.type) {
            case 'emoji':
                newText = beforeCursor.replace(/::\w*$/, `${suggestion.text} `) + afterCursor;
                break;
            case 'agent':
                newText = beforeCursor.replace(/@{2}[a-zA-Z]*$/, `@@${suggestion.text} `) + afterCursor;
                break;
            case 'user':
                newText = beforeCursor.replace(/@{1}[a-zA-Z]*$/, `@${suggestion.text} `) + afterCursor;
                break;
        }

        this.text = newText;
        this.emitTextChange();
        this.mentionActive = false;
        this.mentionSuggestions = [];
        this.mentionQuery = '';
        this.mentionIndex = 0;
        this.actualMention = suggestion;

        setTimeout(() => {
            if (!this.textArea) return;
            const newCursorPos = newText.length - afterCursor.length;
            this.textArea.selectionStart = this.textArea.selectionEnd = newCursorPos;
            this.textArea.focus();
        });
    }


    private extractAgentName(text: string): string | undefined {
        const match = text.match(/^@@(\w+)/);
        if (!match) return undefined;
        let value = match[1];
        if (!value.startsWith('agent')) {
            const capitalized = value.charAt(0).toUpperCase() + value.slice(1);
            value = 'agent' + capitalized;
        }
        return value;
    }

    async handleSend() {
        if (!this.text && this.selectedFiles.length === 0) return;
        let finalText = this.text.trim();
        let isSpecialMention = false;
        let agentName: string | undefined;
        finalText = serializeUserMentions(finalText, this.allUsersValids);

        if (finalText.startsWith('@@')) {

            const _agentNameTemp = this.extractAgentName(finalText.trim());
            const inList = this.allAgents.find((agent) => (agent.name === _agentNameTemp || agent.alias === _agentNameTemp));
            if (inList) {
                isSpecialMention = true;
                agentName = _agentNameTemp
            }
        }

        if (this.onSend && typeof this.onSend === 'function') {
            try {
                await Promise.resolve(this.onSend(finalText, {
                    isSpecialMention,
                    agentName,
                    replyTo: this.replyingTo?.messageId,
                    attachments: this.selectedFiles,
                }));
            } catch (err: any) {
                this.sendError = err?.message || this.msg.sendError;
                return;
            }
        }

        this.replyingTo = undefined;
        this.text = '';
        this.emitTextChange();
        this.selectedFiles = [];
        await this.updateComplete;
        this.adjustTextAreaHeight();
    }
}

interface IMentionAgent {
    name: string,
    description: string,
    alias: string,
    avatar_url?: string,
}
interface IMentions {
    text: string,
    value: string,
    description: string,
    avatar_url?: string | undefined,
    type: 'user' | 'agent' | 'emoji'
}
