/// <mls fileReference="_102025_/l2/collabMessagesTextCode.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let CollabMessagesTextCode = class CollabMessagesTextCode extends StateLitElement {
    constructor() {
        super(...arguments);
        this.language = 'typescript';
        this.languages = [];
        this.text = '';
        this.whenRendered = new Promise((resolve) => {
            this._resolveRendered = resolve;
        });
    }
    markRendered() {
        this._resolveRendered?.();
    }
    updated(changedProperties) {
        if (changedProperties.has('language')) {
            if (!window.hljsLoaded) {
                const script = document.createElement('script');
                script.src = 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js';
                script.onload = () => {
                    window.hljsLoaded = true;
                    this.setCode();
                };
                document.head.appendChild(script);
            }
            else {
                this.setCode();
            }
        }
        if (changedProperties.has('text')) {
            if (!this.codeBlock)
                return;
            this.waitForLoadIfNeeded(() => {
                this.setCode();
            });
        }
        if (changedProperties.has('languages')) {
            if (this.select)
                this.select.value = this.language;
        }
    }
    waitForLoadIfNeeded(callback, timeout = 10000, interval = 100) {
        let elapsedTime = 0;
        const checkVariable = () => {
            if (window.hljsLoaded) {
                callback();
            }
            else if (elapsedTime < timeout) {
                elapsedTime += interval;
                setTimeout(checkVariable, interval);
            }
            else {
                console.error(`Error on load highlight.js. please try again`);
            }
        };
        checkVariable();
    }
    unescapeHtml(str) {
        const map = {
            '&lt;': '<',
            '&gt;': '>',
            '&quot;': '"',
            '&#039;': "'",
            '&amp;': '&',
        };
        let result = str;
        let changed = true;
        while (changed) {
            changed = false;
            result = result.replace(/&(lt|gt|quot|#039|amp);/g, (match) => {
                changed = true;
                return map[match] ?? match;
            });
        }
        return result;
    }
    getHighlightLanguage(language) {
        const value = language.trim();
        const normalized = value === 'plain' ? 'plaintext' : value;
        const hljs = window.hljs;
        return hljs.getLanguage(normalized) ? normalized : undefined;
    }
    markRenderedAfterPaint() {
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                this.markRendered();
            });
        });
    }
    setCode() {
        if (!this.codeBlock)
            return;
        this.codeBlock.innerHTML = '';
        this.codeBlock.removeAttribute('data-highlighted');
        this.codeBlock.classList.add('hljs');
        this.codeBlock.classList.add('language-' + this.language);
        const that = this;
        this.waitForLoadIfNeeded(() => {
            if (!that.codeBlock)
                return;
            window.hljs.configure({ ignoreUnescapedHTML: true });
            if (!that.languages || that.languages.length === 0)
                that.languages = window.hljs.listLanguages();
            const highlightLanguage = that.getHighlightLanguage(that.language);
            if (!highlightLanguage) {
                that.codeBlock.textContent = that.unescapeHtml(that.text);
                that.markRenderedAfterPaint();
                return;
            }
            const res = window.hljs.highlight(this.unescapeHtml(this.text), { language: highlightLanguage });
            that.codeBlock.removeAttribute("data-highlighted");
            that.codeBlock.innerHTML = res.value;
            that.markRenderedAfterPaint();
        });
    }
    render() {
        return html `
       <pre>
            <code class="code" spellcheck="false"></code>
       </pre>
    `;
    }
};
__decorate([
    property({ type: String })
], CollabMessagesTextCode.prototype, "config", void 0);
__decorate([
    property({ type: String, reflect: true, attribute: true })
], CollabMessagesTextCode.prototype, "language", void 0);
__decorate([
    property({ type: Array })
], CollabMessagesTextCode.prototype, "languages", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabMessagesTextCode.prototype, "text", void 0);
__decorate([
    query('.code')
], CollabMessagesTextCode.prototype, "codeBlock", void 0);
__decorate([
    query('select')
], CollabMessagesTextCode.prototype, "select", void 0);
CollabMessagesTextCode = __decorate([
    customElement('collab-messages-text-code-102025')
], CollabMessagesTextCode);
export { CollabMessagesTextCode };
