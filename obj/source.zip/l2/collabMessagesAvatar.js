/// <mls fileReference="_102025_/l2/collabMessagesAvatar.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { collab_user } from '/_102025_/l2/collabMessagesIcons.js';
import { generateAgentAvatar } from '/_102025_/l2/collabMessagesHelper.js';
let CollabMessagesAvatar = class CollabMessagesAvatar extends StateLitElement {
    constructor() {
        super(...arguments);
        this.avatar = '';
        this.alt = '';
        this.width = '30px';
        this.height = '30px';
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('width') || changedProperties.has('height')) {
            this.style.setProperty('--avatar-width', this.width);
            this.style.setProperty('--avatar-height', this.height);
        }
    }
    render() {
        const isSvg = this.avatar.trim().startsWith('<svg');
        const avatar = this.avatar ? this.avatar : generateAgentAvatar(this.alt || '.');
        return html `
        <div class="avatar">
            ${avatar
            ? isSvg ? html `${unsafeHTML(avatar)}` : html `<img src="${avatar}" alt="${this.alt || 'Avatar'}" />`
            : html `<div class="avatar-placeholder">${collab_user}</div>`}
        </div>`;
    }
};
__decorate([
    property()
], CollabMessagesAvatar.prototype, "avatar", void 0);
__decorate([
    property()
], CollabMessagesAvatar.prototype, "alt", void 0);
__decorate([
    property({ type: String })
], CollabMessagesAvatar.prototype, "width", void 0);
__decorate([
    property({ type: String })
], CollabMessagesAvatar.prototype, "height", void 0);
CollabMessagesAvatar = __decorate([
    customElement('collab-messages-avatar-102025')
], CollabMessagesAvatar);
export { CollabMessagesAvatar };
