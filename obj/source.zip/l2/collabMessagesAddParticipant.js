/// <mls fileReference="_102025_/l2/collabMessagesAddParticipant.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { updateThread, updateUsers } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { notifyThreadChange } from '/_102025_/l2/collabMessagesEvents.js';
import { msgAddParticipantToThread, msgGetThreadUpdates, msgGetUsers } from '/_102025_/l2/shared/api.js';
import { collab_floppy_disk } from '/_102025_/l2/collabMessagesIcons.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    btnSave: 'Adicionar participante',
    labelUserId: 'Nome do usuario ou Id',
    labelPermission: 'Autoridade:',
    errorFieldsAddParticipant: 'Preencha todos os campos!',
    successAddParticipant: 'Usuário adicionado com sucesso',
    threadDetails: 'Detalhes da sala'
};
const message_en = {
    loading: 'Loading...',
    btnSave: 'Add participant',
    labelUserId: 'User id or name',
    labelPermission: 'Auth:',
    errorFieldsAddParticipant: 'Fill in all fields!',
    successAddParticipant: 'User added sucessfully',
    threadDetails: 'Thread details'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesAddParticipant = class CollabMessagesAddParticipant extends StateLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.labelOkAddParticipant = '';
        this.labelErrorAddParticipant = '';
        this.userIdOrName = '';
        this.auth = 'write';
        this.isAddParticipant = false;
        this.highlightedIndex = -1;
        this.suggestions = [];
        this.allUsers = [];
        this.users = [];
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        await this.loadUsersAvaliables();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <div class="add-participant">
            <label style="position: relative;">
                ${this.msg.labelUserId}
                <input 
                    name="add participant"
                    autocomplete="off"
                    type="text"
                    .value=${this.userIdOrName}
                     @input=${this.onInput}
                     @blur=${this.onBlur}
                     @focus=${this.onFocus}
                     @keydown=${this.onKeyDown}
                />
                ${this.suggestions.length > 0
            ? html `
                        <div class="suggestions">
                        ${this.suggestions.map((item, index) => html `
                            <div
                                class="suggestion ${index === this.highlightedIndex ? 'highlighted' : ''}"
                                @click=${() => this.selectSuggestion(item)}
                            >
                                ${item}
                            </div>
                            `)}
                        </div>
                    `
            : null}
            </label>

            

            <label>
                ${this.msg.labelPermission}
                <select
                    .value=${this.auth}
                    @change=${(e) => this.auth = e.target.value}
                >
                    <option value="admin">Admin</option>
                    <option value="moderator">Moderator</option>
                    <option value="none">None</option>
                    <option value="read">Read</option>
                    <option value="write">Write</option>
                </select>
            </label>

            <div class="form-actions">
               <button class="btn-save"
                    @click=${this.onSubmitAddParticipant}
                    ?disabled=${this.isAddParticipant}
                >
                     ${this.isAddParticipant ? html `<span class="loader"></span>` : html `${collab_floppy_disk} ${this.msg.btnSave}`}
                 </button>
            
            </div>

         
            
            ${this.labelOkAddParticipant ? html `<small class="add-participant-ok">${this.labelOkAddParticipant}<small>` : ''}
            ${this.labelErrorAddParticipant ? html `<small class="add-participant-error">${this.labelErrorAddParticipant}<small>` : ''}
        </div>
    `;
    }
    onInput(e) {
        const value = e.target.value;
        this.userIdOrName = value;
        if (!value.trim()) {
            this.suggestions = [];
            return;
        }
        this.suggestions = this.allUsers.filter((name) => name.toLowerCase().includes(value.toLowerCase()));
    }
    onBlur() {
        setTimeout(() => {
            this.suggestions = [];
        }, 200);
    }
    selectSuggestion(suggestion) {
        this.userIdOrName = suggestion;
        this.suggestions = [];
    }
    onKeyDown(e) {
        if (this.suggestions.length === 0)
            return;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            this.highlightedIndex = (this.highlightedIndex + 1) % this.suggestions.length;
        }
        if (e.key === 'ArrowUp') {
            e.preventDefault();
            this.highlightedIndex =
                (this.highlightedIndex - 1 + this.suggestions.length) % this.suggestions.length;
        }
        if (e.key === 'Tab' || e.key === 'Enter') {
            if (this.highlightedIndex >= 0 && this.highlightedIndex < this.suggestions.length) {
                e.preventDefault(); // previne foco mudar com Tab
                this.selectSuggestion(this.suggestions[this.highlightedIndex]);
            }
        }
    }
    onFocus() {
        if (this.userIdOrName) {
            this.suggestions = this.allUsers.filter((name) => name.toLowerCase().includes(this.userIdOrName.toLowerCase()));
        }
    }
    async onSubmitAddParticipant() {
        this.labelErrorAddParticipant = '';
        this.labelOkAddParticipant = '';
        if (!this.actualThread || !this.userId)
            return;
        if (!this.userIdOrName || !this.auth) {
            this.labelErrorAddParticipant = 'Please fill in all required fields.';
            return;
        }
        this.isAddParticipant = true;
        try {
            const result = await msgAddParticipantToThread({
                auth: this.auth,
                userIdOrName: this.userIdOrName.trim(),
                threadId: this.actualThread.thread.threadId,
                userId: this.userId,
            });
            if (!result.success || !result.response) {
                this.labelErrorAddParticipant =
                    result.error || 'Failed to add participant to the thread.';
                return;
            }
            const thread = result.response.thread;
            // Update local cache
            const updatedThread = await updateThread(thread.threadId, thread);
            // Sync updates
            const threadUpdate = await msgGetThreadUpdates({
                threadId: thread.threadId,
                userId: this.userId,
                lastOrderAt: updatedThread.lastSync || new Date('2000-01-01').toISOString(),
            });
            if (threadUpdate.success && threadUpdate.response?.users) {
                await updateUsers(threadUpdate.response.users);
            }
            if (threadUpdate.success && threadUpdate.response?.thread) {
                notifyThreadChange(threadUpdate.response.thread);
            }
            // Emit event
            this.dispatchEvent(new CustomEvent('add-participant', {
                detail: { thread: updatedThread },
                bubbles: true,
                composed: true
            }));
            // Success feedback
            this.labelOkAddParticipant =
                this.msg.successAddParticipant || 'Participant added successfully.';
            setTimeout(() => {
                this.labelOkAddParticipant = '';
            }, 3000);
            // Reset form
            this.userIdOrName = '';
            this.auth = 'write';
        }
        catch (error) {
            console.error('Error adding participant to thread:', error);
            this.labelErrorAddParticipant =
                error?.message || 'An unexpected error occurred while adding the participant.';
        }
        finally {
            this.isAddParticipant = false;
        }
    }
    async loadUsersAvaliables() {
        if (!this.userId)
            return;
        const result = await msgGetUsers({
            status: "active",
            prefixName: "",
            userId: this.userId
        });
        if (!result.success || !result.response?.users)
            return;
        this.users = result.response.users;
        this.allUsers = this.users.map((usr) => usr.name);
    }
};
__decorate([
    property()
], CollabMessagesAddParticipant.prototype, "userId", void 0);
__decorate([
    property()
], CollabMessagesAddParticipant.prototype, "labelOkAddParticipant", void 0);
__decorate([
    property()
], CollabMessagesAddParticipant.prototype, "labelErrorAddParticipant", void 0);
__decorate([
    property()
], CollabMessagesAddParticipant.prototype, "userIdOrName", void 0);
__decorate([
    property()
], CollabMessagesAddParticipant.prototype, "auth", void 0);
__decorate([
    property()
], CollabMessagesAddParticipant.prototype, "isAddParticipant", void 0);
__decorate([
    property()
], CollabMessagesAddParticipant.prototype, "actualThread", void 0);
__decorate([
    property()
], CollabMessagesAddParticipant.prototype, "highlightedIndex", void 0);
__decorate([
    state()
], CollabMessagesAddParticipant.prototype, "suggestions", void 0);
__decorate([
    state()
], CollabMessagesAddParticipant.prototype, "allUsers", void 0);
__decorate([
    state()
], CollabMessagesAddParticipant.prototype, "users", void 0);
CollabMessagesAddParticipant = __decorate([
    customElement('collab-messages-add-participant-102025')
], CollabMessagesAddParticipant);
export { CollabMessagesAddParticipant };
